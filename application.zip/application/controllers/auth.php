<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Auth extends CI_Controller {

    public function __construct(){            
        //session_start();
        parent::__construct();
        $this->load->helper('form');
        $this->load->helper('url');
        $this->load->model('common_model', 'Common_model', true);
        $this->load->model('auth_model', 'Auth_model', true);
        $this->load->library('form_validation');
        if(!is_loggedin())
        {
            redirect('login');
            exit;
        }
    }
    public function user_panel(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['user_list'] = $this->Auth_model->slelect_user();
        $this->load->view('auth/user_panel', $data);
    }
	
	public function save_user_auth(){
        if(isPostBack()){
			
			$login_id = $_POST['login_id'];
			$data['user_access'] = implode(',',$_POST['user_access']);
           if($this->Common_model->common_update($data,$login_id,'login_id','tbl_login'))
			{
				$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
			}
			else
			{
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
			}
            redirect('auth/user_panel', 'refresh');
			exit;
        }
    }
	
}
?>