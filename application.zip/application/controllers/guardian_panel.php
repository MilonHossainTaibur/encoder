<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Guardian_panel extends CI_Controller {

    public function __construct(){
		
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->model('guardian_model', 'Guardian_model', true);
		$this->load->model('result_model', 'Result_model', true);
		$this->load->model('admin_model', 'Admin_model', true);
		$this->load->model('common_model', 'Common_model', true);
		$this->load->library('form_validation');
	}
	function index(){
		$this->load->view('home/guardian_panel/guardian_panle');
	}
	public function student_data()
    {
         #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $student_id = $_SESSION['student_id'];
        $data['school_info'] = $this->Admin_model->get_school_information($school_id);
        $data['student_info'] = $this->Admin_model->get_student_info_by_id($school_id, $student_id);
        $data['group_list'] = $this->Admin_model->get_group_list($school_id);
		$data['shift_list'] = $this->Admin_model->get_shift_list($school_id);
		$data['division_list'] = $this->Common_model->common_result_array('tbl_divisions');
		$data['district_list'] = $this->Common_model->common_result_array('tbl_districts');
		$data['upazila_list'] = $this->Common_model->common_result_array('tbl_upazilas');
		$data['fees_list'] = $this->Common_model->common_result_array('tbl_fees_category');
        
            $mainContent=$this->load->view('home/guardian_panel/student_information_view', $data, true);
			
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
    }

	/************** /result ***************/
     public function student_result(){
		$school_id=1;
		$data['class_list'] = $this->Admin_model->get_class_list($school_id);
		$data['term_list'] =  $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
		$data['session_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
		$data['shift_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_shift');
		
			$mainContent=$this->load->view('home/guardian_panel/student_result', $data, true);
			
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;  
	   //$this->load->view('home/result/schoolresult', $data);
    }
	
	public function mark_sheet_json(){
		#$school_id = $_SESSION['school_id'];
        $school_id = 1;
		
		$student_id = $_SESSION['student_id'];
		
		$session_id = $_GET['session_id'];
		$term_id = $_GET['term_id'];
		$term_name = $_GET['term_name'];
		$session = $_GET['session'];// this session use here as exam year
		
		/* class info */
		$s_data['tsc.school_id']=$school_id;
		$s_data['tsc.student_id']=$student_id;
		$s_data['tsc.session_id']=$session_id;
		$class=$this->Guardian_model->class_info($s_data);
		
		
		$class_id = $class['class_id'];
		$section_id = $class['section_id'];
        $class_short_form = $class['class_short_form'];
        
		
		$where_term = array("class_id"=>$class_id,"section_id"=>$section_id,"term_id"=>$term_id,"session_id"=>$session_id,"school_id"=>$school_id,"status"=>1);
		
		if($this->Common_model->common_select_by_multycondition($where_term,'tbl_result_publish')){
		
		
			/*echo $exam_year; die();*/
			$data['student_mark_info'] = $this->Result_model->get_student_marksheet_info($school_id,$class_id,$student_id,$term_id,$session);
			if($class_short_form >= 9){
				$data['student_info'] = $this->Result_model->mark_sheet_student_info_with_optional($school_id,$session_id,$student_id,$class_id);
				$data['optional']=$data['student_info']['subject_id'];
			}else{
				$data['student_info'] = $this->Result_model->mark_sheet_student_info($school_id,$session_id,$student_id,$class_id);
				$data['optional']='151,134';
			}
		
			$data['max_mark'] = $this->Result_model->get_max_subject_number($school_id,$class_id,$term_id,$session);
			$data['ranks'] = $this->Result_model->get_student_rank($school_id,$class_id,$term_id,$session);
			$data['grd_system'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_grd_system');
			$data['details']=array('term_name'=>$term_name,'session'=>$session,'class_short_form'=>$class_short_form);
			$data['school_info'] = $this->Admin_model->get_school_information($school_id);
		
			$mainContent=$this->load->view('result/mark_sheet_json', $data, true);
        }
		else{
			$mainContent="<h3 style='text-align:center'>Result will publish soon ...</h3>";
		}
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
  
  }
  
}