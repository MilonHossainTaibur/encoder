<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Archive extends CI_Controller {

    public function __construct()
        {            
            //session_start();
            parent::__construct();
            $this->load->helper('form');
            $this->load->helper('url');
            $this->load->model('admin_model', 'Admin_model', true);
            $this->load->model('common_model', 'Common_model', true);
            $this->load->library('form_validation');
            if(!is_loggedin())
            {
                redirect('login');
                exit;
            }
        }

       /**Student Archive**/ 
  
    public function student_archive(){
    #$school_id = $_SESSION['school_id'];
        $school_id = 1;
	$data['shift_list'] = $this->Admin_model->get_shift_list($school_id);
	$data['class_list'] = $this->Admin_model->get_class_list($school_id);
	$data['group_list'] = $this->Admin_model->get_group_list($school_id);
$data['session_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
		$where='';
		if($_POST['class_id']){
			if($_POST['class_id']!="all"){
				$this->session->set_userdata('class_id', $_POST['class_id']);
			}
			elseif($_POST['class_id']=="all"){
				$this->session->unset_userdata('class_id');
				$this->session->unset_userdata('section_id');
				$this->session->unset_userdata('group_id');
			}
		}
		if($_POST['section_id']){
			
			if($_POST['section_id']!="all"){
				$this->session->set_userdata('section_id', $_POST['section_id']);
			}
			elseif($_POST['section_id']=="all"){
				$this->session->unset_userdata('section_id');
			}
		}
		if($_POST['group_id']){
			
			if($_POST['group_id']!="all"){
				$this->session->set_userdata('group_id', $_POST['group_id']);
			}
			elseif($_POST['group_id']=="all"){
				$this->session->unset_userdata('group_id');
			}
		}
		if($_POST['shift_id']){
			
			if($_POST['shift_id']!="all"){
				$this->session->set_userdata('shift_id', $_POST['shift_id']);
			}
			elseif($_POST['shift_id']=="all"){
				$this->session->unset_userdata('shift_id');
			}
		}
		if($_POST['gender_id']){
			
			if($_POST['gender_id']!="all"){
				$this->session->set_userdata('gender_id', $_POST['gender_id']);
			}
			elseif($_POST['gender_id']=="all"){
				$this->session->unset_userdata('gender_id');
			}
		}
		if($_POST['stusession_id']){
			
			if($_POST['stusession_id']!="all"){
				$this->session->set_userdata('stusession_id', $_POST['stusession_id']);
			}
			elseif($_POST['stusession_id']=="all"){
				$this->session->unset_userdata('stusession_id');
			}
		}
		
		if($this->session->userdata('class_id'))
			$where.=' and tbl_student_class.class_id='.$this->session->userdata('class_id').' ';

		if($this->session->userdata('stusession_id'))
			$where.=' and tbl_student_class.session_id='.$this->session->userdata('stusession_id').' ';
		
		if($this->session->userdata('section_id'))
			$where.=' and tbl_student_class.section_id='.$this->session->userdata('section_id').' ';
		
		if($this->session->userdata('group_id'))
			$where.=' and tbl_student_class.group_id='.$this->session->userdata('group_id').' ';

		if($this->session->userdata('shift_id'))
			$where.=' and tbl_student_class.shift_id='.$this->session->userdata('shift_id').' ';

		if($this->session->userdata('gender_id'))
			$where.=' and tbl_student.gender="'.$this->session->userdata('gender_id').'" ';
		
        $data['student_list'] = $this->Admin_model->get_all_student_list($school_id,$where);
        $this->load->view('archive/student_archive', $data);
    }
        

    
    
}
?>