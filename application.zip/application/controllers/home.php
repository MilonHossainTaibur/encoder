<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {

    public function __construct()
	{  
		  
		parent::__construct();
		$this->load->database() ;   
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->model('admin_model', 'Admin_model', true);
		$this->load->model('common_model', 'Common_model', true); 
		$this->load->model('academic_model', 'Academic_model', true);            
		$this->load->model('general_model', 'General_model', true);            
		$this->load->model('result_model', 'Result_model', true);  
		$this->load->model('admission_result_model', 'Admission_result_model', true);  
		$this->load->model('exam_model', 'Exam_model', true);  
		$this->load->model('attendance_model', 'Attendance_model', true);	 
		$this->load->helper('text');         

	}	
    
    public function index()
	{ 
		$school_id = 1;
        $data['about'] 			= $this->General_model->get_about_by_school_id();
		$data['gallery_images'] = $this->General_model->get_photo_gallery();
		$data['catagory_lists'] = $this->General_model->get_all_catagory_list($school_id);
        $data['notice_list'] 	= $this->General_model->get_all_latest_notice($school_id);
        $data['notice_list_last']= $this->General_model->get_all_latest_notice_last();
                 
        $data['slide_image'] 	= $this->General_model->get_all_slide_image();
        $data['student_notice'] = $this->General_model->get_student_notice();
        $data['general_notice'] = $this->General_model->get_general_notice();
        $data['class_list'] 	= $this->General_model->get_all_class();
        $data['v_counter'] 		= $this->visitor_counter();
		//visitor start
        $hit['total_hit']	= $data['v_counter']['total_hit_inc'];
        $hit['session_id'] 	= $session_id;
        $hit['browser'] 	= $this->General_model->getBrowser();
        $hit['ip_address'] 	= $this->General_model->getIP();
        $hit['platform'] 	= $this->General_model->getOS();
        $hit['created_at'] 	= date('Y-m-d');          
        $this->Common_model->common_insert($hit,'tbl_visitors');
		//visitor end
		$data['headmaster'] = $this->General_model->getHeadmasterMessage();
		$data['chairman'] = $this->General_model->getChairmanMessage();
		$data['about'] = $this->General_model->getAboutMessage();
		$data['d_content'] 		= $this->load->view('home/inc/body_top_middle', $data, TRUE);
		$data['news'] = $this->General_model->getLatestNews('tbl_news');
		$data['video'] = $this->General_model->getLatestVideo('tbl_video_gallery');
		$data['title'] = 'Telehaty High School';
		$this->load->view('home/index', $data);
    }
	
	public function visitor_counter()
	{
        $session_id = $this->session->userdata('session_id');
        $data['today_visitor'] = $this->General_model->get_today_visitor();
        $data['yesterday_visitor'] = $this->General_model->get_yesterday_visitor();
        $data['weekly_visitor'] = $this->General_model->get_weekly_visitor();
        $data['month_visitor'] = $this->General_model->get_month_visitor();
        $data['yearly_visitor'] = $this->General_model->get_yearly_visitor();
        $total_hits	= $this->db->select('total_hit')->order_by('id',"desc")->limit(1)->get('tbl_visitors')->row();
        $total_hit	= $total_hits->total_hit+1;
        $data['total_visitor'] 	= $total_hits;
        $data['total_hit_inc'] 	= $total_hit;
		
		return $data;
    }
	
	public function structure_exam_routine_by_term()
    {
    	#$school_id = $_SESSION['school_id'];
     	$school_id = 1;
        $exam_term_id = $_POST['exam_term_id'];
        $column_no = $this->Academic_model->exam_show_get_class_count($school_id,$exam_term_id);
        $row_no = $this->Academic_model->exam_show_get_day_count($school_id,$exam_term_id);
        
       // print_r($column_no); die();
        $table='<table class="table table-striped table-bordered"><thead><tr style="border-top:1px;"><th colspan="2"></th>';
        foreach ($column_no as $col_no)
				{
				$table.='<th id="exam_class_id" class="class_id'.$col_no['column_no'].'"></th>';
				}
                
        $table.='</tr><tr rowspan="2"><th style="min-width:125px; max-width:150px;">Exam Date</th><th style="min-width:125px; max-width:150px;">Exam Day</th>';
				foreach ($column_no as $col_no1)
				{
				 $table.='<th class="exam_time'.$col_no1['column_no'].'"></th>';
				}
				$table.='</tr></thead><tbody>';
				
				for($itdday=0; $itdday< $row_no;)
				{
					
					$table.='<tr class="date countvalue" id="'.$itdday.'"><td class="date'.$itdday.'"></td><td class="wkday'.$itdday.'"></td>';
					foreach ($column_no as $col_no2)
					{
						$table.='<td class="sub'.$col_no2['column_no'].'"></td>';
					}
					$table.='</tr>';
					$itdday++;
				}
				$table.='</tbody></table>';
        
        
		echo $table;
		exit;  
    }
	
	public function get_id_per_exam_term(){
        #$school_id = $_SESSION['school_id'];
     	$school_id = 1;
        $exam_term_id = $_POST['exam_term_id'];
        $sectionInfo = $this->Academic_model->get_id_per_exam_term($school_id,$exam_term_id);
		$str='';
        if($sectionInfo)
        {
           foreach($sectionInfo as $sInfo)
           {
              $str .= $sInfo['id']."|";
           }
		   echo $str;
        }
		exit;
    }

    function group_list_ajax()
    {
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
        $sectionInfo = $this->Academic_model->get_group_list_by_id($class_id, $school_id); 
        $str = '<option value="">----Select Group----</option>';
        if($sectionInfo)
        {
           foreach($sectionInfo as $sInfo)
           {
              $str .= "<option value='".$sInfo['group_id']."'>".$sInfo['group_name']."</option>";
           }
        }
        echo $str;exit;
    }
	
	public function managing_commettee()
	{
		$data['v_counter']	= $this->visitor_counter();
		$data['member_list']= $this->Common_model->common_result_array('tbl_managing_committee');
		$data['title']= 'Managing Commetee';
		$this->load->view('home/commettee/managing_commettee',$data);
	}
	
    public function error(){
        //$data['messages'] = $this->General_model->get_message_by_school_id();
        //$this->load->view('home/managing_commettee',$data);
        $this->load->view('home/404');
    }

	public function headmasterMessage()
	{
		$data['v_counter'] 	= $this->visitor_counter();
		$data['messages']	= $this->General_model->get_message_by_id('Headmaster');
		$data['title']= 'Head Teacher Message';
		$this->load->view('home/headmasterMessage',$data);
	}
	
	public function head_master_list()
	{
		$data['v_counter']	= $this->visitor_counter();
		$data['teachers']= $this->Common_model->common_result_array('tbl_head_teacher');
		$data['title'] = 'Head Teachers List';
		$this->load->view('home/head_master_list',$data);
	}
	
	public function commettee_list()
	{
		$data['v_counter'] 	= $this->visitor_counter();
		$data['messages'] 	= $this->General_model->get_message_by_school_id();	
		$data['Comettee List'] = 'Telehaty High School';	
		$this->load->view('home/commettee_list',$data);
	}
	
	public function freedom_fighter()
    {
		$data['v_counter'] 			= $this->visitor_counter();
        $data['freedom_fighter'] 	= $this->Common_model->common_select_field('tbl_freedom_fighter','order_by','ASC','*');

       
        $this->load->view('home/freedom_fighter', $data);
    }
	
    public function freedom_fighter_list()
    {
        $data['v_counter'] 	= $this->visitor_counter();
		$this->load->view('home/freedom_fighter_list',$data);
    }
	
	public function rules()
	{
		
		 $data['rules'] 	= $this->General_model->getSchoolRules('rules');
			 $data['v_counter'] 	= $this->visitor_counter();
			 $data['title'] = 'Rules & Regulation';
		$this->load->view('home/rules',$data);//tbl_important_information
	}
    public function pending()
	{
		$data['v_counter'] 	= $this->visitor_counter();
        $this->load->view('home/pending',$data);
    }
    public function landinfo()
	{
        $data['v_counter'] 	= $this->visitor_counter();
        $data['title'] = 'Land Info';
		$this->load->view('home/about/landinfo',$data);
    }
    
    public function postinfo(){
		$data['v_counter'] 	= $this->visitor_counter();
        $this->load->view('home/about/postinfo',$data);
    }
    public function buildinnginfo(){
		$data['v_counter'] 	= $this->visitor_counter();
		$data['title'] = 'Building Information';
        $this->load->view('home/about/buildinnginfo',$data);
    }
     public function computer_lab(){
		$data['v_counter'] = $this->visitor_counter();
		$data['title'] = 'Computer Lab';
        $this->load->view('home/about/computer_lab',$data);
    }
     public function other_assets(){
		$data['v_counter'] 	= $this->visitor_counter(); 
		$data['title'] = 'Other Assets';
		$this->load->view('home/about/other_assets',$data);
    }
	public function presidentmessage(){
		$data['v_counter'] 	= $this->visitor_counter();
		$data['messages'] 	= $this->General_model->get_message_by_id('Chairman');
		$data['title'] = 'Chairman Message';
		$this->load->view('home/PresidentMessage',$data);
	}
    public function ThirdgradeEmployee(){
        $school_id = 1;
		$data['v_counter'] 	= $this->visitor_counter();
		$data['teacher_list'] = $this->Common_model->common_result_array('tbl_teacher_registration');
		$data['title'] = 'Third Grade Employee';
        $this->load->view('home/employee/ThirdgradeEmployee',$data);
    }
    public function FourthgradeEmployee(){
		$data['v_counter'] 	= $this->visitor_counter();
		$data['title'] = 'Fourth Grade Employee';
        $this->load->view('home/employee/FourthgradeEmployee',$data);
    }
    public function management(){
		$data['v_counter'] 	= $this->visitor_counter();
		$data['title'] = 'Management';
        $this->load->view('home/management',$data);
    }
    public function meritstudent(){
		$data['v_counter'] 	= $this->visitor_counter();
		$data['title'] = 'Merit Student';
        $this->load->view('home/meritstudent/meritstudent',$data);
    }
    public function donnor_list(){
		$data['v_counter'] 	= $this->visitor_counter();
        $data1['donor_list'] = $this->Common_model->common_result_array('tbl_donor');
        $data1['title'] = "Donor's List";
        $this->load->view('home/commettee/donnor_list', $data1);
    }
    public function admission(){
		$data['v_counter'] 	= $this->visitor_counter();
		$data['title'] = 'Admission';
        $this->load->view('home/admission/admission',$data);
    } 
	public function admission_form(){
		$data['v_counter'] 	= $this->visitor_counter();
        $this->load->view('home/admission/admission_form',$data);
    } 
    public function admission_result(){
		$data['v_counter'] 	= $this->visitor_counter();
		$data['title'] = 'Admission Result';
        $this->load->view('home/result/admission_result',$data);
    }
    public function studentinfo(){
		$data['v_counter'] 	= $this->visitor_counter();
		$data['student_count']=$this->General_model->total_student_count();
		$data['title'] = 'Student Info';
        $this->load->view('home/student/studentinfo',$data);
    }
    public function notice(){
		$data['v_counter'] 	= $this->visitor_counter();
		$data['notice_list'] = $this->General_model->get_all_admission_notice();
		$data['title'] = 'Notice List';
        $this->load->view('home/notice', $data);
    }
	public function single_notice($notice_id){
		$data['v_counter'] 	= $this->visitor_counter();
        $data['notice_info'] = $this->General_model->get_notice_info_by_id($notice_id);
        $data['title'] = 'Single Notice';
        $this->load->view('home/notice/notice-detail',$data);
    }
    public function event(){
		$data['v_counter'] 	= $this->visitor_counter();
		$data['title'] = 'Events';
        $this->load->view('home/event',$data);
    }
    public function academic_schedule(){
		$data['v_counter'] 	= $this->visitor_counter();
		$data['title'] = 'Academic Schedule';
        $this->load->view('home/academic/academic_schedule',$data);
    }
	public function get_event(){
		$s_data['school_id'] = 1;
		echo json_encode($this->Common_model->common_select_by_multycondition($s_data,'tbl_academic_calendar'));
    }
    public function attendance(){
		$data['v_counter'] 	= $this->visitor_counter();
		$data['title'] = 'Attendence';
        $this->load->view('home/attendance/attendance',$data);
    }
	public function student_for_att_report_daily_json(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $att_date = date('Y-m-d',strtotime($_GET['att_date']));
		$data['att_date']= date('d M Y',strtotime($_GET['att_date']));
		$data['att_day']= date('l',strtotime($_GET['att_date']));
		$data['att_details'] = $this->Attendance_model->get_class_wise_att_count_daily($school_id,$att_date);
		$mainContent=$this->load->view('attendance/student_att_report_daily', $data, true);
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
    }

	public function emp_attendance(){
		$data['v_counter'] 	= $this->visitor_counter();
		$data['title'] = 'Employee Attendence';
        $this->load->view('home/attendance/emp_attendance');
    }
	// Teacher daily,monthly and teacher wise attendance report
	public function teacher_att_report_json(){
        #$school_id = $_SESSION['school_id'];
         $school_id = 1;
        $teacher_name_json = $this->Attendance_model->teacher_list('tbl_teacher_registration.school_id',$school_id,'tbl_teacher_registration.teacher_id,tbl_teacher_registration.teacher_name,tbl_designation.designation_name');
       
	$att_time=strtotime($_GET['att_date']);
	$att_date = date('Y-m-d',$att_time);
	//$att_date = $_GET['att_date'];
        $att_month = date('Y-').$_GET['month_id'];
        $teacher_id = $_GET['teacher_id'];
        $report_type = $_GET['report_type'];
		$repo_type='';
		if($report_type=='d'):
			$data['att_details'] = $this->Attendance_model->get_teacher_day_att($school_id,$att_date);
			$data['repo_type']='d';
			$data['teacher_name_json'] = $teacher_name_json;//$_GET['teacher_name_json'];
			$data['att_date']= date('d M Y',$att_time);
			$data['att_day']= date('l',$att_time);
		
		else:
			if($teacher_id):
				$data['att_details'] = $this->Attendance_model->get_teacher_wise_att($school_id,$teacher_id,$att_month);
				$data['repo_type']='t';
				$data['teacher_name_json']= $teacher_name_json;//$_GET['teacher_name_json'];
			else:
				$data['att_details'] = $this->Attendance_model->get_teacher_month_att($school_id,$att_month);
				$data['repo_type']='m';
				$data['teacher_name_json']= $teacher_name_json;//$_GET['teacher_name_json'];
			endif;
		endif;
		$data['month_name'] =$_GET['month_name'];
		$data['teacher_name'] =$_GET['teacher_name'];
		
		 $mainContent=$this->load->view('attendance/teacher_att_report_json', $data, true);
			
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=>$mainContent);
        print json_encode($return);
       // exit;   
    }
	
    public function schoolresult()
	{
		$school_id=1;
		$data['v_counter'] 	= $this->visitor_counter();
		$data['class_list']		= $this->Admin_model->get_class_list($school_id);
		$data['term_list'] 		=  $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
		$data['session_list'] 	= $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
		$data['shift_list'] 	= $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_shift');
		$data['title'] = 'School Result';
        $this->load->view('home/result/schoolresult', $data);
    }
	
	
	public function get_student_list_marksheet(){
        #$school_id = $_SESSION['school_id'];
        $s_data['tbl_student_class.school_id'] = 1;
        $s_data['tbl_student_class.class_id'] = $_POST['class_id'];
        $s_data['tbl_student_class.section_id'] = $_POST['section_id'];
        $s_data['tbl_student_class.group_id'] = $_POST['group_id'];
        $s_data['tbl_student_class.shift_id'] = $_POST['shift_id'];
		$s_data['tbl_student_class.session_id'] = $_POST['session_id'];
        $stuInfo =  $this->Result_model->selece_student_marksheet($s_data);
       
        $str = '<option value="">---- Select student ----</option>';
        if($stuInfo)
        {
           foreach($stuInfo as $stuInfos)
           {
              $str .= "<option value='".$stuInfos['student_id']."'>".$stuInfos['student_id'].'-'.$stuInfos['student_name']."</option>";
           }
        }
        echo $str;exit;
		
    }
	
	public function mark_sheet_json()
	{		
		$school_id 		= 1;
		if($_GET['search_type'] == 'id_wise')
		{
			$session_name 	= date('Y')-1;
			$session_array 	= $this->Common_model->common_select_by_condition($session_name,'session_name','tbl_session');
			$session_id 	= $session_array[0]['session_id'];
			
			if($_GET['student_id'])
				$student_id = $_GET['student_id'];
			else
				$student_id = '';
			
			$data['student_list'] 		= $this->Admin_model->get_student_info_by_id($school_id, $student_id, $session_id);
			
			if(count($data['student_list'])>0)
			{
				$class_id               = $data['student_list']['class_id'];
				$group_id 				= $data['student_list']['group_id'];
				$class_short_form       = $data['student_list']['class_short_form'];
				$section_id             = $data['student_list']['section_id'];
				$shift_id               = $data['student_list']['shift_id'];
				$session_id             = $data['student_list']['session_id'];
				$term_id                = $_GET['term_id'];
				$term_name            	= $_GET['term_name'];
				$session                = $data['student_list']['session_name'];// this session use here as exam year
			}
		}else{
			
			$class_id               = $_GET['class_id'];
			$section_id             = $_GET['section_id'];
			$group_id             	= $_GET['group_id'];
			$class_short_form       = $_GET['class_short_form'];
			$shift_id               = $_GET['shift_id'];
			$session_id             = $_GET['session_id'];
			$student_id             = $_GET['student_id'];
			$term_id                = $_GET['term_id'];
			$term_name              = $_GET['term_name'];
			$session                = $_GET['session'];// this session use here as exam year
			$view_type              = $_GET['view_type'];
		}
		//echo $exam_year; die();
		$where_term = array("class_id"=>$class_id,"section_id"=>$section_id,"term_id"=>$term_id,"session_id"=>$session_id,"school_id"=>$school_id,"status"=>1);
		if($this->Common_model->common_select_by_multycondition($where_term,'tbl_result_publish')){
			if($view_type == 'all'){
				$student_list       = $this->Result_model->get_student_lists($school_id,$session_id,$class_id,$shift_id,$section_id,$session,$term_id);
			}else{
				$student_list       = array(array('student_id' => $student_id));
			}
			if($class_id>3){$static_group_id = $group_id;}else{$static_group_id = 4;}
			
			$std_transcript         = array();
			$data['ranks_by_gpa']   = $this->tabulation_marks_json_func($school_id, $class_id, $class_short_form, $section_id, $shift_id, $session_id, $term_id, $session, $static_group_id);
			//print_r(count($data['ranks_by_gpa']));exit;
			foreach($student_list as $i=>$std_list) {
				$student_id = $std_list['student_id'];

				// main code start here
				$data['student_mark_info'] = $this->Result_model->get_student_marksheet_info($school_id, $class_id, $student_id, $term_id, $session);
				if ($class_short_form >= 11) {
					$data['student_info'] = $this->Result_model->mark_sheet_student_info_with_optional($school_id, $session_id, $student_id, $class_id);
					$data['optional'] = $data['student_info']['subject_id'];
				} else {
					$data['student_info'] = $this->Result_model->mark_sheet_student_info($school_id, $session_id, $student_id, $class_id);
					$data['optional'] = '';
					$data['optional_sub_id'] = $this->Result_model->get_student_optional_subject_id($school_id, $class_id, $student_id);
				}

				$data['max_mark'] = $this->Result_model->get_max_subject_number($school_id, $class_id, $term_id, $session);
				$data['ranks'] = $this->Result_model->get_student_rank($school_id, $class_id, $section_id, $shift_id, $term_id, $session);

				$data['grd_system'] = $this->Common_model->common_select_by_condition($school_id, 'school_id', 'tbl_grd_system');
				$data['details'] = array('term_name' => $term_name, 'session' => $session, 'class_short_form' => $class_short_form);
				$data['student_info'] = $this->Admin_model->get_student_info_by_id($school_id, $student_id, $session_id);
				$data['school_info'] = $this->Admin_model->get_school_information($school_id);
				$data['public_flag'] = 1;
				// main code end here

				$std_transcript[$i]['std_transcript']   = $data;
			}
			$data['std_transcripts'] = $std_transcript;
			
			$mainContent=$this->load->view('result/mark_sheet_json', $data, true);
		}else{
            $mainContent="<h3 style='text-align:center'>Result will publish soon ...</h3>";
        }
		
		$result = 'success';
		$return = array('result' => $result, 'mainContent'=> $mainContent);
		print json_encode($return);
		exit;   
  
	}

    public function tabulation_marks_json_func($school_id, $class_id, $class_short_form, $section_id, $shift_id, $session_id, $term_id, $session, $static_group_id)
    {
        $school_id      = $school_id;
        $class_id       = $class_id;
        $section_id     = $section_id;
        $shift_id       = $shift_id;
        $session_id     = $session_id;
        $term_id        = $term_id;
        $exam_year      = $session;
        $group_id       = $static_group_id;

        // previous code start
        $data['subject_infos'] = $this->Result_model->tab_mark_distribution_list_result($school_id,$class_id,$group_id,$term_id);
        // previous code end

        $grd_system 		= $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_grd_system');
        $student_list		= $this->Result_model->get_student_list_tabu_group($school_id,$session_id,$class_id,$shift_id,$section_id,$group_id,$exam_year,"(".$term_id.")");
        //$student_list       = $this->Result_model->get_student_lists($school_id,$session_id,$class_id,$shift_id,$section_id,$session,$term_id);
        //print_r($student_list);exit;
        $val 			= array();
        $total_student 	= count($student_list);
        $tfail			= 0;
        foreach($student_list as $k=>$students_info){
            //if($students_info['student_id'] == '1002771'){
            $total_marks		= 0;
            $std_subj_mark		= array();	
			$sub_array			= array();
            $student_mark_info 	= $this->Result_model->get_student_marksheet_info($students_info['school_id'],$students_info['class_id'],$students_info['student_id'],$students_info['term_id'],$exam_year);
            $optional_sub_id	= $this->Result_model->get_student_optional_subject_id($students_info['school_id'],$students_info['class_id'],$students_info['student_id']);
            //print_r($optional_sub_id);exit;
            $getbn=0; $getbnsubj=0; $getbnobj=0; $bnsubj=0; $bnobj=0; $getbnsubjpass=0; $getbnobjpass=0; $geten=0; $getensubj=0; $ensubj=0; $getensubjpass=0; $total_gpa=0; $pass_flag='1'; $optional_sub_flag = 0; $ttl_mark = 0;
            foreach($student_mark_info as $maks_info){

                // get optional subject exact gpa
                if($maks_info['subject_id']==$optional_sub_id['subject_id']){
                    $optional_sub_flag = 1;
                    if($maks_info['gpa']>2){$total_gpa = $total_gpa+($maks_info['gpa']-2);}
                }else {
                    // student wise total gp count start
                    if ($maks_info['subject_id'] == 2 || $maks_info['subject_id'] == 1) {
                        if(explode('*',$maks_info['sub'])[0]){$bnsubj = explode('*',$maks_info['sub'])[0];}
                        $getbnsubj      = $getbnsubj + $bnsubj;
                        $getbnsubjpass  = $getbnsubjpass+(floor(explode('*',$maks_info['sub'])[1]*$maks_info['p_mark']/100));
                        //
                        if(explode('*',$maks_info['obj'])[0]){$bnobj = explode('*',$maks_info['obj'])[0];}
                        $getbnobj       = $getbnobj + $bnobj;
                        $getbnobjpass   = $getbnobjpass+(round(explode('*',$maks_info['obj'])[1]*$maks_info['p_mark']/100));
                        ///
                        $getbn = $getbn + $maks_info['sub_total'];
                    } elseif ($maks_info['subject_id'] == 4 || $maks_info['subject_id'] == 3) {
                        if(explode('*',$maks_info['sub'])[0]){$ensubj = explode('*',$maks_info['sub'])[0];}
                        $getensubj      = $getensubj + $ensubj;
                        $getensubjpass  = $getensubjpass+(round(explode('*',$maks_info['sub'])[1]*$maks_info['p_mark']/100));
                        ///
                        $geten = $geten + $maks_info['sub_total'];
                    } else {
                        if ($maks_info['gpa'] != 0) {
                            $total_gpa = $total_gpa + $maks_info['gpa'];
                        }else{
                            $pass_flag = '0';/*$total_gpa=0;break;*/
                        }
                    }
                }
				$ttl_mark = $ttl_mark+$maks_info['sub_total'];
                // student wise total gp count end
                //student wise subject info start
                $getbnm=0;$getbnms=0; $getenm=0;$subj_total=0;$sub_pass=1;$obj_pass=1;$prac_pass=1;$sub_gpa=0;
                foreach($data['subject_infos'] as $i=>$stu_data){
                    if($stu_data['subject_id'] == $maks_info['subject_id'])
                    {	//print_r(explode('*',$maks_info['sub']));
                        //echo ' not else ';
                        //start student subject mark calculation
                        $subj_id		= $maks_info['subject_id'];
                        $pass_id		= $maks_info['pass_id'];
                        $subj_sub		= explode('*',$maks_info['sub'])[0];
                        $subj_obj		= explode('*',$maks_info['obj'])[0];
                        $subj_pract		= explode('*',$maks_info['prac'])[0];
                        $subj_total		= ($subj_sub+$subj_obj+$subj_pract);
                        $ttl_full_mark	= $maks_info['f_mark'];
                        $ttl_pass_mark	= $maks_info['p_mark'];
                        $sub_gpa	    = $maks_info['gpa'];
                        // subj, obj, pract wise pass mark check
                        if($pass_id==1){
                            if($subj_sub<(round(explode('*',$maks_info['sub'])[1]*$maks_info['p_mark']/100)))  $sub_pass  = 0;
                            if($subj_obj<(round(explode('*',$maks_info['obj'])[1]*$maks_info['p_mark']/100)))  $obj_pass  = 0;
                            if($subj_pract<(round(explode('*',$maks_info['prac'])[1]*$maks_info['p_mark']/100))) $prac_pass = 0;
                        }
                        //if(count($subj_pract)>0){$subj_prac=$subj_pract;}else{$subj_prac=0;}
                        if($maks_info['subject_id']==2){
                            $subjectsin		= "1','2";
                            $bn_en_total 	= $this->Result_model->get_bn_en_total($school_id,$students_info['student_id'],$term_id,$exam_year,$subjectsin);
                            $ttl_full_mark	= $bn_en_total[0]['full_mark'];
                            $subj_total		= $bn_en_total[0]['total'];
                            $b_ttl_full_mark= $ttl_full_mark;
                        }elseif($maks_info['subject_id']==4){
                            $subjectsin		= "3','4";
                            $bn_en_total 	= $this->Result_model->get_bn_en_total($school_id,$students_info['student_id'],$term_id,$exam_year,$subjectsin);
                            $ttl_full_mark	= $bn_en_total[0]['full_mark'];
                            $subj_total		= $bn_en_total[0]['total'];
                            $e_ttl_full_mark= $ttl_full_mark;
                        }


                        $std_subj_mark[$i]['subj_id']		= $subj_id;
                        $std_subj_mark[$i]['subj_sub']		= $subj_sub;
                        $std_subj_mark[$i]['subj_obj']		= $subj_obj;
                        $std_subj_mark[$i]['subj_prac']		= $subj_pract;
                        $std_subj_mark[$i]['sub_pass']		= $sub_pass;
                        $std_subj_mark[$i]['obj_pass']		= $obj_pass;
                        $std_subj_mark[$i]['prac_pass']		= $prac_pass;
                        $std_subj_mark[$i]['subj_total']	= $subj_total;
                        $std_subj_mark[$i]['ttl_full_mark']	= $ttl_full_mark;
                        $std_subj_mark[$i]['ttl_pass_mark']	= $ttl_pass_mark;
                        $std_subj_mark[$i]['sub_gpa']	    = $sub_gpa;


                        break;

                        //$subj_total[]	= ($subj_sub[]+$subj_obj[]);
                        //end student subject mark calculation
                    }
                }$sub_array[] = $maks_info['subject_code'];
                //student wise subject info end

            }//print_r($getbnsubj);//print_r($subj_obj);print_r($subj_prac);
            //print_r($getbnsubj); print_r($getbnsubjpass);
            //exit;

            // for check bn & eng subj, obj wise pass
            if(($getensubj<$getensubjpass)){
				$pass_flag = 0;
			}else {
				$do = 1;
				if(($getbnsubj<$getbnsubjpass) || ($getbnobj<$getbnobjpass)){
					// for check bangla 1st & 2nd paper subj, obj wise pass (only for 9&10)
					if(($get_class==4) ||($get_class==5)){$pass_flag = 0;$do = 0;}
				}
				
				if($do == 1)
				{
					// for bn total grade pointforeach($grd_system as $gplbn):
					$total_getbn = floor(($getbn*100)/$b_ttl_full_mark);
					$total_geten = floor(($geten*100)/$e_ttl_full_mark);

					foreach ($grd_system as $gplbn) {
						if ($gplbn['start_marks'] <= $total_getbn && $gplbn['end_marks'] >= $total_getbn) {
							$gpabn = $gplbn['grd_point'];
							$total_gpa = $total_gpa + $gpabn;

						}
					}

					foreach ($grd_system as $gplbn) {
						if ($gplbn['start_marks'] <= $total_geten && $gplbn['end_marks'] >= $total_geten) {
							$gpaen      = $gplbn['grd_point'];
							$total_gpa  = $total_gpa + $gpaen;
						}
					}
				}
			}//print_r($pass_flag); exit;
            // if any subject fail then make this student gp 0
            if($pass_flag!=1){$total_gpa = 0;}
            // for point calculation
			if (in_array('101', $sub_array, true)) 
			{				
				$avgpp=sprintf('%0.2f', $total_gpa/(count($student_mark_info)-(2+$optional_sub_flag)));
				$avgp=($avgpp > 5 ? 5 : $avgpp);
			}else
			{				
				$avgpp=sprintf('%0.2f', $total_gpa/(count($student_mark_info)-(0+$optional_sub_flag)));
				$avgp=($avgpp > 5 ? 5 : $avgpp);
			}

            // for grade system calculation
            foreach ($grd_system as $key => $row) {
                $mid[$key]  = $row['grd_point'];
            }
            // Sort the data with mid descending
            // Add $data as the last parameter, to sort by the common key
            array_multisort($mid, SORT_DESC, $grd_system);

            $i=0;
            while($i <= count($grd_system)) {
                if ($grd_system[$i]['grd_point'] <= $avgp) {
                    $obtgpa=$grd_system[$i]['gpa'];
                    break;
                }
                $i++;
            }

            if($obtgpa=='F'){$tfail++;}
            // for merit list

            //$val[$k]['position']		= $position;
            $val[$k]['student_id']		= $students_info['student_id'];
            $val[$k]['student_name']	= $students_info['student_name'];
            $val[$k]['roll_no']			= $students_info['roll_no'];
            $val[$k]['point']			= $avgp;
            $val[$k]['grade']			= $obtgpa;
            $val[$k]['ttl_get_mark']	= $ttl_mark;
            //$val[$k]['subjects_mark']	= $std_subj_mark;
            //}
        }//print_r($val);
        //$data['output']			= $val;
        //$data['total_student']	= $total_student;
        //$data['total_fail']		= $tfail;

        return $val;
    }
    
    public function PSCresult(){
		$data['v_counter'] 	= $this->visitor_counter();
		$data['title'] = 'PSC Result';
        $this->load->view('home/result/PSCresult',$data);
    }
    public function JSCresult(){
		$data['v_counter'] 	= $this->visitor_counter();
		$data['title'] = 'JSC Result';
        $this->load->view('home/result/JSCresult',$data);
    }
    public function SSCresult(){
		$data['v_counter'] 	= $this->visitor_counter();
		$data['title'] = 'SSC Result';
        $this->load->view('home/result/SSCresult',$data);
    }
    public function latestnews(){
		$data['v_counter'] 	= $this->visitor_counter();
		$data['title'] = 'Latest News';
        $this->load->view('home/latestnews',$data);
    }
    public function career(){
		$data['v_counter'] 	= $this->visitor_counter();
        $this->load->view('home/career',$data);
    }
    public function digital_classroom(){
		$data['v_counter'] 	= $this->visitor_counter();
        $this->load->view('home/digital_classroom',$data);
    }
    public function login(){
		$data['v_counter'] 	= $this->visitor_counter();
        $this->load->view('home/student/login',$data);
    }
	public function guardian_panle_login_check(){
		$s_data['student_id']=$_POST['student_id'];
		$s_data['password']=$_POST['password'];
		
		if($this->Common_model->common_select_by_multycondition($s_data,'tbl_student')){
		       $_SESSION['student_id']       = $_POST['student_id'];
			redirect('guardian_panel');
		}
		else{
		$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Your ID or Password is not valid.</div>');
		redirect('home/login');
		}
	} 
	function logout()
	{            
		session_destroy();
		redirect('home');
	}  
    public function about(){
		$data['v_counter'] 	= $this->visitor_counter();
		$data['about'] = $this->General_model->getAboutMessage();
        $this->load->view('home/about/about',$data);
    }
    public function founder(){
        //$data['about'] = $this->General_model->get_about_by_school_id();
		$data['v_counter'] 	= $this->visitor_counter();
		$data['founder'] = $this->Common_model->common_result_array('tbl_founder');
		//print_r($data);
		//die();
        $this->load->view('home/about/founder',$data);
    }
    public function history(){
		$data['v_counter'] 	= $this->visitor_counter();
        $this->load->view('home/about/history',$data);
    }
    public function contact_us(){
		$data['v_counter'] 	= $this->visitor_counter();
        $this->load->view('home/about/contact_us',$data);
    }
    public function contact(){
		$data['v_counter'] 	= $this->visitor_counter();
        $this->load->view('home/contact',$data);
    }
	public function teacher(){
        $school_id = 1;
		$data['v_counter'] 	= $this->visitor_counter();
		//$data['teacher_list'] = $this->Common_model->common_result_array_orderby('tbl_teacher_registration','designation_id');
		//print_r($data['teacher_list']);
		//die();
		$data['department_list'] = $this->General_model->get_all_department_list($school_id);
        $data['designation_list'] = $this->General_model->get_all_designation_list($school_id);

		$data['teacher_list'] = $this->General_model->get_all_teacher_list();
		//print_r($data['teacher_list']);
		//die();
        //print_r($data['designation_list']); exit();
		$this->load->view('home/employee/teacher', $data);
	}
	public function gallery(){
		$school_id = 1;
		$data['v_counter'] 	= $this->visitor_counter();
		$data['photo_gallery'] = $this->General_model->get_photo_gallery();
		$data['catagory_list'] = $this->General_model->get_all_catagory_list($school_id);
		$this->load->view('home/gallery',$data);
	}
	
	public function admit_card(){
		$data['v_counter'] 	= $this->visitor_counter();
		$this->load->view('home/admit_card',$data);
	}

	public function guardian_panle_login(){
		$data['v_counter'] 	= $this->visitor_counter();
		$this->load->view('home/guardian_panle_login',$data);
	}

    public function message($message_id){ 
		$data['v_counter'] 	= $this->visitor_counter();
        $data['messages'] = $this->General_model->get_message_by_id($message_id);
        $this->load->view('welcome/message', $data);
    }
    
    public function important_information(){
        $information_type = 1;
		$data['v_counter'] 	= $this->visitor_counter();
        $data['info_list'] = $this->General_model->get_information_list_by_id($information_type);
        $this->load->view('welcome/important_information',$data);
    }
    
    public function rules_regulations(){            
        $information_type = 2;
		$data['v_counter'] 	= $this->visitor_counter();
        $data['rules_list'] = $this->General_model->get_information_list_by_id($information_type);
        $this->load->view('welcome/rules_regulations',$data);
    }
    
    public function steps(){
        $information_type = 3;
		$data['v_counter'] 	= $this->visitor_counter();
        $data['rules_list'] = $this->General_model->get_information_list_by_id($information_type);
        $this->load->view('welcome/steps',$data);
    }
    
    public function facilities(){
        $information_type = 4;
		$data['v_counter'] 	= $this->visitor_counter();
        $data['rules_list'] = $this->General_model->get_information_list_by_id($information_type);
        $this->load->view('welcome/facilities',$data);
    }
    
    public function principal_list(){
        $information_type = 5;
		$data['v_counter'] 	= $this->visitor_counter();
        $data['principal_list'] = $this->General_model->get_information_list_by_id($information_type);
        $this->load->view('welcome/principal_list',$data);
    }
    
    public function vice_principal_list(){
        $information_type = 6;
		$data['v_counter'] 	= $this->visitor_counter();
        $data['vice_principal_list'] = $this->General_model->get_information_list_by_id($information_type);
        $this->load->view('welcome/vice_principal_list',$data);
    }
    
    public function library(){
        $school_id = 1;
		$data['v_counter'] 	= $this->visitor_counter();
		$data['book_list'] = $this->General_model->get_all_book_list($school_id);
		$data['category_list'] = $this->General_model->get_all_book_category_list($school_id);
        $this->load->view('welcome/library', $data);
    }
    
    public function vacant_post(){
        $information_type = 8;
		$data['v_counter'] 	= $this->visitor_counter();
        $data['vacant_post'] = $this->General_model->get_information_list_by_id($information_type);
        $this->load->view('welcome/vacant_post',$data);
    }
	
	public function teacher_panel(){
        $information_type = 9;
		$data['v_counter'] 	= $this->visitor_counter();
        $data['teacher_panel'] = $this->General_model->get_information_list_by_id($information_type);
        $this->load->view('welcome/teacher_panel',$data);
    }
	
	public function student_panel(){
        $information_type = 10;
		$data['v_counter'] 	= $this->visitor_counter();
        $data['student_panel'] = $this->General_model->get_information_list_by_id($information_type);
        $this->load->view('welcome/student_panel',$data);
    }
	
	public function guardian_panel(){
        $information_type = 11;
		$data['v_counter'] 	= $this->visitor_counter();
        $data['guardian_panel'] = $this->General_model->get_information_list_by_id($information_type);
        $this->load->view('welcome/guardian_panel',$data);
    }
    
    public function department(){
		$data['v_counter'] 	= $this->visitor_counter();
        $data['class_list'] = $this->General_model->get_all_class_assign_list();
        $this->load->view('welcome/department', $data);
    }
	
    public function classroutine()
	{
		$school_id = 1;
		$data['v_counter'] 	= $this->visitor_counter();
		$data['class_list'] = $this->Common_model->common_result_array('tbl_class');
		$data['shift_list'] = $this->Academic_model->get_shift_list($school_id);
		//$c1 = $count['count'];
		$this->load->view('home/routine/classroutine', $data);
	}

	public function get_class_routine_json_show()
	{
		$s_data['school_id']	= 1;
        $s_data['class_id'] 	= $_GET['class_id'];
		$s_data['section_id'] 	= $_GET['section_id'];
		$s_data['group_id'] 	= $_GET['group_id'];
		$s_data['shift_id'] 	= $_GET['shift_id'];
		
        $data['class_name'] 	= $this->Common_model->common_select_by_condition($s_data['class_id'],'class_id','tbl_class');
        $data['section_name'] 	= $this->Common_model->common_select_by_condition($s_data['section_id'],'section_id','tbl_section');
        $data['group_name'] 	= $this->Common_model->common_select_by_condition($s_data['group_id'],'group_id','tbl_group');		
        $data['class_time'] 	= $this->Common_model->common_select_by_multycondition_sorting($s_data,'tbl_class_time_input','row_no', 'asc');
		$data['week']			= $this->Academic_model->get_weekdays($s_data['school_id']);
		$data['teacher']		= $this->Academic_model->get_class_wise_teacher_list_routine($s_data['school_id'],$s_data['class_id'],$s_data['section_id']);
		$data['subject']		= $this->Academic_model->get_class_wise_subject_list($s_data['class_id'],$s_data['group_id'],$s_data['school_id']);
	
		$mainContent=$this->load->view('home/routine/get_class_routine_json_show', $data, true);
			
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;    
    }

    public function get_old_routine_by_section_class_show()
    {
     	#$school_id = $_SESSION['school_id'];
     	$school_id = 1;
    	$class_id = $_GET['class_id'];
    	$section_id = $_GET['section_id'];
    	$group_id = $_GET['group_id'];
    	$shift_id = $_GET['shift_id'];
    	$data= $this->Academic_model->get_old_routine_by_section_class_show($class_id, $school_id,$section_id,$group_id,$shift_id);
    	 print json_encode($data);
        exit;   
    }

    public function central_routine(){
        $data['central_routine'] = $this->General_model->get_central_routine();
        $this->load->view('welcome/central_routine', $data);
    }

    public function examroutine(){
		$school_id = 1;
		$data['v_counter'] 	= $this->visitor_counter();
		$data['class_list'] = $this->Admin_model->get_class_list($school_id);
		$data['term_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
		$data['session_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
		$this->load->view('home/routine/examroutine', $data);
	}

     public function get_old_exam_routine_by_term()
    {
        #$school_id = $_SESSION['school_id'];
        $school_id      = 1;
        $class_id       = $_GET['class_id'];
        $exam_term_id   = $_GET['exam_term_id'];
        $section_id     = $_GET['section_id'];
        $group_id       = $_GET['group_id'];
        $session_id     = $_GET['session_id'];
        $data = $this->Academic_model->get_old_exam_routine_by_term($class_id,$exam_term_id,$section_id,$group_id,$session_id);
        print json_encode($data);
        exit;   
    }
     function section_list_ajax()
    {
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
        $sectionInfo = $this->Admin_model->get_section_list_by_id($class_id, $school_id); 
        $str = '<option value="">----Select Section----</option>';
        if($sectionInfo)
        {
           foreach($sectionInfo as $sInfo)
           {
              $str .= "<option value='".$sInfo['section_id']."'>".$sInfo['section_name']."</option>";
           }
        }
        echo $str;exit;
    }

	public function exam_routine_json()
    {
        $school_id 	= 1;
        $class_id 	= $_GET['class_id'];
		$session_id = $_GET['session_id'];
		$section_id = $_GET['section_id'];
		$group_id 	= $_GET['group_id'];
		$term_id 	= $_GET['term_id'];
		//$student_id = "('" . implode("','", $_GET['student_id']) . "')";
		
		//$data['student_info']	= $this->Exam_model->get_class_wise_student_list_admit_print($school_id, $class_id, $session_id,$section_id, $group_id, $student_id);
		$exam_routine 			= $this->Exam_model->get_class_wise_exam_routine($school_id, $class_id,$section_id, $group_id, $term_id, $session_id);
		$data['exam_routine']	= array_chunk($exam_routine, 2);

		$s_data['school_id']	= $school_id;
		$s_data['term_id']		= $term_id;
		$d_data['session_id']	= $session_id;
		$data['exam_year'] 		= date('Y',strtotime($_GET['exam_date']));
        $data['term'] 			= $this->Common_model->common_select_by_multycondition($s_data,'tbl_term');
        $data['session'] 		= $this->Common_model->common_select_by_multycondition($d_data,'tbl_session');
		$data['school'] 		= $this->Common_model->common_row_by_condition($school_id,'school_id','tbl_school_information');
		//$mainContent=$data['school'];
		$mainContent	= $this->load->view('home/routine/exam_routine_json', $data, true);
        $logo			= $data['school']['logo'];
        $result 		= 'success';
        $return 		= array('result' => $result, 'mainContent'=> $mainContent,'logo'=>$logo);
        print json_encode($return);
        exit;
    }
		
	public function get_old_exam_routine_by_term_show()
	{
    	#$school_id = $_SESSION['school_id'];
     	$school_id = 1;
		$class_id = $_GET['class_id'];
		$exam_term_id = $_GET['exam_term_id'];
		$data= $this->Academic_model->get_old_exam_routine_by_term_show($class_id,$exam_term_id);
        //print($data);exit();
		 print json_encode($data);
        exit;   
	}     
        
    /**Ajax Data for Result View**/
    public function get_department_list_by_class_id(){            
        $class_id = $_GET['class_id'];
                    
        $department_list = $this->General_model->get_department_list_by_class_id($class_id);
        
        $mainContent='<option value="">---- Select Department ----</option>';
        if($department_list){
            foreach($department_list as $dl){
                $department_id = $dl['department_id'];
                $dept_name=$this->General_model->get_department_info_by_id($department_id);
                $department_name=$dept_name['department_name'];
                
                $mainContent.='<option value="'.$dl['department_id'].'">'.$department_name.'</option>';
            }
        }           
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;            
    }
		
    public function get_session_list_by_class_id(){
        $class_id = $_GET['class_id'];
        $session_list = $this->General_model->get_session_list_by_class_id($class_id);
        $mainContent='<option value="">---- Select Session ----</option>';
        if($session_list){
            foreach($session_list as $sl){
                $session_id = $sl['session_id'];
                $sess_name=$this->General_model->get_session_info_by_id($session_id);
                $session_name=$sess_name['session_name'];
                
                $mainContent.='<option value="'.$sl['session_id'].'">'.$session_name.'</option>';
            }
        }           
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;            
    }
		
    public function get_exam_list_by_class_id(){
    $class_id = $_GET['class_id'];
                
    $exam_list = $this->General_model->get_exam_list_by_class_id($class_id);
    
    $mainContent='<option value="">---- Select Exam ----</option>';
    if($exam_list){
        foreach($exam_list as $el){
            $exam_id = $el['exam_id'];
            $ex_name=$this->General_model->get_exam_info_by_id($exam_id);
            $exam_name=$ex_name['exam_name'];
            
            $mainContent.='<option value="'.$el['exam_id'].'">'.$exam_name.'</option>';
        }
    }           
    $result = 'success';
    $return = array('result' => $result, 'mainContent'=> $mainContent);
    print json_encode($return);
    exit;            
    }
        
		
    public function get_student_list_for_result_view(){
        $class_id = $_GET['class_id'];
        $department_id = $_GET['department_id'];
        $session_id = $_GET['session_id'];
        $exam_id = $_GET['exam_id'];
		
        $data['class_id']=$class_id;
        $data['department_id']=$department_id;
        $data['session_id']=$session_id;
        $data['exam_id']=$exam_id;

        $data['result_list']=$this->General_model->get_result_list_by_class_id($class_id, $department_id, $session_id, $exam_id);
        $data['fail_list']=$this->General_model->get_fail_list_by_class_id($class_id, $department_id, $session_id, $exam_id);           
        
        $data['result_type']=$this->General_model->get_result_type_by_class_id($class_id);
        
        
        $data['degree_result_list']=$this->General_model->get_degree_result_list_by_class_id($class_id, $department_id, $session_id, $exam_id);
        
        $data['degree_fail_list']=$this->General_model->get_degree_fail_list_by_class_id($class_id, $department_id, $session_id, $exam_id);
		
        $mainContent=$this->load->view('welcome/get_student_list_for_result_view', $data, true);
        
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;              
    }
		
	public function get_teacher_list_by_department_id(){
		$school_id = 1;
		$department_id = $_GET['department_id'];
		//echo $department_id; die();
		$data['tt']=$this->General_model->get_teacher_list_by_department($school_id, $department_id);
		$data['department_name']=$this->General_model->get_department_name($department_id);
		$mainContent=$this->load->view('welcome/teacher_department_wise', $data, true);
			
		$result = 'success';
		$return = array('result' => $result, 'mainContent'=>$mainContent);
		print json_encode($return);
		exit;            
	}		
		
	public function get_photo_list_by_catagory_id(){
		$school_id = 1;
		$catagory_id = $_GET['catagory_id'];
		$data['tt']=$this->General_model->get_photo_list_by_catagory($school_id, $catagory_id);
		$data['catagory_name']=$this->General_model->get_catagory_name($catagory_id);
		
		$mainContent=$this->load->view('welcome/photo_catagory_wise', $data, true);
			
		$result = 'success';
		$return = array('result' => $result, 'mainContent'=>$mainContent);
	   
		print json_encode($return);
		exit;            
	}
		
		public function get_book_list_by_category_id(){
			$school_id = 1;
            $category_id = $_GET['category_id'];
			//$data['category_id']= $_GET['category_id'];
			//$data['book_list'] = $this->Admin_model->get_all_book_list($school_id);
			//$data['category_list'] = $this->Admin_model->get_all_book_category_list($school_id);
            $data['tt']=$this->General_model->get_book_list_by_category($school_id, $category_id);
			$data['category_name']=$this->General_model->get_book_category_name($category_id);
			$mainContent=$this->load->view('welcome/book_category_wise', $data, true);
 				
			$result = 'success';
            $return = array('result' => $result, 'mainContent'=>$mainContent);
           
            print json_encode($return);
            exit;            
        }	
			
	/********************** result **************/
	public function mark_sheet()
	{
		$school_id = 1;
		$data['v_counter'] 	= $this->visitor_counter();
		$data['class_list'] = $this->Admin_model->get_class_list($school_id);
		$data['term_list'] =  $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
		$data['session_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
		$data['shift_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_shift');
		$this->load->view('home/mark_sheet',$data);
	}
  
	public function print_mark_sheet()
	{
        $school_id = 1;
        $class_id = $_POST['class_id'];
		$section_id = $_POST['section_id'];
		$student_id = $_POST['student_id'];
		$term_id = $_POST['term_id'];
        $exam_year = $_POST['exam_year'];
		//echo $exam_year.' class '.$class_id.' sec '.$section_id.' student '.$student_id.' term '.$term_id; die();
		$data['v_counter'] 	= $this->visitor_counter();
        $data['student_information'] = $this->Academic_model->get_class_wise_student_info_marksheet($school_id, $class_id,$section_id,$student_id);
        $data['term'] = $this->Academic_model->get_term_list_by_id($term_id,$school_id); 
		$data['school_info'] = $this->Academic_model->admit_card_view_school($school_id);
        $data['details'] =  array("class_id"=>$class_id,"section_id"=>$section_id,"term_id"=>$term_id,"exam_year"=>$exam_year,'student_id'=>$student_id,'school_id'=>$school_id);
	
		$this->load->view('welcome/print_mark_sheet', $data);
        
        
  
	}
  
	public function result_view()
    {
		$school_id = 1;
		$data['v_counter'] 	= $this->visitor_counter();
		$data['class_list'] = $this->Admin_model->get_class_list($school_id);
		$data['term'] = $this->Academic_model->get_term_list($school_id); 

		$this->load->view('welcome/result_view',$data);
    }
      
      
	function result_marks_json()
	{
        $school_id = 1;
        $class_id = $_GET['class_id'];
		$section_id = $_GET['section_id'];
		$term_id = $_GET['term_id'];
        $exam_year = $_GET['exam_year'];
        $data['student_list'] = $this->Academic_model->get_class_wise_student_list_admit($school_id, $class_id,$section_id);
        $data['term'] = $this->Academic_model->get_term_list_by_id($term_id,$school_id); 

        $data['details'] =  array("class"=>$class_id,"section_id"=>$section_id,"term_id"=>$term_id,"exam_year"=>$exam_year,'sub_id'=>$sub_id);
	
					$mainContent=$this->load->view('welcome/result_view_json', $data, true);
        
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
  
  }
	function admissionresult()
	{
		/*$school_id	= 1;
		$data['school_info'] 	= $this->Admin_model->get_school_information($school_id);
		$data['results'] 		= $this->Admission_result_model->get_admission_result($school_id);*/
		$school_id = 1;
		$data['v_counter'] 		= $this->visitor_counter();
        $data['about'] 			= $this->General_model->get_about_by_school_id();
		$data['gallery_images'] = $this->General_model->get_photo_gallery();
		$data['catagory_lists'] = $this->General_model->get_all_catagory_list($school_id);
        $data['notice_list'] 	= $this->General_model->get_all_latest_notice($school_id);
        $data['notice_list_last']= $this->General_model->get_all_latest_notice_last();            
        $data['slide_image'] 	= $this->General_model->get_all_slide_image();
        $data['student_notice'] = $this->General_model->get_student_notice();
        $data['general_notice'] = $this->General_model->get_general_notice();
        $data['class_list'] 	= $this->General_model->get_all_class();
		///
		$condition              = " ";
        $c_data['school_id']    = $school_id;
        $c_data['status']    	= '1';
		$data['stusession_id']  = $this->Common_model->common_select_by_multycondition($c_data,'tbl_session');
        $data['class_list']     = $this->Admin_model->get_select_class_list($school_id, $condition);
		$data['d_content'] 		= $this->load->view('home/result/admissionresult', $data, TRUE);
		//print_r($data['d_content']);exit;
        //$this->load->view('home/result/admissionresult', $data);
        $this->load->view('home/index', $data);
	}

    public function admission_result_json()
    {
        $school_id  = 1;
        $class_id   = $_GET['class_id'];
        $class_name = $_GET['class_name'];
        $year_id    = $_GET['year_id'];
		
        $c_data		= " where school_id = $school_id and class_id = $class_id and exam_date like '$year_id%' and status=1 and published=1";
        // previous code start
        $data['school_info']    = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_school_information');
		$data['student_list']	= $this->Common_model->common_where_condition('tbl_student_admission',$c_data);
        $data['details']        = array("class_name"=>$_GET['class_name'],"exam_year"=>$year_id,"class_id"=>$class_id);
        $mainContent = $this->load->view('home/result/admissionresult_json', $data, true);

        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;
    }


    public function news_details($news_id)
    {
        $data['news'] = $this->General_model->getDeatailsById($news_id);
        $data['other_news']=$this->General_model->getOtherNews($news_id);
        $data['videos'] = $this->Common_model->common_result_array('tbl_video_gallery');
        $this->load->view('home/news_details', $data);
    }
    public function video_gallery()
    {
        $data['videos'] = $this->Common_model->common_result_array('tbl_video_gallery');
        $this->load->view('home/video_gallery', $data);
    }
    public function news_list()
    {
        $data['news'] = $this->Common_model->common_result_array('tbl_news');
        $this->load->view('home/news_list', $data);
    }



    
  /************************** / result ******************/

}