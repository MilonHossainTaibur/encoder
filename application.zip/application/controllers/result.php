<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Result extends CI_Controller {

    public function __construct()
        {            
            session_start();
            parent::__construct();
            $this->load->helper('form');
            $this->load->helper('url');
            $this->load->model('academic_model', 'Academic_model', true);
			$this->load->model('result_model', 'Result_model', true);
			$this->load->model('admin_model', 'Admin_model', true);
            $this->load->model('common_model', 'Common_model', true);
            $this->load->library('form_validation');
            if(!is_loggedin())
            {
                redirect('login');
                exit;
            }		
        }


//Ssc, Jsc, Psc Result Sheet Start//

  public function mark_entry()
     {

      $school_id = 1;
      $data['session_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
      $this->load->view('result/mark_entry', $data);

      }

 public function get_mark_entry_json(){

    $school_id = 1;
    $class_id = $_POST['class_id'];
    $group_id = $_POST['group_id'];
    $session_id = $_POST['session_id'];
    $data['mark_entry_list'] = $this->Result_model->get_mark_entry_json($school_id, $class_id, $group_id, $session_id);
    //echo "<pre>";
    //print_r($data['mark_entry_list']);exit();
    //echo "</pre>";
    $this->load->view('result/get_mark_entry_json', $data);
 
 }


 public function get_mark_entry_report_json(){

    $class_id = $_POST['class_id'];
    $group_id = $_POST['group_id'];
    $session_id = $_POST['session_id'];
    $data['mark_entry_report'] = $this->Result_model->get_mark_entry_report_json($class_id, $group_id, $session_id);
    //echo "<pre>";
    //print_r($data['mark_entry_report']);exit();
    //echo "</pre>";
    $this->load->view('result/get_mark_entry_report_json', $data);
 }





 public function get_mark_entry_save(){

            //echo "<pre>";
            //print_r($_POST);
            //echo "</pre>";
            //exit();
         
            $student_id         = $_POST['student_id'];
            $student_name        = $_POST['student_name'];
            $gender  = $_POST['gender'];
            $student_image        = $_POST['student_image'];
            $present_address         = $_POST['present_address'];
            $father_name   = $_POST['father_name'];
            $mobile_contact        = $_POST['mobile_contact'];
            $student_class_id        = $_POST['student_class_id'];
            $roll_no  = $_POST['roll_no'];
            $session_id        = $_POST['session_id'];
            $section_id            = $_POST['section_id'];
            $group_id      = $_POST['group_id'];
            $class_id      = $_POST['class_id'];
            $class_name            = $_POST['class_name'];
            $class_short_form      = $_POST['class_short_form'];
            $gpa      = $_POST['gpa'];
            $grade        = $_POST['grade'];
            $registration        = $_POST['registration'];
            $participate          = $_POST['participate'];
            $count = count($this->input->post('student_name'));
            
            for($i=0;$i<$count;$i++){ 
                $data = array(                  
                    'student_id'       => $student_id[$i],              
                    'student_name'        => $student_name[$i],
                    'gender'       => $gender[$i],
                    'student_image' => $student_image[$i],
                    'present_address'       => $present_address[$i],
                    'father_name'        => $father_name[$i],
                    'mobile_contact'  => $mobile_contact[$i],
                    'student_class_id'       => $student_class_id[$i],
                    'roll_no'       => $roll_no[$i],
                    'session_id' => $session_id[$i],
                    'section_id'       => $section_id[$i],
                    'group_id'           => $group_id[$i],
                    'class_id'     => $class_id[$i],
                    'class_name'     => $class_name[$i],
                    'class_short_form'           => $class_short_form[$i],
                    'gpa'     => $gpa[$i],
                    'grade'     => $grade[$i],
                    'registration'       => $registration[$i],
                    'participate'         => $participate[$i],             
                );
                $insert         = $this->Common_model->common_insert($data,'tbl_jsc_ssc_result');
            }//exit;

            if($insert)
            {
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
            }
            else
            {
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
            }
            redirect('result/mark_entry');

 }


 function mark_entry_report(){

    $school_id = 1;
    $data['session_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
    $this->load->view('result/mark_entry_report', $data);

 }




//Ssc, Jsc, Psc Result Sheet End//






function subject_list_ajax_ct()
    {
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
		$group_id = $_POST['group_id'];
        
		//$sectionInfo = $this->Admin_model->get_section_list_by_id($class_id, $school_id); 
        $subInfo = $this->Academic_model->get_sub_list_by_id_ct($class_id, $school_id,$group_id); 
        
		$str = '<option value="">----Select Subject----</option>';
        
		if($subInfo)
        {
           foreach($subInfo as $sInfo)
           {
              $str .= "<option value='".$sInfo['subject_id']."'>".$sInfo['subject_name']."</option>";
           }
        }
        echo $str;exit;
    }

function subject_list_ajax()
    {
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
		$group_id = $_POST['group_id'];
        
		//$sectionInfo = $this->Admin_model->get_section_list_by_id($class_id, $school_id); 
        $subInfo = $this->Academic_model->get_sub_list_by_id($class_id, $school_id,$group_id); 
        
		$str = '<option value="">----Select Subject----</option>';
        
		if($subInfo)
        {
           foreach($subInfo as $sInfo)
           {
              $str .= "<option value='".$sInfo['subject_id']."'>".$sInfo['subject_name']."</option>";
           }
        }
        echo $str;exit;
    }
	
	function group_list_ajax()
    {
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
        $sectionInfo = $this->Academic_model->get_group_list_by_id($class_id, $school_id); 
        $str = '<option value="">----Select Group----</option>';
        if($sectionInfo)
        {
           foreach($sectionInfo as $sInfo)
           {
              $str .= "<option value='".$sInfo['group_id']."'>".$sInfo['group_name']."</option>";
           }
        }
        echo $str;exit;
    }
	
	
  

	
	/************** /result ***************/
    

  public function result_view()
      {
      #$school_id = $_SESSION['school_id'];
        $school_id = 1;
       $data['class_list'] = $this->Admin_model->get_class_list($school_id);
       $data['term'] = $this->Academic_model->get_term_list($school_id); 

      $this->load->view('result/result_view',$data);
      }
      
      
   	  function result_marks_json()
	  {
  #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_GET['class_id'];
		$section_id = $_GET['section_id'];
		$term_id = $_GET['term_id'];
        $exam_year = $_GET['exam_year'];
        $data['student_list'] = $this->Academic_model->get_class_wise_student_list_admit($school_id, $class_id,$section_id);
        $data['term'] = $this->Academic_model->get_term_list_by_id($term_id,$school_id); 

        $data['details'] =  array("class"=>$class_id,"section_id"=>$section_id,"term_id"=>$term_id,"exam_year"=>$exam_year,'sub_id'=>$sub_id);
	
					$mainContent=$this->load->view('result/result_view_json', $data, true);
        
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
  
  }
		
	
	 public function ssc_result()
    {
        $this->load->view('result/ssc_result');
    }
     public function psc_result()
    {
        $this->load->view('result/psc_result');
    }
	public function mark_sheet(){
		#$school_id = $_SESSION['school_id'];
		$school_id = 1;
		$data['class_list'] = $this->Admin_model->get_class_list($school_id);
		$data['term_list'] =  $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
		$data['session_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
		$data['shift_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_shift');
		$this->load->view('result/mark_sheet',$data);
	}
	  
	public function get_student_list_marksheet(){
        #$school_id = $_SESSION['school_id'];
        $s_data['tbl_student_class.school_id'] = 1;
        $s_data['tbl_student_class.class_id'] = $_POST['class_id'];
        $s_data['tbl_student_class.section_id'] = $_POST['section_id'];
        $s_data['tbl_student_class.group_id'] = $_POST['group_id'];
		$s_data['tbl_student_class.session_id'] = $_POST['session_id'];
		$s_data['tbl_student_class.shift_id'] = $_POST['shift_id'];
        $stuInfo =  $this->Result_model->selece_student_marksheet($s_data);
       
        $str = '<option value="">---- Select student ----</option>';
        if($stuInfo)
        {
           foreach($stuInfo as $stuInfos)
           {
              $str .= "<option value='".$stuInfos['student_id']."'>".$stuInfos['student_id'].'-'.$stuInfos['student_name']."</option>";
           }
        }
        echo $str;exit;
	
    }
	
	public function mark_sheet_json()
    {
		$school_id              = 1;
		$class_id               = $_GET['class_id'];
		$class_short_form       = $_GET['class_short_form'];
		$section_id             = $_GET['section_id'];
		$group_id             	= $_GET['group_id'];
		$shift_id               = $_GET['shift_id'];
		$session_id             = $_GET['session_id'];
		$student_id             = $_GET['student_id'];
		$term_id                = $_GET['term_id'];
		$term_name              = $_GET['term_name'];
		$session                = $_GET['session'];// this session use here as exam year
        $view_type              = $_GET['view_type'];
		
        if($view_type == 'all'){
            $student_list       = $this->Result_model->get_student_lists($school_id,$session_id,$class_id,$shift_id,$section_id,$group_id,$session,$term_id);
        }else{
            $student_list       = array(array('student_id' => $student_id));
        }
        if($class_id>3){$static_group_id = $group_id;}else{$static_group_id = 4;}
		
        $std_transcript         = array();
        $data['ranks_by_gpa']   = $this->tabulation_marks_json_func($school_id, $class_id, $class_short_form, $section_id, $shift_id, $session_id, $term_id, $session, $static_group_id);
        
        foreach($student_list as $i=>$std_list) {
            $student_id = $std_list['student_id'];

            // main code start here
            $data['student_mark_info'] = $this->Result_model->get_student_marksheet_info($school_id, $class_id, $student_id, $term_id, $session);
            if ($class_short_form >= 11) {
                $data['student_info'] = $this->Result_model->mark_sheet_student_info_with_optional($school_id, $session_id, $student_id, $class_id);
                $data['optional'] = $data['student_info']['subject_id'];
            } else {
                $data['student_info'] = $this->Result_model->mark_sheet_student_info($school_id, $session_id, $student_id, $class_id);
                $data['optional'] = '';
                $data['optional_sub_id'] = $this->Result_model->get_student_optional_subject_id($school_id, $class_id, $student_id);
            }

            $data['max_mark'] = $this->Result_model->get_max_subject_number($school_id, $class_id, $term_id, $session);
            $data['ranks'] = $this->Result_model->get_student_rank($school_id, $class_id, $section_id, $shift_id, $term_id, $session);

            $data['grd_system'] = $this->Common_model->common_select_by_condition($school_id, 'school_id', 'tbl_grd_system');
            $data['details'] = array('term_name' => $term_name, 'session' => $session, 'class_short_form' => $class_short_form);
            $data['student_info'] = $this->Admin_model->get_student_info_by_id($school_id, $student_id, $session_id);
            $data['school_info'] = $this->Admin_model->get_school_information($school_id);
            // main code end here
            $std_transcript[$i]['std_transcript']   = $data;
        }
        $data['std_transcripts'] = $std_transcript;
		$mainContent=$this->load->view('result/mark_sheet_json', $data, true);
		$result = 'success';
		$return = array('result' => $result, 'mainContent'=> $mainContent);
		print json_encode($return);
		exit;   

	}
  /************** /result ***************/
  	
 /***  tabulation sheet ***/
 
 	public function tabulation_sheet(){
		#$school_id = $_SESSION['school_id'];
		$school_id = 1;
		$data['class_list'] = $this->Admin_model->get_class_list($school_id);
		$data['term_list'] =  $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
		$data['session_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
		$data['shift_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_shift');
		$this->load->view('result/tabulation_sheet',$data);
	}	
	
	public function tabulation_marks_json()
	{
		$school_id = 1;
        $class_id = $_GET['class_id'];
		$section_id = $_GET['section_id'];
		$group_id = $_GET['group_id'];
		$shift_id = $_GET['shift_id'];
		$session_id = $_GET['session_id'];
		$term_id = $_GET['term_id'];
        $exam_year = $_GET['exam_year'];
		
		//$class_short_form = $_GET['class_short_form'];
		//$term_name = $_GET['term_name'];
		//$session = $_GET['session'];
		
		// previous code start		
		$data['subject_infos'] = $this->Result_model->tab_mark_distribution_list_result($school_id,$class_id,$group_id,$term_id);
		
		//$data['student_list']=$this->Result_model->get_student_list_tabu($school_id,$session_id,$class_id,$shift_id,$section_id,$group_id,$exam_year,$term_id);
		//$data['ranks'] = $this->Result_model->get_student_rank($school_id,$class_id,$section_id,$shift_id,$term_id,$exam_year);
		//$data['grd_system'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_grd_system');
		$data['school_info'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_school_information');
		$data['details']=array("term_name"=>$_GET['term_name'],"class_name"=>$_GET['class_name'],"section_name"=>$_GET['section_name'],"group_name"=>$_GET['group_name'],"shift_name"=>$_GET['shift_name'],"exam_year"=>$exam_year);
		// previous code end
		
		$grd_system 		= $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_grd_system');
		$ranks 				= $this->Result_model->get_student_rank($school_id,$class_id,$section_id,$shift_id,$term_id,$exam_year);
        $ranks_by_gpa		= $this->Result_model->get_student_rank_by_gpa($school_id,$class_id,$section_id,$shift_id,$term_id,$exam_year);
		
		$student_list		= $this->Result_model->get_student_list_tabu_group($school_id,$session_id,$class_id,$shift_id,$section_id,$group_id,$exam_year,"(".$term_id.")");
		//print_r($student_list);exit;
		$val 			= array();
		$total_student 	= count($student_list);
		$tfail			= 0;
		foreach($student_list as $k=>$students_info){
		//if($students_info['student_id'] == '1001809'){
			$total_marks		= 0;
			$std_subj_mark		= array();	
			$sub_array			= array();	
			$student_mark_info 	= $this->Result_model->get_student_marksheet_info($students_info['school_id'],$students_info['class_id'],$students_info['student_id'],$students_info['term_id'],$exam_year);
			$optional_sub_id	= $this->Result_model->get_student_optional_subject_id($students_info['school_id'],$students_info['class_id'],$students_info['student_id']);
			//print_r($optional_sub_id);exit;
			$getbn=0; $getbnsubj=0; $getbnobj=0; $bnsubj=0; $bnobj=0; $getbnsubjpass=0; $getbnobjpass=0; $geten=0; $getensubj=0; $ensubj=0; $getensubjpass=0; $total_gpa=0; $pass_flag='1'; $optional_sub_flag = 0;$ttl_mark = 0;
			foreach($student_mark_info as $maks_info){
				
				// get optional subject exact gpa
                if($maks_info['subject_id']==$optional_sub_id['subject_id']){
                    $optional_sub_flag = 1;
                    if($maks_info['gpa']>2){$total_gpa = $total_gpa+($maks_info['gpa']-2);}
                }else {
                    // student wise total gp count start
                    if ($maks_info['subject_id'] == 2 || $maks_info['subject_id'] == 1) {
                        if(explode('*',$maks_info['sub'])[0]){$bnsubj = explode('*',$maks_info['sub'])[0];}
                        $getbnsubj      = $getbnsubj + $bnsubj;
                        $getbnsubjpass  = $getbnsubjpass+(floor(explode('*',$maks_info['sub'])[1]*$maks_info['p_mark']/100));
                        //
                        if(explode('*',$maks_info['obj'])[0]){$bnobj = explode('*',$maks_info['obj'])[0];}
                        $getbnobj       = $getbnobj + $bnobj;
                        $getbnobjpass   = $getbnobjpass+(round(explode('*',$maks_info['obj'])[1]*$maks_info['p_mark']/100));
                                    ///
                        $getbn = $getbn + $maks_info['sub_total'];
                    } elseif ($maks_info['subject_id'] == 4 || $maks_info['subject_id'] == 3) {
                        if(explode('*',$maks_info['sub'])[0]){$ensubj = explode('*',$maks_info['sub'])[0];}
                        $getensubj      = $getensubj + $ensubj;
                        $getensubjpass  = $getensubjpass+(round(explode('*',$maks_info['sub'])[1]*$maks_info['p_mark']/100));
                                    ///
                        $geten = $geten + $maks_info['sub_total'];
                    } else {
                        if ($maks_info['gpa'] != 0) {
                            $total_gpa = $total_gpa + $maks_info['gpa'];
                        }else{
                            $pass_flag = '0';/*$total_gpa=0;break;*/
                        }
                    }
                }
				$ttl_mark = $ttl_mark+$maks_info['sub_total'];
				// student wise total gp count end
				//student wise subject info start
				$getbnm=0;$getbnms=0; $getenm=0;$subj_total=0;$sub_pass=1;$obj_pass=1;$prac_pass=1;$sub_gpa=0;
				foreach($data['subject_infos'] as $i=>$stu_data){
					if($stu_data['subject_id'] == $maks_info['subject_id'])
					{	//print_r(explode('*',$maks_info['sub']));
						//echo ' not else ';				
						//start student subject mark calculation
						$subj_id		= $maks_info['subject_id'];
						$pass_id		= $maks_info['pass_id'];
						$subj_sub		= explode('*',$maks_info['sub'])[0];
						$subj_obj		= explode('*',$maks_info['obj'])[0];
						$subj_pract		= explode('*',$maks_info['prac'])[0];
						$subj_total		= ($subj_sub+$subj_obj+$subj_pract);
						$ttl_full_mark	= $maks_info['f_mark'];
						$ttl_pass_mark	= $maks_info['p_mark'];
                        $sub_gpa	    = $maks_info['gpa'];
                        // subj, obj, pract wise pass mark check
                        if($pass_id==1){
                            if($subj_sub<(round(explode('*',$maks_info['sub'])[1]*$maks_info['p_mark']/100)))  $sub_pass  = 0;
                            if($subj_obj<(round(explode('*',$maks_info['obj'])[1]*$maks_info['p_mark']/100)))  $obj_pass  = 0;
                            if($subj_pract<(round(explode('*',$maks_info['prac'])[1]*$maks_info['p_mark']/100))) $prac_pass = 0;
                        }
						//if(count($subj_pract)>0){$subj_prac=$subj_pract;}else{$subj_prac=0;}
						if($maks_info['subject_id']==2){
							$subjectsin		= "1','2";
							$bn_en_total 	= $this->Result_model->get_bn_en_total($school_id,$students_info['student_id'],$term_id,$exam_year,$subjectsin);
                            $ttl_full_mark	= $bn_en_total[0]['full_mark'];
							$subj_total		= $bn_en_total[0]['total'];
                            $b_ttl_full_mark= $ttl_full_mark;
						}elseif($maks_info['subject_id']==4){
							$subjectsin		= "3','4";
							$bn_en_total 	= $this->Result_model->get_bn_en_total($school_id,$students_info['student_id'],$term_id,$exam_year,$subjectsin);
                            $ttl_full_mark	= $bn_en_total[0]['full_mark'];
							$subj_total		= $bn_en_total[0]['total'];
                            $e_ttl_full_mark= $ttl_full_mark;
						}
						
																
							$std_subj_mark[$i]['subj_id']		= $subj_id;
							$std_subj_mark[$i]['subj_sub']		= $subj_sub;
							$std_subj_mark[$i]['subj_obj']		= $subj_obj;
							$std_subj_mark[$i]['subj_prac']		= $subj_pract;
                            $std_subj_mark[$i]['sub_pass']		= $sub_pass;
                            $std_subj_mark[$i]['obj_pass']		= $obj_pass;
                            $std_subj_mark[$i]['prac_pass']		= $prac_pass;
							$std_subj_mark[$i]['subj_total']	= $subj_total;
							$std_subj_mark[$i]['ttl_full_mark']	= $ttl_full_mark;
							$std_subj_mark[$i]['ttl_pass_mark']	= $ttl_pass_mark;
							$std_subj_mark[$i]['sub_gpa']	    = $sub_gpa;

							
							break;
						
						//$subj_total[]	= ($subj_sub[]+$subj_obj[]);					
						//end student subject mark calculation						
					}
                }$sub_array[] = $maks_info['subject_code'];
				//student wise subject info end
				
			}//print_r($getbnsubj);//print_r($subj_obj);print_r($subj_prac);
            //print_r($getbnsubj); print_r($getbnsubjpass);
			//exit;

            // for check bn & eng subj, obj wise pass
            if(($getensubj<$getensubjpass)){
				$pass_flag = 0;
			}else {
				$do = 1;
				if(($getbnsubj<$getbnsubjpass) || ($getbnobj<$getbnobjpass)){
					// for check bangla 1st & 2nd paper subj, obj wise pass (only for 9&10)
					if(($get_class==4) ||($get_class==5)){$pass_flag = 0;$do = 0;}
				}
				
				if($do == 1)
				{
					// for bn total grade pointforeach($grd_system as $gplbn):
					$total_getbn = floor(($getbn*100)/$b_ttl_full_mark);
					$total_geten = floor(($geten*100)/$e_ttl_full_mark);

					foreach ($grd_system as $gplbn) {
						if ($gplbn['start_marks'] <= $total_getbn && $gplbn['end_marks'] >= $total_getbn) {
							$gpabn = $gplbn['grd_point'];
							$total_gpa = $total_gpa + $gpabn;

						}
					}

					foreach ($grd_system as $gplbn) {
						if ($gplbn['start_marks'] <= $total_geten && $gplbn['end_marks'] >= $total_geten) {
							$gpaen      = $gplbn['grd_point'];
							$total_gpa  = $total_gpa + $gpaen;
						}
					}
				}
			}//print_r($pass_flag); exit;
			// if any subject fail then make this student gp 0
			if($pass_flag!=1){$total_gpa = 0;}
			// for point calculation
			if (in_array('101', $sub_array, true)) 
			{				
				$avgpp=sprintf('%0.2f', $total_gpa/(count($student_mark_info)-(2+$optional_sub_flag)));
				$avgp=($avgpp > 5 ? 5 : $avgpp);
			}else
			{				
				$avgpp=sprintf('%0.2f', $total_gpa/(count($student_mark_info)-(0+$optional_sub_flag)));
				$avgp=($avgpp > 5 ? 5 : $avgpp);
			}
			
			// for grade system calculation
			foreach ($grd_system as $key => $row) {
				$mid[$key]  = $row['grd_point'];
			}
				// Sort the data with mid descending
				// Add $data as the last parameter, to sort by the common key
				array_multisort($mid, SORT_DESC, $grd_system);

				$i=0;
				while($i <= count($grd_system)) { 
					if ($grd_system[$i]['grd_point'] <= $avgp) { 
						$obtgpa=$grd_system[$i]['gpa'];
						break;
					} 
					$i++;
				}
			
			if($obtgpa=='F'){$tfail++;}
			// for merit list
			if(isset($avgp)){
				$key = array_search($students_info['student_id'], array_column($ranks_by_gpa, 'student_id'));
                if( $key !== false ) {$position = $key+1;}else{$position = count($ranks_by_gpa)+1;}
			}
		
		$val[$k]['position']		= $position;
		$val[$k]['student_id']		= $students_info['student_id'];
		$val[$k]['student_name']	= $students_info['student_name'];
		$val[$k]['roll_no']			= $students_info['roll_no'];
		$val[$k]['point']			= $avgp;
		$val[$k]['grade']			= $obtgpa;
		$val[$k]['subjects_mark']	= $std_subj_mark;
        $val[$k]['ttl_get_mark']	= $ttl_mark;
		//}
		}//print_r($val);
		$data['output']			= $val;
		$data['total_student']	= $total_student;
		$data['total_fail']		= $tfail;
	
		$mainContent=$this->load->view('result/tabulation_marks_json', $data, true);
        
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;  
	}

	public function bill_sheet_term(){
		#$school_id = $_SESSION['school_id'];
		$school_id = 1;
		$data['class_list'] = $this->Admin_model->get_class_list($school_id);
		$data['term_list'] =  $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
		$data['session_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
		$data['shift_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_shift');
		$this->load->view('result/tabulation_sheet_term_bill',$data);
	}

	public function tabulation_sheet_term_all(){
		#$school_id = $_SESSION['school_id'];
		$school_id = 1;
		$data['class_list'] = $this->Admin_model->get_class_list($school_id);
		$data['term_list'] =  $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
		$data['session_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
		$data['shift_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_shift');
		$this->load->view('result/tabulation_sheet_term_all',$data);
	}

	public function tabulation_sheet_term(){
		#$school_id = $_SESSION['school_id'];
		$school_id = 1;
		$data['class_list'] = $this->Admin_model->get_class_list($school_id);
		$data['term_list'] =  $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
		$data['session_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
		$data['shift_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_shift');
		$this->load->view('result/tabulation_sheet_term',$data);
	}

	
	public function tabulation_marks_term_json()
	{
        $school_id      = 1;
        $class_id       = $_GET['class_id'];
        $group_id       = $_GET['group_id'];
        $shift_id       = $_GET['shift_id'];
        $session_id     = $_GET['session_id'];
        $termid         = "('1','2','3','4')";
        $terms_id       = $_GET['term_id'];
        $exam_year      = $_GET['exam_year'];
        $bill      		= $_GET['bill'];

        // previous code start
        $data['school_info']    = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_school_information');
        $data['term_list']      = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
        $data['details']        = array("term_name"=>$_GET['term_name'],"class_name"=>$_GET['class_name'],"group_name"=>$_GET['group_name'],"shift_name"=>$_GET['shift_name'],"exam_year"=>$exam_year,"session_id"=>$session_id,"group_id"=>$group_id,"shift_id"=>$shift_id,"class_id"=>$class_id);
        $data['terms_id']       = $_GET['term_id'];
        // previous code end
        $student_list		    = $this->Result_model->get_student_list_tabu_group($school_id,$session_id,$class_id,$shift_id,'',$group_id,$exam_year,$termid);

        $grd_system 		    = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_grd_system');
        $val 			= array();
        $total_student 	= count($student_list);
        $tfail			= 0;
        foreach($student_list as $k=>$students_info){
            //if($students_info['student_id'] == '1000253'){

            $termavgp = array(); $ttlavgp = 0;
            foreach($terms_id as $t=>$term_id) {
                $total_marks		= 0;
                $std_subj_mark		= array();	
				$sub_array			= array();
                $data['subject_infos']  = $this->Result_model->tab_mark_distribution_list_result($school_id,$class_id,$group_id,$term_id);
                //print_r($student_list);exit;
                $student_mark_info 	    = $this->Result_model->get_student_marksheet_info($students_info['school_id'],$students_info['class_id'],$students_info['student_id'],$term_id,$exam_year);
                $optional_sub_id	    = $this->Result_model->get_student_optional_subject_id($students_info['school_id'],$students_info['class_id'],$students_info['student_id']);

                    $getbn = 0;
                    $getbnsubj = 0;
                    $getbnobj = 0;
                    $bnsubj = 0;
                    $bnobj = 0;
                    $getbnsubjpass = 0;
                    $getbnobjpass = 0;
                    $geten = 0;
                    $getensubj = 0;
                    $ensubj = 0;
                    $getensubjpass = 0;
                    $total_gpa = 0;
                    $pass_flag = '1';
                    $optional_sub_flag = 0;
                    foreach ($student_mark_info as $maks_info) {

                        // get optional subject exact gpa
						if($maks_info['subject_id']==$optional_sub_id['subject_id']){
							$optional_sub_flag = 1;
							if($maks_info['gpa']>2){$total_gpa = $total_gpa+($maks_info['gpa']-2);}
						}else {
							// student wise total gp count start
							if ($maks_info['subject_id'] == 2 || $maks_info['subject_id'] == 1) {
								if(explode('*',$maks_info['sub'])[0]){$bnsubj = explode('*',$maks_info['sub'])[0];}
								$getbnsubj      = $getbnsubj + $bnsubj;
								$getbnsubjpass  = $getbnsubjpass+(floor(explode('*',$maks_info['sub'])[1]*$maks_info['p_mark']/100));
								//
								if(explode('*',$maks_info['obj'])[0]){$bnobj = explode('*',$maks_info['obj'])[0];}
								$getbnobj       = $getbnobj + $bnobj;
								$getbnobjpass   = $getbnobjpass+(round(explode('*',$maks_info['obj'])[1]*$maks_info['p_mark']/100));
											///
								$getbn = $getbn + $maks_info['sub_total'];
							} elseif ($maks_info['subject_id'] == 4 || $maks_info['subject_id'] == 3) {
								if(explode('*',$maks_info['sub'])[0]){$ensubj = explode('*',$maks_info['sub'])[0];}
								$getensubj      = $getensubj + $ensubj;
								$getensubjpass  = $getensubjpass+(round(explode('*',$maks_info['sub'])[1]*$maks_info['p_mark']/100));
											///
								$geten = $geten + $maks_info['sub_total'];
							} else {
								if ($maks_info['gpa'] != 0) {
									$total_gpa = $total_gpa + $maks_info['gpa'];
								}else{
									$pass_flag = '0';/*$total_gpa=0;break;*/
								}
							}
						}
                        // student wise total gp count end
                        //student wise subject info start
                        $getbnm=0;$getbnms=0; $getenm=0;$subj_total=0;$sub_pass=1;$obj_pass=1;$prac_pass=1;$sub_gpa=0;
                        foreach($data['subject_infos'] as $i=>$stu_data){
                            if($stu_data['subject_id'] == $maks_info['subject_id'])
                            {	//print_r(explode('*',$maks_info['sub']));
                                //echo ' not else ';
                                //start student subject mark calculation
                                $subj_id		= $maks_info['subject_id'];
                                $pass_id		= $maks_info['pass_id'];
                                $subj_sub		= explode('*',$maks_info['sub'])[0];
                                $subj_obj		= explode('*',$maks_info['obj'])[0];
                                $subj_pract		= explode('*',$maks_info['prac'])[0];
                                $subj_total		= ($subj_sub+$subj_obj+$subj_pract);
                                $ttl_full_mark	= $maks_info['f_mark'];
                                $ttl_pass_mark	= $maks_info['p_mark'];
                                $sub_gpa	    = $maks_info['gpa'];
                                // subj, obj, pract wise pass mark check
                                if($pass_id==1){
                                    if($subj_sub<(round(explode('*',$maks_info['sub'])[1]*$maks_info['p_mark']/100)))  $sub_pass  = 0;
                                    if($subj_obj<(round(explode('*',$maks_info['obj'])[1]*$maks_info['p_mark']/100)))  $obj_pass  = 0;
                                    if($subj_pract<(round(explode('*',$maks_info['prac'])[1]*$maks_info['p_mark']/100))) $prac_pass = 0;
                                }
                                //if(count($subj_pract)>0){$subj_prac=$subj_pract;}else{$subj_prac=0;}			
								if($maks_info['subject_id']==2){
                                    $subjectsin		= "1','2";
                                    $bn_en_total 	= $this->Result_model->get_bn_en_total($school_id,$students_info['student_id'],$term_id,$exam_year,$subjectsin);
                                    $ttl_full_mark	= $bn_en_total[0]['full_mark'];
                                    $subj_total		= $bn_en_total[0]['total'];
                                    $b_ttl_full_mark= $ttl_full_mark;
                                }elseif($maks_info['subject_id']==4){
                                    $subjectsin		= "3','4";
                                    $bn_en_total 	= $this->Result_model->get_bn_en_total($school_id,$students_info['student_id'],$term_id,$exam_year,$subjectsin);
                                    $ttl_full_mark	= $bn_en_total[0]['full_mark'];
                                    $subj_total		= $bn_en_total[0]['total'];
                                    $e_ttl_full_mark= $ttl_full_mark;
                                }


                                $std_subj_mark[$i]['subj_id']		= $subj_id;
                                $std_subj_mark[$i]['subj_sub']		= $subj_sub;
                                $std_subj_mark[$i]['subj_obj']		= $subj_obj;
                                $std_subj_mark[$i]['subj_prac']		= $subj_pract;
                                $std_subj_mark[$i]['sub_pass']		= $sub_pass;
                                $std_subj_mark[$i]['obj_pass']		= $obj_pass;
                                $std_subj_mark[$i]['prac_pass']		= $prac_pass;
                                $std_subj_mark[$i]['subj_total']	= $subj_total;
                                $std_subj_mark[$i]['ttl_full_mark']	= $ttl_full_mark;
                                $std_subj_mark[$i]['ttl_pass_mark']	= $ttl_pass_mark;
                                $std_subj_mark[$i]['sub_gpa']	    = $sub_gpa;


                                break;

                                //$subj_total[]	= ($subj_sub[]+$subj_obj[]);
                                //end student subject mark calculation
                            }
						}$sub_array[] = $maks_info['subject_code'];
                        //student wise subject info end

                    }//print_r($getbnsubj);//print_r($subj_obj);print_r($subj_prac);
                    //exit;

                    // for check bn & eng subj, obj wise pass
                    if(($getensubj<$getensubjpass)){
						$pass_flag = 0;
					}else {
						$do = 1;
						if(($getbnsubj<$getbnsubjpass) || ($getbnobj<$getbnobjpass)){
							// for check bangla 1st & 2nd paper subj, obj wise pass (only for 9&10)
							if(($get_class==4) ||($get_class==5)){$pass_flag = 0;$do = 0;}
						}
						
						if($do == 1)
						{
							// for bn total grade pointforeach($grd_system as $gplbn):
							$total_getbn = floor(($getbn*100)/$b_ttl_full_mark);
							$total_geten = floor(($geten*100)/$e_ttl_full_mark);

							foreach ($grd_system as $gplbn) {
								if ($gplbn['start_marks'] <= $total_getbn && $gplbn['end_marks'] >= $total_getbn) {
									$gpabn = $gplbn['grd_point'];
									$total_gpa = $total_gpa + $gpabn;

								}
							}

							foreach ($grd_system as $gplbn) {
								if ($gplbn['start_marks'] <= $total_geten && $gplbn['end_marks'] >= $total_geten) {
									$gpaen      = $gplbn['grd_point'];
									$total_gpa  = $total_gpa + $gpaen;
								}
							}
						}
					}//print_r($pass_flag); exit;
                    // if any subject fail then make this student gp 0
                    if ($pass_flag != 1) {
                        $total_gpa = 0;
                    }
                    // for point calculation
					if (in_array('101', $sub_array, true)) 
					{				
						$avgpp  = $total_gpa / (count($student_mark_info) - (2 + $optional_sub_flag));
					}else
					{				
						$avgpp  = $total_gpa / (count($student_mark_info) - (0 + $optional_sub_flag));
					}

                    $termgpp    = sprintf('%0.2f', $avgpp);
                    $termavgp[] = ($avgpp > 5 ? 5 : $termgpp);
                    // sum total gpa
                    $ttlavgp = $ttlavgp+$avgpp;
            }
                $avgpp  = sprintf('%0.2f', ($ttlavgp/count($terms_id)));
                $avgp   = ($avgpp > 5 ? 5 : $avgpp);

                // for grade system calculation
                foreach ($grd_system as $key => $row) {
                    $mid[$key] = $row['grd_point'];
                }
                // Sort the data with mid descending
                // Add $data as the last parameter, to sort by the common key
                array_multisort($mid, SORT_DESC, $grd_system);

                $i = 0;
                while ($i <= count($grd_system)) {
                    if ($grd_system[$i]['grd_point'] <= $avgpp) {
                        $obtgpa = $grd_system[$i]['gpa'];
                        break;
                    }
                    $i++;
                }
                if ($obtgpa == 'F') {
                    $tfail++;
                }
			
			$criteria = 'no';
			$term_count	= count($termavgp);
			if($term_count>0)
			{
				$t2 = $termavgp[$term_count-1]; $t1 = $termavgp[$term_count-2];
				if(($t2 == '0') && ($t1>0)){$criteria = 'yes';}
			}
			if(isset($_GET['criteria'])){$criteria = 'no';}
			
			if($criteria == 'no')
			{
				$val[$k]['student_id']		= $students_info['student_id'];
				$val[$k]['student_name']	= $students_info['student_name'];
				$val[$k]['father_name']		= $students_info['father_name'];
				$val[$k]['mother_name']		= $students_info['mother_name'];
				$val[$k]['section_name']	= $students_info['section_name'];
				$val[$k]['roll_no']			= $students_info['roll_no'];
				$val[$k]['term_point']		= $termavgp;
				$val[$k]['point']			= $avgp;
				$val[$k]['grade']			= $obtgpa;
				//$val[$k]['subjects_mark']	= $std_subj_mark;
			}
            //}
        }//print_r($val);
        $data['output']			= $val;
        $data['total_student']	= count($val);
        $data['total_fail']		= $tfail;
        if(isset($_GET['promote'])){
            $mainContent = $this->load->view('result/student_yearly_promote_json', $data, true);
        }else if($bill == 'bill'){
            $mainContent = $this->load->view('result/tabulation_marks_term_bill_json', $data, true);
        }else{
            $mainContent = $this->load->view('result/tabulation_marks_term_json', $data, true);
        }

        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;
    }

    public function tabulation_marks_json_func($school_id, $class_id, $class_short_form, $section_id, $shift_id, $session_id, $term_id, $session, $static_group_id)
    {
        $school_id      = $school_id;
        $class_id       = $class_id;
        $section_id     = $section_id;
        $shift_id       = $shift_id;
        $session_id     = $session_id;
        $term_id        = $term_id;
        $exam_year      = $session;
        $group_id       = $static_group_id;

        // previous code start
        $data['subject_infos'] = $this->Result_model->tab_mark_distribution_list_result($school_id,$class_id,$group_id,$term_id);

        $grd_system 		= $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_grd_system');
        $student_list		= $this->Result_model->get_student_list_tabu_group($school_id,$session_id,$class_id,$shift_id,$section_id,$group_id,$exam_year,"(".$term_id.")");
        //$student_list       = $this->Result_model->get_student_lists($school_id,$session_id,$class_id,$shift_id,$section_id,$session,$term_id);
        //print_r($student_list);exit;
        $val 			= array();
        $total_student 	= count($student_list);
        $tfail			= 0;
        foreach($student_list as $k=>$students_info){
            //if($students_info['student_id'] == '1002771'){
            $total_marks		= 0;
            $std_subj_mark		= array();	
			$sub_array			= array();
            $student_mark_info 	= $this->Result_model->get_student_marksheet_info($students_info['school_id'],$students_info['class_id'],$students_info['student_id'],$students_info['term_id'],$exam_year);
            $optional_sub_id	= $this->Result_model->get_student_optional_subject_id($students_info['school_id'],$students_info['class_id'],$students_info['student_id']);
            //print_r($optional_sub_id);exit;
            $getbn=0; $getbnsubj=0; $getbnobj=0; $bnsubj=0; $bnobj=0; $getbnsubjpass=0; $getbnobjpass=0; $geten=0; $getensubj=0; $ensubj=0; $getensubjpass=0; $total_gpa=0; $pass_flag='1'; $optional_sub_flag = 0; $ttl_mark = 0;
            foreach($student_mark_info as $maks_info){

                // get optional subject exact gpa
                if($maks_info['subject_id']==$optional_sub_id['subject_id']){
                    $optional_sub_flag = 1;
                    if($maks_info['gpa']>2){$total_gpa = $total_gpa+($maks_info['gpa']-2);}
                }else {
                    // student wise total gp count start
                    if ($maks_info['subject_id'] == 2 || $maks_info['subject_id'] == 1) {
                        if(explode('*',$maks_info['sub'])[0]){$bnsubj = explode('*',$maks_info['sub'])[0];}
                        $getbnsubj      = $getbnsubj + $bnsubj;
                        $getbnsubjpass  = $getbnsubjpass+(floor(explode('*',$maks_info['sub'])[1]*$maks_info['p_mark']/100));
                        //
                        if(explode('*',$maks_info['obj'])[0]){$bnobj = explode('*',$maks_info['obj'])[0];}
                        $getbnobj       = $getbnobj + $bnobj;
                        $getbnobjpass   = $getbnobjpass+(round(explode('*',$maks_info['obj'])[1]*$maks_info['p_mark']/100));
                        ///
                        $getbn = $getbn + $maks_info['sub_total'];
                    } elseif ($maks_info['subject_id'] == 4 || $maks_info['subject_id'] == 3) {
                        if(explode('*',$maks_info['sub'])[0]){$ensubj = explode('*',$maks_info['sub'])[0];}
                        $getensubj      = $getensubj + $ensubj;
                        $getensubjpass  = $getensubjpass+(round(explode('*',$maks_info['sub'])[1]*$maks_info['p_mark']/100));
                        ///
                        $geten = $geten + $maks_info['sub_total'];
                    } else {
                        if ($maks_info['gpa'] != 0) {
                            $total_gpa = $total_gpa + $maks_info['gpa'];
                        }else{
                            $pass_flag = '0';/*$total_gpa=0;break;*/
                        }
                    }
                }
				$ttl_mark = $ttl_mark+$maks_info['sub_total'];
                // student wise total gp count end
                //student wise subject info start
                $getbnm=0;$getbnms=0; $getenm=0;$subj_total=0;$sub_pass=1;$obj_pass=1;$prac_pass=1;$sub_gpa=0;
                foreach($data['subject_infos'] as $i=>$stu_data){
                    if($stu_data['subject_id'] == $maks_info['subject_id'])
                    {	//print_r(explode('*',$maks_info['sub']));
                        //echo ' not else ';
                        //start student subject mark calculation
                        $subj_id		= $maks_info['subject_id'];
                        $pass_id		= $maks_info['pass_id'];
                        $subj_sub		= explode('*',$maks_info['sub'])[0];
                        $subj_obj		= explode('*',$maks_info['obj'])[0];
                        $subj_pract		= explode('*',$maks_info['prac'])[0];
                        $subj_total		= ($subj_sub+$subj_obj+$subj_pract);
                        $ttl_full_mark	= $maks_info['f_mark'];
                        $ttl_pass_mark	= $maks_info['p_mark'];
                        $sub_gpa	    = $maks_info['gpa'];
                        // subj, obj, pract wise pass mark check
                        if($pass_id==1){
                            if($subj_sub<(round(explode('*',$maks_info['sub'])[1]*$maks_info['p_mark']/100)))  $sub_pass  = 0;
                            if($subj_obj<(round(explode('*',$maks_info['obj'])[1]*$maks_info['p_mark']/100)))  $obj_pass  = 0;
                            if($subj_pract<(round(explode('*',$maks_info['prac'])[1]*$maks_info['p_mark']/100))) $prac_pass = 0;
                        }
                        //if(count($subj_pract)>0){$subj_prac=$subj_pract;}else{$subj_prac=0;}
                        if($maks_info['subject_id']==2){
                            $subjectsin		= "1','2";
                            $bn_en_total 	= $this->Result_model->get_bn_en_total($school_id,$students_info['student_id'],$term_id,$exam_year,$subjectsin);
                            $ttl_full_mark	= $bn_en_total[0]['full_mark'];
                            $subj_total		= $bn_en_total[0]['total'];
                            $b_ttl_full_mark= $ttl_full_mark;
                        }elseif($maks_info['subject_id']==4){
                            $subjectsin		= "3','4";
                            $bn_en_total 	= $this->Result_model->get_bn_en_total($school_id,$students_info['student_id'],$term_id,$exam_year,$subjectsin);
                            $ttl_full_mark	= $bn_en_total[0]['full_mark'];
                            $subj_total		= $bn_en_total[0]['total'];
                            $e_ttl_full_mark= $ttl_full_mark;
                        }


                        $std_subj_mark[$i]['subj_id']		= $subj_id;
                        $std_subj_mark[$i]['subj_sub']		= $subj_sub;
                        $std_subj_mark[$i]['subj_obj']		= $subj_obj;
                        $std_subj_mark[$i]['subj_prac']		= $subj_pract;
                        $std_subj_mark[$i]['sub_pass']		= $sub_pass;
                        $std_subj_mark[$i]['obj_pass']		= $obj_pass;
                        $std_subj_mark[$i]['prac_pass']		= $prac_pass;
                        $std_subj_mark[$i]['subj_total']	= $subj_total;
                        $std_subj_mark[$i]['ttl_full_mark']	= $ttl_full_mark;
                        $std_subj_mark[$i]['ttl_pass_mark']	= $ttl_pass_mark;
                        $std_subj_mark[$i]['sub_gpa']	    = $sub_gpa;


                        break;

                        //$subj_total[]	= ($subj_sub[]+$subj_obj[]);
                        //end student subject mark calculation
                    }
                }$sub_array[] = $maks_info['subject_code'];
                //student wise subject info end

            }//print_r($getbnsubj);//print_r($subj_obj);print_r($subj_prac);
            //print_r($getbnsubj); print_r($getbnsubjpass);
            //exit;

            // for check bn & eng subj, obj wise pass
            if(($getensubj<$getensubjpass)){
				$pass_flag = 0;
			}else {
				$do = 1;
				if(($getbnsubj<$getbnsubjpass) || ($getbnobj<$getbnobjpass)){
					// for check bangla 1st & 2nd paper subj, obj wise pass (only for 9&10)
					if(($get_class==4) ||($get_class==5)){$pass_flag = 0;$do = 0;}
				}
				
				if($do == 1)
				{
					// for bn total grade pointforeach($grd_system as $gplbn):
					$total_getbn = floor(($getbn*100)/$b_ttl_full_mark);
					$total_geten = floor(($geten*100)/$e_ttl_full_mark);

					foreach ($grd_system as $gplbn) {
						if ($gplbn['start_marks'] <= $total_getbn && $gplbn['end_marks'] >= $total_getbn) {
							$gpabn = $gplbn['grd_point'];
							$total_gpa = $total_gpa + $gpabn;

						}
					}

					foreach ($grd_system as $gplbn) {
						if ($gplbn['start_marks'] <= $total_geten && $gplbn['end_marks'] >= $total_geten) {
							$gpaen      = $gplbn['grd_point'];
							$total_gpa  = $total_gpa + $gpaen;
						}
					}
				}
			}//print_r($pass_flag); exit;
            // if any subject fail then make this student gp 0
            if($pass_flag!=1){$total_gpa = 0;}
            // for point calculation
			if (in_array('101', $sub_array, true)) 
			{				
				$avgpp=sprintf('%0.2f', $total_gpa/(count($student_mark_info)-(2+$optional_sub_flag)));
				$avgp=($avgpp > 5 ? 5 : $avgpp);
			}else
			{				
				$avgpp=sprintf('%0.2f', $total_gpa/(count($student_mark_info)-(0+$optional_sub_flag)));
				$avgp=($avgpp > 5 ? 5 : $avgpp);
			}

            // for grade system calculation
            foreach ($grd_system as $key => $row) {
                $mid[$key]  = $row['grd_point'];
            }
            // Sort the data with mid descending
            // Add $data as the last parameter, to sort by the common key
            array_multisort($mid, SORT_DESC, $grd_system);

            $i=0;
            while($i <= count($grd_system)) {
                if ($grd_system[$i]['grd_point'] <= $avgp) {
                    $obtgpa=$grd_system[$i]['gpa'];
                    break;
                }
                $i++;
            }

            if($obtgpa=='F'){$tfail++;}
            // for merit list

            //$val[$k]['position']		= $position;
            $val[$k]['student_id']		= $students_info['student_id'];
            $val[$k]['student_name']	= $students_info['student_name'];
            $val[$k]['roll_no']			= $students_info['roll_no'];
            $val[$k]['point']			= $avgp;
            $val[$k]['grade']			= $obtgpa;
            $val[$k]['ttl_get_mark']	= $ttl_mark;
            //$val[$k]['subjects_mark']	= $std_subj_mark;
            //}
        }//print_r($val);
        //$data['output']			= $val;
        //$data['total_student']	= $total_student;
        //$data['total_fail']		= $tfail;

        return $val;
    }

    public function student_class_roll_json()
    {
        $school_id      = 1;
        $class_id       = $_GET['class_id'];
        $group_id       = $_GET['group_id'];
        $shift_id       = $_GET['shift_id'];
        $section_id     = $_GET['section_id'];
        //$session_id     = $_GET['session_id'];
        $termid         = "('1','2','3','4')";
        //$terms_id       = $_GET['term_id'];
        $exam_year      = $_GET['exam_year'];

        // previous code start
        $data['school_info']    = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_school_information');
        $data['term_list']      = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
        $data['details']        = array("term_name"=>$_GET['term_name'],"class_name"=>$_GET['class_name'],"group_name"=>$_GET['group_name'],"shift_name"=>$_GET['shift_name'],"exam_year"=>$exam_year,"group_id"=>$group_id,"shift_id"=>$shift_id,"class_id"=>$class_id);
        //$data['terms_id']       = $_GET['term_id'];
        // previous code end
        $data['student_list']   = $this->Result_model->select_student_roll($school_id,$class_id,$shift_id,$section_id,$group_id,$exam_year);
        $mainContent = $this->load->view('result/student_roll_assign_json', $data, true);

        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;
    }





	
  public function tabulation_marks_print(){
  	#$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_GET['class_id'];
		$section_id = $_GET['section_id'];
		$group_id = $_GET['group_id'];
		$shift_id = $_GET['shift_id'];
		$session_id = $_GET['session_id'];
		$term_id = $_GET['term_id'];
        $exam_year = $_GET['exam_year'];
		
		$data['subject_infos'] = $this->Result_model->tab_mark_distribution_list_result($school_id,$class_id,$group_id,$term_id);
		
		$data['student_list']=$this->Result_model->get_student_list_tabu($school_id,$session_id,$class_id,$shift_id,$section_id,$group_id,$exam_year,$term_id);
		$data['grd_system'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_grd_system');
		$data['school_info'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_school_information');
		$data['details']=array("term_name"=>$_GET['term_name'],"class_name"=>$_GET['class_name'],"section_name"=>$_GET['section_name'],"group_name"=>$_GET['group_name'],"shift_name"=>$_GET['shift_name'],"exam_year"=>$exam_year);
		
		$this->load->view('result/tabulation_marks_print', $data);   
  }
 /***  /tabulation sheet ***/
 
 /***  tabulation sheet subject wise ***/
  public function tabulation_sheet_subject_wise(){
      	#$school_id = $_SESSION['school_id'];
       	$school_id = 1;
       	$data['class_list'] = $this->Admin_model->get_class_list($school_id);
		$data['term_list'] =  $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
		$data['session_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
		$data['shift_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_shift');
		$this->load->view('result/tabulation_sheet_subject_wise',$data);
	}
	
	public function tabulation_marks_subject_wise_json()
	{
		$school_id		= 1;
		$class_id 		= $_GET['class_id'];
		$section_id 	= $_GET['section_id'];
		$group_id 		= $_GET['group_id'];
		$shift_id 		= $_GET['shift_id'];
		$session_id 	= $_GET['session_id'];
		$subject_id 	= $_GET['subject_id'];
		$term_id 		= $_GET['term_id'];
		$exam_year 		= $_GET['exam_year'];
		$passing_id 	= $_GET['passing_id'];
		$type_id 		= $_GET['type_id'];
		$details_data 	= $_GET['details_data'];

		$data['final_submit'] 	= $this->Result_model->check_final_submit($school_id,$subject_id,$class_id,$group_id,$term_id,$exam_year,$section_id,$shift_id);
		$data['subject_infos'] 	= $this->Result_model->mark_distribution_list_result($school_id,$subject_id,$class_id,$group_id,$term_id);
		$data['student_list']	= $this->Result_model->get_student_list_sub_tabu($school_id,$session_id,$class_id,$shift_id,$section_id,$group_id,$subject_id,$exam_year,$term_id);

		$g_data['school_id']	= $school_id;
		$g_data['type_id']		= $type_id;
		$data['gp_list']		= $this->Common_model->common_select_by_multycondition($g_data,'tbl_grd_system');

		$data['details']		= array("class_id"=>$class_id,"section_id"=>$section_id,"session_id"=>$session_id,"details_data"=>$details_data,"subject_id"=>$subject_id,"term_id"=>$term_id,"exam_year"=>$exam_year,"school_id"=>$school_id,"group_id"=>$group_id,"shift_id"=>$shift_id,"passing_id"=>$passing_id,"type_id"=>$type_id);

		$mainContent=$this->load->view('result/tabulation_marks_subject_wise_json', $data, true);

		$result = 'success';
		$return = array('result' => $result, 'mainContent'=> $mainContent);
		print json_encode($return);
		exit;   
	}
  public function tabulation_marks_subject_wise_print(){
  	#$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
		$section_id = $_POST['section_id'];
		$group_id = $_POST['group_id'];
		$shift_id = $_POST['shift_id'];
		$subject_id = $_POST['subject_id'];
		$term_id = $_POST['term_id'];
        $exam_year = $_POST['exam_year'];
		$passing_id = $_POST['passing_id'];
		$type_id = $_POST['type_id'];
		
        $data['subject_infos'] = $this->Academic_model->subject_info_for_tabulation_sheet_subject_wise($school_id,$term_id,$exam_year,$class_id,$section_id,$subject_id);
	$data['school_infos'] = $this->Academic_model->admit_card_view_school($school_id);
	$data['student_list']=$this->Academic_model->get_class_wise_student_list($school_id,$class_id,$section_id,$group_id,$shift_id);
        $data['term']=$this->Academic_model->get_term_list_by_id($term_id,$school_id);
	
	$data['details']=array("class_id"=>$class_id,"section_id"=>$section_id,"subject_id"=>$subject_id,"term_id"=>$term_id,"exam_year"=>$exam_year,"school_id"=>$school_id,"group_id"=>$group_id,"shift_id"=>$shift_id,"passing_id"=>$passing_id,"type_id"=>$type_id);
		$this->load->view('academic/tabulation_marks_subject_wise_print', $data);
        
    }
  
   public function marks_status_change(){
   	$school_id = $_POST['school_id'];
        $class_id = $_POST['class_id'];
	$section_id = $_POST['section_id'];
	$group_id = $_POST['group_id'];
	$shift_id = $_POST['shift_id'];
	$subject_id = $_POST['subject_id'];
	$term_id = $_POST['term_id'];
        $exam_year = $_POST['exam_year'];
	$status = $_POST['status'];
		
	$data_term = array ('status'=>$status);
	$where_term = array("class_id"=>$class_id,"section_id"=>$section_id,"sub_id"=>$subject_id,"term_id"=>$term_id,"exam_year"=>$exam_year,"school_id"=>$school_id,"group_id"=>$group_id,"shift_id"=>$shift_id,"status"=>0);		
	$this->db->where($where_term);
	$this->db->update('tbl_term_marks', $data_term);
				
	$data = array ('status'=>$status);
	$where = array("class_id"=>$class_id,"section_id"=>$section_id,"subject_id"=>$subject_id,"term_id"=>$term_id,"exam_year"=>$exam_year,"school_id"=>$school_id,"group_id"=>$group_id,"shift_id"=>$shift_id,"status"=>0);
	$this->db->where($where);
	$this->db->update('tbl_ct_marks', $data);
	$this->session->set_flashdata('message', " Final submition successful ");
	redirect('school/tabulation_sheet_subject_wise','refresh');exit;  
	}
  
  public function tabulation_marks_save(){
	// single value
	$school_id = $_POST['school_id'];
	$exam_year = $_POST['exam_year'];
	$class_id = $_POST['class_id'];
	$section_id = $_POST['section_id'];
	$group_id = $_POST['group_id'];
	$shift_id = $_POST['shift_id'];
	$term_id = $_POST['term_id'];
	$subject_id = $_POST['subject_id'];
	$f_mark = $_POST['f_mark'];
	$p_mark = $_POST['p_mark'];
	$type_id = $_POST['type_id'];
	$pass_id = $_POST['pass_id'];

	// full mark
	$sub_mark=$_POST['sub_mark'];
	$obj_mark=$_POST['obj_mark'];
	$prac_mark=$_POST['prac_mark'];
	$mark_dis = explode('*', $_POST['mark_dis']);
	$all_mark_name=array('CA','CW','HW','CT','ASPJ');
	// array values
		
	$student_id = $_POST['student_id'];
	$other_mark = $_POST['other_mark'];
	$sub = $_POST['sub'];
	$obj = $_POST['obj'];
	$prac = $_POST['prac'];
	$sub_total = $_POST['sub_total'];
	$gpa = $_POST['gpa'];
		
	// get array value to insert
		for($i=0; $i < count($student_id); $i++){
			
			
			if($other_mark)
			{
				$other_marks = explode('*', $other_mark[$i]);
			
				for($mia=0; $mia < count($other_marks)-1; $mia++){
					
					$other_mark_s[str_replace('/', '', explode(',', $other_marks[$mia])[0])]=explode(',', $other_marks[$mia])[1].'*'.explode(',', $mark_dis[$mia])[1];

					$mark_dis_names[] = str_replace('/', '', explode(',', $other_marks[$mia])[0]);
				};

				foreach($all_mark_name as $all_mark_name_arr )
				{
					if(!in_array($all_mark_name_arr, $mark_dis_names))
					{
						$other_mark_s[$all_mark_name_arr]='0*0';
					}
				}
			}
			else
			{
				foreach($all_mark_name as $all_mark_name_arr )
				{
					$other_mark_s[$all_mark_name_arr]='0*0';
				}

			}

			$data_mark_info=array(
						'school_id' => $school_id,
						'exam_year' => $exam_year,
						'class_id' => $class_id,
						'section_id' => $section_id,
						'group_id' => $group_id,
						'shift_id' => $shift_id,
						'term_id' => $term_id,
						'student_id' => $student_id[$i],
						'subject_id' => $subject_id,
						'f_mark' => $f_mark,
						'p_mark' => $p_mark,
						'sub' => $sub[$i].'*'.$sub_mark,
						'obj' => $obj[$i].'*'.$obj_mark,
						'prac' => $prac[$i].'*'.$prac_mark,
						'sub_total' => $sub_total[$i],
						'gpa' => $gpa[$i],
						'pass_id' => $pass_id,
						'type_id' => $type_id,
						'status' => 0,
						'created_on' => date('Y-m-d H:i:s',time())
					);
				/*insert new data*/
			$data[] = array_merge($data_mark_info,$other_mark_s);
		}
		//print_r($data); die();
		/* delete data */
		$d_data['school_id'] = $_POST['school_id'];
		$d_data['exam_year'] = $_POST['exam_year'];
		$d_data['class_id'] = $_POST['class_id'];
		$d_data['section_id'] = $_POST['section_id'];
		$d_data['group_id'] = $_POST['group_id'];
		$d_data['shift_id'] = $_POST['shift_id'];
		$d_data['term_id'] = $_POST['term_id'];
		$d_data['subject_id'] = $_POST['subject_id'];
		$insert_apv=0;
		
		if($this->db->where($d_data)->count_all_results('tbl_tabulation_marks') > 0 ){
			if($this->Common_model->common_delete($d_data,'tbl_tabulation_marks')){
				$insert_apv=1;
			}
			else{
				$insert_apv=0;
			}
		}
		else{
			$insert_apv=1;
		}
		
		/* insart batch data */
		if($insert_apv==1){
			if($this->Common_model->common_insert_batch($data,'tbl_tabulation_marks'))
				$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
			else
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
		}
		else{
			$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
		}
			redirect('result/tabulation_sheet_subject_wise', 'refresh');
}
  
 	/*** / tabulation sheet subject wise ***/ 
	
	/**** result publish ****/
	public function result_publish(){
		#$school_id = $_SESSION['school_id'];
       	$school_id = 1;
		$data['term_list'] =  $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
		$data['session_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
		$this->load->view('result/result_publish',$data);
	}
	
	public function result_publish_json(){
		#$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $c_data['session_id'] = $_GET['session_id'];
		$c_data['term_id'] = $_GET['term_id'];
		$c_data['school_id'] = $school_id;
		
		$data['cs_list'] = $this->Result_model->get_class_section_list($school_id);
		$data['csp_list'] = $this->Result_model->get_class_section_Pub_list($c_data);
		$data['details']=array('session_id'=>$_GET['session_id'],'term_id'=>$_GET['term_id']);
		$mainContent=$this->load->view('result/result_publish_json', $data, true);
        
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
  
	}
	
	public function result_publish_change(){
		#$school_id = $_SESSION['school_id'];
       	$school_id = 1;
		$class_id = $_POST['class_id'];
		$section_id = $_POST['section_id'];
		$term_id = $_POST['term_id'];
		$session_id = $_POST['session_id'];
		$status = $_POST['status'];
		$row = $_POST['row'];
		
		$where_term = array("class_id"=>$class_id,"section_id"=>$section_id,"term_id"=>$term_id,"session_id"=>$session_id,"school_id"=>$school_id);
		$this->db->where($where_term);
		$query = $this->db->get('tbl_result_publish');
		if($query->num_rows() > 0){
			$this->db->where($where_term);
			$data_u['status']=$status;
			$this->db->update('tbl_result_publish', $data_u);
			$success = $this->db->affected_rows();
		}
		else{
			$data['school_id']=$school_id;
			$data['class_id']=$class_id;
			$data['section_id']=$section_id;
			$data['term_id']=$term_id;
			$data['session_id']=$session_id;
			$data['status']=$status;
			$data['created_on']=date('Y-m-d H:i:s',time());
			$this->db->insert('tbl_result_publish', $data);
			$success= $this->db->insert_id();
		}
		if($success > 0){
			if($status==1){
				echo "<button class='btn btn-danger' onclick='change_status($class_id,$section_id,$session_id,$term_id,0,$row)'>Unpublish </button>";
			}
			else{
				echo "<button class='btn btn-primary' onclick='change_status($class_id,$section_id,$session_id,$term_id,1,$row)'>Publish </button>";
			}
		}
	}
	/**** /result publish ****/
	
	 // student enrolment
	 
	public function student_enrollment(){
      	#$school_id = $_SESSION['school_id'];
       	$school_id = 1;
       	$data['class_list'] = $this->Admin_model->get_class_list($school_id);
		$data['session'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
      	$this->load->view('result/student_enrollment',$data);
    }
	public function student_enrollment_json(){
		#$school_id = $_SESSION['school_id'];
		$school_id              = 1;
		$class_id               = $_GET['class_id'];
		$session_id             = $_GET['session_id'];
		$data['student_list']   = $this->Academic_model->get_class_wise_student_list_admit($school_id, $class_id,$section_id);

			$mainContent=$this->load->view('result/student_enrollment_json', $data, true);
				
		$result = 'success';
		$return = array('result' => $result, 'mainContent'=> $mainContent);
		print json_encode($return);
		exit;
	}

    // students promoted code start here
    public function student_yearly_promote()
	{
        #$school_id = $_SESSION['school_id'];
        $condition              = " and class_id not in ('5') ";
        $school_id              = 1;
        $data['class_list']     = $this->Admin_model->get_select_class_list($school_id, $condition);
        $data['term_list']      = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
        $data['session_list']   = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
        $data['shift_list']     = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_shift');
        $this->load->view('result/student_yearly_promote',$data);
    }

    public function student_yearly_promote_save()
    {
        $school_id  = 1;
        $class_id   = $_POST['class_id'];
        $shift_id = $_POST['shift_id'];
        $group_id   = $_POST['group_id'];
        $session_id = $_POST['session_id'];

        for($i=0; $i < count($_POST['student_iddfsd']); $i++)
        {
            $d_data['student_id'] = $_POST['student_iddfsd'][$i];
            $this->Common_model->common_delete($d_data,'tbl_student_promote_class');

            if($_POST['std_check'][$_POST['student_iddfsd'][$i]] == 'on' ):
                $i_data[] = array (
                    'student_id'    =>$_POST['student_iddfsd'][$i],
                    'session_id'    =>$session_id,
                    'group_id'      =>$group_id,
                    'shift_id'      =>$shift_id,
                    'promote_class_id'=>$_POST['stdclassno-'.$i]
                );
            endif;
        }
        //print_r($i_data);
        //exit;
        /* this will insert new data */
        if($i_data):
            if($this->Common_model->common_insert_batch($i_data,'tbl_student_promote_class')):
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
            else:
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
            endif;
        endif;

        redirect('result/student_yearly_promote','refresh');
        exit;
    }

    public function student_yearly_final_promote(){
        #$school_id = $_SESSION['school_id'];
        $condition              = " and class_id not in ('1') ";
        $school_id              = 1;
        $data['class_list']     = $this->Admin_model->get_select_class_list($school_id, $condition);
        $data['term_list']      = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
        $data['session_list']   = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
        $data['shift_list']     = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_shift');
        $this->load->view('result/student_yearly_final_promote',$data);
    }

    public function student_yearly_final_promote_save()
    {
        $school_id  = 1;
        $class_id   = $_POST['class_id'];
        $shift_id   = $_POST['shift_id'];
        $group_id   = $_POST['group_id'];
        $session_id = $_POST['session_id'];
        $new_roll   = $_POST['new_roll'];
        $created_by = $_SESSION['user_id'];

        for($i=0; $i < count($_POST['students_id']); $i++)
        {
            $d_data['student_id']   = $_POST['students_id'][$i];
            $this->Common_model->common_delete($d_data,'tbl_student_promote_class');

            $d_data['session_id']   = $session_id;
            $this->Common_model->common_delete($d_data,'tbl_student_class');

            $i_data[] = array (
                'student_id'    =>$_POST['students_id'][$i],
                'roll_no'       =>$new_roll[$i],
                'session_id'    =>$session_id,
                'status'        =>1,
                'section_id'    =>$_POST['sectionno-'.$i],
                'school_id'     =>$school_id,
                'class_id'      =>$class_id,
                'group_id'      =>$_POST['groupno-'.$i],
                'shift_id'      =>$shift_id,
                'created_by'      =>$created_by
            );

        }
        //print_r($d_data);
        //exit;
        /* this will insert new data */
        if($i_data):
            if($this->Common_model->common_insert_batch($i_data,'tbl_student_class')):
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
            else:
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
            endif;
        endif;

        redirect('student_final_promote','refresh');
        exit;
    }
     public function student_groupall_promote_save()
      {  

        $data = array(
        'class_id' => $this->input->post('class_id'),
        'shift_id' => $this->input->post('shift_id'),
        'group_id' => $this->input->post('group_id'),
        'session_id' => $this->input->post('session_id'),
        'new_roll' => $this->input->post('new_roll'),
        
            );
        var_dump($data);
        exit();

           
    }
    public function student_change_group_final()
    {
        $condition              = " and class_id not in ('1','2','3') ";
        $school_id              = 1;
        $data['class_list']     = $this->Admin_model->get_select_class_list($school_id, $condition);
        $data['term_list']      = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
        $data['session_list']   = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
        $data['shift_list']     = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_shift');
                 
                 $this->load->view('result/student_change_group_final',$data);
    }

    // students promoted code start here
    public function student_roll_assign(){
        //$condition              = " and class_id not in ('5') ";
        $condition              = " ";
        $school_id              = 1;
        $data['class_list']     = $this->Admin_model->get_select_class_list($school_id, $condition);
        $data['term_list']      = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
        $data['session_list']   = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
        $data['shift_list']     = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_shift');
        $this->load->view('result/student_roll_assign',$data);
    }

    public function student_promote_class_json()
    {
        $school_id      = 1;
        $class_id       = $_GET['class_id'];
        $group_id       = $_GET['group_id'];
        $shift_id       = $_GET['shift_id'];
        $session_id     = $_GET['session_id'];
        $termid         = 1;
        $terms_id       = $_GET['term_id'];
        $exam_year      = $_GET['exam_year'];

        // previous code start
        $data['school_info']    = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_school_information');
        $data['term_list']      = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
        $data['details']        = array("term_name"=>$_GET['term_name'],"class_name"=>$_GET['class_name'],"group_name"=>$_GET['group_name'],"shift_name"=>$_GET['shift_name'],"exam_year"=>$exam_year,"session_id"=>$session_id,"group_id"=>$group_id,"shift_id"=>$shift_id,"class_id"=>$class_id);
        $data['terms_id']       = $_GET['term_id'];
        $data['sectionInfo']    = $this->Admin_model->get_section_list_by_id($class_id, $school_id);
        $data['groupInfo']      = $this->Academic_model->get_group_list_by_id($class_id, $school_id);
        // previous code end
        $data['student_list']	= $this->Result_model->get_student_promote_class($school_id,$session_id,$class_id,$group_id);

        $mainContent            = $this->load->view('result/final_promote_student_json', $data, true);

        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;
    }

      public function final_promote_group_json()
         {
        $school_id      = 1;
        $class_id       = $_GET['class_id'];
        $group_id       = $_GET['group_id'];
        $shift_id       = $_GET['shift_id'];
        $section_id     = $_GET['section_id'];
        //$session_id     = $_GET['session_id'];
        $termid         = "('1','2','3','4')";
        //$terms_id       = $_GET['term_id'];
        $exam_year      = $_GET['exam_year'];

        // previous code start
        $data['school_info']    = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_school_information');
        $data['term_list']      = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
        $data['details']        = array("term_name"=>$_GET['term_name'],"class_name"=>$_GET['class_name'],"group_name"=>$_GET['group_name'],"shift_name"=>$_GET['shift_name'],"exam_year"=>$exam_year,"group_id"=>$group_id,"shift_id"=>$shift_id,"class_id"=>$class_id);
        //$data['terms_id']       = $_GET['term_id'];
        // previous code end
        $data['groupInfo']    = $this->Academic_model->get_group_list_by_id($class_id, $school_id);
        $data['student_list']   = $this->Result_model->select_student_roll($school_id,$class_id,$shift_id,$section_id,$group_id,$exam_year);
        $mainContent = $this->load->view('result/final_promote_group_json', $data, true);

        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;
    }


    public function student_roll_assign_save()
    {//print_r($_POST);exit;
        $school_id          = 1;
        $class_id           = $_POST['class_id'];
        $shift_id           = $_POST['shift_id'];
        $group_id           = $_POST['group_id'];
        $session_id         = $_POST['session_id'];
        $new_roll           = $_POST['new_roll'];
        $student_class_id   = $_POST['student_class_id'];
        $created_by = $_SESSION['user_id'];

        for ($i = 0; $i < count($_POST['students_id']); $i++) {

            $i_data[] = array(
                'student_class_id' => $student_class_id[$i],
                'roll_no' => $new_roll[$i]
            );

        }
        //print_r($d_data);
        //exit;
        /* this will insert new data */
        if ($i_data) {
            if ($this->Common_model->common_batch_update('tbl_student_class', $i_data, 'student_class_id')) {
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
            }
        }

        redirect('student_roll_assign','refresh');
        exit;
    }

    public function student_change_section(){
        //$condition              = " and class_id not in ('5') ";
        $condition              = " ";
        $school_id              = 1;
        $data['class_list']     = $this->Admin_model->get_select_class_list($school_id, $condition);
        $data['term_list']      = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
        $data['session_list']   = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
        $data['shift_list']     = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_shift');
        $this->load->view('result/student_change_section',$data);
    }

    public function student_change_section_json()
    {
        $school_id      = 1;
        $class_id       = $_GET['class_id'];
        $group_id       = $_GET['group_id'];
        $shift_id       = $_GET['shift_id'];
        $section_id     = $_GET['section_id'];
        //$session_id     = $_GET['session_id'];
        $termid         = "('1','2','3','4')";
        //$terms_id       = $_GET['term_id'];
        $exam_year      = $_GET['exam_year'];

        // previous code start
        $data['school_info']    = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_school_information');
        $data['term_list']      = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
        $data['details']        = array("term_name"=>$_GET['term_name'],"class_name"=>$_GET['class_name'],"group_name"=>$_GET['group_name'],"shift_name"=>$_GET['shift_name'],"exam_year"=>$exam_year,"group_id"=>$group_id,"shift_id"=>$shift_id,"class_id"=>$class_id);
        //$data['terms_id']       = $_GET['term_id'];
        // previous code end
        $data['sectionInfo']    = $this->Admin_model->get_section_list_by_id($class_id, $school_id);
        $data['student_list']   = $this->Result_model->select_student_roll($school_id,$class_id,$shift_id,$section_id,$group_id,$exam_year);
        $mainContent = $this->load->view('result/student_change_section_json', $data, true);

        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;
    }

    public function student_change_section_save()
    {//print_r($_POST);exit;
        $school_id          = 1;
        $class_id           = $_POST['class_id'];
        $shift_id           = $_POST['shift_id'];
        $group_id           = $_POST['group_id'];
        $session_id         = $_POST['session_id'];
        $new_roll           = $_POST['new_roll'];
        $student_class_id   = $_POST['student_class_id'];
        $created_by = $_SESSION['user_id'];

        for ($i = 0; $i < count($_POST['students_id']); $i++) {

            $i_data[] = array(
                'student_class_id'  => $student_class_id[$i],
                'section_id'        =>$_POST['sectionno-'.$i]
            );

        }
        //print_r($i_data);
        //exit;
        /* this will insert new data */
        if ($i_data) {
            if ($this->Common_model->common_batch_update('tbl_student_class', $i_data, 'student_class_id')) {
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
            }
        }

        redirect('student_change_section','refresh');
        exit;
    }

    public function student_change_group_save()
          {//print_r($_POST);exit;
        $school_id          = 1;
        $class_id           = $_POST['class_id'];
        $shift_id           = $_POST['shift_id'];
        $group_id           = $_POST['group_id'];
        $session_id         = $_POST['session_id'];
        $new_roll           = $_POST['new_roll'];
        $student_class_id   = $_POST['student_class_id'];

        for ($i = 0; $i < count($_POST['students_id']); $i++) {

            $i_data[] = array(
                'student_class_id'  => $student_class_id[$i],
                'group_id'        =>$_POST['groupno-'.$i]
            );

        }
        //print_r($i_data);
        //exit;
        /* this will insert new data */
        if ($i_data) {
            if ($this->Common_model->common_batch_update('tbl_student_class', $i_data, 'student_class_id')) {
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
            }
        }

        redirect('student_change_group_final','refresh');
        exit;
    }


    // students promoted code end here
}