<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Attendance extends CI_Controller {

    public function __construct()
    {            
            //session_start();
            parent::__construct();
            $this->load->helper('form');
            $this->load->helper('url');
            //$this->load->model('admin_model', 'Admin_model', true);
			$this->load->model('attendance_model', 'Attendance_model', true);
            $this->load->model('common_model', 'Common_model', true);
            $this->load->library('form_validation');
            if(!is_loggedin())
            {
                redirect('login');
                exit;
            }		
    }
	
	
	/* Students attendance */
	public function student_attendance(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['class_list'] = $this->Attendance_model->get_class_list($school_id);
		$data['session'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
		$data['shift_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_shift');
        $this->load->view('attendance/student_attendance', $data);
    } 
    
	public function get_student_list_for_attendance_json(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_GET['class_id'];
		$section_id = $_GET['section_id'];
		$shift_id = $_GET['shift_id'];
		$session_id = $_GET['session_id'];
		$data['class_id']=$class_id;
		$data['section_id']=$section_id;
		$data['shift_id']=$shift_id;
		$data['session_id']=$session_id;
		
		$old_attendance=$this->Attendance_model->get_class_wise_att_student_list($school_id, $class_id, $section_id, $session_id,$shift_id);
		if(count($old_attendance) > 0){
			$data['student_details'] = $old_attendance;
		}
		else{
			$s_data['tbl_student.school_id']=$school_id;
			$s_data['tbl_student_class.class_id']=$class_id;
			$s_data['tbl_student_class.section_id']=$section_id;
			$s_data['tbl_student_class.shift_id']=$shift_id;
			$s_data['tbl_student_class.session_id']=$session_id;
			$data['student_details'] = $this->Attendance_model->get_class_wise_student_list($s_data, 'tbl_student_class.roll_no', 'ASC');
		}
			$mainContent=$this->load->view('attendance/get_student_list_for_attendance_json', $data, true);
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
    }
	
	/* student attendance insert and update */
	public function save_student_attendance(){
		#$school_id = $_SESSION['school_id'];
        $school_id = 1;
		$student_id = $_POST['student_id'];
		$status = $_POST['status'];
		$student_name = $_POST['student_name'];
		$mobile_contact = $_POST['mobile_contact'];
		$class_id = $_POST['class_id'];
		$section_id = $_POST['section_id'];
		$session_id = $_POST['session_id'];
		if(isset($_POST['att_id'])){
			$oldsms_status = $_POST['sms_status'];
			
			for($i=0; $i < count($_POST['att_id']); $i++){
				$osms_status=0;
				/* for absent sms */
				if($status[$i]==0 && $oldsms_status[$i]==0){
					$smsdata[]=array(
								'from' =>'MMLHS',
								'to' => $mobile_contact[$i],
								'text'=> $student_name[$i]." is absent from school today."
							);
					$osms_status=1;
				};
				
				$u_data[] = array(
						'att_id' => $_POST['att_id'][$i],
						'status' => $status[$i],
						'sms_status' => $osms_status,
						'att_update_date' => date('Y-m-d H:i:s',time())
						);
			}
		}
		else{
			for($i=0; $i < count($student_id); $i++){
				$sms_status=0;
				/* for absent sms */
				if($status[$i]==0){
					$smsdata[]=array(
								'from' =>'MMLHS',
								'to' => $mobile_contact[$i],
								'text'=> $student_name[$i]." is absent from school today."
							);
					$sms_status=1;
				};
				
				$i_data[] = array(
						'school_id' => $school_id,
						'session_id' => $session_id,
						'class_id' => $class_id,
						'section_id' => $section_id,
						'student_id' => $student_id[$i],
						'status' => $status[$i],
						'sms_status' => $sms_status,
						'att_date' => date('Y-m-d H:i:s',time())
						);
			}
		}
		if(isset($smsdata)){
			$this->absms($smsdata);
		};
		if(isset($u_data)){
			// update old attendance data
			if($this->Common_model->common_batch_update('tbl_student_attendance',$u_data,'att_id'))
				$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
			else
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
		}
		else{
				// insert new attendance data
			if($this->Common_model->common_insert_batch($i_data,'tbl_student_attendance'))
				$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
			else
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
		}
			redirect('attendance/student_attendance', 'refresh');
	}
	/* absent sms sent */
	public function absms($smsdata){
		$sms_json_data=json_encode($smsdata);
       $curl = curl_init();
		curl_setopt_array($curl, array(
		CURLOPT_URL => "http://107.20.199.106/restapi/sms/1/text/multi",
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => "",
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 30,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => "POST",
		CURLOPT_POSTFIELDS => '{ "messages": '.$sms_json_data.'}',
		CURLOPT_HTTPHEADER => array(
		"accept: application/json",
		"authorization: Basic d2VibGluazE6bGluazU1NjY=",
		"content-type: application/json"
		),
		));
		$response = curl_exec($curl);
		$err = curl_error($curl);
		curl_close($curl);
		if ($err) {
		echo "cURL Error #:" . $err;
		} else {
			$arr=json_decode($response,true);
			
			foreach($arr['messages'] as $msg){
				$sms_data[] = array(
					'sms_datas' => $msg['messageId'],
					'mobile' => $msg['to'],
					'sms_count' => $msg['smsCount'],
					'created_on' => date('Y-m-d H:i:s',time())
				);
			}
			$this->Common_model->common_insert_batch($sms_data,'tbl_notice_sms');
		}
	}
	
	/* teacher_attendance */
	public function teacher_attendance()
	{
		#$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $old_attendance=$this->Attendance_model->get_class_wise_att_teacher_list($school_id);
		if(count($old_attendance) > 0)
			$data['teacher_details'] = $old_attendance;
		else
			 $data['teacher_details'] = $this->Attendance_model->teacher_list('tbl_teacher_registration.school_id',$school_id,'tbl_teacher_registration.teacher_id,tbl_teacher_registration.teacher_name,tbl_designation.designation_name');
        $this->load->view('attendance/teacher_attendance', $data);
	}
	
	/* teacher attendance insert and update */
	public function save_teacher_attendance()
	{
		#$school_id = $_SESSION['school_id'];
        $school_id = 1;
		$teacher_id = $_POST['teacher_id'];
		$status = $_POST['status'];
		$absent_reason = $_POST['absent_reason'];
		
		if(isset($_POST['att_id'])){
			for($i=0; $i < count($_POST['att_id']); $i++){
			
				$u_data[] = array(
						'att_id' => $_POST['att_id'][$i],
						'status' => $status[$i],
						'absent_reason' => $absent_reason[$i],
						'att_update_date' => date('Y-m-d H:i:s',time())
						);
			}
		}
		else{
			for($i=0; $i < count($teacher_id); $i++){
			
				$i_data[] = array(
						'school_id' => $school_id,
						'teacher_id' => $teacher_id[$i],
						'status' => $status[$i],
						'absent_reason' => $absent_reason[$i],
						'att_date' => date('Y-m-d H:i:s',time())
						);
			}
		}
		if(isset($u_data)){
			// update old attendance data
			if($this->Common_model->common_batch_update('tbl_teacher_attendance',$u_data,'att_id'))
				$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
			else
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
		}
		else{
				// insert new attendance data
			if($this->Common_model->common_insert_batch($i_data,'tbl_teacher_attendance'))
				$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
			else
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
		}
		redirect('attendance/teacher_attendance', 'refresh');
	}
	
	
	/* report */
	
	/* Students attendance report */
	public function student_attendance_report(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['class_list'] = $this->Attendance_model->get_class_list($school_id);
		$data['session'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
        $this->load->view('attendance/student_attendance_report', $data);
    } 
	
    function get_student_list_by_class()
    {
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $s_data['tbl_student.school_id']=$school_id;
		$s_data['tbl_student_class.class_id']=$_POST['class_id'];
		$s_data['tbl_student_class.session_id']=$_POST['session_id'];
		//$sectionInfo = $this->Admin_model->get_section_list_by_id($class_id, $school_id); 
        $stuInfo = $this->Attendance_model->get_class_wise_student_list($s_data, 'tbl_student.student_name', 'ASC');
        
		$str = '<option value="">----Select Student----</option>';
        
		if($stuInfo)
        {
           foreach($stuInfo as $sInfo)
           {
              $str .= "<option value='".$sInfo['student_id']."'>".$sInfo['student_name']."</option>";
           }
        }
		print_r($stuInfo);
        echo $str;exit;
    }
	
	public function student_for_att_report_daily_json(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $att_date = date('Y-m-d',strtotime($_GET['att_date']));
		$data['att_date']= date('d M Y',strtotime($_GET['att_date']));
		$data['att_day']= date('l',strtotime($_GET['att_date']));
		$data['att_details'] = $this->Attendance_model->get_class_wise_att_count_daily($school_id,$att_date);
		 
			$mainContent=$this->load->view('attendance/student_att_report_daily', $data, true);
			
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
    }
	
	// student monthly report
	public function student_for_att_report_monthly_json(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $att_month = date('Y-').$_GET['month_id'];
		//$att_month = trim($_GET['month_id']).'-'.trim($_GET['month_id']); should be active
        $class_id = $_GET['class_id'];
        $student_id = $_GET['student_id'];
		
		if($student_id){
			$data['month_name'] =$_GET['month_name'];
			$data['student_name'] =$_GET['student_name'];
			$data['student_id'] =$_GET['student_id'];
			$data['class_name'] =$_GET['class_name'];
			$data['att_details'] = $this->Attendance_model->get_student_wise_att_count_monthly($school_id,$class_id,$att_month,$student_id);
			$mainContent=$this->load->view('attendance/student_att_report_student', $data, true);
		}
		else{
			$data['month_name'] = $_GET['month_name'];
			$data['class_name'] = $_GET['class_name'];
			$data['att_details'] = $this->Attendance_model->get_class_wise_att_count_monthly($school_id,$class_id,$att_month);
			$mainContent=$this->load->view('attendance/student_att_report_monthly', $data, true);
		}
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return); 
        exit;   
    }

    public function student_monthly_details()
    {
    	$year = $_GET['year'];
		$month = $_GET['month'];    	
		$student_id = $_GET['student_id'];
    	$data['att_details'] = $this->Attendance_model->get_monthly_att_details($year,$month,$student_id);
    	$this->load->view('attendance/student_monthly_details', $data);
    }
	
	/* Teacher attendance report */
	
	public function teacher_attendance_report(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['teacher_list'] = $this->Attendance_model->teacher_list('tbl_teacher_registration.school_id',$school_id,'tbl_teacher_registration.teacher_id,tbl_teacher_registration.teacher_name,tbl_designation.designation_name');
        $this->load->view('attendance/teacher_attendance_report', $data);
    } 

	// Teacher daily,monthly and teacher wise attendance report
	public function teacher_att_report_json(){
        #$school_id = $_SESSION['school_id'];
         $school_id = 1;
        $teacher_name_json = $this->Attendance_model->teacher_list('tbl_teacher_registration.school_id',$school_id,'tbl_teacher_registration.teacher_id,tbl_teacher_registration.teacher_name,tbl_designation.designation_name');
       
	$att_time=strtotime($_GET['att_date']);
	$att_date = date('Y-m-d',$att_time);
	//$att_date = $_GET['att_date'];
        $att_month = date('Y-').$_GET['month_id'];
        $teacher_id = $_GET['teacher_id'];
        $report_type = $_GET['report_type'];
		$repo_type='';
		if($report_type=='d'):
			$data['att_details'] = $this->Attendance_model->get_teacher_day_att($school_id,$att_date);
			$data['repo_type']='d';
			$data['teacher_name_json'] = $teacher_name_json;//$_GET['teacher_name_json'];
			$data['att_date']= date('d M Y',$att_time);
			$data['att_day']= date('l',$att_time);
		
		else:
			if($teacher_id):
				$data['att_details'] = $this->Attendance_model->get_teacher_wise_att($school_id,$teacher_id,$att_month);
				$data['repo_type']='t';
				$data['teacher_name_json']= $teacher_name_json;//$_GET['teacher_name_json'];
			else:
				$data['att_details'] = $this->Attendance_model->get_teacher_month_att($school_id,$att_month);
				$data['repo_type']='m';
				$data['teacher_name_json']= $teacher_name_json;//$_GET['teacher_name_json'];
			endif;
		endif;
		$data['month_name'] =$_GET['month_name'];
		$data['teacher_name'] =$_GET['teacher_name'];
		
		 $mainContent=$this->load->view('attendance/teacher_att_report_json', $data, true);
			
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=>$mainContent);
        print json_encode($return);
       // exit;   
    }
	
}
?>