<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Welcome extends CI_Controller {

    public function __construct()
        {            
            //session_start();
            parent::__construct();
            $this->load->helper('form');
            $this->load->helper('url');
            $this->load->model('admin_model', 'Admin_model', true);
            $this->load->model('common_model', 'Common_model', true); 
			$this->load->model('academic_model', 'Academic_model', true);            
            $this->load->model('general_model', 'General_model', true);            
            
         #   if(!is_loggedin())
         #   {
         #       redirect('admin_login');
         #       exit;
         #   }
        
        }
	
	function section_list_ajax()
    {
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
        $sectionInfo = $this->Admin_model->get_section_list_by_id($class_id, $school_id); 
        $str = '<option value="">----Select Section----</option>';
        if($sectionInfo)
        {
           foreach($sectionInfo as $sInfo)
           {
              $str .= "<option value='".$sInfo['section_id']."'>".$sInfo['section_name']."</option>";
           }
        }
        echo $str;
		exit;
    }
	

	public function get_old_routine_by_section_class_show()
	{
     	#$school_id = $_SESSION['school_id'];
     	$school_id = 1;
		$class_id = $_GET['class_id'];
		$section_id = $_GET['section_id'];
		$group_id = $_GET['group_id'];
		$shift_id = $_GET['shift_id'];
		$data= $this->Academic_model->get_old_routine_by_section_class_show($class_id, $school_id,$section_id,$group_id,$shift_id);
		 print json_encode($data);
        exit;   
	}
	
	
	public function structure_exam_routine_by_term()
    {
    	#$school_id = $_SESSION['school_id'];
     	$school_id = 1;
        $exam_term_id = $_POST['exam_term_id'];
        $column_no = $this->Academic_model->exam_show_get_class_count($school_id,$exam_term_id);
        $row_no = $this->Academic_model->exam_show_get_day_count($school_id,$exam_term_id);
        
       // print_r($column_no); die();
        $table='<table class="table table-striped table-bordered"><thead><tr style="border-top:1px;"><th colspan="2"></th>';
        foreach ($column_no as $col_no)
				{
				$table.='<th id="exam_class_id" class="class_id'.$col_no['column_no'].'"></th>';
				}
                
        $table.='</tr><tr rowspan="2"><th style="min-width:125px; max-width:150px;">Exam Date</th><th style="min-width:125px; max-width:150px;">Exam Day</th>';
				foreach ($column_no as $col_no1)
				{
				 $table.='<th class="exam_time'.$col_no1['column_no'].'"></th>';
				}
				$table.='</tr></thead><tbody>';
				
				for($itdday=0; $itdday< $row_no;)
				{
					
					$table.='<tr class="date countvalue" id="'.$itdday.'"><td class="date'.$itdday.'"></td><td class="wkday'.$itdday.'"></td>';
					foreach ($column_no as $col_no2)
					{
						$table.='<td class="sub'.$col_no2['column_no'].'"></td>';
					}
					$table.='</tr>';
					$itdday++;
				}
				$table.='</tbody></table>';
        
        
		echo $table;
		exit;
    
    }
	 public function get_id_per_exam_term(){
        #$school_id = $_SESSION['school_id'];
     	$school_id = 1;
        $exam_term_id = $_POST['exam_term_id'];
        $sectionInfo = $this->Academic_model->get_id_per_exam_term($school_id,$exam_term_id);
		$str='';
        if($sectionInfo)
        {
           foreach($sectionInfo as $sInfo)
           {
              $str .= $sInfo['id']."|";
           }
		   echo $str;
        }
		exit;
    }
	
	 public function get_old_exam_routine_by_term_show()
	{
     	#$school_id = $_SESSION['school_id'];
     	$school_id = 1;
		$id = $_GET['id'];
		$data= $this->Academic_model->get_old_exam_routine_by_term_show($id);
		 print json_encode($data);
        exit;   
	}
	
	public function show_exam_routine_download()
    {
         #$school_id = $_SESSION['school_id'];
       $school_id = 1;
       $term_id=$_POST['term_id'];
	   $data['school_info'] = $this->Academic_model->admit_card_view_school($school_id);
       $data['column_no'] = $this->Academic_model->exam_show_get_class_count($school_id,$term_id);
       $data['row_no'] = $this->Academic_model->exam_show_get_day_count($school_id,$term_id);
       $data['full_routine']= $this->Academic_model->get_old_exam_routine_by_term_download($school_id,$term_id);
       $data['routine_class']= $this->Academic_model->get_old_exam_routine_by_term_download_class($school_id,$term_id);
       $data['routine_day_date']= $this->Academic_model->get_old_exam_routine_by_term_download_day_date($school_id,$term_id);
       $this->load->view('academic/show_exam_routine_download', $data);
    }
    
    function group_list_ajax()
    {
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
        $sectionInfo = $this->Academic_model->get_group_list_by_id($class_id, $school_id); 
        $str = '<option value="">----Select Section----</option>';
        if($sectionInfo)
        {
           foreach($sectionInfo as $sInfo)
           {
              $str .= "<option value='".$sInfo['group_id']."'>".$sInfo['group_name']."</option>";
           }
        }
        echo $str;exit;
    }
    
        public function index()
        { 
			$school_id = 1;
            $data['about'] = $this->General_model->get_about_by_school_id();
            $data['messages'] = $this->General_model->get_message_by_school_id();
			$data['gallery_images'] = $this->General_model->get_photo_gallery();
			$data['catagory_lists'] = $this->General_model->get_all_catagory_list($school_id);
            $data['notice_list'] = $this->General_model->get_all_latest_notice();
            $data['notice_list_last'] = $this->General_model->get_all_latest_notice_last();            
            $data['slide_image'] = $this->General_model->get_all_slide_image();
            $data['class_list'] = $this->General_model->get_all_class();
            $this->load->view('welcome/index', $data);
        }
        
        public function photo_gallery(){
            $data['photo_gallery'] = $this->General_model->get_photo_gallery();
			$data['catagory_list'] = $this->General_model->get_all_catagory_list($school_id);
			//$data['photo_list'] = $this->General_model->get_all_photo_list($school_id);

            $this->load->view('welcome/photo_gallery',$data);
        }
        
        public function contact(){
            $this->load->view('welcome/contact');
        }
        
        public function about_college(){           
            $data['about'] = $this->General_model->get_about_by_school_id();
            $this->load->view('welcome/about_college', $data);
        }
        
        public function message($message_id){           
            $data['messages'] = $this->General_model->get_message_by_id($message_id);
            $this->load->view('welcome/message', $data);
        }
        
        public function important_information(){
            $information_type = 1;
            $data['info_list'] = $this->General_model->get_information_list_by_id($information_type);
            $this->load->view('welcome/important_information',$data);
        }
        
        public function rules_regulations(){            
            $information_type = 2;
            $data['rules_list'] = $this->General_model->get_information_list_by_id($information_type);
            $this->load->view('welcome/rules_regulations',$data);
        }
        
        public function steps(){            
            $information_type = 3;
            $data['rules_list'] = $this->General_model->get_information_list_by_id($information_type);
            $this->load->view('welcome/steps',$data);
        }
        
        
        public function facilities(){            
            $information_type = 4;
            $data['rules_list'] = $this->General_model->get_information_list_by_id($information_type);
            $this->load->view('welcome/facilities',$data);
        }
        
        public function principal_list(){            
            $information_type = 5;
            $data['principal_list'] = $this->General_model->get_information_list_by_id($information_type);
            $this->load->view('welcome/principal_list',$data);
        }
        
        public function vice_principal_list(){            
            $information_type = 6;
            $data['vice_principal_list'] = $this->General_model->get_information_list_by_id($information_type);
            $this->load->view('welcome/vice_principal_list',$data);
        }
        
        public function library(){            
            $school_id = 1;
			$data['book_list'] = $this->General_model->get_all_book_list($school_id);
			$data['category_list'] = $this->General_model->get_all_book_category_list($school_id);
            $this->load->view('welcome/library', $data);
        }
        
         public function vacant_post(){            
            $information_type = 8;
            $data['vacant_post'] = $this->General_model->get_information_list_by_id($information_type);
            $this->load->view('welcome/vacant_post',$data);
        }
		
		 public function teacher_panel(){            
            $information_type = 9;
            $data['teacher_panel'] = $this->General_model->get_information_list_by_id($information_type);
            $this->load->view('welcome/teacher_panel',$data);
        }
		
		 public function student_panel(){            
            $information_type = 10;
            $data['student_panel'] = $this->General_model->get_information_list_by_id($information_type);
            $this->load->view('welcome/student_panel',$data);
        }
		
		 public function guardian_panel(){            
            $information_type = 11;
            $data['guardian_panel'] = $this->General_model->get_information_list_by_id($information_type);
            $this->load->view('welcome/guardian_panel',$data);
        }
        
        public function department(){
            $data['class_list'] = $this->General_model->get_all_class_assign_list();
            $this->load->view('welcome/department', $data);
        }
        
       	public function class_routine()
		{
			 $school_id = 1;
			$data['class_list'] = $this->Admin_model->get_class_list($school_id);
			$data['shift_list'] = $this->Academic_model->get_shift_list($school_id);
			//$c1 = $count['count'];
			$this->load->view('welcome/class_routine', $data);
			
		}
        
		public function get_class_routine_json_show(){
        #$school_id = $_SESSION['school_id'];
        $s_data['school_id'] = 1;
        $s_data['class_id'] = $_GET['class_id'];
		$s_data['section_id'] = $_GET['section_id'];
		$s_data['group_id'] = $_GET['group_id'];
		$s_data['shift_id'] = $_GET['shift_id'];
		
        $data['class_time'] = $this->Common_model->common_select_by_multycondition($s_data,'tbl_class_time_input');
		$data['week']= $this->Academic_model->get_weekdays($s_data['school_id']);
		$data['teacher']= $this->Academic_model->get_class_wise_teacher_list_routine($s_data['school_id'],$s_data['class_id'],$s_data['section_id']);
		$data['subject']= $this->Academic_model->get_class_wise_subject_list($s_data['class_id'],$s_data['school_id']);
	
			$mainContent=$this->load->view('academic/get_class_routine_json_show', $data, true);
			
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
    }
	
        public function class_routine_view(){
            $class_routine_id = $_GET['id'];
            $data['class_routine_list'] = $this->General_model->get_all_class_routine_by_id($class_routine_id);
            $this->load->view('welcome/class_routine_view', $data);
        }
        
        public function central_routine(){
            $data['central_routine'] = $this->General_model->get_central_routine();
            $this->load->view('welcome/central_routine', $data);
        }
        
        public function exam_routine()
    {
         #$school_id = $_SESSION['school_id'];
       $school_id = 1;
        //$data['class_count'] = $this->Admin_model->exam_show_get_class_count($school_id);
		 $data['term_list'] = $this->Academic_model->get_term_list($school_id);
         $data['subject_count']= $this->Academic_model->exam_get_subject_count($school_id);
		$data['count']= $this->Academic_model->exam_get_class_count($school_id);
         $data['exam_time'] = $this->Academic_model->exam_routine_time($school_id);
		$data['subject']= $this->Admin_model->get_subject_list($school_id);
		//$c1 = $count['count'];
        $this->load->view('welcome/exam_routine', $data);
    }
		
       /* public function exam_routine(){
            $data['exam_routine_list'] = $this->General_model->get_all_exam_routine_list();
            $this->load->view('welcome/exam_routine', $data);
        }*/
        
        public function exam_routine_view(){
            $exam_routine_id = $_GET['id'];
            $data['exam_routine_list'] = $this->General_model->get_all_exam_routine_by_id($exam_routine_id);
            $this->load->view('welcome/exam_routine_view', $data);
        }        
        
        public function general_notice(){
            $data['notice_list'] = $this->General_model->get_all_general_notice();
            $this->load->view('welcome/general_notice',$data);
        }
       
		public function forms(){
            $data['form_list'] = $this->General_model->get_all_form_data();
            $this->load->view('welcome/form_view',$data);
        }
		
        public function admission_notice(){
            $data['notice_list'] = $this->General_model->get_all_admission_notice();
            $this->load->view('welcome/admission_notice',$data);
        }
        
        public function single_notice($notice_id){
            $data['notice_info'] = $this->General_model->get_notice_info_by_id($notice_id);
            $this->load->view('welcome/single_notice',$data);
        }
        
        public function teacher(){
            $school_id = 1;
            $data['department_list'] = $this->General_model->get_all_department_list($school_id);
            $data['teacher_list'] = $this->General_model->get_all_teacher_list();
            $this->load->view('welcome/teacher', $data);
        }
        public function teacher_archive(){
            $school_id = 1;
            $data['department_list'] = $this->General_model->get_all_department_list($school_id);
            $data['teacher_list'] = $this->General_model->get_all_teacher_archive_list();
            $this->load->view('welcome/teacher_archive', $data);
        }
        public function student(){ 
		    
            $data['class_list'] = $this->General_model->get_all_class_assign_list();
            $this->load->view('welcome/student',$data);
        }
        
        public function student_details(){     
            $class_id = $_GET['cid'];
            $department_id = $_GET['did'];
            $data['student_list'] = $this->General_model->get_student_list_by_class_department_id($class_id, $department_id);
            $this->load->view('welcome/student_details',$data);
        }
        
        
       /* public function result(){
            $data['class_list'] = $this->General_model->get_all_class();
            $this->load->view('welcome/result', $data);
        }*/
        
        public function individual_result(){
            $data['exam_list'] = $this->General_model->get_all_exam();
            $data['session_list'] = $this->General_model->get_all_session();
            $this->load->view('welcome/individual_result', $data);
        }
        
       /* public function result_view(){          
            $student_id = $_POST['student_id'];
            $class_data = $this->General_model->get_student_info_by_student_id($student_id);
            
            $class_id = $class_data['class_id'];
            $department_id = $class_data['department_id'];
            $session_id = $_POST['session_id'];
            $exam_id = $_POST['exam_id'];            
            $data['exam_id'] = $exam_id;            
            $data['result_type']=$this->General_model->get_result_type_by_class_id($class_id);
            $data['student_info']=$this->General_model->get_student_info_by_student_id($student_id);
            
            $data['result_info']=$this->General_model->get_result_info_by_student_id($class_id, $department_id, $session_id, $exam_id, $student_id);
            $this->load->view('welcome/result_view', $data);
        }*/
        
        
        /**Ajax Data for Result View**/
        public function get_department_list_by_class_id(){            
            $class_id = $_GET['class_id'];
                        
            $department_list = $this->General_model->get_department_list_by_class_id($class_id);
            
            $mainContent='<option value="">---- Select Department ----</option>';
            if($department_list){
                foreach($department_list as $dl){
                    $department_id = $dl['department_id'];
                    $dept_name=$this->General_model->get_department_info_by_id($department_id);
                    $department_name=$dept_name['department_name'];
                    
                    $mainContent.='<option value="'.$dl['department_id'].'">'.$department_name.'</option>';
                }
            }           
            $result = 'success';
            $return = array('result' => $result, 'mainContent'=> $mainContent);
            print json_encode($return);
            exit;            
        }
		
		
        public function get_session_list_by_class_id(){
            $class_id = $_GET['class_id'];
            $session_list = $this->General_model->get_session_list_by_class_id($class_id);
            $mainContent='<option value="">---- Select Session ----</option>';
            if($session_list){
                foreach($session_list as $sl){
                    $session_id = $sl['session_id'];
                    $sess_name=$this->General_model->get_session_info_by_id($session_id);
                    $session_name=$sess_name['session_name'];
                    
                    $mainContent.='<option value="'.$sl['session_id'].'">'.$session_name.'</option>';
                }
            }           
            $result = 'success';
            $return = array('result' => $result, 'mainContent'=> $mainContent);
            print json_encode($return);
            exit;            
        }
		
            public function get_exam_list_by_class_id(){
            $class_id = $_GET['class_id'];
                        
            $exam_list = $this->General_model->get_exam_list_by_class_id($class_id);
            
            $mainContent='<option value="">---- Select Exam ----</option>';
            if($exam_list){
                foreach($exam_list as $el){
                    $exam_id = $el['exam_id'];
                    $ex_name=$this->General_model->get_exam_info_by_id($exam_id);
                    $exam_name=$ex_name['exam_name'];
                    
                    $mainContent.='<option value="'.$el['exam_id'].'">'.$exam_name.'</option>';
                }
            }           
            $result = 'success';
            $return = array('result' => $result, 'mainContent'=> $mainContent);
            print json_encode($return);
            exit;            
        }
        
		
        public function get_student_list_for_result_view(){
            $class_id = $_GET['class_id'];
            $department_id = $_GET['department_id'];
            $session_id = $_GET['session_id'];
            $exam_id = $_GET['exam_id'];
			
            $data['class_id']=$class_id;
            $data['department_id']=$department_id;
            $data['session_id']=$session_id;
            $data['exam_id']=$exam_id;

            $data['result_list']=$this->General_model->get_result_list_by_class_id($class_id, $department_id, $session_id, $exam_id);
            $data['fail_list']=$this->General_model->get_fail_list_by_class_id($class_id, $department_id, $session_id, $exam_id);           
            
            $data['result_type']=$this->General_model->get_result_type_by_class_id($class_id);
            
            
            $data['degree_result_list']=$this->General_model->get_degree_result_list_by_class_id($class_id, $department_id, $session_id, $exam_id);
            
            $data['degree_fail_list']=$this->General_model->get_degree_fail_list_by_class_id($class_id, $department_id, $session_id, $exam_id);
			
            $mainContent=$this->load->view('welcome/get_student_list_for_result_view', $data, true);
            
            $result = 'success';
            $return = array('result' => $result, 'mainContent'=> $mainContent);
            print json_encode($return);
            exit;              
        }
		
	   public function get_teacher_list_by_department_id(){
            $school_id = 1;
            $department_id = $_GET['department_id'];
			//echo $department_id; die();
            $data['tt']=$this->General_model->get_teacher_list_by_department($school_id, $department_id);
		 	$data['department_name']=$this->General_model->get_department_name($department_id);
			$mainContent=$this->load->view('welcome/teacher_department_wise', $data, true);
				
			$result = 'success';
            $return = array('result' => $result, 'mainContent'=>$mainContent);
            print json_encode($return);
            exit;            
        }		
		
		public function get_photo_list_by_catagory_id(){
            $school_id = 1;
            $catagory_id = $_GET['catagory_id'];
            $data['tt']=$this->General_model->get_photo_list_by_catagory($school_id, $catagory_id);
			$data['catagory_name']=$this->General_model->get_catagory_name($catagory_id);
			
			$mainContent=$this->load->view('welcome/photo_catagory_wise', $data, true);
 				
			$result = 'success';
            $return = array('result' => $result, 'mainContent'=>$mainContent);
           
            print json_encode($return);
            exit;            
        }
		
		public function get_book_list_by_category_id(){
			$school_id = 1;
            $category_id = $_GET['category_id'];
			//$data['category_id']= $_GET['category_id'];
			//$data['book_list'] = $this->Admin_model->get_all_book_list($school_id);
			//$data['category_list'] = $this->Admin_model->get_all_book_category_list($school_id);
            $data['tt']=$this->General_model->get_book_list_by_category($school_id, $category_id);
			$data['category_name']=$this->General_model->get_book_category_name($category_id);
			$mainContent=$this->load->view('welcome/book_category_wise', $data, true);
 				
			$result = 'success';
            $return = array('result' => $result, 'mainContent'=>$mainContent);
           
            print json_encode($return);
            exit;            
        }	
			
	/********************** result **************/
	
	 public function mark_sheet()
      {
      #$school_id = $_SESSION['school_id'];
        $school_id = 1;
       $data['class_list'] = $this->Admin_model->get_class_list($school_id);
       $data['term'] = $this->Academic_model->get_term_list($school_id); 

      $this->load->view('welcome/mark_sheet',$data);
      }
	  
  function get_student_list_marksheet()
    {
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
		$group_id = $_POST['group_id'];
		$section_id = $_POST['section_id'];
        $stuInfo =  $this->Academic_model->get_class_wise_student_list($school_id, $class_id,$section_id,$group_id);
       
        $str = '<option value="">---- Select student ----</option>';
        if($stuInfo)
        {
           foreach($stuInfo as $stuInfos)
           {
              $str .= "<option value='".$stuInfos['student_id']."'>".$stuInfos['student_id'].'-'.$stuInfos['student_name']."</option>";
           }
        }
        echo $str;exit;
		
    }
	
	public function mark_sheet_json()
	{
  		#$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_GET['class_id'];
		$section_id = $_GET['section_id'];
		$student_id = $_GET['student_id'];
		$term_id = $_GET['term_id'];
        $exam_year = $_GET['exam_year'];
		//echo $exam_year; die();
        $data['student_information'] = $this->Academic_model->get_class_wise_student_info_marksheet($school_id, $class_id,$section_id,$student_id);
        $data['term'] = $this->Academic_model->get_term_list_by_id($term_id,$school_id); 

        $data['details'] =  array("class_id"=>$class_id,"section_id"=>$section_id,"term_id"=>$term_id,"exam_year"=>$exam_year,'student_id'=>$student_id,'school_id'=>$school_id);
	
					$mainContent=$this->load->view('welcome/mark_sheet_json', $data, true);
        
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
  
  }
  
  public function print_mark_sheet()
	{
  		#$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
		$section_id = $_POST['section_id'];
		$student_id = $_POST['student_id'];
		$term_id = $_POST['term_id'];
        $exam_year = $_POST['exam_year'];
	//echo $exam_year.' class '.$class_id.' sec '.$section_id.' student '.$student_id.' term '.$term_id; die();
        $data['student_information'] = $this->Academic_model->get_class_wise_student_info_marksheet($school_id, $class_id,$section_id,$student_id);
        $data['term'] = $this->Academic_model->get_term_list_by_id($term_id,$school_id); 
		$data['school_info'] = $this->Academic_model->admit_card_view_school($school_id);
        $data['details'] =  array("class_id"=>$class_id,"section_id"=>$section_id,"term_id"=>$term_id,"exam_year"=>$exam_year,'student_id'=>$student_id,'school_id'=>$school_id);
	
		$this->load->view('welcome/print_mark_sheet', $data);
        
        
  
  }
  
   public function result_view()
      {
      #$school_id = $_SESSION['school_id'];
        $school_id = 1;
       $data['class_list'] = $this->Admin_model->get_class_list($school_id);
       $data['term'] = $this->Academic_model->get_term_list($school_id); 

      $this->load->view('welcome/result_view',$data);
      }
      
      
   	  function result_marks_json()
	  {
  #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_GET['class_id'];
		$section_id = $_GET['section_id'];
		$term_id = $_GET['term_id'];
        $exam_year = $_GET['exam_year'];
        $data['student_list'] = $this->Academic_model->get_class_wise_student_list_admit($school_id, $class_id,$section_id);
        $data['term'] = $this->Academic_model->get_term_list_by_id($term_id,$school_id); 

        $data['details'] =  array("class"=>$class_id,"section_id"=>$section_id,"term_id"=>$term_id,"exam_year"=>$exam_year,'sub_id'=>$sub_id);
	
					$mainContent=$this->load->view('welcome/result_view_json', $data, true);
        
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
  
  }
  /************************** / result ******************/
  
  public function academic_calendar(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
      // echo json_encode($this->Common_model->common_display('tbl_academic_calendar')); die();
        $this->load->view('welcome/academic_calendar');
    }
	public function get_event(){
        #$school_id = $_SESSION['school_id'];
        $s_data['school_id'] = 1;
       echo json_encode($this->Common_model->common_select_by_multycondition($s_data,'tbl_academic_calendar'));
    }	
}