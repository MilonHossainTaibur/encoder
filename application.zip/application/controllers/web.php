<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
class Web extends CI_Controller
{
    
    public function __construct()
    {
        //session_start();
        parent::__construct();
        $this->load->helper('form');
        $this->load->helper('url');
        $this->load->model('common_model', 'Common_model', true);
        $this->load->library('form_validation');
        if (!is_loggedin()) {
            redirect('login');
            exit;
        }
    }

    /**F**/
     public function freedom_fighter()
    {
        if (isPostBack()) {
            
            if ($_FILES AND $_FILES['f_photo']['name']) {
            	
               
                 if ($_POST['f_photo_old'] == '0'){
                 $config['upload_path']   = "upload/freedom_fighter";
                $config['allowed_types'] = "jpg|jpeg|png|gif";
                #$config['encrypt_name']  = true;
                $config['max_size']      = "720";
                $config['max_width']     = "1500";
                $config['max_height']    = "1500";
            	 	$config['overwrite']     =   false;				
                	$config['file_name']     = "freedom_fighter";
            	 }
            	 else{
            	  $config['upload_path']   = "upload/freedom_fighter";
                $config['allowed_types'] = "jpg|jpeg|png|gif";
                #$config['encrypt_name']  = true;
                $config['max_size']      = "720";
                $config['max_width']     = "1500";
                $config['max_height']    = "1500";
            	  	$config['overwrite']     =   true;				
                	$config['file_name']     = substr($_POST['f_photo_old'], 0 , (strrpos($_POST['f_photo_old'], ".")));
            	 }
                $this->load->library('upload', $config);
                
                if (!$this->upload->do_upload('f_photo')) {
                    echo $this->upload->display_errors();
                } else {
                    $spinfo               = $this->upload->data();
                    $data['f_photo'] = $spinfo['file_name'];
                }
                unset($config);
            }
            $school_id            = 1;
            $data['school_id']    = $school_id;
            $data['f_name']  = $_POST['f_name'];
            $data['f_des'] = $_POST['f_des'];
            $data['f_address'] = $_POST['f_address'];
            $data['f_phone'] = $_POST['f_phone'];
            $data['f_sector']     = $_POST['f_sector'];
            $data['order_by']     = $_POST['order_by'];
            if ($_POST['f_id'] != 0) {
                $save_data = $this->Common_model->common_update($data, $_POST['f_id'],'f_id','tbl_freedom_fighter');
            } else {
                $data['status']     = 1;
                $data['created_on'] = date('Y-m-d H:i:s', time());
                $save_data          = $this->Common_model->common_insert($data, 'tbl_freedom_fighter');
            }
          // print_r ($save_data);
          // die();
            if ($save_data)
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>A Freedom Fighter Added successfully</div>');
            else
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved.</div>');
            redirect('web/freedom_fighter');
            exit;
        }
        $data['freedom_fighter_list'] = $this->Common_model->common_result_array('tbl_freedom_fighter');
        $this->load->view('web/freedom_fighter', $data);
        
    }
      public  function freedom_fighter_delete($f_id, $f_photo)
    {
        $data['school_id'] = 1;
        $data['f_id'] = $f_id;
        #$img= explode("|", $member_image);
        $image_path        = "upload/freedom_fighter/" . $f_photo;
        unlink($image_path);
        //echo $image_path;
        #unlink(base_url("upload/freedom_fighter/".$f_photo));
        $this->Common_model->common_delete($data, 'tbl_freedom_fighter');
        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
        redirect('web/freedom_fighter');
        exit;
    }
   public function freedom_fighter_edit($f_id)
    {
        $data1['freedom_fighter_list'] = $this->Common_model->common_result_array('tbl_freedom_fighter');
        $this->load->view('web/freedom_fighter_edit', $data1);
    }
   public function managing_committee()
    {
        if (isPostBack()) {
            if ($_FILES AND $_FILES['m_image']['name']) {
                $config['upload_path']   = "upload/managing_committee";
                $config['allowed_types'] = "jpg|jpeg|png|gif";
                #$config['encrypt_name']  = true;
                $config['max_size']      = "720";
                $config['max_width']     = "1500";
                $config['max_height']    = "1500";
                #$config['overwrite']     =   true;				
                $config['file_name']     = "member";
                
                $this->load->library('upload', $config);
                
                if (!$this->upload->do_upload('m_image')) {
                    echo $this->upload->display_errors();
                } else {
                    $spinfo               = $this->upload->data();
                    $data['member_image'] = $spinfo['file_name'];
                }
                unset($config);
            }
            $school_id            = 1;
            $data['school_id']    = $school_id;
            $data['member_name']  = $_POST['m_name'];
            $data['member_desig'] = $_POST['m_des'];
            $data['mobile_no'] = $_POST['mobile_no'];
            $data['order_by']     = $_POST['m_order'];
            if ($_POST['member_id'] != 0) {
                $save_data = $this->Common_model->common_update($data, $_POST['member_id'], 'member_id', 'tbl_managing_committee');
            } else {
                $data['status']     = 1;
                $data['created_on'] = date('Y-m-d H:i:s', time());
                $save_data          = $this->Common_model->common_insert($data, 'tbl_managing_committee');
            }
            if ($save_data)
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>A New Member Added successfully</div>');
            else
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved.</div>');
            redirect('web/managing_committee');
            exit;
        }
        $data1['member_list'] = $this->Common_model->common_result_array('tbl_managing_committee');
        $this->load->view('web/managing_committee', $data1);
    }
  public  function managing_committee_delete($member_id, $member_image)
    {
        $data['school_id'] = 1;
        $data['member_id'] = $member_id;
        #$img= explode("|", $member_image);
        $image_path        = "upload/managing_committee/" . $member_image;
        unlink($image_path);
        //echo $image_path;
        #unlink(base_url("upload/managing_committee/".$member_image));
        $this->Common_model->common_delete($data, 'tbl_managing_committee');
        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
        redirect('web/managing_committee');
        exit;
    }
   public function managing_committee_edit($member_id)
    {
        $data1['member_list'] = $this->Common_model->common_result_array('tbl_managing_committee');
        $this->load->view('web/managing_committee_edit', $data1);
    }
   public function donor()
    {
if (isPostBack()) {
            #$school_id = $_SESSION['school_id'];
            $school_id              = 1;
            $data['school_id']      = $school_id;
            $data['donnor_name']    = $_POST['d_name'];
            $data['donnor_phone']   = $_POST['d_phone'];
            $data['donnor_address'] = $_POST['d_add'];
            $data['status']         = 1;
            $data['created_on']     = date('Y-m-d H:i:s', time());
            
            if ($_POST['id'] != 0) {
                $save_data = $this->Common_model->common_update($data, $_POST['id'], 'id', 'tbl_donor');
            } else {
                $data['status']     = 1;
                $data['created_on'] = date('Y-m-d H:i:s', time());
                $save_data          = $this->Common_model->common_insert($data, 'tbl_donor');
            }
            
            if ($save_data)
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
            
            else
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved.</div>');
            redirect('web/donor');
            exit;
        }
        $data['donor_list'] = $this->Common_model->common_result_array('tbl_donor');
        $this->load->view('web/donor', $data);
    }
    
        function donor_delete($id)
    {

        $data['id'] = $id;

        $this->Common_model->common_delete($data, 'tbl_donor');
        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
        redirect('web/donor');
        exit;
    }
    public function message()
    {
        //$school_id = $_SESSION['school_id'];
        $s_data['school_id']  = 1;
        $data['message_list'] = $this->Common_model->common_select_by_multycondition($s_data, 'tbl_message');
        $this->load->view('web/message', $data);
    }
    
    public function message_update($message_id)
    {
        //$school_id = $_SESSION['school_id'];
        $s_data['school_id']  = 1;
        $s_data['message_id'] = $message_id;
        $data['message']      = $this->Common_model->common_select_by_multycondition($s_data, 'tbl_message');
        $this->load->view('web/message_update', $data);
    }
    
    function message_save()
    {
        //$school_id = $_SESSION['school_id'];
        $school_id           = 1;
        $message_type        = $_POST['type'];
        $s_data['school_id'] = $school_id;
        $principal_message   = $this->Common_model->common_select_by_multycondition($s_data, 'tbl_message');
        if (count($principal_message) >= 3) {
            $this->session->set_flashdata('message', '<div class="alert alert-danger"><strong>Danger!</strong><a href="#" class="close" data-dismiss="alert">&times;</a> You cannot add more then three (3) types of message.</div>');
            redirect('web/message');
            exit;
        } elseif ($message_type != '') {
            $data['type']       = $message_type;
            $data['name']       = 'No';
            $data['image']      = '';
            $data['message']    = 'No';
            $data['school_id']  = $school_id;
            $data['status']     = 1;
            $data['created_on'] = date('Y-m-d H:i:s', time());
            if ($this->Common_model->common_insert($data, 'tbl_message'))
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been saved</div>');
            else
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Data has not been saved. Please try again.</div>');
            redirect('web/message');
            exit;
            
        }
    }
    
    function message_update_save()
    {
        //$school_id=$_SESSION['school_id'];
        $school_id  = 1;
        $message_id = $_POST['message_id'];
        $type       = $_POST['type'];
        $name       = $_POST['name'];
        $message    = $_POST['message'];
        $summary    = $_POST['summary'];     
        if ($_POST['image_name'])
            $image_name = $_POST['image_name'];
        else
            $image_name = date('dmYHis') . $school_id . "_message_image";
        
        if ($_FILES AND $_FILES['image']['name']) {
            $config['upload_path']   = "upload/message_image";
            $config['allowed_types'] = "jpg|jpeg|png|gif";
            $config['max_size']      = "320";
            $config['max_width']     = "700";
            $config['max_height']    = "800";
            $config['overwrite']     = TRUE;
            $config['file_name']     = $image_name;
            
            $this->load->library('upload', $config);
            
            if (!$this->upload->do_upload('image')) {
                echo $this->upload->display_errors();
            }
            
            else {
                $finfo = $this->upload->data();
                $image = $finfo['file_name'];
                
                $data['type']       = $type;
                $data['name']       = $name;
                $data['image']      = $image;
                $data['message']    = $message;
                $data['summary']    = $summary;
                $data['created_on'] = date('Y-m-d H:i:s', time());
                if ($this->Common_model->common_update($data, $message_id, 'message_id', 'tbl_message'))
                    $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been saved</div>');
                else
                    $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Data has not been saved. Please try again.</div>');
                
                redirect('web/message');
                exit;
            }
        } else {
            $data['type']       = $type;
            $data['name']       = $name;
            $data['message']    = $message;
            $data['summary']    = $summary;
            $data['created_on'] = date('Y-m-d H:i:s', time());
            if ($this->Common_model->common_update($data, $message_id, 'message_id', 'tbl_message'))
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been saved</div>');
            else
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Data has not been saved. Please try again.</div>');
            redirect('web/message');
            exit;
        }
    }
    
    function message_delete($message_id)
    {
        //$school_id = $_SESSION['school_id'];
        $d_data['school_id']  = 1;
        $d_data['message_id'] = $message_id;
        if ($this->Common_model->common_delete($d_data, 'tbl_message'))
            $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been deleted successfully</div>');
        else
            $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Data has not been deleted. Please try again.</div>');
        
        redirect('web/message');
        exit;
    }
    
    /************** information ******************/
    
    public function information_list()
    {
        //$school_id = $_SESSION['school_id'];
        $s_data['school_id']      = 1;
        $data['information_list'] = $this->Common_model->common_select_by_multycondition($s_data, 'tbl_important_information');
        $this->load->view('web/information_list', $data);
    }
    
    function information_save()
    {
        if (isPostBack()) {
            $c_data['information_type'] = $_POST['information_type'];
            $c_data['school_id']        = 1;
            $chk                        = $this->Common_model->common_select_by_multycondition($c_data, 'tbl_important_information');
            
            if (!$chk) {
                //$school_id = $_SESSION['school_id'];
                $data['school_id']           = 1;
                $data['information_type']    = $_POST['information_type'];
                $data['information_heading'] = $_POST['information_heading'];
                $data['information_details'] = $_POST['information_details'];
                $data['status']              = '1';
                $data['created_on']          = date('Y-m-d H:i:s', time());
                
                if ($this->Common_model->common_insert($data, 'tbl_important_information'))
                    $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been saved</div>');
                else
                    $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Data has not been deleted. Please try again.</div>');
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Under this information type data had been saved. You can just edit old data from edit option.</div>');
            }
        }
        redirect('web/information_list');
        exit;
    }
    
    public function single_information_edit($info_id)
    {
        //$school_id = $_SESSION['school_id'];
        $s_data['info_id']        = $info_id;
        $s_data['school_id']      = 1;
        $data['information_list'] = $this->Common_model->common_select_by_multycondition($s_data, 'tbl_important_information');
        $this->load->view('web/single_information_edit', $data);
    }
    
    function information_edit_save()
    {
        if (isPostBack()) {
            $info_id                     = $_POST['info_id'];
            $data['information_heading'] = $_POST['information_heading'];
            $data['information_details'] = $_POST['information_details'];
            if ($this->Common_model->common_update($data, $info_id, 'info_id', 'tbl_important_information'))
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been saved</div>');
            else
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Data has not been deleted. Please try again.</div>');
            
            redirect('web/information_list');
            exit;
        }
    }
    
    /********************** /information ******************/
    
    /********************** slide ******************/
    
    public function slide()
    {
        //$school_id = $_SESSION['school_id'];
        $s_data['school_id'] = 1;
        $data['slide_image'] = $this->Common_model->common_select_by_multycondition($s_data, 'tbl_slide_image');
        $this->load->view("web/slide", $data);
    }
    
    function slide_image_save()
    {
        if (isPostBack()) {
            // $school_id = $_SESSION['school_id'];
            $school_id               = 1;
            $config['upload_path']   = "upload/slides";
            $config['allowed_types'] = "jpg|jpeg|png";
            $config['max_size']      = "1000";
            $config['max_width']     = "1140";
            $config['max_height']    = "592";
            $config['file_name']     = $school_id . "_slide_image";
            
            $this->load->library('upload', $config);
            
            if (!$this->upload->do_upload('slide_image')) {
                echo $this->upload->display_errors();
            }
            
            else {
                $finfo            = $this->upload->data();
                $slide_image_name = $finfo['file_name'];
                
                $data['school_id']        = $school_id;
                $data['slide_image_name'] = $slide_image_name;
                $data['slide_caption']    = $_POST['slide_caption'];
                $data['status']           = 1;
                $data['created_on']       = date('Y-m-d H:i:s', time());
                if ($this->Common_model->common_insert($data, 'tbl_slide_image'))
                    $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been saved</div>');
                else
                    $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Data has not been deleted. Please try again.</div>');
                
                redirect('web/slide');
                exit;
            }
        }
    }
    
    
    function delete_slide_image($slide_image_id, $image_name)
    {
        //$school_id = $_SESSION['school_id'];
        $d_data['school_id']      = 1;
        $d_data['slide_image_id'] = $slide_image_id;
        $image_path               = 'upload/slides/' . $image_name;
        if ($this->Common_model->common_delete($d_data, 'tbl_slide_image')) {
            unlink($image_path);
            $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been deleted successfully</div>');
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Data has not been deleted. Please try again.</div>');
        }
        redirect('web/slide');
        exit;
    }
    
    
    /**************** /slide ***********************/
    
    /**************** about college ***********************/
     public function computer_lab_info()
    {

        $this->load->view('web/computer_lab_info');
    }

    
     public function founder()
    {
        $data['founder'] = $this->Common_model->common_result_array('tbl_founder');
        $this->load->view('web/founder',$data);
    }
    public function founder_edit()
    {

        $data['founder'] = $this->Common_model->common_result_array('tbl_founder');
        $this->load->view('web/founder_edit',$data);
    }
    public function founder_edit_save()
    {

        if (isPostBack()) {
            if ($_FILES AND $_FILES['photo']['name']) {
                
                 if ($_POST['photo'] == '0'){
                 $config['upload_path']   = "upload/founder";
                $config['allowed_types'] = "jpg|jpeg|png|gif";
                #$config['encrypt_name']  = true;
                $config['max_size']      = "1020";
                $config['max_width']     = "1920";
                $config['max_height']    = "1080";
                $config['overwrite']     =   false;             
                $config['file_name']     = "founder";
                 }
                 else{
                  $config['upload_path']   = "upload/founder";
                $config['allowed_types'] = "jpg|jpeg|png|gif";
                #$config['encrypt_name']  = true;
                $config['max_size']      = "720";
                $config['max_width']     = "1500";
                $config['max_height']    = "1500";
                    $config['overwrite']     =   true;              
                    $config['file_name']     = substr($_POST['photo'], 0 , (strrpos($_POST['photo'], ".")));
                 }
                $this->load->library('upload', $config);
                
                if (!$this->upload->do_upload('photo')) {
                    echo $this->upload->display_errors();
                } else {
                    $spinfo               = $this->upload->data();
                    $data['photo'] = $spinfo['file_name'];
                }
                unset($config);
            }

            if(!empty($_POST['id'])){
          $id  = $_POST['id'];  
         }

        // print_r($id);
        // die();
         if(!empty($_POST['photo'])){
          $data['photo']  = $_POST['photo'];  
         }
            if(!empty($_POST['name'])){
            $data['name'] = $_POST['name'];
        }
        if(!empty($_POST['body'])){
            $data['body'] = $_POST['body'];
        }
            $data['status']     = 1;
            $data['updated_at'] = date('Y-m-d H:i:s', time());
            //print_r($data);
           // die();
            $save_data          = $this->Common_model->common_update($data, $id, 'id', 'tbl_founder');
            if ($save_data)
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Updated successfully</div>');
            else
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved.</div>');
            redirect('web/founder');
        }
         redirect('web/founder');
    }

    
    public function about()
    {
        //$school_id = $_SESSION['school_id'];
        $s_data['school_id'] = 1;
        $data['about']       = $this->Common_model->common_select_by_multycondition($s_data, 'tbl_about');
        $this->load->view('web/about', $data);
    }
    
    function about_edit_save()
    {
        if (isPostBack()) {
            //$school_id=$_SESSION['school_id'];
            $school_id           = 1;
            $s_data['school_id'] = $school_id;
            if ($_FILES AND $_FILES['about_image']['name']) {
                $config['upload_path']   = "upload/message";
                $config['allowed_types'] = "jpg|jpeg|png|gif";
                $config['max_size']      = "1500";
                $config['max_width']     = "1920";
                $config['max_height']    = "1080";
                $config['overwrite']     = TRUE;
                $config['file_name']     = $school_id . "_about_image";
                $this->load->library('upload', $config);
                if (!$this->upload->do_upload('about_image')) {
                    $error = $this->upload->display_errors();
                }
                
                else {
                    $chk = $this->Common_model->common_select_by_multycondition($s_data, 'tbl_about');
                    if (!$chk) {
                        $finfo       = $this->upload->data();
                        $about_image = $finfo['file_name'];
                        
                        $data['school_id']     = $school_id;
                        $data['summary'] = $_POST['summary'];
                        $data['about_details'] = $_POST['about_details'];
                        $data['about_image']   = $about_image;
                        $data['status']        = 1;
                        $data['created_on']    = date('Y-m-d H:i:s', time());
                        if ($this->Common_model->common_insert($data, 'tbl_about'))
                            $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been saved</div>');
                        else
                            $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Data has not been deleted. Please try again.</div>');
                    } else {
                        $finfo       = $this->upload->data();
                        $about_image = $finfo['file_name'];
                        
                        
                        $data['school_id']     = $school_id;
                        $data['about_details'] = $_POST['about_details'];
                        $data['summary'] = $_POST['summary'];
                        
                        $data['about_image']   = $about_image;
                        if ($this->Common_model->common_update($data, $school_id, 'school_id', 'tbl_about'))
                            $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been saved</div>');
                        else
                            $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Data has not been deleted. Please try again.</div>');
                    }
                }
            }
            
            else {
                
                $chk = $this->Common_model->common_select_by_multycondition($s_data, 'tbl_about');
                if (!$chk) {
                    $finfo       = $this->upload->data();
                    $about_image = $finfo['file_name'];
                    
                    $data['school_id']     = $school_id;
                    $data['about_details'] = $_POST['about_details'];
                    $data['about_image']   = $about_image;
                    $data['status']        = 1;
                    $data['created_on']    = date('Y-m-d H:i:s', time());
                    if ($this->Common_model->common_insert($data, 'tbl_about'))
                        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been saved</div>');
                    else
                        $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Data has not been deleted. Please try again.</div>');
                } else {
                    $data['about_details'] = $_POST['about_details'];
                    
                    if ($this->Common_model->common_update($data, $school_id, 'school_id', 'tbl_about'))
                        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been saved</div>');
                    else
                        $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Data has not been deleted. Please try again.</div>');
                    
                    
                }
            }
        }
        if ($error)
            $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
        
        redirect('web/about');
        exit;
    }
    
    /**************** /about college ***********************/
    
    /**************** photo gallery  ***********************/
    
    
    public function catagory_list()
    {
        //$school_id = $_SESSION['school_id'];
        $s_data['school_id']   = 1;
        $data['catagory_list'] = $this->Common_model->common_select_by_multycondition($s_data, 'tbl_photo_catagory');
        $this->load->view('web/catagory_list', $data);
    }
    
    function catagory_save()
    {
        if (isPostBack()) {
            //$data['school_id'] = $_SESSION['school_id'];
            $data['school_id']     = 1;
            $data['catagory_name'] = $_POST['catagory_name'];
            if ($_POST['catagory_id']) {
                $catagory_id = $_POST['catagory_id'];
                if ($this->Common_model->common_update($data, $catagory_id, 'catagory_id', 'tbl_photo_catagory'))
                    $save = 1;
                else
                    $save = 0;
            } else {
                $data['created_on'] = date('Y-m-d H:i:s', time());
                if ($this->Common_model->common_insert($data, 'tbl_photo_catagory'))
                    $save = 1;
                else
                    $save = 0;
            }
            
            if ($save == 1) {
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been saved</div>');
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Data has not been deleted. Please try again.</div>');
            }
        }
        
        redirect('web/catagory_list');
        exit;
    }
    
    
    function catagory_delete($catagory_id)
    {
        $d_data['school_id']   = 1;
        $d_data['catagory_id'] = $catagory_id;
        if ($this->Common_model->common_delete($d_data, 'tbl_photo_catagory')) {
            $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been deleted successfully</div>');
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Data has not been deleted. Please try again.</div>');
        }
        redirect('web/catagory_list');
        exit;
    }
    
    
    public function picture_gallery()
    {
        //$school_id = $_SESSION['school_id'];
        $s_data['school_id']   = 1;
        $data['gallery_image'] = $this->Common_model->common_select_by_multycondition($s_data, 'tbl_photo_gallery');
        $data['catagory_list'] = $this->Common_model->common_select_by_multycondition($s_data, 'tbl_photo_catagory');
        $this->load->view('web/picture_gallery', $data);
    }
    
    function picture_gallery_save()
    {
        if (isPostBack()) {
            //$school_id = $_SESSION['school_id'];
            $school_id               = 1;
            $config['upload_path']   = "upload/photo_gallery";
            $config['allowed_types'] = "jpg|jpeg|png";
            $config['max_size']      = "1000";
            $config['max_width']     = "1200";
            $config['max_height']    = "900";
            $config['file_name']     = $school_id . "_gallery_photo";
            
            $this->load->library('upload', $config);
            
            if (!$this->upload->do_upload('gallery_image_name')) {
                $error = $this->upload->display_errors();
            }
            
            else {
                $finfo              = $this->upload->data();
                $gallery_image_name = $finfo['file_name'];
                
                $data['school_id']          = $school_id;
                $data['photo_caption']      = $_POST['photo_caption'];
                $data['catagory_id']        = $_POST['catagory_id'];
                $data['gallery_image_name'] = $gallery_image_name;
                $data['status']             = 1;
                $data['created_on']         = date('Y-m-d H:i:s', time());
                if ($this->Common_model->common_insert($data, 'tbl_photo_gallery')) {
                    $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been saved</div>');
                } else {
                    $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Data has not been deleted. Please try again.</div>');
                }
                
            }
        }
        if ($error)
            $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
        
        redirect('web/picture_gallery');
        exit;
    }
    
    function delete_gallery_image($photo_gallery_id, $image_name)
    {
        //$school_id = $_SESSION['school_id'];
        $d_data['school_id']        = 1;
        $d_data['photo_gallery_id'] = $photo_gallery_id;
        $image_path                 = 'upload/photo_gallery/' . $image_name;
        if ($this->Common_model->common_delete($d_data, 'tbl_photo_gallery')) {
            unlink($image_path);
            $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been deleted successfully</div>');
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Data has not been deleted. Please try again.</div>');
        }
        redirect('web/picture_gallery');
        exit;
    }
    
    /**************** /photo gallery  ***********************/
        public function other_assets()
    {
        /* if (isPostBack()) {
            $school_id            = 1;
            $data['school_id']    = $school_id;
            $data['asset_name']  = $_POST['m_name'];
            $data['member_desig'] = $_POST['m_des'];
            $data['mobile_no'] = $_POST['mobile_no'];
            if ($_POST['member_id'] != 0) {
                $save_data = $this->Common_model->common_update($data, $_POST['member_id'], 'member_id', 'tbl_assets');
            } else {
                $data['status']     = 1;
                $data['created_on'] = date('Y-m-d H:i:s', time());
                $save_data          = $this->Common_model->common_insert($data, 'tbl_assets');
            }
            if ($save_data)
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Added successfully</div>');
            else
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved.</div>');
            redirect('web/other_assets');
            exit;
        }
        $data1['member_list'] = $this->Common_model->common_result_array('tbl_assets');*/
        $this->load->view('web/other_assets');
    }  


public function head_teacher_list()
    {
        $data['teachers'] = $this->Common_model->common_result_array('tbl_head_teacher');
        $this->load->view('teacher/index',$data);
    }
    
       function headteacher_delete($id)
    {
        $d_data['id'] = $id;
        if ($this->Common_model->common_delete($d_data, 'tbl_head_teacher')) {
            $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been deleted successfully</div>');
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Data has not been deleted. Please try again.</div>');
        }
        redirect('web/head_teacher_list');
        exit;
    }

       public function headteacher_save()
    {
        if (isPostBack()) {
             if ($_FILES AND $_FILES['photo']['name']) {
                  $config['upload_path']   = "upload/teacher_image";
                $config['allowed_types'] = "jpg|jpeg|png|gif";
                #$config['encrypt_name']  = true;
                $config['max_size']      = "3000";
                $config['max_width']     = "1500";
                $config['max_height']    = "1500";
                $config['overwrite']     =   true;              
                $config['file_name']     = substr($_POST['photo'], 0 , (strrpos($_POST['photo'], ".")));
                $this->load->library('upload', $config);
                if (!$this->upload->do_upload('photo')) {
                    echo $this->upload->display_errors();
                } else {
                    $spinfo               = $this->upload->data();
                    $data['photo'] = $spinfo['file_name'];
                }
                unset($config);
            }
         if(!empty($_POST['photo'])){
          $data['photo']  = $_POST['photo'];  
         }
            if(!empty($_POST['name'])){
            $data['name'] = $_POST['name'];
        }
        if(!empty($_POST['period'])){
            $data['period'] = $_POST['period'];
        }
         if(!empty($_POST['qualification'])){
            $data['qualification'] = $_POST['qualification'];
        }
            $data['status']     = 1;
            $data['created_at'] = date('Y-m-d H:i:s', time());
            $save_data          = $this->Common_model->common_insert($data, 'tbl_head_teacher');
            if ($save_data)
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Added successfully</div>');
            else
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved.</div>');
            redirect('web/head_teacher_list');
        }
        redirect('web/head_teacher_list');
    }





       public function headteacher_edit_save()
    {
        if (isPostBack()) {
             if ($_FILES AND $_FILES['photo']['name']) {
                  $config['upload_path']   = "upload/teacher_image";
                $config['allowed_types'] = "jpg|jpeg|png|gif";
                #$config['encrypt_name']  = true;
                $config['max_size']      = "3000";
                $config['max_width']     = "1500";
                $config['max_height']    = "1500";
                $config['overwrite']     =   true;              
                $config['file_name']     = substr($_POST['photo'], 0 , (strrpos($_POST['photo'], ".")));
                $this->load->library('upload', $config);
                if (!$this->upload->do_upload('photo')) {
                    echo $this->upload->display_errors();
                } else {
                    $spinfo               = $this->upload->data();
                    $data['photo'] = $spinfo['file_name'];
                }
                unset($config);
            }
        $id=$_POST['id'];
         if(!empty($_POST['photo'])){
          $data['photo']  = $_POST['photo'];  
         }
            if(!empty($_POST['name'])){
            $data['name'] = $_POST['name'];
        }
        if(!empty($_POST['period'])){
            $data['period'] = $_POST['period'];
        }
         if(!empty($_POST['qualification'])){
            $data['qualification'] = $_POST['qualification'];
        }
            $data['status']     = 1;
            $data['created_at'] = date('Y-m-d H:i:s', time());
            $save_data          = $this->Common_model->common_update($data, $id,'id', 'tbl_head_teacher');
            if ($save_data)
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Added successfully</div>');
            else
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved.</div>');
            redirect('web/head_teacher_list');
        }
        redirect('web/head_teacher_list');
    }

     public function headteacher_edit($id)
    {

        $data['id']=$id;
        $data['teachers'] = $this->Common_model->common_select_by_multycondition($data,'tbl_head_teacher');
        $this->load->view('teacher/edit',$data);
    }


    public function land_info()
    {
        $this->load->view('web/land_info');
    }  
    public function computer_lab()
    {
        $this->load->view('web/computer_lab');
    }

    public function news()
    {
       $data['news'] = $this->Common_model->common_result_array('tbl_news');
        $this->load->view('news/index',$data);
    }
     public function edit_news($id)
    {

        $data['id']=$id;
        $data['news'] = $this->Common_model->common_select_by_multycondition($data,'tbl_news');
       // print_r($data);
       // die();
        $this->load->view('news/edit',$data);
    }
    public function news_create()
    {
       
        $this->load->view('news/create');
    }


    public function video_gallery()
    {
       $data['videos'] = $this->Common_model->common_result_array('tbl_video_gallery');
        $this->load->view('video/index',$data);
    }
     public function edit_video($id)
    {
        $data['id']=$id;
        $data['video'] = $this->Common_model->common_select_by_multycondition($data,'tbl_video_gallery');
        $this->load->view('video/edit',$data);
    }
    public function video_create()
    {
        $this->load->view('video/create');
    }

    public  function video_delete($id)
    {
        $data['id'] = $id;
      $hi=  $this->Common_model->common_delete($data,'tbl_video_gallery');
      if($hi>0){
        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
        redirect('web/video_gallery');
      }
      else
      {
 $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted</div>');
        redirect('web/video_gallery');
        exit;
      }
       
    }

    

  


    public function video_save()
    {
        if (isPostBack()) {
            if(!empty($_POST['url'])){
            $data['video_url'] = $_POST['url'];
        }
         if(!empty($_POST['view_url'])){
            $data['view_url'] = $_POST['view_url'];
            }
            else
            {
                $data['view_url']=NULL;
            }
        if(!empty($_POST['title'])){
            $data['title'] = $_POST['title'];
        }
         if(!empty($_POST['body'])){
            $data['body'] = $_POST['body'];
        }
        if(!empty($_POST['status'])){
            $data['status'] = $_POST['status'];
        }
        else
        {
            $data['status']     = 1;
        }
            $data['created_at'] = date('Y-m-d H:i:s', time());
            $save_data          = $this->Common_model->common_insert($data, 'tbl_video_gallery');
            if ($save_data)
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Added successfully</div>');
            else
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved.</div>');
            $this->load->view('video/create');
        }
    }

     function video_update()
    {

        if (isPostBack()) {
            $id                     = $_POST['id'];

            if(!empty($id)){
                if(!empty($_POST['title'])){
            $data['title'] = $_POST['title'];
            }
            else
            {
                $data['title']=NULL;
            }
            
            
            if(!empty($_POST['url'])){
            $data['video_url'] = $_POST['url'];
            }
            else
            {
                $data['video_url']=NULL;
            }
            if(!empty($_POST['view_url'])){
            $data['view_url'] = $_POST['view_url'];
            }
            else
            {
                $data['view_url']=NULL;
            }
            if(!empty($_POST['body'])){
            $data['body'] = $_POST['body'];
        }
        else{
            $data['body'] =NULL;
        }
          if(!empty($_POST['status'])){
            $data['status'] = $_POST['status'];
        }
        else
        {
           $data['status'] = 0;
        }

        //print_r($data);
        //die();
            if ($this->Common_model->common_update($data, $id,'id', 'tbl_video_gallery'))
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been saved</div>');
            else
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Data has not been Updated. Please try again.</div>');
            
            redirect('web/video_gallery');
            exit;
            }
            else
            {
                echo "ID NOt Found";

            }
        }
    }



    public  function news_delete($id, $photo=NULL)
    {


        $data['id'] = $id;
        if(!empty($photo)){
           $image_path        = "upload/news/" . $photo;
        unlink($image_path); 
        }
      $hi=  $this->Common_model->common_delete($data,'tbl_news');
      if($hi>0){
        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
        redirect('web/news');
      }
      else
      {
 $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted</div>');
        redirect('web/news');
        exit;
      }
       
    }
    public function news_save()
    {
        if (isPostBack()) {
              if ($_FILES AND $_FILES['image']['name']) {
                $config['upload_path']   = "./upload/news";
                $config['allowed_types'] = "jpg|jpeg|png|gif";
                #$config['encrypt_name']  = true;
                $config['max_size']      = "1200";
                $config['max_width']     = "1500";
                $config['max_height']    = "1500";
                $config['overwrite']     =   true;				
                $config['file_name']     = $_FILES['image']['name'];
                
                $this->load->library('upload', $config);
                
                if (!$this->upload->do_upload('image')) {
                    echo $this->upload->display_errors();
                } else {
                    $spinfo               = $this->upload->data();
                    $data['image'] = $spinfo['file_name'];
                }
                unset($config);
            }

        if(!empty($_POST['title'])){
            $data['title'] = $_POST['title'];
        }
        if(!empty($_POST['venue'])){
            $data['venue'] = $_POST['venue'];
        }
         if(!empty($_POST['date'])){
            $data['news_date'] = $_POST['date'];
         }
        if(!empty($_POST['time'])){
            $data['news_time'] = $_POST['time'];
        }
        if(!empty($_POST['body'])){
            $data['body']     = $_POST['body'];
        }
         if(!empty($_POST['status'])){
            $data['status'] = $_POST['status'];
        }
        else
        {
           $data['status'] = 1;
        }
            $data['created_at'] = date('Y-m-d H:i:s', time());
            $save_data          = $this->Common_model->common_insert($data, 'tbl_news');
            if ($save_data){
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Added successfully</div>');
                 redirect('web/news');
            }
            else{
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved.</div>');
            redirect('web/news');
            }
        }
        redirect('web/news');
        
    }
    
    
    
public function news_update()
    {
        
                if ($_FILES AND $_FILES['image']['name']) {
                $config['upload_path']   = "./upload/news";
                $config['allowed_types'] = "jpg|jpeg|png|gif";
                #$config['encrypt_name']  = true;
                $config['max_size']      = "1200";
                $config['max_width']     = "1500";
                $config['max_height']    = "1500";
                $config['overwrite']     =   true;				
                $config['file_name']     = $_FILES['image']['name'];
                
                $this->load->library('upload', $config);
                
                if (!$this->upload->do_upload('image')) {
                    echo $this->upload->display_errors();
                } else {
                    $spinfo               = $this->upload->data();
                    $data['image'] = $spinfo['file_name'];
                }
                unset($config);
            }
        
        if(!empty($_POST['id'])){
          $id  = $_POST['id'];  
         }
            if(!empty($_POST['title'])){
            $data['title'] = $_POST['title'];
        }
        if(!empty($_POST['venue'])){
            $data['venue'] = $_POST['venue'];
        }
         if(!empty($_POST['date'])){
            $data['news_date'] = $_POST['date'];
         }
        if(!empty($_POST['time'])){
            $data['news_time'] = $_POST['time'];
        }
        if(!empty($_POST['body'])){
            $data['body']     = $_POST['body'];
        }
         if(!empty($_POST['status'])){
            $data['status'] = $_POST['status'];
        }
        else
        {
           $data['status'] = 0;
        }
        //print_r($data['image']);
        //die();
        
            $data['updated_at'] = date('Y-m-d H:i:s', time());
            $save_data          = $this->Common_model->common_update($data, $id, 'id', 'tbl_news');
           // print_r($save_data);
           // die();
            if ($save_data){
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Updated successfully</div>');
                redirect('web/news');
            }
            else{
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved.</div>');
            redirect('web/news');
            }
        
         redirect('web/news');
    }
   
    


}

?>