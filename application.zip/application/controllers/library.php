<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Library extends CI_Controller {

    public function __construct()
        {            
            //session_start();
            parent::__construct();
            $this->load->helper('form');
            $this->load->helper('url');
            $this->load->model('common_model', 'Common_model', true);
			$this->load->model('library_model', 'Library_model', true);
			$this->load->model('admin_model', 'Admin_model', true);
			$this->load->model('library_model', 'Library_model', true);
            $this->load->library('form_validation');
           if(!is_loggedin())
            {
               redirect('login');
               exit;
            }
			
        }

		
		/**************** book Category  ***********************/
		
		function book_category_list(){
            //$school_id = $_SESSION['school_id'];
			$school_id = 1;
            $data['category_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_book_category');
            $this->load->view('library/book_category_list',$data);
        }
		
        function book_category_save(){
            if(isPostBack()){
                $data['school_id'] = 1;
                $data['category_name'] = $_POST['category_name'];
                $data['created_on'] = date('Y-m-d H:i:s',time());
               
				 if($this->Common_model->common_insert($data, 'tbl_book_category'))
					{
						$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
					}
				else
					{
						$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
					}
                redirect('library/book_category_list');exit;
            }
        }
		
		public function book_category_edit($category_id){
            $data['category_info']=$this->Common_model->common_select_by_condition($category_id,'category_id','tbl_book_category');
            $this->load->view('library/book_category_edit', $data);
        }
		
        function book_category_edit_save(){
            if(isPostBack()){
                $category_id = $_POST['category_id'];
                $data['category_name'] = $_POST['category_name'];
                if($this->Common_model->common_update($data, $category_id,'category_id','tbl_book_category'))
					{
						$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
					}
				else
					{
						$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
					}
                redirect('library/book_category_list');exit;
            }
        }
        
        function book_category_delete($category_id){            
            
			$d_data['category_id']=$category_id;
			$this->Common_model->common_delete($d_data,'tbl_book_category');
			$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
            redirect('library/book_category_list');exit;
        }     
		
		/**************** / book Category  ***********************/
		
		/**************** book List  ***********************/
		public function book_list(){
        //$school_id = $_SESSION['school_id'];
		$school_id = 1;
        $data['book_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_book_library');
		$data['category_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_book_category');
        $this->load->view('library/book_list', $data);
    	}
        
        function book_save(){
            if(isPostBack()){
                $data['school_id'] = 1;
				//$school_id = 1;
				$data['register_no'] = $_POST['register_no'];
                $data['book_name'] = $_POST['book_name'];
				$data['writer_name'] = $_POST['writer_name'];
				$data['category_id'] = $_POST['category_id'];
				$data['remarks'] = $_POST['remarks'];
                $data['created_on'] = date('Y-m-d H:i:s',time());
               
				if($this->Common_model->common_insert($data, 'tbl_book_library'))
					{
						$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
					}
				else
					{
						$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
					}
                redirect('library/book_list');exit;
            }
        }
		
		public function book_edit($book_id){
            //$school_id = $_SESSION['school_id'];
			$school_id = 1;
            $data['book_info']= $this->Common_model->common_select_by_condition($book_id,'book_id','tbl_book_library');
			$data['category_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_book_category');
            $this->load->view('library/book_edit', $data);
        }
		
        function book_edit_save(){
            if(isPostBack()){
                $book_id = $_POST['book_id'];
				$data['register_no'] = $_POST['register_no'];
                $data['book_name'] = $_POST['book_name'];
				$data['writer_name'] = $_POST['writer_name'];
				$data['category_id'] = $_POST['category_id'];
				$data['remarks'] = $_POST['remarks'];
                if($this->Common_model->common_update($data, $book_id,'book_id','tbl_book_library'))
					{
						$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
					}
				else
					{
						$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
					}
				redirect('library/book_list');exit;
            }
        }
        
        function book_delete($book_id){            
            $d_data['book_id']=$book_id;
			$this->Common_model->common_delete($d_data,'tbl_book_library');
			$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
            redirect('library/book_list');exit;
        }        
		/**************** /book Issue  ***********************/
		public function book_issue(){
        //$school_id = $_SESSION['school_id'];
		$school_id = 1; 
        $data['book_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_book_library');
		$data['category_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_book_category');
		$data['student_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_student');
        $this->load->view('library/book_issue', $data);
    	}

    	public function book_issue_save(){
        if (isPostBack()) {
            $data['school_id']    = 1;
            $data['issue_to_type']  = $_POST['issue_to_type'];
            $data['issue_to'] = $_POST['issue_to'];
            $data['category_id'] = $_POST['category_id'];
            $data['book_id']     = $_POST['book_id'];
            $data['issue_date']     = $_POST['issue_date'];
            $data['due_date']     = $_POST['due_date'];
            $data['status']     = 1;
            $data['created_on'] = date('Y-m-d H:i:s', time());
            $save_data          = $this->Common_model->common_insert($data, 'tbl_book_issue');
            }
            if ($save_data)
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Book Issue successfully</div>');
            else
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved.</div>');
            redirect('library/book_issue');
            exit;
    	
}
    	  function cat_list_ajax()
    {
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['category_id'];
        $catInfo = $this->Common_model->common_select_by_condition($category_id, $school_id); 
        $str = '<option value="">----Select Section----</option>';
        if($sectionInfo)
        {
           foreach($catInfo as $cInfo)
           {
              $str .= "<option value='".$cInfo['category_id']."'>".$cInfo['category_name']."</option>";
           }
        }
        echo $str;exit;
    }

    	  function get_name_list()
    {
       $school_id = 1;
       $str = '<option value="">----Select Name----</option>';
        if($_POST['id']==2){

        	$c_data['school_id']=$school_id;
			$c_data['session_name']=date('Y');
			$stusession_id=$this->Common_model->common_select_by_multycondition($c_data,'tbl_session');
			$where=' and tbl_student_class.session_id='.$stusession_id[0]['session_id'].' ';
        	$stuInfo = $this->Admin_model->get_all_student_list($school_id,$where);
        	if($stuInfo){
	           foreach($stuInfo as $sInfo){
	              $str .= "<option value='".$sInfo['student_id']."'>".$sInfo['student_name']."(".$sInfo['student_id'].")</option>";
	           }
	        }
        }
        else{
			$tecInfo = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_teacher_registration');
			if($tecInfo){
	           foreach($tecInfo as $sInfo){
	              $str .= "<option value='".$sInfo['teacher_id']."'>".$sInfo['teacher_name']."(".$sInfo['teacher_id'].")</option>";
	           }
	        }
        }
        
        
        echo $str;exit;
}
function get_book_name_list()
    {
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['category_id'] = $_POST['category_id'];
        $booklist = $this->Common_model->common_select_by_multycondition($data,'tbl_book_library'); 
        $str = '<option value="">----Select Section----</option>';
        if($booklist)
        {
           foreach($booklist as $blist)
           {
              $str .= "<option value='".$blist['book_id']."'>".$blist['book_name']."</option>";
           }
        }
        echo $str;exit;
    }
}
?>