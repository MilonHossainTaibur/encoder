<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Exam extends CI_Controller {

    public function __construct()
        {            
            session_start();
            parent::__construct();
            $this->load->helper('form');
            $this->load->helper('url');
            $this->load->model('academic_model', 'Academic_model', true);
			$this->load->model('exam_model', 'Exam_model', true);
			$this->load->model('admin_model', 'Admin_model', true);
            $this->load->model('common_model', 'Common_model', true);  
            $this->load->model('admission_result_model', 'Admission_result_model', true);
            $this->load->library('form_validation'); 
            if(!is_loggedin())
            {
                redirect('login');
                exit;
            }		
        }
    
    
    
    
function subject_list_ajax_ct()
    {
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
		$group_id = $_POST['group_id'];
        
		//$sectionInfo = $this->Admin_model->get_section_list_by_id($class_id, $school_id); 
        $subInfo = $this->Academic_model->get_sub_list_by_id_ct($class_id, $school_id,$group_id); 
        
		$str = '<option value="">----Select Subject----</option>';
        
		if($subInfo)
        {
           foreach($subInfo as $sInfo)
           {
              $str .= "<option value='".$sInfo['subject_id']."'>".$sInfo['subject_name']."</option>";
           }
        }
        echo $str;exit;
    }

function subject_list_ajax()
    {
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
		$group_id = $_POST['group_id'];
        
		//$sectionInfo = $this->Admin_model->get_section_list_by_id($class_id, $school_id); 
        $subInfo = $this->Academic_model->get_sub_list_by_id($class_id, $school_id,$group_id); 
        
		$str = '<option value="">----Select Subject----</option>';
        
		if($subInfo)
        {
           foreach($subInfo as $sInfo)
           {
              $str .= "<option value='".$sInfo['subject_id']."'>".$sInfo['subject_name']."</option>";
           }
        }
        echo $str;exit;
    }
	
	function group_list_ajax()
    {
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
        $sectionInfo = $this->Academic_model->get_group_list_by_id($class_id, $school_id); 
        $str = '<option value="">----Select Group----</option>';
        if($sectionInfo)
        {
           foreach($sectionInfo as $sInfo)
           {
              $str .= "<option value='".$sInfo['group_id']."'>".$sInfo['group_name']."</option>";
           }
        }
        echo $str;exit;
    }
	
		
		/***  CA ***/
		public function set_ca_marks(){
			#$school_id = $_SESSION['school_id'];
			$school_id = 1;
			$data['class_list'] = $this->Admin_model->get_class_list($school_id);
			$data['term_list'] =  $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
			$data['session_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
			$data['shift_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_shift');
			$this->load->view('exam/set_ca_marks', $data);
    	}
    
		public function get_student_list_for_ca_json(){
			#$school_id = $_SESSION['school_id'];
			$school_id = 1;
			$class_id = $_GET['class_id'];
			$section_id = $_GET['section_id'];
			$group_id = $_GET['group_id'];
			$subject_id = $_GET['subject_id'];
			$session_id = $_GET['session_id'];
			$term_id = $_GET['term_id'];
			$shift_id = $_GET['shift_id'];
			$exam_year = $_GET['exam_year'];
			$data['student_list'] = $this->Exam_model->get_class_wise_student_list_exam_ca($school_id,$class_id,$section_id,$group_id,$session_id,$shift_id,$term_id,$exam_year,$subject_id);
			
			$data_s['school_id']=$school_id;
			$data_s['class_id']=$class_id;
			$data_s['group_id']=$group_id;
			$data_s['subject_id']=$subject_id;
			$data_s['exam_type']=1;
			$data['mark_dis_info'] = $this->Common_model->common_select_by_multycondition($data_s, 'tbl_mark_distribution');
			
			$data['details'] =  array("class"=>$class_id,"section"=>$section_id,"group_id"=>$group_id,"subject_id"=>$subject_id,"session_id"=>$session_id,"term_id"=>$term_id,'exam_year'=>$exam_year);
			if($data['mark_dis_info'])
				$mainContent=$this->load->view('exam/set_ca_marks_json', $data, true);
			else
				$mainContent='<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Class Attendence marks was not assign for this subject. please assign marks from "setting > exam > exam setting > Marks Distribution System" </div>';
				
			$result = 'success';
			$return = array('result' => $result, 'mainContent'=> $mainContent);
			print json_encode($return);
			exit;   
		}
	
	 	public function ca_marks_save(){
			#$school_id = $_SESSION['school_id'];
			$school_id = 1;
			$class_id = $_POST['class_id'];
			$section_id = $_POST['section_id'];
			$group_id = $_POST['group_id'];
			$session_id = $_POST['session_id'];
			$exam_year = $_POST['exam_year'];
			$term_id = $_POST['term_id'];
			$subject_id = $_POST['subject_id'];
			$status= 1;
		
			for($i=0; $i < count($_POST['ca_marks_id']); $i++)
			{
				if($_POST['ca_marks_id'][$i] > 0 ):
					$u_data[] = array (
									'ca_marks_id'=>$_POST['ca_marks_id'][$i],
									'obtained_marks'=>$_POST['obtain_marks'][$i]
								);
				else:
					$i_data[] = array (
									'school_id'=>$school_id,
									'class_id'=>$class_id,
									'section_id'=>$section_id,
									'group_id'=>$group_id,
									'session_id'=>$session_id,
									'exam_year'=>$exam_year,
									'term_id'=>$term_id,
									'subject_id'=>$subject_id,
									'student_id'=>$_POST['student_iddfsd'][$i],
									'obtained_marks'=>$_POST['obtain_marks'][$i],
									'status'=>$status
								);
				endif;
			}
			
			/* this will update old data*/
			if($u_data):
				if($this->Common_model->common_batch_update('tbl_ca_marks',$u_data,'ca_marks_id')):
					$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
				else:
					$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
				endif;
			endif;
			
			/* this will insert new data */
			if($i_data):
				if($this->Common_model->common_insert_batch($i_data,'tbl_ca_marks')):
					$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
				else:
					$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
				endif;
			endif;
				
			redirect('exam/set_ca_marks','refresh');
			exit;
		 }
    
	/***  /CA ***/
	
	/*****  CW ****/
  
	 	public function set_cw_marks(){
			#$school_id = $_SESSION['school_id'];
			$school_id = 1;
			$data['class_list'] = $this->Admin_model->get_class_list($school_id);
			$data['term_list'] =  $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
			$data['session_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
			$data['shift_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_shift');
			$this->load->view('exam/set_cw_marks', $data);
    	}
    
    	public function get_student_list_for_cw_json(){
			#$school_id = $_SESSION['school_id'];
			$school_id = 1;
			$class_id = $_GET['class_id'];
			$section_id = $_GET['section_id'];
			$group_id = $_GET['group_id'];
			$subject_id = $_GET['subject_id'];
			$session_id = $_GET['session_id'];
			$term_id = $_GET['term_id'];
			$shift_id = $_GET['shift_id'];
			$exam_year = $_GET['exam_year'];
			$data['student_list'] = $this->Exam_model->get_class_wise_student_list_exam_cw($school_id,$class_id,$section_id,$group_id,$session_id,$shift_id,$term_id,$exam_year,$subject_id);
			
			$data_s['school_id']=$school_id;
			$data_s['class_id']=$class_id;
			$data_s['group_id']=$group_id;
			$data_s['subject_id']=$subject_id;
			$data_s['exam_type']=2;
			$data['mark_dis_info'] = $this->Common_model->common_select_by_multycondition($data_s, 'tbl_mark_distribution');
			
			$data['details'] =  array("class"=>$class_id,"section"=>$section_id,"group_id"=>$group_id,"subject_id"=>$subject_id,"session_id"=>$session_id,"term_id"=>$term_id,'exam_year'=>$exam_year);
			if($data['mark_dis_info'])
				$mainContent=$this->load->view('exam/set_cw_marks_json', $data, true);
			else
				$mainContent='<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Class Work marks was not assign for this subject. please assign marks from "setting > exam > exam setting > Marks Distribution System" </div>';
				
			$result = 'success';
			$return = array('result' => $result, 'mainContent'=> $mainContent);
			print json_encode($return);
			exit;   
    	}
	

		public function cw_marks_save(){
	    	#$school_id = $_SESSION['school_id'];
			$school_id = 1;
			$class_id = $_POST['class_id'];
			$section_id = $_POST['section_id'];
			$group_id = $_POST['group_id'];
			$session_id = $_POST['session_id'];
			$exam_year = $_POST['exam_year'];
			$term_id = $_POST['term_id'];
			$subject_id = $_POST['subject_id'];
			$status= 1;
		
			for($i=0; $i < count($_POST['cw_marks_id']); $i++)
			{
				if($_POST['cw_marks_id'][$i] > 0 ):
					$u_data[] = array (
									'cw_marks_id'=>$_POST['cw_marks_id'][$i],
									'obtained_marks'=>$_POST['obtain_marks'][$i]
								);
				else:
					$i_data[] = array (
									'school_id'=>$school_id,
									'class_id'=>$class_id,
									'section_id'=>$section_id,
									'group_id'=>$group_id,
									'session_id'=>$session_id,
									'exam_year'=>$exam_year,
									'term_id'=>$term_id,
									'subject_id'=>$subject_id,
									'student_id'=>$_POST['student_iddfsd'][$i],
									'obtained_marks'=>$_POST['obtain_marks'][$i],
									'status'=>$status
								);
				endif;
			}
			
			/* this will update old data*/
			if($u_data):
				if($this->Common_model->common_batch_update('tbl_cw_marks',$u_data,'cw_marks_id')):
					$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
				else:
					$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
				endif;
			endif;
			
			/* this will insert new data */
			if($i_data):
				if($this->Common_model->common_insert_batch($i_data,'tbl_cw_marks')):
					$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
				else:
					$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
				endif;
			endif;
				
			redirect('exam/set_cw_marks','refresh');
			exit;
	
	 	}
    
    /***  / CW ***/
	
	
	  /*****  HW ****/
  
	 	public function set_hw_marks(){
        	#$school_id = $_SESSION['school_id'];
			$school_id = 1;
			$data['class_list'] = $this->Admin_model->get_class_list($school_id);
			$data['term_list'] =  $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
			$data['session_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
			$data['shift_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_shift');
        	$this->load->view('exam/set_hw_marks', $data);
    	}
	
	
    
    	public function get_student_list_for_hw_json(){
        	#$school_id = $_SESSION['school_id'];
			$school_id = 1;
			$class_id = $_GET['class_id'];
			$section_id = $_GET['section_id'];
			$group_id = $_GET['group_id'];
			$subject_id = $_GET['subject_id'];
			$session_id = $_GET['session_id'];
			$term_id = $_GET['term_id'];
			$shift_id = $_GET['shift_id'];
			$exam_year = $_GET['exam_year'];
			$data['student_list'] = $this->Exam_model->get_class_wise_student_list_exam_hw($school_id,$class_id,$section_id,$group_id,$session_id,$shift_id,$term_id,$exam_year,$subject_id);
			
			$data_s['school_id']=$school_id;
			$data_s['class_id']=$class_id;
			$data_s['group_id']=$group_id;
			$data_s['subject_id']=$subject_id;
			$data_s['exam_type']=3;
			$data['mark_dis_info'] = $this->Common_model->common_select_by_multycondition($data_s, 'tbl_mark_distribution');
			
			$data['details'] =  array("class"=>$class_id,"section"=>$section_id,"group_id"=>$group_id,"subject_id"=>$subject_id,"session_id"=>$session_id,"term_id"=>$term_id,'exam_year'=>$exam_year);
			if($data['mark_dis_info'])
				$mainContent=$this->load->view('exam/set_hw_marks_json', $data, true);
			else
				$mainContent='<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>House Work marks was not assign for this subject. please assign marks from "setting > exam > exam setting > Marks Distribution System" </div>';
				
			$result = 'success';
			$return = array('result' => $result, 'mainContent'=> $mainContent);
			print json_encode($return);
			exit;   
    	}


		public function hw_marks_save(){
	    	#$school_id = $_SESSION['school_id'];
			$school_id = 1;
			$class_id = $_POST['class_id'];
			$section_id = $_POST['section_id'];
			$group_id = $_POST['group_id'];
			$session_id = $_POST['session_id'];
			$exam_year = $_POST['exam_year'];
			$term_id = $_POST['term_id'];
			$subject_id = $_POST['subject_id'];
			$status= 1;
		
			for($i=0; $i < count($_POST['hw_marks_id']); $i++)
			{
				if($_POST['hw_marks_id'][$i] > 0 ):
					$u_data[] = array (
									'hw_marks_id'=>$_POST['hw_marks_id'][$i],
									'obtained_marks'=>$_POST['obtain_marks'][$i]
								);
				else:
					$i_data[] = array (
									'school_id'=>$school_id,
									'class_id'=>$class_id,
									'section_id'=>$section_id,
									'group_id'=>$group_id,
									'session_id'=>$session_id,
									'exam_year'=>$exam_year,
									'term_id'=>$term_id,
									'subject_id'=>$subject_id,
									'student_id'=>$_POST['student_iddfsd'][$i],
									'obtained_marks'=>$_POST['obtain_marks'][$i],
									'status'=>$status
								);
				endif;
			}
			
			/* this will update old data*/
			if($u_data):
				if($this->Common_model->common_batch_update('tbl_hw_marks',$u_data,'hw_marks_id')):
					$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
				else:
					$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
				endif;
			endif;
			
			/* this will insert new data */
			if($i_data):
				if($this->Common_model->common_insert_batch($i_data,'tbl_hw_marks')):
					$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
				else:
					$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
				endif;
			endif;
				
			redirect('exam/set_hw_marks','refresh');
			exit;
	
	 	}
    
    /***  / HW ***/
	
	 /*** CT ***/
    
    	public function set_ct_marks(){
        #$school_id = $_SESSION['school_id'];
			$school_id = 1;
			$data['class_list'] = $this->Admin_model->get_class_list($school_id);
			$data['term_list'] =  $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
			$data['session_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
			$data['shift_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_shift');
        	$this->load->view('exam/set_ct_marks', $data);
    	}
	
	
    
    	public function get_student_list_for_ct_json(){
        	#$school_id = $_SESSION['school_id'];
			$school_id = 1;
			$class_id = $_GET['class_id'];
			$section_id = $_GET['section_id'];
			$group_id = $_GET['group_id'];
			$subject_id = $_GET['subject_id'];
			$session_id = $_GET['session_id'];
			$term_id = $_GET['term_id'];
			$shift_id = $_GET['shift_id'];
			$exam_year = $_GET['exam_year'];
			$data['student_list'] = $this->Exam_model->get_class_wise_student_list_exam_ct($school_id,$class_id,$section_id,$group_id,$session_id,$shift_id,$term_id,$exam_year,$subject_id);
			
			$data_s['school_id']=$school_id;
			$data_s['class_id']=$class_id;
			$data_s['group_id']=$group_id;
			$data_s['subject_id']=$subject_id;
			$data_s['exam_type']=4;
			$data['mark_dis_info'] = $this->Common_model->common_select_by_multycondition($data_s, 'tbl_mark_distribution');
			
			$data['details'] =  array("class"=>$class_id,"section"=>$section_id,"group_id"=>$group_id,"subject_id"=>$subject_id,"session_id"=>$session_id,"term_id"=>$term_id,'exam_year'=>$exam_year);
			if($data['mark_dis_info'])
				$mainContent=$this->load->view('exam/set_ct_marks_json', $data, true);
			else
				$mainContent='<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Class Test marks was not assign for this subject. please assign marks from "setting > exam > exam setting > Marks Distribution System" </div>';
				
			$result = 'success';
			$return = array('result' => $result, 'mainContent'=> $mainContent);
			print json_encode($return);
			exit;   
    	}
	
		public function ct_marks_save(){
	   		#$school_id = $_SESSION['school_id'];
			$school_id = 1;
			$class_id = $_POST['class_id'];
			$section_id = $_POST['section_id'];
			$group_id = $_POST['group_id'];
			$session_id = $_POST['session_id'];
			$exam_year = $_POST['exam_year'];
			$term_id = $_POST['term_id'];
			$subject_id = $_POST['subject_id'];
			$status= 1;
		
			for($i=0; $i < count($_POST['ct_marks_id']); $i++)
			{
				if($_POST['ct_marks_id'][$i] > 0 ):
					$u_data[] = array (
									'ct_marks_id'=>$_POST['ct_marks_id'][$i],
									'obtained_marks'=>$_POST['obtain_marks'][$i]
								);
				else:
					$i_data[] = array (
									'school_id'=>$school_id,
									'class_id'=>$class_id,
									'section_id'=>$section_id,
									'group_id'=>$group_id,
									'session_id'=>$session_id,
									'exam_year'=>$exam_year,
									'term_id'=>$term_id,
									'subject_id'=>$subject_id,
									'student_id'=>$_POST['student_iddfsd'][$i],
									'obtained_marks'=>$_POST['obtain_marks'][$i],
									'status'=>$status
								);
				endif;
			}
			
			/* this will update old data*/
			if($u_data):
				if($this->Common_model->common_batch_update('tbl_ct_marks',$u_data,'ct_marks_id')):
					$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
				else:
					$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
				endif;
			endif;
			
			/* this will insert new data */
			if($i_data):
				if($this->Common_model->common_insert_batch($i_data,'tbl_ct_marks')):
					$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
				else:
					$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
				endif;
			endif;
				
			redirect('exam/set_ct_marks','refresh');
			exit;
	
	 	}
    	
    /***  /CT ***/

	
/*****  Create assignment ****/
 
		public function assignment_list(){
			#$school_id = $_SESSION['school_id'];
			$school_id = 1;
			$data['class_list'] = $this->Admin_model->get_class_list($school_id);
			$data['term_list'] =  $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
			$data['assignment_list'] =  $this->Exam_model->get_assignment_list($school_id);
			$this->load->view('exam/assignment_list', $data);
	
		}   
		function create_assignment_save(){
			if(isPostBack()){
				#$school_id = $_SESSION['school_id'];
				$school_id = 1;
				$data['school_id'] = $school_id;
				$data['name'] = $_POST['assignment_name'];            
				$data['topic'] = $_POST['assignment_topic'];            
				$data['class_id'] = $_POST['class_id'];
				$data['section_id'] = $_POST['section_id'];
				$data['group_id'] = $_POST['group_id'];
				$data['sub_id'] = $_POST['sub_id'];
				$data['submission_date'] = $_POST['submission_date'];
				$data['term_id'] = $_POST['term_id'];
				$data['marks'] = $_POST['marks'];
				$data['created_on'] = date('Y-m-d H:i:s',time());
				
				if($this->Common_model->common_insert($data,'tbl_assignment'))		
				{
				$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
				}
				else
				{
					$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
				}
				
				redirect('exam/assignment_list','refresh');exit;  
			}
		}
    
		public function assignment_edit($id){
                 
            $data['assignment_info'] =$this->Common_model->common_select_by_condition($id,'id','tbl_assignment');
            $this->load->view('exam/assignment_edit', $data);
        }
        
        public function assignment_edit_save(){
          $id = $_POST['assignment_id'];  
			
			if(isPostBack()){
			
				$data['name'] = $_POST['assignment_name'];            
				$data['topic'] = $_POST['assignment_topic'];
				$data['submission_date'] = $_POST['submission_date'];
				$data['marks'] = $_POST['marks'];
				
				if($this->Common_model->common_update($data, $id,'id','tbl_assignment'))
				{
					$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
				}
				else
				{
					$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
				}       
					   redirect('exam/assignment_list','refresh');exit;
                
            }
        }
		
		
        public function assignment_delete($id){
			#$school_id = $_SESSION['school_id'];
			$school_id = 1;
			$d_data['school_id']=$school_id;
			$d_data['id']=$id;
			
			if($this->Common_model->common_delete($d_data,'tbl_assignment'))
			{
				$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
			}
			else
			{
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been deleted. Please try again.</div>');
			}
			redirect('exam/assignment_list','refresh');exit;
		}
// project marks entry section
		public function set_project_marks(){
      		$school_id = 1;
        	$data['class_list'] = $this->Admin_model->get_class_list($school_id);
			$data['term_list'] =  $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
			$data['session_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
			$data['shift_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_shift');
        	$this->load->view('exam/set_project_marks', $data);
  
  		}
		
		function project_list_ajax()
		{
			#$school_id = $_SESSION['school_id'];
			$data['school_id'] = 1;
			$data['class_id'] = $_POST['class_id'];
			$data['section_id'] = $_POST['section_id'];
			$data['group_id'] = $_POST['group_id'];
			$data['term_id'] = $_POST['term_id'];
			$data['sub_id'] = $_POST['subject_id'];
			  
			$ctInfo = $this->Common_model->common_select_by_multycondition($data,'tbl_assignment');
			
			$str = '<option value="">----Select Project/Assignment----</option>';
			if($ctInfo)
			{
			   foreach($ctInfo as $Info)
			   {
				  $str .= "<option value='".$Info['id']."'>".$Info['name']."</option>";
			   }
			}
			echo $str;exit;
			
		}

		function get_student_list_for_project_json(){
			#$school_id = $_SESSION['school_id'];
			$school_id = 1;
			$class_id = $_GET['class_id'];
			$section_id = $_GET['section_id'];
			$group_id = $_GET['group_id'];
			$subject_id = $_GET['subject_id'];
			$session_id = $_GET['session_id'];
			$term_id = $_GET['term_id'];
			$shift_id = $_GET['shift_id'];
			$exam_year = $_GET['exam_year'];
			$pa_id = $_GET['pa_id'];
			$data['student_list'] = $this->Exam_model->get_class_wise_student_list_exam_pa($school_id,$class_id,$section_id,$group_id,$session_id,$shift_id,$term_id,$exam_year,$subject_id,$pa_id);
			
			$data_s['school_id']=$school_id;
			$data_s['class_id']=$class_id;
			$data_s['group_id']=$group_id;
			$data_s['subject_id']=$subject_id;
			$data_s['exam_type']=5;
			$data['mark_dis_info'] = $this->Common_model->common_select_by_multycondition($data_s, 'tbl_mark_distribution');
			
			$data['assignment_info'] =$this->Common_model->common_select_by_condition($pa_id,'id','tbl_assignment');
			
			$data['details'] =  array("class"=>$class_id,"section"=>$section_id,"group_id"=>$group_id,"subject_id"=>$subject_id,"session_id"=>$session_id,"term_id"=>$term_id,'exam_year'=>$exam_year,'pa_id'=>$pa_id);
			if($data['mark_dis_info'])
				$mainContent=$this->load->view('exam/set_project_marks_json', $data, true);
			else
				$mainContent='<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Project marks was not assign for this subject. please assign marks from "setting > exam > exam setting > Marks Distribution System" </div>';
				
			$result = 'success';
			$return = array('result' => $result, 'mainContent'=> $mainContent);
			print json_encode($return);
			exit;
		}
  

		public function project_marks_save(){
	    #$school_id = $_SESSION['school_id'];
			$school_id = 1;
			$class_id = $_POST['class_id'];
			$section_id = $_POST['section_id'];
			$group_id = $_POST['group_id'];
			$session_id = $_POST['session_id'];
			$exam_year = $_POST['exam_year'];
			$term_id = $_POST['term_id'];
			$subject_id = $_POST['subject_id'];
			$pa_id = $_POST['pa_id'];
			$status= 1;
		
			for($i=0; $i < count($_POST['pa_marks_id']); $i++)
			{
				if($_POST['pa_marks_id'][$i] > 0 ):
					$u_data[] = array (
									'pa_marks_id'=>$_POST['pa_marks_id'][$i],
									'obtained_marks'=>$_POST['obtain_marks'][$i]
								);
				else:
					$i_data[] = array (
									'school_id'=>$school_id,
									'class_id'=>$class_id,
									'section_id'=>$section_id,
									'group_id'=>$group_id,
									'session_id'=>$session_id,
									'exam_year'=>$exam_year,
									'term_id'=>$term_id,
									'subject_id'=>$subject_id,
									'student_id'=>$_POST['student_iddfsd'][$i],
									'obtained_marks'=>$_POST['obtain_marks'][$i],
									'status'=>$status,
									'pa_id'=>$pa_id
								);
				endif;
			}
			
			/* this will update old data*/
			if($u_data):
				if($this->Common_model->common_batch_update('tbl_assignment_marks',$u_data,'pa_marks_id')):
					$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
				else:
					$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
				endif;
			endif;
			
			/* this will insert new data */
			if($i_data):
				if($this->Common_model->common_insert_batch($i_data,'tbl_assignment_marks')):
					$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
				else:
					$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
				endif;
			endif;
				
			redirect('exam/set_project_marks','refresh');
			exit;
	
	 	}

/******************* / Project *****************/

	
	/*** Term  ***/
		function term_list(){
			#$school_id = $_SESSION['school_id'];
			$school_id = 1;
			$data['term_list'] =  $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
			$this->load->view('exam/term_list', $data);
		
		}
		public function create_term_save(){
			if(isPostBack()){
				#$school_id = $_SESSION['school_id'];
				if(isset($_POST['year_end_exam']))
				{
					$year_end_exam=1;
				}
				else
				{
					$year_end_exam=0;
				}
				
				$school_id = 1;
				$data['school_id'] = $school_id;
				$data['term'] = $_POST['term_name'];
				$data['year_end_exam'] = $year_end_exam;
				$data['created_on'] = date('Y-m-d H:i:s',time());
				if($this->Common_model->common_insert($data,'tbl_term'))
				{
					$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
				}
				else
				{
					$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
				}       
				redirect('exam/term_list','refresh');exit;  
			}
		}
    
	

        public function term_delete($id){
			#$school_id = $_SESSION['school_id'];
			$d_data['school_id'] = 1;
			$d_data['term_id'] = $id;
			if($this->Common_model->common_delete($d_data,'tbl_term'))
				{
					$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
				}
				else
				{
					$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been deleted. Please try again.</div>');
				}
			 
			redirect('exam/term_list','refresh');exit;
    	}
	
		
        public function term_edit($id){
                     
            $data['term_list'] =$this->Common_model->common_select_by_condition($id,'term_id','tbl_term');

		 	$this->load->view('exam/term_edit', $data);
        }
        
        public function term_edit_save(){
          	$id = $_POST['term_id'];  
			
			if(isPostBack()){
				if(isset($_POST['year_end_exam']))
				{
					$year_end_exam=1;
				}
				else
				{
					$year_end_exam=0;
				}
            $data['term'] = $_POST['term_name']; 
			$data['year_end_exam'] = $year_end_exam;           
			if($this->Common_model->common_update($data, $id,'term_id','tbl_term')) 
			{
				$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
			}
			else
			{
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been deleted. Please try again.</div>');
			}
			  
            redirect('exam/term_list','refresh');exit;
               
            }
        }
		
		// term merks section
		function set_term_marks(){
		  	$school_id = 1;
		  	$data['class_list'] = $this->Admin_model->get_class_list($school_id);
			$data['term_list'] =  $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
			$data['session_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
			$data['shift_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_shift');
        	$this->load->view('exam/set_term_marks', $data);
	  	}
		
		function get_student_list_for_term_json(){
			#$school_id = $_SESSION['school_id'];
			$school_id = 1;
			$session_id = $_GET['session_id'];
			$class_id = $_GET['class_id'];
			$section_id = $_GET['section_id'];
			$group_id = $_GET['group_id'];
			$shift_id = $_GET['shift_id'];
			$term_id = $_GET['term_id'];
			$exam_year = $_GET['exam_year'];
			$subject_id = $_GET['subject_id'];
			$term_name = $_GET['term_name'];
			$details_data = $_GET['details_data'];
			// get  subject details
			$data['subject_info']=$this->Common_model->common_row_by_condition($subject_id,'subject_id','tbl_subject');
			// religion subject array
			$religion=array('111'=>'Islam','112'=>'Hinduism','113'=>'Christianity','114'=>'Buddhism');
			// gender subject check array
			$option_sub=array('13'=>'Higher Mathematics','14'=>'Agriculture Studies', '25'=>'Biology', '15'=>'Home Science', '43'=>'Home Science (Nine-Ten)', '44'=>'Agriculture Studies (Nine-Ten)',);

			if($religion[$data['subject_info']['subject_code']]){
				$data['student_list'] = $this->Exam_model->get_class_wise_student_list_exam_term($school_id, $class_id,$section_id,$group_id,$shift_id,$session_id,$term_id,$subject_id,$exam_year,'religion',$data['subject_info']['subject_code']);
			}
			elseif($data['subject_info']['is_optional'] == 1){
				$data['student_list'] = $this->Exam_model->get_class_wise_student_list_exam_term($school_id, $class_id,$section_id,$group_id,$shift_id,$session_id,$term_id,$subject_id,$exam_year,'option_sub',$data['subject_info']['subject_id']);
			}
			else{
				$data['student_list'] = $this->Exam_model->get_class_wise_student_list_exam_term($school_id, $class_id,$section_id,$group_id,$shift_id,$session_id,$term_id,$subject_id,$exam_year,'','');
			}

			$data['sml'] = $this->Exam_model->subject_wise_total_marks_class_wise($school_id,$subject_id,$class_id);
			$data['details'] = array("class"=>$class_id,"section"=>$section_id,"term"=>$term_id,"term_name"=>$term_name,"exam_year"=>$exam_year,'subject_id'=>$subject_id,'group_id'=>$group_id,'shift_id'=>$shift_id,'session_id'=>$session_id,"details_data"=>$details_data);
		
				$mainContent=$this->load->view('exam/set_term_marks_json', $data, true);
			
			$result = 'success';
			$return = array('result' => $result, 'mainContent'=> $mainContent);
			print json_encode($return);
			exit;   
  
  		}

		public function term_marks_save(){
			
			#$school_id = $_SESSION['school_id'];
			$school_id = 1;
			$class_id = $_POST['class_id'];
			$section_id = $_POST['section_id'];
			$group_id = $_POST['group_id'];
			$session_id = $_POST['session_id'];
			$exam_year = $_POST['exam_year'];
			$term_id = $_POST['term_id'];
			$subject_id = $_POST['subject_id'];
			$status= 1;
		
			for($i=0; $i < count($_POST['student_iddfsd']); $i++)
			{
				if($_POST['term_marks_id'][$i] > 0 ):
					$u_data[] = array (
									'term_marks_id'=>$_POST['term_marks_id'][$i],
									'subjective_marks'=>$_POST['subjective_marks'][$i],
									'objective_marks'=>$_POST['objective_marks'][$i],
									'practical_marks'=>$_POST['practical_marks'][$i]
								);
				else:
					$i_data[] = array (
									'school_id'=>$school_id,
									'class_id'=>$class_id,
									'section_id'=>$section_id,
									'group_id'=>$group_id,
									'session_id'=>$session_id,
									'exam_year'=>$exam_year,
									'term_id'=>$term_id,
									'subject_id'=>$subject_id,
									'student_id'=>$_POST['student_iddfsd'][$i],
									'subjective_marks'=>$_POST['subjective_marks'][$i],
									'objective_marks'=>$_POST['objective_marks'][$i],
									'practical_marks'=>$_POST['practical_marks'][$i],
									'status'=>$status
								);
				endif;
			}
			
			/* this will update old data*/
			if($u_data):
				if($this->Common_model->common_batch_update('tbl_term_marks',$u_data,'term_marks_id')):
					$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
				else:
					$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
				endif;
			endif;
			
			/* this will insert new data */
			if($i_data):
				if($this->Common_model->common_insert_batch($i_data,'tbl_term_marks')):
					$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
				else:
					$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
				endif;
			endif;
				
			redirect('exam/set_term_marks','refresh');
			exit;
		
		}
      
      /*** /Term  ***/
	  
	
	
	  /********************* exam routine *********************/
    
		public function set_exam_time()
		{
			$s_data['school_id'] = 1;
			$data['exam_time']=$this->Common_model->common_select_by_multycondition($s_data,'tbl_exam_time');
			$this->load->view('exam/set_exam_time', $data);
		}
    
		// this is for both entry save and update save
		public function save_exam_timing()
		{
			#$school_id = $_SESSION['school_id'];
			
			$data['school_id'] = 1;
			$data['exam_time'] = $_POST['timerange'];
			$data['status']=1;
			if($_POST['id'])
			{
				$success= $this->Common_model->common_update($data, $_POST['id'],'id','tbl_exam_time');   
			}
			else
			{
				$success=$this->Common_model->common_insert($data,'tbl_exam_time');
			}
			
			if($success)
			{
				$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
			}
			else
			{
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
			}
			redirect('exam/set_exam_time');				
		}
	
	public function exam_routine()
	{
		$school_id = 1;
		$data['class_list'] = $this->Admin_model->get_class_list($school_id);
		$data['term_list'] 	= $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
		$data['session_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
		$this->load->view('exam/exam_routine', $data);
	}
    
	public function exam_routine_json()
	{
		$school_id 	= 1;
		$class_id	= $_GET['class_id'];
		$section_id	= $_GET['section_id'];
		$group_id	= $_GET['group_id'];
		$session_id	= $_GET['session_id'];

		$data['exam_time']	= $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_exam_time');
		$data['subject']	= $this->Academic_model->get_class_wise_subject_list($class_id,$group_id,$school_id);
		if($data['exam_time'] && $data['subject'])
			$mainContent=$this->load->view('exam/exam_routine_json', $data, true);
		else
			$mainContent='<b>NB :</b>Either no subject assigned for this class or no exam time set. Please go to setting->subject->subject assign to assign subject or setting -> exam -> exam setting -> set term exam time to set exam time.';
		$result = 'success';
		$return = array('result' => $result, 'mainContent'=> $mainContent);
		print json_encode($return);
		exit;

	}
 
    public function save_exam_routine()
	{
		$d_data['school_id']	= 1;
        $d_data['class_id'] 	= $_POST['class_id'];
        $d_data['group_id'] 	= $_POST['group_id'];
        $d_data['section_id'] 	= $_POST['section_id'];
		$d_data['exam_term_id'] = $_POST['term_id'];
		$final_data				= $_POST['final_routine'];
		
		$this->Common_model->common_delete($d_data,'tbl_exam_routine');
		
		if($this->Common_model->common_insert_batch($final_data,'tbl_exam_routine'))
		{
			echo '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>';
		}else{
			echo '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>';
		}
		exit;
	}
    
    public function show_exam_routine()
    {
         #$school_id = $_SESSION['school_id'];
       $school_id = 1;
        //$data['class_count'] = $this->Admin_model->exam_show_get_class_count($school_id);
		 $data['term_list'] = $this->Academic_model->get_term_list($school_id);
         $data['subject_count']= $this->Academic_model->exam_get_subject_count($school_id);
		$data['count']= $this->Academic_model->exam_get_class_count($school_id);
         $data['exam_time'] = $this->Academic_model->exam_routine_time($school_id);
		$data['subject']= $this->Admin_model->get_subject_list($school_id);
		//$c1 = $count['count'];
        $this->load->view('exam/show_exam_routine', $data);
    }
    
     public function show_exam_routine_download()
    {
         #$school_id = $_SESSION['school_id'];
       $school_id = 1;
       $term_id=$_POST['term_id'];
	   $data['school_info'] = $this->Academic_model->admit_card_view_school($school_id);
       $data['column_no'] = $this->Academic_model->exam_show_get_class_count($school_id,$term_id);
       $data['row_no'] = $this->Academic_model->exam_show_get_day_count($school_id,$term_id);
       $data['full_routine']= $this->Academic_model->get_old_exam_routine_by_term_download($school_id,$term_id);
       $data['routine_class']= $this->Academic_model->get_old_exam_routine_by_term_download_class($school_id,$term_id);
       $data['routine_day_date']= $this->Academic_model->get_old_exam_routine_by_term_download_day_date($school_id,$term_id);
       $this->load->view('exam/show_exam_routine_download', $data);
    }
    

    public function get_old_exam_routine_by_term()
	{
    	#$school_id = $_SESSION['school_id'];
     	$school_id 		= 1;
		$class_id 		= $_GET['class_id'];
		$exam_term_id 	= $_GET['exam_term_id'];
		$section_id 	= $_GET['section_id'];
		$group_id 		= $_GET['group_id'];
		$session_id 	= $_GET['session_id'];
		$data = $this->Academic_model->get_old_exam_routine_by_term($class_id,$exam_term_id,$section_id,$group_id,$session_id);
		print json_encode($data);
        exit;   
	}
    
    public function get_old_exam_routine_by_term_show()
	{
     	#$school_id = $_SESSION['school_id'];
     	$school_id = 1;
		$id = $_GET['id'];
		$data= $this->Academic_model->get_old_exam_routine_by_term_show($id);
		 print json_encode($data);
        exit;   
	}
    
    public function structure_exam_routine_by_term()
    {
    	#$school_id = $_SESSION['school_id'];
     	$school_id = 1;
        $exam_term_id = $_POST['exam_term_id'];
        $column_no = $this->Academic_model->exam_show_get_class_count($school_id,$exam_term_id);
        $row_no = $this->Academic_model->exam_show_get_day_count($school_id,$exam_term_id);
        
       // print_r($column_no); die();
        $table='<table class="table table-striped table-bordered"><thead><tr style="border-top:1px;"><th colspan="2"></th>';
        foreach ($column_no as $col_no)
				{
				$table.='<th id="exam_class_id" class="class_id'.$col_no['column_no'].'"></th>';
				}
                
        $table.='</tr><tr rowspan="2"><th style="min-width:125px; max-width:150px;">Exam Date</th><th style="min-width:125px; max-width:150px;">Exam Day</th>';
				foreach ($column_no as $col_no1)
				{
				 $table.='<th class="exam_time'.$col_no1['column_no'].'"></th>';
				}
				$table.='</tr></thead><tbody>';
				
				for($itdday=0; $itdday< $row_no;)
				{
					
					$table.='<tr class="date countvalue" id="'.$itdday.'"><td class="date'.$itdday.'"></td><td class="wkday'.$itdday.'"></td>';
					foreach ($column_no as $col_no2)
					{
						$table.='<td class="sub'.$col_no2['column_no'].'"></td>';
					}
					$table.='</tr>';
					$itdday++;
				}
				$table.='</tbody></table>';
        
        
		echo $table;
		exit;
    
    }
    
    /*************** /exam routine ***************/
	
	 /************ admit card ****************/
	
	public function admit_card_initial()
	{
		$school_id = 1;           
		#$data['student_info'] = $this->Admin_model->get_student_info_by_id($school_id, $student_id);
		$data['term_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
		$data['session_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
		$data['class_list'] = $this->Admin_model->get_class_list($school_id);
		$this->load->view('exam/admit_card_initial', $data);
    }
	
	public function admitcard_student_list_json()
	{
		$school_id	= 1;
        $class_id 	= $_GET['class_id'];
		$session_id = $_GET['session_id'];
		$section_id = $_GET['section_id'];
		$group_id 	= $_GET['group_id'];
		$exam_date 	= date('Y-m',strtotime($_GET['exam_date'])).'-01';
		
		$data['student_list'] = $this->Exam_model->class_wise_student_list_for_admit($school_id, $class_id, $session_id, $section_id, $group_id);
        
		$mainContent=$this->load->view('exam/admitcard_student_list_json', $data, true);
                
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
	}
	
    public function print_admit_card()
	{
        $school_id 	= 1;
        $class_id 	= $_GET['class_id'];
		$session_id = $_GET['session_id'];
		$section_id = $_GET['section_id'];
		$group_id = $_GET['group_id'];
		$term_id 	= $_GET['term_id'];
		$student_id = "('" . implode("','", $_GET['student_id']) . "')";
		
		$data['student_info']	= $this->Exam_model->get_class_wise_student_list_admit_print($school_id, $class_id, $session_id,$section_id, $group_id, $student_id);
		$exam_routine 			= $this->Exam_model->get_class_wise_exam_routine($school_id, $class_id,$section_id, $group_id, $term_id, $session_id);
		$data['exam_routine']	= array_chunk($exam_routine, 2);

		$s_data['school_id']	= $school_id;
		$s_data['term_id']		= $term_id;
		$d_data['session_id']	= $session_id;
		$data['exam_year'] 		= date('Y',strtotime($_GET['exam_date']));
        $data['term'] 			= $this->Common_model->common_select_by_multycondition($s_data,'tbl_term');
        $data['session'] 		= $this->Common_model->common_select_by_multycondition($d_data,'tbl_session');
		$data['school'] 		= $this->Common_model->common_row_by_condition($school_id,'school_id','tbl_school_information');
		//$mainContent=$data['school'];
		$mainContent	= $this->load->view('exam/print_admit_card_json', $data, true);
        $logo			= $data['school']['logo'];
        $result 		= 'success';
        $return 		= array('result' => $result, 'mainContent'=> $mainContent,'logo'=>$logo);
        print json_encode($return);
        exit;
	}
        

	/************** /admit card ***************/

  
  /************* subject wise marks *************/
    
    public function subject_wise_total_marks_list(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['class_list'] = $this->Admin_model->get_class_list($school_id);
        $data['subject_marks_list'] = $this->Exam_model->subject_wise_total_marks($school_id);
        $data['term_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
        $this->load->view('exam/subject_wise_total_marks_list', $data);
    }
    
    public function get_mark_box_json()
	{
  #$school_id = $_SESSION['school_id'];
        $s_data['school_id'] = 1;
        $s_data['subject_id'] = $_GET['subject_id'];
		//echo $exam_year; die();
        $data['subject_info'] = $this->Common_model->common_select_by_multycondition($s_data,'tbl_subject');
		$mainContent=$this->load->view('exam/get_mark_box_json', $data, true);
        
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
  
  	}
	function subject_list_mark_ajax()
    {
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
		$group_id = $_POST['group_id'];
		$term_id = $_POST['term_id'];
        
		$mark_sub = $this->Exam_model->get_subject_marks_list_by_class_group($school_id,$class_id,$group_id,$term_id);
		if($mark_sub){
			$created=$mark_sub['sub'];
		}
		else{
			$created="''";
		}
        $subInfo = $this->Exam_model->get_sub_list_by_id_mark_dist($class_id, $school_id,$group_id,$created); 
		$str = '<option value="">----Select Subject----</option>';
        
		if($subInfo)
        {
           foreach($subInfo as $sInfo)
           {
              $str .= "<option value='".$sInfo['subject_id']."'>".$sInfo['subject_name']."</option>";
           }
        }
        echo $str;exit;
    }

   function subject_wise_total_marks_save(){
        
        if(isPostBack()){
            #$school_id = $_SESSION['school_id'];
			if($_POST['subjective_marks']){$sub=$_POST['subjective_marks'];}else{$sub=0;}
			if($_POST['objective_marks']){$obj=$_POST['objective_marks'];}else{$obj=0;}
			if($_POST['practical_marks']){$prac=$_POST['practical_marks'];}else{$prac=0;}
			if($_POST['term_id']){$term_id=$_POST['term_id'];}else{$term_id=0;}

            $school_id = 1;
			$data['school_id'] = $school_id;
            $data['class_id'] = $_POST['class_id'];
            $data['section_id'] = 0; //$_POST['section_id'];
			$data['group_id'] = $_POST['group_id'];
            $data['subject_id'] = $_POST['subject_id'];
            $data['term_id'] = $term_id;
            $data['subjective_marks'] = $sub;
            $data['objective_marks'] = $obj;
            $data['practical_marks'] = $prac;
			$data['pass_marks'] = $_POST['pass_marks'];
            $data['status'] = 1 ;
			
			//print_r($data); die();
            if($this->Common_model->common_insert($data,'tbl_subject_wise_total_marks'))
			{
				$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
			}
			else
			{
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
			}
			redirect('exam/subject_wise_total_marks_list','refresh');
            exit;  
        }
    }
    
    
    public function subject_wise_total_marks_edit($subject_marks_id){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
       $data['subject_marks_list'] = $this->Exam_model->subject_wise_total_marks_by_id($school_id,$subject_marks_id);
       $this->load->view('exam/subject_wise_total_marks_edit', $data);
    }
    
    
    function subject_wise_total_marks_edit_save(){
          $subject_marks_id = $_POST['subject_marks_id'];  
			
			if(isPostBack()){
			 #$school_id = $_SESSION['school_id'];

				$data['subjective_marks'] = $_POST['subjective_marks'];
				$data['objective_marks'] = $_POST['objective_marks'];
				$data['practical_marks'] = $_POST['practical_marks'];
				$data['pass_marks'] = $_POST['pass_marks'];
							
				if($this->Common_model->common_update($data, $subject_marks_id,'subject_marks_id','tbl_subject_wise_total_marks'))
				{
					$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
				}
				else
				{
					$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
				}
           		redirect('exam/subject_wise_total_marks_list', 'refresh');
				exit;
            }
        }
    
     function subject_wise_total_marks_delete($subject_marks_id){
     	#$school_id = $_SESSION['school_id'];
        $d_data['school_id'] = 1;
		$d_data['subject_marks_id'] = $subject_marks_id;
        if($this->Common_model->common_delete($d_data,'tbl_subject_wise_total_marks'))
            {
				$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
			}
		else
			{
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been deleted. Please try again.</div>');
			}
        
		redirect('exam/subject_wise_total_marks_list', 'refresh');
		exit;
    }
    
 
	
    /************* / subject wise marks *************/
	
	/*** term subject marks **
   
    public function term_subject_list(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['class_list'] = $this->Admin_model->get_class_list($school_id);
        $data['term_sub_list'] = $this->Academic_model->get_term_subject_list($school_id);
        $data['term_list'] = $this->Academic_model->get_term_list($school_id);
        $this->load->view('academic/term_subject_list', $data);
    }
    
    
     function create_term_subject_save(){
        
        if(isPostBack()){
            #$school_id = $_SESSION['school_id'];
            $school_id = 1;
			$data['school_id'] = $school_id;
            $data['class_id'] = $_POST['class_id'];
            $data['group_id'] = $_POST['group_id'];
            $data['term_id'] = $_POST['term_id'];
            $data['subject_id'] = $_POST['subject_id'];
			$data['sub_full_marks'] = $_POST['full_marks'];
			$data['pass_marks'] = $_POST['pass_marks'];
            $data['status'] = 1;
            $data['created_on'] = date('Y-m-d H:i:s',time());
            $this->Common_model->common_insert($data,'tbl_term_subject');
			
			 $this->session->set_flashdata('message', " New term subject has been saved ");
			
			redirect('academic/term_subject_list','refresh');
            exit;  
        }
    }
    
    
    public function term_subject_edit($ts_id){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
         $data['class_list'] = $this->Admin_model->get_class_list($school_id);
        $data['term_sub_list'] = $this->Academic_model->get_term_subject_info_by_id($school_id, $ts_id);
        $data['term_list'] = $this->Academic_model->get_term_list($school_id);
        //$data['section_list'] = $this->Admin_model->get_section_list($school_id);
		$data['group_list'] = $this->Admin_model->get_group_list($school_id);
        $this->load->view('academic/term_subject_edit', $data);
    }
    
    
    function edit_term_subject_save(){
          $id = $_POST['id'];  
			
			if(isPostBack()){
			 #$school_id = $_SESSION['school_id'];
            $school_id = 1;
            $data['school_id'] = $school_id;
            $data['class_id'] = $_POST['class_id'];
            $data['group_id'] = $_POST['group_id'];
            $data['term_id'] = $_POST['term_id'];
            $data['subject_id'] = $_POST['subject_id'];
			$data['sub_full_marks'] = $_POST['full_marks'];
			$data['pass_marks'] = $_POST['pass_marks'];
            $data['status'] = 1;
            $data['created_on'] = date('Y-m-d H:i:s',time());
            			
			$this->Common_model->common_update($data, $id,'id','tbl_term_subject');
            
                $this->session->set_flashdata('message', " Term subject has been updated successfully ");       
                    redirect('academic/term_subject_list', 'refresh');exit;
                
            }
        }
    
    function term_subject_delete($id){
            #$school_id = $_SESSION['school_id'];
            $school_id = 1;
            $this->Common_model->condition_delete($data,$id,'id','tbl_term_subject');
                $this->session->set_flashdata('message', " Term subject has been deleted successfully </div>");  
            redirect('academic/term_subject_list', 'refresh');exit;
    }*/
    
   /*************** GPA System *************/ 
  public function gpa_system(){
        #$school_id = $_SESSION['school_id'];
        $data1['school_id'] = 1;
		$data['gpa_list'] = $this->Common_model->common_select_by_multycondition($data1,'tbl_grd_system');
        $this->load->view('exam/gpa_system', $data);
    }
	
	
    
    public function grd_system_json(){
        #$school_id = $_SESSION['school_id'];
        $data1['school_id'] = 1;
		$data1['type_id'] = $_GET['type_id'];
		
		$data['old_value']=$this->Common_model->common_select_by_multycondition($data1,'tbl_grd_system');
        $data['details'] =  array("type_id"=>$_GET['type_id']);
		$mainContent=$this->load->view('exam/grd_system_json', $data, true);
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
    }
	
	  public function grade_scale_save(){
	    #$school_id = $_SESSION['school_id'];
        $school_id = 1;
		$type_id = $_POST['type_id'];
		$i=0;
		while($i<count($_POST['start_marks'])){

			$data[] = array(
						'school_id' => $school_id,
						'type_id' => $type_id,
						'start_marks' => $_POST['start_marks'][$i],
						'end_marks' => $_POST['end_marks'][$i],
						'grd_point' => $_POST['grd_point'][$i],
						'gpa' => $_POST['gpa'][$i],
						'comments' => $_POST['comments'][$i]
						);
		$i++;
		}
			
		if($data)
			{
				$d_data['school_id']=$school_id;
				$d_data['type_id']=$type_id;
				
				$this->Common_model->common_delete($d_data,'tbl_grd_system');
				
				if($this->Common_model->common_insert_batch($data,'tbl_grd_system'))
					{
						$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
					}
					else
					{
						$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
					}
		
			}
		redirect('exam/gpa_system','refresh');exit;
	 }
	  
	
		/************ / GPA system ************/
		
		/************ Mark Distribution System ************/
    public function mark_distribution_system(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['class_list'] = $this->Admin_model->get_class_list($school_id);
        $data['mark_distribution_list'] = $this->Exam_model->mark_distribution_list($school_id);
        $this->load->view('exam/mark_distribution_system', $data);
    }
    
	function subject_list_mark_dist_ajax()
    {
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
		$group_id = $_POST['group_id'];
        
		$mark_sub = $this->Exam_model->get_marks_list_by_class_group($school_id,$class_id,$group_id); 
		if($mark_sub['sub'])
			$subInfo = $this->Exam_model->get_sub_list_by_id_mark_dist($class_id, $school_id,$group_id,$mark_sub['sub']); 
        else
			$subInfo = $this->Exam_model->get_sub_list_by_id_mark_dist($class_id, $school_id,$group_id,0); 
		$str = '<option value="">----Select Subject----</option>';
        
		if($subInfo)
        {
           foreach($subInfo as $sInfo)
           {
              $str .= "<option value='".$sInfo['subject_id']."'>".$sInfo['subject_name']."</option>";
           }
        }
        echo $str;exit;
    }
	
	 public function mark_distribution_system_json(){
        #$school_id = $_SESSION['school_id'];
        $data_s['school_id'] = 1;
        $data_s['class_id'] = $_GET['class_id'];
		$data_s['group_id'] = $_GET['group_id'];
		$data_s['subject_id'] = $_GET['subject_id'];
		
		$data['mark_dis_info'] = $this->Common_model->common_select_by_multycondition($data_s, 'tbl_mark_distribution');
        $data['details'] =  array("class_id"=>$_GET['class_id'],"group_id"=>$_GET['group_id'],"subject_id"=>$_GET['subject_id']);
					
	
					$mainContent=$this->load->view('exam/mark_distribution_system_json', $data, true);
        
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
    }
	
	 public function mark_distribution_system_save(){
	    #$school_id = $_SESSION['school_id'];
        $school_id = 1;
		$class_id = $_POST['class_id'];
		$group_id = $_POST['group_id'];
		$subject_id = $_POST['subject_id'];
		
		$i=0;
		while($i<count($_POST['exam_type'])){
			$exam_type=explode(',',$_POST['exam_type'][$i]);
			$data[] = array(
						'school_id' => $school_id,
						'class_id' => $class_id,
						'group_id' => $group_id,
						'subject_id' => $subject_id,
						'exam_type' => $exam_type[0],
						'exam_short_name' => $exam_type[1],
						'exam_name' => $exam_type[2],
						'term_mark_per' => $_POST['term_mark_per'][$i],
						'status' => 1
						);
						
			$i++;
			}
	
		if($data)
			{
				$d_data['school_id'] = $school_id;
				$d_data['class_id'] = $class_id;
				$d_data['group_id'] = $group_id;
				$d_data['subject_id'] = $subject_id;
				
				$this->Common_model->common_delete($d_data,'tbl_mark_distribution');
				
				if($this->Common_model->common_insert_batch($data,'tbl_mark_distribution'))
					{
						$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
					}
					else
					{
						$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
					}
		
			}
			
		redirect('exam/mark_distribution_system','refresh');exit;
	
	 	}

	public function mark_distribution_system_delete($class_id,$group_id,$subject_id)
	{
		$d_data['school_id'] = 1;
		$d_data['class_id'] = $class_id;
		$d_data['group_id'] = $group_id;
		$d_data['subject_id'] = $subject_id;
		
		$this->Common_model->common_delete($d_data,'tbl_mark_distribution');
		redirect('exam/mark_distribution_system','refresh');exit;
	}

	
    /***  /mark ***/
	
	 /***  tabulation sheet subject wise ***/
	public function tabulation_sheet_subject_wise()
      {
      #$school_id = $_SESSION['school_id'];
       $school_id = 1;
       $data['class_list'] = $this->Admin_model->get_class_list($school_id);
       $data['term'] = $this->Academic_model->get_term_list($school_id); 
		$data['shift_list'] = $this->Academic_model->get_shift_list($school_id);
      $this->load->view('academic/tabulation_sheet_subject_wise',$data);
      }
	public function tabulation_marks_subject_wise_json()
	{
  #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_GET['class_id'];
		$section_id = $_GET['section_id'];
		$group_id = $_GET['group_id'];
		$shift_id = $_GET['shift_id'];
		$subject_id = $_GET['subject_id'];
		$term_id = $_GET['term_id'];
        $exam_year = $_GET['exam_year'];
		$passing_id = $_GET['passing_id'];
		$type_id = $_GET['type_id'];
		
		$data['subject_infos'] = $this->Academic_model->subject_info_for_tabulation_sheet_subject_wise($school_id,$term_id,$exam_year,$class_id,$section_id,$subject_id);
		$data['school_infos'] = $this->Academic_model->admit_card_view_school($school_id);
        $data['student_list']=$this->Academic_model->get_class_wise_student_list($school_id,$class_id,$section_id,$group_id,$shift_id);
        $data['term']=$this->Academic_model->get_term_list_by_id($term_id,$school_id);
		$data['details']=array("class_id"=>$class_id,"section_id"=>$section_id,"subject_id"=>$subject_id,"term_id"=>$term_id,"exam_year"=>$exam_year,"school_id"=>$school_id,"group_id"=>$group_id,"shift_id"=>$shift_id,"passing_id"=>$passing_id,"type_id"=>$type_id);
		$mainContent=$this->load->view('academic/tabulation_marks_subject_wise_json', $data, true);
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
  }
  public function tabulation_marks_subject_wise_print()
	{
  #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
		$section_id = $_POST['section_id'];
		$group_id = $_POST['group_id'];
		$shift_id = $_POST['shift_id'];
		$subject_id = $_POST['subject_id'];
		$term_id = $_POST['term_id'];
        $exam_year = $_POST['exam_year'];
		 $passing_id = $_POST['passing_id'];
		 $type_id = $_POST['type_id'];
		
        $data['subject_infos'] = $this->Academic_model->subject_info_for_tabulation_sheet_subject_wise($school_id,$term_id,$exam_year,$class_id,$section_id,$subject_id);
		 $data['school_infos'] = $this->Academic_model->admit_card_view_school($school_id);
		$data['student_list']=$this->Academic_model->get_class_wise_student_list($school_id,$class_id,$section_id,$group_id,$shift_id);
        $data['term']=$this->Academic_model->get_term_list_by_id($term_id,$school_id);
		$data['details']=array("class_id"=>$class_id,"section_id"=>$section_id,"subject_id"=>$subject_id,"term_id"=>$term_id,"exam_year"=>$exam_year,"school_id"=>$school_id,"group_id"=>$group_id,"shift_id"=>$shift_id,"passing_id"=>$passing_id,"type_id"=>$type_id);
		$this->load->view('academic/tabulation_marks_subject_wise_print', $data);
        
  }
  
   public function marks_status_change()
 {
	  	$school_id = $_POST['school_id'];
        $class_id = $_POST['class_id'];
		$section_id = $_POST['section_id'];
		$group_id = $_POST['group_id'];
		$shift_id = $_POST['shift_id'];
		$subject_id = $_POST['subject_id'];
		$term_id = $_POST['term_id'];
        $exam_year = $_POST['exam_year'];
		$status = $_POST['status'];
		
		$data_term = array ('status'=>$status);
	            $where_term = array("class_id"=>$class_id,"section_id"=>$section_id,"sub_id"=>$subject_id,"term_id"=>$term_id,"exam_year"=>$exam_year,"school_id"=>$school_id,"group_id"=>$group_id,"shift_id"=>$shift_id,"status"=>0);		
				 $this->db->where($where_term);
                $this->db->update('tbl_term_marks', $data_term);
				
		$data = array ('status'=>$status);
	            $where = array("class_id"=>$class_id,"section_id"=>$section_id,"subject_id"=>$subject_id,"term_id"=>$term_id,"exam_year"=>$exam_year,"school_id"=>$school_id,"group_id"=>$group_id,"shift_id"=>$shift_id,"status"=>0);
                $this->db->where($where);
                $this->db->update('tbl_ct_marks', $data);
		
		
				
				 $this->session->set_flashdata('message', " Final submition successful ");
		redirect('school/tabulation_sheet_subject_wise','refresh');exit;  
 }
 

	function mock_admission()
    {       
		$school_id 			= 1;
		$data['results'] 	= $this->Admission_result_model->get_admission_list($school_id);
		$this->load->view('exam/admission',$data);
    }
	
    function admission_marks_save()
    {
		$school_id 	= 1;
		$total_mark = 100;
		$pass_mark 	= 33;
		$status		= 1;
		$exam_year	= '2019';
		$exam_date	= '2019-01-06';
		
			for($i=0; $i < count($_POST['roll_no']); $i++)
			{
				
				$i_data[] = array (
								'school_id'	=>$school_id,
								'exam_roll'	=>$_POST['roll_no'][$i],
								'total_mark'=>$total_mark,
								'pass_mark'	=>$pass_mark,
								'get_mark'	=>$_POST['marks'][$i],
								'exam_year'	=>$exam_year,
								'exam_date'	=>$exam_date
							);
			}
			
			$this->db->truncate('tbl_mock_admission');
			/* this will insert new data */
			if($i_data):
				if($this->Common_model->common_insert_batch($i_data,'tbl_mock_admission')):
					$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
				else:
					$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
				endif;
			endif;
				
			redirect('mock_admission','refresh');
			exit;
    }
  
  
 	/*** / tabulation sheet subject wise ***/ 
	
	
	
}