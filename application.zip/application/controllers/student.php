<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Student extends CI_Controller {

    public function __construct()
        {
            //session_start();
            parent::__construct();
            $this->load->helper('form');
            $this->load->helper('url');
            $this->load->model('admin_model', 'Admin_model', true);
            $this->load->model('common_model', 'Common_model', true);
            
            if(!is_student_loggedin())
            {
                redirect('login');
                exit;
            }
        }
	
	        
        public function index()
        {               
            $this->load->view('student/index');
        }













}

