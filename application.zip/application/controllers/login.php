<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Login extends CI_Controller {

    public function __construct()
        {            
            //session_start();
            parent::__construct();
            $this->load->helper('form');
            $this->load->helper('url');
			$this->load->library('form_validation');
            $this->load->model('admin_model', 'Admin_model', true);
            $this->load->model('common_model', 'Common_model', true);   
        }
	
	public function index(){
            if(is_loggedin())
            {
                redirect('admin');
            }
            else
            {
                $this->load->view('welcome/login_admin', '');//$this->load->view('index');
            }            
        }
        
        
        
    public function login_check()
        {
			$this->load->library('form_validation');
		 
			$this->form_validation->set_rules('username', 'username', 'trim|required|xss_clean');
			$this->form_validation->set_rules('password', 'password', 'trim|required|xss_clean');
		
            if($this->form_validation->run() == FALSE)
			{
				//Field validation failed. User redirected to login page
				$this->load->view('welcome/login_admin');
			}
			else
			{
				$data['user_name']       = htmlspecialchars(strip_tags($_POST['username']));
				$data['password']       = md5($_POST['password']);
				$adminInfo = $this->Admin_model->login_check($data); 

				if($adminInfo)
				{    
				    $_SESSION['user_id']       = $adminInfo['login_id'];
					$_SESSION['admin_id']       = $adminInfo['admin_id'];
					$_SESSION['user_name']      = $adminInfo['user_name'];
					$_SESSION['is_superadmin']  = $adminInfo['user_type'];
					$_SESSION['user_access']  = $adminInfo['user_access'];
					$_SESSION['is_loggedin']    = 1;
					
					redirect('admin');
				}
				exception('invalid login information');
				redirect('login');exit;
			}
        }
        
        function logout()
        {            
            session_destroy();
            unset($_SESSION['admin_id'],$_SESSION['user_name'],$_SESSION['is_superadmin'],$_SESSION['is_loggedin']); 
            message('Successfully logout');
            redirect('login');exit;
        }
	function check_user_name()
	{
		echo $this->db
       ->where('user_name',$_POST['user_name'])
       ->count_all_results('tbl_login');
	}
}

