<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Academic extends CI_Controller {

    public function __construct()
        {            
            //session_start();
            parent::__construct();
            $this->load->helper('form');
            $this->load->helper('url');
            $this->load->model('academic_model', 'Academic_model', true);
			$this->load->model('admin_model', 'Admin_model', true);
            $this->load->model('common_model', 'Common_model', true);
            $this->load->library('form_validation');
            if(!is_loggedin())
            {
                redirect('login');
                exit;
            }		
        }

function subject_list_ajax_ct()
    {
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
		$group_id = $_POST['group_id'];
        
		//$sectionInfo = $this->Admin_model->get_section_list_by_id($class_id, $school_id); 
        $subInfo = $this->Academic_model->get_sub_list_by_id_ct($class_id, $school_id,$group_id); 
        
		$str = '<option value="">----Select Subject----</option>';
        
		if($subInfo)
        {
           foreach($subInfo as $sInfo)
           {
              $str .= "<option value='".$sInfo['subject_id']."'>".$sInfo['subject_name']."</option>";
           }
        }
        echo $str;exit;
    }

function subject_list_ajax()
    {
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
		$group_id = $_POST['group_id'];
        
		//$sectionInfo = $this->Admin_model->get_section_list_by_id($class_id, $school_id); 
        $subInfo = $this->Academic_model->get_sub_list_by_id($class_id, $school_id,$group_id); 
        
		$str = '<option value="">----Select Subject----</option>';
        
		if($subInfo)
        {
           foreach($subInfo as $sInfo)
           {
              $str .= "<option value='".$sInfo['subject_id']."'>".$sInfo['subject_name']."</option>";
           }
        }
        echo $str;exit;
    }
	
	function group_list_ajax()
    {
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
        $sectionInfo = $this->Academic_model->get_group_list_by_id($class_id, $school_id); 
        $str = '<option value="">----Select Group----</option>';
        if($sectionInfo)
        {
           foreach($sectionInfo as $sInfo)
           {
              $str .= "<option value='".$sInfo['group_id']."'>".$sInfo['group_name']."</option>";
           }
        }
        echo $str;exit;
    }
	
	  
	          // ******************* class teacher assign /////////////////////////////
    function class_teacher_assign()
    {
    	#$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['class_list'] = $this->Admin_model->get_class_list($school_id);
		$data['shift_list'] = $this->Academic_model->get_shift_list($school_id);
        $this->load->view('academic/class_teacher_assign', $data);
    }
    
	function get_taecher_list_assign()
    {
        $data['school_id']	= 1;
		$data['class_id'] 	= $_POST['class_id'];
		$data['group_id'] 	= $_POST['group_id'];
		$data['section_id'] = $_POST['section_id'];
		$data['shift_id'] 	= $_POST['shift_id'];
		
        $class_teacher_list = $this->Common_model->common_select_by_multycondition($data,'tbl_class_teacher_assign');
		$teacher_list 		= $this->Admin_model->get_teacher_list($data['school_id']);
		
		$tir = '<table class="table table-responsive table-striped table-bordered"><thead><tr><th></th><th>Teacher Name</th><th>Is Class Teacher</th></tr></thead><tbody>';
        if($teacher_list)
        {
			foreach($teacher_list as $tl)
			{
				$str ='';
				$clte='';
				if($class_teacher_list)
				{
				   foreach($class_teacher_list as $ctli)
				   {
					   if($tl['teacher_id'] == $ctli['teacher_id'])
						{$str = "checked";}
						
						if($tl['teacher_id'] == $ctli['teacher_id'] && $ctli['class_teacher']==1)
						{$clte="checked";}
						
				   }
				}
				$tir.='<tr><td><input type="checkbox" name="teacher_id[]" value="'.$tl['teacher_id'].'" '.$str.' /></td><td><label> '.$tl['teacher_name'].'</label></td> <td><input type="radio" name="class_teacher" value="'.$tl['teacher_id'].'" '.$clte.' /> </td></tr>'	;
			}
         
        }
		$tir.='</tbody></table><button type="submit" class="btn btn-primary">Submit</button>';
		echo $tir;
		exit;
    }
    
	
    function save_class_teacher_assign()
    {
    	#$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
        $section_id = $_POST['section_id'];
		$group_id = $_POST['group_id'];
		$shift_id = $_POST['shift_id'];
        $teacher_id = $_POST['teacher_id'];
        
		for($i=0; $i < count($teacher_id); $i++)
			{
				if($_POST['class_teacher']==$teacher_id[$i])
					$class_teacher=1;
				else
					$class_teacher=0;
				$data[] = array(
								'school_id' => $school_id,
								'class_id' => $class_id,
								'section_id' => $section_id,
								'group_id' => $group_id,
								'shift_id' => $shift_id,
								'teacher_id' => $teacher_id[$i],
								'class_teacher' => $class_teacher
								);
			}
		
		$d_data['school_id']=$school_id;
		$d_data['class_id']=$class_id;
		$d_data['section_id']=$section_id;
		$d_data['group_id']=$group_id;
		$d_data['shift_id']=$shift_id;
        
		$this->Common_model->common_delete($d_data,'tbl_class_teacher_assign');
		
		if($this->Common_model->common_insert_batch($data,'tbl_class_teacher_assign'))
			{
				$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
			}
		else
			{
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
			}
        
		redirect('academic/class_teacher_assign','refresh');
		
    }
    
    // ******************* / class teacher assign /////////////////////////////

/* class routine */
	
	public function class_routine()
	{
		$school_id = 1;
        $data['class_list'] = $this->Admin_model->get_class_list($school_id);
		$data['shift_list'] = $this->Academic_model->get_shift_list($school_id);
        $this->load->view('academic/class_routine', $data);
    }
	
	public function get_class_routine_json()
	{
        $s_data['school_id'] 	= 1;
        $s_data['class_id'] 	= $_GET['class_id'];
		$s_data['section_id'] 	= $_GET['section_id'];
		$s_data['group_id'] 	= $_GET['group_id'];
		$s_data['shift_id'] 	= $_GET['shift_id']; 
		
        $data['class_time'] 	= $this->Common_model->common_select_by_multycondition_sorting($s_data,'tbl_class_time_input','row_no','ASC');
		$data['week']			= $this->Academic_model->get_weekdays($s_data['school_id']);
		$data['teacher']		= $this->Academic_model->get_class_wise_teacher_list_routine($s_data['school_id'],$s_data['class_id'],$s_data['section_id']);
		$data['subject']		= $this->Academic_model->get_class_wise_subject_list($s_data['class_id'],$s_data['group_id'],$s_data['school_id']);
		//print_r($data['subject']);exit();
	
		$mainContent = $this->load->view('academic/get_class_routine_json', $data, true);
			
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
    }
	
	public function get_class_wise_subject()
	{
        #$school_id = $_SESSION['school_id'];
     	$school_id = 1;
        $class_id = $_POST['class_id'];
        $sectionInfo = $this->Academic_model->get_class_wise_subject_list($class_id, $school_id);
		$count= $this->Academic_model->get_class_time_count($school_id);
		
		$str = '<option value="">----Select Subject----</option>';
        if($sectionInfo)
        {
           foreach($sectionInfo as $sInfo)
           {
              $str .= "<option value='".$sInfo['subject_id']."'>".$sInfo['subject_name']."</option>";
           }
		
		   echo $str;
        }
		exit;
    }	
	
	public function save_class_routine()
	{		
		$d_data['school_id']	= 1;
        $d_data['class_id'] 	= $_POST['class_id'];
		$d_data['section_id'] 	= $_POST['section_id'];
		$d_data['group_id'] 	= $_POST['group_id'];
		$d_data['shift_id'] 	= $_POST['shift_id'];
		$final_data				= $_POST['final_routine'];	
		
		$this->Common_model->common_delete($d_data,'tbl_class_routine');
		
		if($this->Common_model->common_insert_batch($final_data,'tbl_class_routine'))
		{
			echo '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>';
		}else{
			echo '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>';
		}		
	}
	
	
	public function get_old_routine_by_section_class()
	{
    	#$school_id = $_SESSION['school_id'];
     	$school_id = 1;
		$class_id = $_GET['class_id'];
		$section_id = $_GET['section_id'];
		$group_id = $_GET['group_id'];
		$shift_id = $_GET['shift_id'];
		//$id = $_GET['id'];
		$data= $this->Academic_model->get_old_routine_by_section_class($class_id, $school_id,$section_id,$group_id,$shift_id);
		 print json_encode($data);
        exit;   
	}
	
	public function get_old_routine_by_section_class_show()
	{
     	$school_id	= 1;
		$class_id 	= $_GET['class_id'];
		$section_id = $_GET['section_id'];
		$group_id 	= $_GET['group_id'];
		$shift_id 	= $_GET['shift_id'];
		$data		= $this->Academic_model->get_old_routine_by_section_class_show($class_id, $school_id,$section_id,$group_id,$shift_id);
		
		print json_encode($data);
        exit;   
	}
	
	public function show_class_routine_by_teacher()
	{
		$school_id = 1;
		$data['status'] = 1;		
        $data['teacher_list'] = $this->Common_model->common_select_by_multycondition($data,'tbl_teacher_registration');
        $this->load->view('academic/show_class_routine_teacher', $data);		
	}
	
	public function get_class_routine_teacher_json_show()
	{
        $s_data['school_id']	= 1;
        $teacher_id		 		= $_GET['teacher_id'];
		
        $data['teacher_class'] 	= $this->Academic_model->get_teacher_routine_info($teacher_id);print_r($data['teacher_class']);exit;
        //$data['section_name'] 	= $this->Common_model->common_select_by_condition($s_data['section_id'],'section_id','tbl_section');
        //$data['group_name'] 	= $this->Common_model->common_select_by_condition($s_data['group_id'],'group_id','tbl_group');
        //$data['class_time'] 	= $this->Common_model->common_select_by_multycondition_sorting($s_data,'tbl_class_time_input','row_no', 'asc');
		//$data['week']			= $this->Academic_model->get_weekdays($s_data['school_id']);
		//$data['teacher']		= $this->Academic_model->get_class_wise_teacher_list_routine($s_data['school_id'],$s_data['class_id'],$s_data['section_id']);
		//$data['subject']		= $this->Academic_model->get_class_wise_subject_list($s_data['class_id'],$s_data['group_id'],$s_data['school_id']);
		
		$mainContent = $this->load->view('academic/get_class_routine_teacher_json_show', $data, true);
			
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
    }
	
	public function get_old_routine_by_teacher_show()
	{
     	$school_id	= 1;
		$class_id 	= $_GET['class_id'];
		$section_id = $_GET['section_id'];
		$group_id 	= $_GET['group_id'];
		$shift_id 	= $_GET['shift_id'];
		$data		= $this->Academic_model->get_old_routine_by_section_class_show($class_id, $school_id,$section_id,$group_id,$shift_id);
		
		print json_encode($data);
        exit;   
	}
	
	public function show_class_routine()
	{
		$school_id = 1;
        $data['class_list'] = $this->Admin_model->get_class_list($school_id);
		$data['shift_list'] = $this->Academic_model->get_shift_list($school_id);
		//$c1 = $count['count'];
        $this->load->view('academic/show_class_routine', $data);		
	}
	
	public function get_class_routine_json_show()
	{
        $s_data['school_id']	= 1;
        $s_data['class_id'] 	= $_GET['class_id'];
		$s_data['section_id'] 	= $_GET['section_id'];
		$s_data['group_id'] 	= $_GET['group_id'];
		$s_data['shift_id'] 	= $_GET['shift_id'];
		
        $data['class_name'] 	= $this->Common_model->common_select_by_condition($s_data['class_id'],'class_id','tbl_class');
        $data['section_name'] 	= $this->Common_model->common_select_by_condition($s_data['section_id'],'section_id','tbl_section');
        $data['group_name'] 	= $this->Common_model->common_select_by_condition($s_data['group_id'],'group_id','tbl_group');
        $data['class_time'] 	= $this->Common_model->common_select_by_multycondition_sorting($s_data,'tbl_class_time_input','row_no', 'asc');
		$data['week']			= $this->Academic_model->get_weekdays($s_data['school_id']);
		$data['teacher']		= $this->Academic_model->get_class_wise_teacher_list_routine($s_data['school_id'],$s_data['class_id'],$s_data['section_id']);
		$data['subject']		= $this->Academic_model->get_class_wise_subject_list($s_data['class_id'],$s_data['group_id'],$s_data['school_id']);
	
		$mainContent=$this->load->view('academic/get_class_routine_json_show', $data, true);
			
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
    }
    
	
	/* class timing box section */
	public function set_class_timing()
	{
		$school_id = 1;
		$data['shift_list'] = $this->Academic_model->get_shift_list($school_id);
		$data['class_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_class');
		$this->load->view('academic/set_class_timing', $data);
	}
	
	public function get_class_time_box()
	{
		$data['school_id']	= 1;
		$data['class_id'] 	= $_POST['class_id'];
		$data['section_id'] = $_POST['section_id'];
		$data['group_id'] 	= $_POST['group_id'];
		$data['shift_id'] 	= $_POST['shift_id'];
		
        $timeInfo 	= $this->Common_model->common_select_by_multycondition_sorting($data,'tbl_class_time_input','row_no','ASC');		
		$periodInfo = $this->Common_model->common_select_by_condition($data['school_id'],'school_id','tbl_class_period');
		
		$str = '<option value="">----Select Period----</option>';
        if($periodInfo)
        {
           foreach($periodInfo as $pInfo)
           {
				$str .= "<option value='".$pInfo['period_name']."' >".$pInfo['period_name']."</option>";
           }
		
        }
		
		$tir = '';
        if($timeInfo)
        {
			foreach($timeInfo as $ti)
			{
				$str = '<option value="">----Select Period----</option>';
				if($periodInfo)
				{
				   foreach($periodInfo as $pInfo)
				   {
					   if($ti['period'] == $pInfo['period_name'])
						$str .= "<option value='".$pInfo['period_name']."' selected >".$pInfo['period_name']."</option>";
						else
						$str .= "<option value='".$pInfo['period_name']."' >".$pInfo['period_name']."</option>";
				   }
				}
				
				$tir.='<tr><td>Start Time :</td><td><input type="text" name="start_time[]" value="'.$ti['start_time'].'" class="form-control"></td><td >End Time :</td><td><input type="text" name="close_time[]" value="'.$ti['close_time'].'" class="form-control"></td><td>Period :</td><td><select class="form-control" name="period[]" >'.$str.'</select></td></tr>'	;
			}
         
        }
		else
		{
			$tir.='<tr><td>Start Time :</td><td><input type="text" name="start_time[]" class="form-control"></td><td >End Time :</td><td><input type="text" name="close_time[]" class="form-control"></td><td>Period :</td><td><select class="form-control" name="period[]" >'.$str.'</select></td></tr>'	;
		}
		echo $tir;
		exit;
    }
	
	public function save_class_timing()
	{		
		$school_id	= 1;
		$class_id 	= $_POST['class_id'];
		$section_id = $_POST['section_id'];
		$group_id 	= $_POST['group_id'];
		$shift_id 	= $_POST['shift_id'];
        $period 	= $_POST['period'];
        $start_time = $_POST['start_time'];
        $close_time = $_POST['close_time'];
		
		if(isset($_POST['del_btn'])){
			
			$d_data['school_id']	= $school_id;
			$d_data['class_id']		= $class_id;
			$d_data['section_id'] 	= $section_id;
			$d_data['group_id'] 	= $group_id;
			$d_data['shift_id'] 	= $shift_id;
			
			$this->Common_model->common_delete($d_data,'tbl_class_time_input');
			redirect('academic/set_class_timing', 'refresh');
		}
		
		for($i=0; $i< count($start_time); $i++)
		{
			if($start_time[$i] && $close_time[$i] && $period[$i])
			{
				$data[] = array(
					'school_id'	=> $school_id,
					'class_id' => $class_id,
					'section_id' => $section_id,
					'group_id' => $group_id,
					'shift_id' => $shift_id,
					'period' => $period[$i],
					'start_time' => $start_time[$i],
					'close_time' =>$close_time[$i],
					'row_no' => $i
				);
			}
		}
		
		if($data)
		{
			$d_data['school_id']	= $school_id;
			$d_data['class_id']		= $class_id;
			$d_data['section_id'] 	= $section_id;
			$d_data['group_id'] 	= $group_id;
			$d_data['shift_id'] 	= $shift_id;
			
			$this->Common_model->common_delete($d_data,'tbl_class_time_input');
			
			if($this->Common_model->common_insert_batch($data,'tbl_class_time_input'))
			{
				$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
			}else{
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
			}
			
		}else{
			$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
		}
			
		redirect('academic/set_class_timing', 'refresh');
	}
	
	public function get_class_period(){
        #$school_id = $_SESSION['school_id'];
     	$school_id = 1;
        $periodInfo = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_class_period');
		
		$str = '<option value="">----Select Period----</option>';
        if($periodInfo)
        {
           foreach($periodInfo as $pInfo)
           {
				$str .= "<option value='".$pInfo['period_name']."' >".$pInfo['period_name']."</option>";
           }
		
		   echo $str;
        }
		exit;
    }
	
    
	/**************** /class routine *******************/


	/************** /result ***************/
    

  public function result_view()
      {
      #$school_id = $_SESSION['school_id'];
        $school_id = 1;
       $data['class_list'] = $this->Admin_model->get_class_list($school_id);
       $data['term'] = $this->Academic_model->get_term_list($school_id); 

      $this->load->view('academic/result_view',$data);
      }
      
      
   	  function result_marks_json()
	  {
  #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_GET['class_id'];
		$section_id = $_GET['section_id'];
		$term_id = $_GET['term_id'];
        $exam_year = $_GET['exam_year'];
        $data['student_list'] = $this->Academic_model->get_class_wise_student_list_admit($school_id, $class_id,$section_id);
        $data['term'] = $this->Academic_model->get_term_list_by_id($term_id,$school_id); 

        $data['details'] =  array("class"=>$class_id,"section_id"=>$section_id,"term_id"=>$term_id,"exam_year"=>$exam_year,'sub_id'=>$sub_id);
	
					$mainContent=$this->load->view('academic/result_view_json', $data, true);
        
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
  
  }
  
  public function result_marks_save()
  {
	    #$school_id = $_SESSION['school_id'];
        $school_id = 1;
	$class_id = $_POST['class_id'];
	$section_id = $_POST['section_id'];
	$term_id = $_POST['term_id'];
	$exam_year = $_POST['exam_year'];
    $created_on = date('Y-m-d H:i:s',time());
	$status = 1 ;
	$i=0;
	while($i<count($_POST['student_id'])){
	$student_id = $_POST['student_id'][$i];
	$total_marks = $_POST['total_marks'][$i];
	$total_point = $_POST['total_point'][$i];
	$gpa = $_POST['total_gpa'][$i];
	$data = array ('school_id'=>$school_id,'class_id'=>$class_id,'section_id'=>$section_id,'student_id'=>$student_id,'term_id'=>$term_id,'exam_year'=>$exam_year,'total_marks'=>$total_marks,'total_point'=>$total_point,'gpa'=>$gpa,'status'=>$status,'created_on'=>$created_on);
               
                $this->Common_model->common_insert($data,'tbl_result_marks');
				
	
	$i++;
	}
             $this->session->set_flashdata('message', " Result Marks has been saved successfully ");
		
		redirect('academic/result_view','refresh');exit;  
	
	 	}
		
		
 
	
  /************** /result ***************/
  
  
   public function marks_status_change()
 {
	  	$school_id = $_POST['school_id'];
        $class_id = $_POST['class_id'];
		$section_id = $_POST['section_id'];
		$group_id = $_POST['group_id'];
		$shift_id = $_POST['shift_id'];
		$subject_id = $_POST['subject_id'];
		$term_id = $_POST['term_id'];
        $exam_year = $_POST['exam_year'];
		$status = $_POST['status'];
		
		$data_term = array ('status'=>$status);
	            $where_term = array("class_id"=>$class_id,"section_id"=>$section_id,"sub_id"=>$subject_id,"term_id"=>$term_id,"exam_year"=>$exam_year,"school_id"=>$school_id,"group_id"=>$group_id,"shift_id"=>$shift_id,"status"=>0);		
				 $this->db->where($where_term);
                $this->db->update('tbl_term_marks', $data_term);
				
		$data = array ('status'=>$status);
	            $where = array("class_id"=>$class_id,"section_id"=>$section_id,"subject_id"=>$subject_id,"term_id"=>$term_id,"exam_year"=>$exam_year,"school_id"=>$school_id,"group_id"=>$group_id,"shift_id"=>$shift_id,"status"=>0);
                $this->db->where($where);
                $this->db->update('tbl_ct_marks', $data);
		
		
				
				 $this->session->set_flashdata('message', " Final submition successful ");
		redirect('school/tabulation_sheet_subject_wise','refresh');exit;  
 }
  
  
 	/*** / tabulation sheet subject wise ***/ 
	
	 /**Group Management**/
    public function group_list(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['group_list'] = $this->Admin_model->get_group_list($school_id);
        $this->load->view('academic/group_list', $data);
    }
    
    function group_save(){
        if(isPostBack()){
            #$school_id = $_SESSION['school_id'];
            $school_id = 1;
            $data['group_name'] = $_POST['group_name'];            
            $data['school_id'] = $school_id;
            $data['status'] = 1;
            $data['created_on'] = date('Y-m-d H:i:s',time());
            $this->Common_model->common_insert($data,'tbl_group');
			$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
            redirect('academic/group_list');exit;
            
        }
    }
    
    public function group_edit($group_id){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['group_list'] = $this->Academic_model->get_group_info_by_id($school_id, $group_id);
        $this->load->view('academic/group_edit', $data);
    }
    
    function group_edit_save(){
        if(isPostBack()){
            $group_id = $_POST['group_id'];
            $data['group_name'] = $_POST['group_name'];
            $this->Common_model->common_update($data, $group_id,'group_id','tbl_group');        
            $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
            redirect('academic/group_list');exit;                    
        }
    }
    
    function group_delete($group_id){
        #$school_id = $_SESSION['school_id'];
        $d_data['school_id'] = 1;
        $d_data['group_id'] = $group_id;
        $this->Common_model->common_delete($d_data,'tbl_group');
       $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
        redirect('academic/group_list');exit;
    }
	
	 public function group_assign(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['class_list'] = $this->Admin_model->get_class_list($school_id);
        $this->load->view('academic/group_assign', $data);
    }
    
    function get_group_list_json()
        {
           
			#$school_id = $_SESSION['school_id'];
			$data['school_id'] = 1;
			$data['class_id'] = $_POST['class_id'];
			
			$class_group_list = $this->Common_model->common_select_by_multycondition($data,'tbl_class_group');
			$group_list = $this->Admin_model->get_group_list($data['school_id']);
			
			$tir = '';
			if($group_list)
			{
				foreach($group_list as $tl)
				{
					$str ='';
					if($class_group_list)
					{
					   foreach($class_group_list as $ctli)
					   {
						   if($tl['group_id'] == $ctli['group_id'])
							{$str = "checked";}
							
					   }
					}
					$tir.='<input type="checkbox" name="group_id[]" value="'.$tl['group_id'].'" '.$str.' /> <label> '.$tl['group_name'].'</label><br/>';
				}
			 
			}
			$tir.='<button type="submit" class="btn btn-primary">Save</button>';
			echo $tir;
			exit;
    
        }
            
        
    function save_class_group()
    {
        
            #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
		$group_id = $_POST['group_id'];
        
		for($i=0; $i < count($group_id); $i++)
			{
				$data[] = array(
								'school_id' => $school_id,
								'class_id' => $class_id,
								'group_id' => $group_id[$i],
								'status' => 1
								);
			}
		
		$d_data['school_id']=$school_id;
		$d_data['class_id']=$class_id;
        
		$this->Common_model->common_delete($d_data,'tbl_class_group');
		
		if($this->Common_model->common_insert_batch($data,'tbl_class_group'))
			{
				$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
			}
		else
			{
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
			}
		 redirect('academic/group_assign');exit;
	}
	/*****  Academic Calendar ****/
    public function academic_calendar(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
      // echo json_encode($this->Common_model->common_display('tbl_academic_calendar')); die();
        $this->load->view('academic/academic_calendar');
    }
	
	public function add_event(){
        #$school_id = $_SESSION['school_id'];
		//$color=substr($_POST['color'],-7);
        $school_id = 1;
        $data['school_id'] = $school_id;
        $data['title'] = $_POST['title'];            
        $data['description'] = $_POST['description'];            
		$data['start'] = $_POST['start'];
		$data['end'] = $_POST['end'];
		$data['color'] = substr($_POST['color'],-7);
		$data['textColor'] = '#FFFFFF';
        $data['status'] = 1;
        $data['created_on'] = date('Y-m-d H:i:s',time());
        if($this->Common_model->common_insert($data,'tbl_academic_calendar'))
		{
			return "TRUE";
		}
       // $data['term_list'] = $this->Academic_model->get_term_list($school_id);
       // redirect('academic/academic_calendar');exit;
    }
	public function update_event(){
        #$school_id = $_SESSION['school_id'];
		$id=$_POST['id'];
		$data['start'] = $_POST['start'];
		$data['description'] = $_POST['description'];
		$data['end'] = $_POST['end'];
        if($this->Common_model->common_update($data,$id,'id','tbl_academic_calendar'))
		{
			return "TRUE";
		}
       // $data['term_list'] = $this->Academic_model->get_term_list($school_id);
       // redirect('academic/academic_calendar');exit;
    }
    public function get_event(){
        #$school_id = $_SESSION['school_id'];
        $s_data['school_id'] = 1;
       echo json_encode($this->Common_model->common_select_by_multycondition($s_data,'tbl_academic_calendar'));
    }
	
	function delete_event(){
        #$school_id = $_SESSION['school_id'];
        $d_data['school_id'] = 1;
		$d_data['id']=$_POST['id'];
        $this->Common_model->common_delete($d_data,'tbl_academic_calendar');
      	exit;
    }
    
    
    
           public function examroutine(){
			#$school_id = $_SESSION['school_id'];
			$school_id = 1;
			$data['class_list'] = $this->Admin_model->get_class_list($school_id);
			$data['term_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
			$this->load->view('exam/show_exam_routine', $data);
		}
    
		public function exam_routine_json()
		{
			$school_id=1;
			$class_id=$_GET['class_id'];
			
			$data['exam_time']=$this->Common_model->common_select_by_condition($school_id,'school_id','tbl_exam_time');
			$data['subject']= $this->Academic_model->get_class_wise_subject_list($class_id, $school_id);
			if($data['exam_time'] && $data['subject'])
				$mainContent=$this->load->view('home/routine/exam_routine_json', $data, true);
			else
				$mainContent='<b>NB :</b>Ether no subject assigned for this class or no exam time set. Please go to setting->subject->subject assign to assign subject or setting -> exam -> exam setting -> set term exam time to set exam time.';
			$result = 'success';
			$return = array('result' => $result, 'mainContent'=> $mainContent);
			print json_encode($return);
			exit;   
	
		}

}