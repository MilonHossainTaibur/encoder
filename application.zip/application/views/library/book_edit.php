<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">			
            <div class="content">
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i> Book Edit</h1>
                </div>
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="widget" style="min-height:300px;">
							<div class="widget-content padding">
                                <form role="form" method="POST" action="<?= base_url();?>library/book_edit_save">
                                    <br/><br/><br/>
                                    
                                    <div class="form-group">
										<div class="row">
											<div class="col-sm-6 col-md-6">
												<label>Register No <span style="color:red;">*</span></label>
												<input type="text" class="form-control" name="register_no" value="<?= $book_info[0]['register_no'];?>" required />
												<input type="hidden" name="book_id" value="<?= $book_info[0]['book_id'];?>" />
											</div>
											<div class="col-sm-6 col-md-6">
												<label>Book Name<span style="color:red;">*</span></label>
												<input type="text" class="form-control" name="book_name" id="book_name" value="<?= $book_info[0]['book_name'];?>" required />
											</div>
										</div>
									</div>
									<div class="form-group">
										<div class="row">
											<div class="col-sm-6 col-md-6">
												<label>Writer Name</label>
												<input type="text" class="form-control" name="writer_name" id="writer_name" value="<?= $book_info[0]['writer_name'];?>" />
											</div>
											<div class="col-sm-6 col-md-6">
												<label>Category<span style="color:red;">*</span></label>
												<select name="category_id" id="category_id" class="form-control" required >
													<option value="">Select Category</option>
													<?php foreach($category_list as $catl){ ?>
													<option value="<?php echo $catl['category_id'];?>" <?php if($book_info[0]['category_id']==$catl['category_id']) { echo "selected='selected'";} ?>><?php echo $catl['category_name'];?></option>      
													<?php } ?>
												</select>
											</div>
										</div>
									</div>
									<div class="form-group">
										<div class="row">
											<div class="col-sm-12 col-md-12">
												<label>Remarks</label>
												<textarea class="form-control" name="remarks" id="remarks"> <?= $book_info[0]['remarks'];?> </textarea>
												<b>Some word about book</b>
											</div>
										</div>
									</div>
									<div class="form-group">
										<div class="row">
											<div class="col-sm-12 col-md-12">
												<button type="submit" class="btn btn-primary">Update</button>
											</div>
										</div>
									</div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
<?php include 'application/views/includes/footer.php';?>