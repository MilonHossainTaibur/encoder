<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

<!--Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">			
            <div class="content">
            <?php if($this->session->flashdata('message')):?>
			<?=$this->session->flashdata('message')?>
		<?php endif?>
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i>Issue Book</h1>
                </div>
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="widget" style="min-height:300px;">
							<div class="widget-content padding">
                                <form role="form" method="POST" action="<?= base_url();?>library/book_issue_save">
                                    <br/><br/><br/>
                                    
                                    <div class="form-group">
										<div class="row">
											<div class="col-sm-4 col-md-4">
												<label>Issue To <span style="color:red;">*</span></label>
												<select name="issue_to_type" class="form-control" onchange="get_name_list(this.value);">
													<option value="">Select</option>
												    <option value="1">Teacher</option>
												    <option value="2">Student</option>
												</select>
											</div>

											<div class="col-sm-4 col-md-4">
												<label>Name/ID<span style="color:red;">*</span></label>
												<select name="issue_to" class="form-control">
												<option value="">Select</option>
												   
												</select>
											</div>
										</div>
									</div>
									<div class="form-group">
										<div class="row">
											<div class="col-sm-4 col-md-4">
												<label>Category<span style="color:red;">*</span></label>
												<select name="category_id" id="category_id" class="form-control" required  onchange=" get_book_name_list(this.value)">
												<option value="all">----Select Category----</option>
												<?php foreach($category_list as $catl){ ?>
												<option value="<?= $catl['category_id'];?>"><?= $catl['category_name'];?></option>
												<?php } ?>
												</select>
											</div>
											<div class="col-sm-4 col-md-4">
												<label>Book Name/ID<span style="color:red;">*</span></label>
												<select name="book_id" id="book_id" class="form-control" required >
												</select>
											</div>
										</div>
									</div>
									<div class="form-group">
										<div class="row">
											<div class="col-sm-4 col-md-4">
												<label>Issue Date</label>
												<input class="form-control datepicker-input" placeholder="yyyy-mm-dd" name="issue_date" id="issue_date"type="text">
											</div>
											<div class="col-sm-4 col-md-4">
												<label>Due Date</label>
												<input class="form-control datepicker-input" placeholder="yyyy-mm-dd" name="due_date" id="due_date" type="text">
											</div>
										</div>
									</div>
									<div class="form-group">
										<div class="row">
											<div class="col-sm-12 col-md-12">
												<button type="submit" class="btn btn-primary">Book Issue</button>
												<input type="reset" class="reset btn btn-danger" id="reset" value="Cancel">
											</div>
										</div>
									</div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

  <script>
function get_name_list(id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'library/get_name_list',
    data:
    {
        'id':id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('[name=issue_to]').html(html_data);

        }
    }
    });  
}

function get_book_name_list(category_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'library/get_book_name_list',
    data:
    {
        'category_id':category_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
             $('#book_id').html(html_data);
		
        }
    }
    });  
}</script>              
<?php include 'application/views/includes/footer.php';?>