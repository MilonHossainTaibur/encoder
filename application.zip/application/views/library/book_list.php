<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">		
            <div class="content">
            
			<?php if($this->session->flashdata('message')):?>
			
				<?=$this->session->flashdata('message')?>
			
			<?php endif?>
            
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i>Book List</h1>
                </div>
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="widget" style="min-height:500px;">
                            <div class="widget-content padding">
                                <div class="row">				
                                    <div class="col-md-12">
                                        <div class="widget">
                                            <div class="widget-content">
                                           <a class="btn btn-info" href="javascript:void(0);" onclick="toggle_insertion_box(); return false;"><i class="fa fa-plus" aria-hidden="true"></i>
 Add New Book</a><br>
 <hr>
 
                                                <div class="insertion_div">
													<form action="<?php echo base_url();?>library/book_save" method="POST">
														<div class="form-group">
															<div class="row">
																<div class="col-sm-3 col-md-3">
																	<label>Register No <span style="color:red;">*</span></label>
																	<input type="text" class="form-control" name="register_no" id="register_no" required />
																</div>
																<div class="col-sm-3 col-md-3">
																	<label>Book Name<span style="color:red;">*</span></label>
																	<input type="text" class="form-control" name="book_name" id="book_name" required />
																</div>
																<div class="col-sm-3 col-md-3">
																	<label>Name of Writer</label>
																	<input type="text" class="form-control" name="writer_name" id="writer_name" />
																</div>
																<div class="col-sm-3 col-md-3">
																	<label>Category<span style="color:red;">*</span></label>
																	<select name="category_id" id="category_id" class="form-control" required >
																		<option value="">Select Category</option>
																		<?php foreach($category_list as $catl){ ?>
																		<option value="<?php echo $catl['category_id'];?>"><?php echo $catl['category_name'];?></option>      
																		<?php } ?>
																	</select>
																</div>
															</div>
														</div>
														
														<div class="form-group">
															<div class="row">
																<div class="col-sm-3 col-md-3">
																	<label>Volume</label>
																	<input type="text" class="form-control" name="volume" id="volume" />
																</div>
																<div class="col-sm-3 col-md-3">
																	<label>Number of Copies</label>
																	<input type="text" class="form-control" name="writer_name" id="writer_name" />
																</div>
																<div class="col-sm-3 col-md-3">
																	<label>Edition/Version</label>
																	<input type="text" class="form-control" name="edition" id="edition" />
																</div>
																<div class="col-sm-3 col-md-3">
																	<label>Language</label>
																	<select name="lang" id="lang" class="form-control">
																		<option value="">Select Book Language</option>
																		<option value="bangla">Bangla</option>
																		<option value="english">English</option>
																		<option value="other">Other</option>
																	</select>
															</div>
														</div>
														
														<div class="form-group">
															<div class="row">
																<div class="col-sm-6 col-md-6 col-mdoffset-6">
																	<label>Remarks</label>
																	<textarea class="form-control" name="remarks" id="remarks"> </textarea>
																	<b>Some word about book</b>
																</div>
															</div>
														</div>

														<div class="form-group">
															<div class="row">
																<div class="col-sm-12 col-md-12">
																	<button type="submit" class="btn btn-primary">Save</button>
																</div>
															</div>
														</div>
													</form><hr/>
												</div>
											</div>
											<div class="widget-content">
												<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0">
													<thead>
														<tr>
															<th>Book ID</th>
															<th>Register No</th>
															<th>Book Name</th>
															<th>Writer Name</th>
															<th>Category Name</th>
															<th>Remarks</th>
															<th>Action</th>
														</tr>
													</thead>
													<tbody>
														<?php
															foreach($book_list as $bl){ ?>
														<tr>
															<td><?= $bl['book_id'];?></td>
															<td><?= $bl['register_no'];?></td>
															<td><?= $bl['book_name'];?></td>
															<td><?= $bl['writer_name'];?></td>
															<td><?php 
																	foreach($category_list as $scatl){ 
																		if($scatl['category_id']==$bl['category_id'])
																	echo $scatl['category_name']; 
																	};
																?>
															</td>
															<td><?php echo $bl['remarks'];?></td>                                        
															<td>
																<a href="<?= base_url();?>library/book_edit/<?= $bl['book_id'];?>" title="Edit">
																	<i class="fa fa-edit"></i>
																</a> |
																<?=anchor("library/book_delete/".$bl['book_id'],"<i class=\"fa fa-remove\"></i>",array('onclick' => "return confirm('Do you want delete this record')"))?>
															</td>
														</tr>
															 <?php } ?>
													</tbody>
												</table>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

<?php include 'application/views/includes/footer.php';?>