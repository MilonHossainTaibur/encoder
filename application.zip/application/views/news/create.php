<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
	<div class="content-page">
		
		<div class="content">
			<div class="page-heading">
            	<h1><i class="fa fa-file-text-o"></i> News & Event Create</h1>
			</div>
            <?php if($this->session->flashdata('message')):?>
				<?=$this->session->flashdata('message')?>
			<?php endif?>
			<div class="row">
                <div class="col-sm-12">
                    <div class="widget" style="min-height:500px;">
                        <div class="widget-content padding">
                            <div class="row">				
                                <div class="col-md-12">
                                    <form role="form" id="ct_entry" name="ct_entry" method="POST" action="<?php echo base_url();?>web/news_save"  enctype="multipart/form-data>
													<div class="form-group row">
														<div class="col-md-12">
															<label for="title" class="">Heading</label>
														<input type="text" class="form-control" name="title" id="title" required />
														</div>
                                                    </div>
                                                    <div class="form-group row">
														<div class="col-md-6">
															<label for="image" class="">Image</label>
														<input type="file" class="form-control" name="image" id="image" required />
														</div>
														<div class="col-md-6">
															<label for="venue" class="">Venue</label>
														<input type="text" class="form-control" name="venue" id="venue" required />
														</div>
                                                    </div>
                                                    <div class="form-group row">
														<div class="col-md-6">
															<label for="date" class="">Date</label>
														<input type="text" class="form-control" name="date" id="date" />
														</div>
														<div class="col-md-6">
															<label for="time" class="">Time</label>
														<input type="text" class="form-control" name="time" id="time" />
														</div>
                                                    </div>
													<div class="form-group">
														<label for="body">Details</label>
														<textarea class="form-control" rows="5" id="body" name="body" style="min-height:300px;"></textarea>
													</div>
													<div class="form-group">
														<label for="status">Status</label>
														<select name="status" id="status" class="form-control">
															<option value="0">Deactive</option>
															<option value="1">Active</option>
														</select>
														
													</div>
													<div class="form-group">
														<button type="submit" class="btn btn-success btn-block">Save</button>
													</div>
												</form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

<?php include 'application/views/includes/footer.php';?>
<script type="text/javascript">

window.onload = function () {
	// Create Wysiwig editor for textare
	TinyMCEStart('#body', null);
	TinyMCEStart('#wysiwig_full', 'extreme');
	$('#date').datepicker( {minDate: '0', dateFormat: 'yy-dd-mm' } );
	// Load Timepicker plugin
	LoadTimePickerScript(DemoTimePicker);
};
</script>