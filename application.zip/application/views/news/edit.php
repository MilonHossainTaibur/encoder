<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
	<div class="content-page">
		
		<div class="content">
			<div class="page-heading">
            	<h1><i class="fa fa-file-text-o"></i> News & Event Create</h1>
			</div>
            <?php if($this->session->flashdata('message')):?>
				<?=$this->session->flashdata('message')?>
			<?php endif?>
			<div class="row">
                <div class="col-sm-12">
                    <div class="widget" style="min-height:500px;">
                        <div class="widget-content padding">
                            <div class="row">				
                                <div class="col-md-12">
                                    <form role="form" id="ct_entry" name="ct_entry" method="POST" action="<?php echo base_url();?>news_update"  enctype="multipart/form-data">
													<div class="form-group row">
					<input type="hidden" class="form-control" name="id" id="id" value="<?= $news[0]['id'];?>">
					<php echo '$news[0]['id'];' ?>

														<div class="col-md-12">
															<label for="title" class="">Heading</label>
														<input type="text" class="form-control" name="title" id="title" value="<?= $news[0]['title'];?>" required />
														</div>
                                                    </div>
                                                    <div class="form-group row">
														<div class="col-md-4">
															<label for="image" class="">Image</label>
														<input type="file" class="form-control" name="image" id="image" />
														
														</div>
														<div class="col-md-2">
															<img width="50px;" height="50px" class="img-circle center-block zoom-image" src="<?= base_url()?>upload/news/<?= $news[0]['image'];?>" alt="">
														</div>
														<div class="col-md-6">
															<label for="venue" class="">Venue</label>
														<input type="text" class="form-control" name="venue" id="venue" value="<?= $news[0]['venue'];?>" required />
														</div>
                                                    </div>
                                                    <div class="form-group row">
														<div class="col-md-6">
															<label for="date" class="">Date</label>
														<input type="text" class="form-control" name="date" id="date" value="<?= $news[0]['news_date'];?>" />
														</div>
														<div class="col-md-6">
															<label for="time" class="">Time</label>
														<input type="text" class="form-control" name="time" id="time" value="<?= $news[0]['news_time'];?>" />
														</div>
                                                    </div>
													<div class="form-group">
														<label for="body">Details</label>
														<textarea class="form-control" rows="5" id="body" name="body" style="min-height:300px;"> <?= $news[0]['body'];?></textarea>
													</div>
													<div class="form-group">
														<label for="status">Status</label>
														<select name="status" id="status" class="form-control">
															<option value="0" <?php if($news[0]['status']==0){echo "selected";} ?> >Deactive</option>
															<option value="1" <?php if($news[0]['status']==1){echo "selected";} ?> >Active</option>
														</select>
														
													</div>
													<div class="form-group">
														<button type="submit" class="btn btn-success btn-block">Save</button>
													</div>
												</form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

<?php include 'application/views/includes/footer.php';?>
<script type="text/javascript">

window.onload = function () {
	// Create Wysiwig editor for textare
	TinyMCEStart('#body', null);
	TinyMCEStart('#wysiwig_full', 'extreme');
};
</script>