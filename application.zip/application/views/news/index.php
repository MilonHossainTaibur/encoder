
<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
<div class="content-page">
<div class="content">
<div class="page-heading">
   <h1><i class="fa fa-calendar-o" aria-hidden="true"></i>News & Events</h1>
      <hr>
   <!-- Button trigger modal -->
   <a class="btn btn-info" href="<?= base_url();?>web/news_create">
   <i class="fa fa-plus-square" aria-hidden="true"> Add New</i>
   </a>
</div>
<?php if($this->session->flashdata('message')):?>
<?=$this->session->flashdata('message')?>
<?php endif?>
<div class="row">
   <div class="col-sm-12">
      <div class="widget" style="min-height:500px;">
         <div class="widget-content padding">
            <div class="row">
               <div class="col-md-12">
                  <div class="widget">
                  
                    
                     <div class="widget-content">
                        <table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
                           <thead>
                              <tr>
                                 <th> ID</th>
                                 <th>Title</th>
                                 <th>Photo</th>
                                 <th>Body</th>
                                 <th>Status</th>
                                 <th>Action</th>
                              </tr>
                           </thead>
                           <tbody>
                              <?php foreach($news as $new){ ?>
                              
                              <tr>
                                 <td><?= $new['id'];?></td>
                                 <td><?= $new['title'];?></td>
                                 <td><img width="50px;" height="50px" class="img-circle center-block zoom-image" src="<?= base_url()?>upload/news/<?= $new['image'];?>" alt=""></td>
                                 <td><?= $new['body'];?></td>
                                 <td><?php if($new['status']==1) {echo "<a class='btn btn-sm btn-success'>Active</a>";}else{echo "<a class='btn btn-sm btn-danger'>Inactive</a>";} ?></td>
                                 <td width="100">
                                    <a class="btn btn-success btn-sm" href="<?= base_url();?>web/edit_news/<?= $new['id'];?>"><i class="fa fa-edit"></i></a>
                                    <a class="btn btn-danger btn-sm" href="<?= base_url();?>web/news_delete/<?= $new['id'];?>/<?= $new['image'];?>" title="Delete" onclick="return confirm('Are You Want to Delete it?' );"><i class="fa fa-remove"></i></a></a>
                                 </td>
                              </tr>
                              <?php    } ?>
                             
                           </tbody>
                        </table>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php include 'application/views/includes/footer.php';?>

