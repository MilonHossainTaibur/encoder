<?php include 'application/views/home/inc/header.php';?>
<link rel="stylesheet" href="<?= base_url() ?>template/css/magnific-popup.css" type="text/css" media="all" />
<script src="<?= base_url() ?>template/js/jquery.magnific-popup.min.js" type="text/javascript"></script>
<script src="<?= base_url() ?>template/js/masonry.min.js" type="text/javascript"></script>
<script src="https://unpkg.com/imagesloaded@4/imagesloaded.pkgd.min.js"></script>
<script src="https://unpkg.com/isotope-layout@3/dist/isotope.pkgd.min.js"></script>

<style>

.button:active,
.button.is-checked {
  background-color: #ffffff;
  color: #000;
}
</style>
<div class="full-width-section">
   <div class="container py-4 min-height bg-white">
      <div class="row">
         <div class="col-md-12">
            <div class="card bg-white">
               <div class="card-header hr-title curl">
                  <h3><i class="fa fa-camera" aria-hidden="true"></i>
                     Photo Gallery
                  </h3>
                  <div class="title-sep"> </div>
               </div>
            
            <div class="card-body bg-white">
               <div class="row">
                  <div class="col-md-12">
                    <div class="button-group filters-button-group py-4 text-center">
                    <button class="button is-checked btn btn-info btn-sm text-capitalize" data-filter="*">show all</button>
                    <?php foreach($catagory_list as $cat_name){ ?>
                    <button class="button btn btn-info btn-sm my-1" data-filter=".gallery-<?= $cat_name['catagory_id']?>"><?= $cat_name['catagory_name']?></button>
                    <?php } ?>
                  </div>
                  </div>
               </div>
               <div class="grid row">
                  <?php foreach($photo_gallery as $images){ ?>
                  <div class="col-md-3 element-item all-sort gallery-<?= $images['catagory_id']?> border mb-2">
                     <div class="gallery">
                        <a href="<?= base_url() ?>upload/photo_gallery/<?= $images['gallery_image_name']?>" title="<?= $images['photo_caption']?>">
                          <img class="img-fluid" src="<?= base_url() ?>upload/photo_gallery/<?= $images['gallery_image_name']?>"  alt="<?= $images['photo_caption']?>"/>
                        </a>

                        <div class="gallery-caption p-2 text-sm-center ">
                           <p class="text-sm-center"><?= $images['photo_caption']?></p>
                     </div>
                     </div>
                     
                  </div>
                  <?php } ?>
               </div>
            </div>
</div>
            
         </div>
      </div>
   </div>
</div>
<script>
   $(document).ready(function() {
   $('.gallery').magnificPopup({
      delegate: 'a',
      type: 'image',
      closeOnContentClick: false,
      closeBtnInside: false,
      mainClass: 'mfp-with-zoom mfp-img-mobile',
      image: {
         verticalFit: true,
         titleSrc: function(item) {
            return item.el.attr('title') + ' &middot; <a class="image-source-link" href="'+item.el.attr('data-source')+'" target="_blank"><?= $images['photo_caption']?></a>';
         }
      },
      gallery: {
         enabled: true
      },
      zoom: {
         enabled: true,
         duration: 300, // don't foget to change the duration also in CSS
         opener: function(element) {
            return element.find('img');
         }
      }
      
   });
});


</script>
<script>
  // external js: isotope.pkgd.js

// init Isotope
var $grid = $('.grid').isotope({
  itemSelector: '.element-item',
  layoutMode: 'fitRows'
});
// filter functions
var filterFns = {
  // show if number is greater than 50
  numberGreaterThan50: function() {
    var number = $(this).find('.number').text();
    return parseInt( number, 10 ) > 50;
  },
  // show if name ends with -ium
  ium: function() {
    var name = $(this).find('.name').text();
    return name.match( /ium$/ );
  }
};
// bind filter button click
$('.filters-button-group').on( 'click', 'button', function() {
  var filterValue = $( this ).attr('data-filter');
  // use filterFn if matches value
  filterValue = filterFns[ filterValue ] || filterValue;
  $grid.isotope({ filter: filterValue });
});
// change is-checked class on buttons
$('.button-group').each( function( i, buttonGroup ) {
  var $buttonGroup = $( buttonGroup );
  $buttonGroup.on( 'click', 'button', function() {
    $buttonGroup.find('.is-checked').removeClass('is-checked');
    $( this ).addClass('is-checked');
  });
});

</script>

<?php include 'application/views/home/inc/footer.php';?>