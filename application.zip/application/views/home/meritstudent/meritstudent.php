<?php include 'application/views/home/inc/header.php';?>
<!-- **container - Starts** -->
<section id="primary" class="content-full-width grey1">
<div class="container py-4 min-height bg-white">

                    <div class="row">
                       <div class="col-md-12">
                          <div class="card">
                             <div class="card-header hr-title dt-sc-hr-invisible-small curl">
                                <h3>List of Meritorious Students</h3>
                        <div class="title-sep"> </div>
                             </div>
                             <div class="card-body">
                                <table class="table table-condensed">
            <thead>
               <tr>
                  <th class="">Photo</th>
                  <th class="">Student Name </th>
                  <th class="">Class</th>
                  <th class="">Examination</th>
                  <th class="">GPA</th>
                  <th class="">Session</th>
               </tr>
            </thead>
            <tbody>
               <tr class = "">
   
                  <td class="">
                     <img class=""  src="" width="70" alt="image"/> 
                  </td>
          
                  <td class="">
                     <span class=""></span>
                  </td>
            
                  <td class="">
                                       
                  </td>

                  <td class="">
 
                  </td>

                  <td class="">
                     A+                                        
                  </td>
                  <td class="">
                                     
                  </td>
               </tr>
            </tbody>
         </table>
                             </div>
                          </div>
                       </div>
                    </div>

</div>
</section>
<?php include 'application/views/home/inc/footer.php';?>

