		<section class="top-notice py-3">
            <div class="top-notice-body border py-2">
               <div class="row">
                  <div class="col-md-2">
                     <h5 class="pl-2"><i class="fa fa-newspaper-o" aria-hidden="true"></i>Latest News</h5>
                  </div>
                  <div class="col-md-10">
                     <?php if($notice_list){
                        $bangel_month=array('','জানুয়ারি', 'ফেব্রুয়ারী','মার্চ','এপ্রিল','মে','জুন','জুলাই','আগস্ট','সেপ্টেম্বর','অক্টোবর','নভেম্বর','ডিসেম্বর') ;
                        $bangel_day=array('০','১','২','৩','৪','৫','৬','৭','৮','৯','১০','১১','১২','১৩','১৪','১৫','১৬','১৭','১৮','১৯','২০','২১','২২','২৩','২৪','২৫','২৬','২৭','২৮','২৯','৩০','৩১') ;  
                        ?>
                     <marquee truespeed="truespeed" scrolldelay="15" scrollamount="1" onmouseover="this.stop();" onmouseout="this.start();" direction="left" behavior="scroll" align="top">
                        <a style="color:#8F3985;font-size: 15px;" href="javascript:void(0)" class="bangla"><?= $notice_list[0]['notice_heading'] ?> </a>
                        <?php } else{ ?>
                        Not Available
                        <?php } ?>
                     </marquee>
                  </div>
               </div>
            </div>
        </section>
		<!-- slide -->
		<section class="hero-section py-2 ">
            <div class="row">
               <div class="col-md-8">
                  <div class="home-slider">
                     <?php foreach($slide_image as $img){ ?>
                     <div class="slider-item">
                        <img class="img-fluid" src="<?= base_url();?>upload/slides/<?= $img['slide_image_name'];?>" />
                        <div class="slider-caption">
                           <h5 class="text-white"><?= $img['slide_caption'];?></h5>
                        </div>
                     </div>
                     <?php   } ?>
                  </div>
               </div>
               <div class="col-md-4">
                  <div class="notice-board card p-1 overflow-hidden card border" style="height: 410px">
                     <div class="sidebar-title color-2 p-2 card-header">
                        <h5 class="text-center text-white"><i class="fa fa-tags"></i> Notice</h5>
                     </div>
                     <div class="notice-body card-body">
                        <aside class="widget widget_product_categories">
                           <ul class="list-unstyled">
                              <?php if($notice_list){
                                 $bangel_month=array('','জানুয়ারি', 'ফেব্রুয়ারী','মার্চ','এপ্রিল','মে','জুন','জুলাই','আগস্ট','সেপ্টেম্বর','অক্টোবর','নভেম্বর','ডিসেম্বর') ;
                                 $bangel_day=array('০','১','২','৩','৪','৫','৬','৭','৮','৯','১০','১১','১২','১৩','১৪','১৫','১৬','১৭','১৮','১৯','২০','২১','২২','২৩','২৪','২৫','২৬','২৭','২৮','২৯','৩০','৩১') ;  
                                  ?>
                              <marquee class="product_marquee" direction="up" behavior="scroll" onmouseover="this.setAttribute('scrollamount', 0, 0);" onmouseout="this.setAttribute('scrollamount', 3, 0);" scrollamount="3" style="height:350px;">
                                 <?php foreach($notice_list as $nl){ ?>
                                 <li class="" style="border-bottom: 1px solid #dddddd;padding: 3px 0 3px 10px;font-size: 12px;">
                                    <a class="bangla" style="color:#343A40;" href="<?= base_url()?>home/single_notice/<?= $nl['notice_id'] ?>"><?= $nl['notice_heading'] ?> </a>
                                 </li>
                                 <?php }} else{ ?>
                                 <p>No Notice Available</p>
                                 <?php } ?>
                              </marquee>
                           </ul>
                        </aside>
                     </div>
                  </div>
               </div>
            </div>
        </section>