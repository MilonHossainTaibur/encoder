				<div class="col-md-2">
					<div class="left-sidebar mb-3 clearfix">
					 <div class="sidebar-title color-1 py-2 mb-1">
						<h6 class="text-center text-white">Admission/Apply</h6>
					 </div>
					 <ul class="list-group">
						<li class="list-group-item"><a class="font-weight-bold text-red" target="_blank" href="<?= base_url(); ?>upload/admission_form/Admission-form-new_THS_2020.pdf" >Admission Form (pdf)</a></li>
						<li class="list-group-item"><a class="font-weight-bold text-red" href="<?= base_url(); ?>home/admissionresult" > Admission Result </a></li>
						<!--li><a target="_blank" class="" href="<?= base_url(); ?>home/rules" > Rules and Policies </a></li-->
					 </ul>
					</div>
					<div class="left-sidebar my-2 clearfix">
                     <div class="sidebar-title color-1 py-2 mb-1">
                        <h6 class="text-center text-white">About Institution</h6>
                     </div>
                     <ul class="list-group">
                        <li class="list-group-item"><a target="_blank" class="" href="<?= base_url(); ?>home/about"> History</a></li>
                        <li class="list-group-item"><a target="_blank" class="" href="<?= base_url(); ?>home/buildinnginfo"> General Information</a></li>
                        <li class="list-group-item"><a target="_blank" class="" href="<?= base_url(); ?>home/landinfo"> Land Ownership </a></li>
                        <li class="list-group-item"><a target="_blank" class="" href="<?= base_url(); ?>home/postinfo"> Posts Information </a></li>
                        <li class="list-group-item"><a target="_blank" class="" href="<?= base_url(); ?>home/rules"> Rules and Policies </a></li>
                     </ul>
					</div>
					<div class="left-sidebar mt-3 clearfix">
						<div class="sidebar-title color-1 py-2 mb-md-2">
							<h6 class="text-center text-white">Teacher & Employee</h6>
						</div>
						<ul class="list-group">
							<li class="list-group-item"><a target="_blank" class="" href="<?= base_url(); ?>home/managing_commettee" >Managing Committee </a></li>
							<li class="list-group-item"> <a target="_blank" class="" href="<?= base_url(); ?>home/Teacher" > Teachers </a></li>
							<li class="list-group-item"><a target="_blank" class="" href="<?= base_url(); ?>home/ThirdgradeEmployee">Third Class Employees </a></li>
							<li class="list-group-item"><a target="_blank" class="" href="<?= base_url(); ?>home/FourthgradeEmployee">Fourth Class Employee </a></li>
							<li class="list-group-item"><a target="_blank" class="" href="<?= base_url(); ?>home/managing_commettee"> Administrative Structures</a></li>
						</ul>
					</div>
					<div class="left-sidebar mt-3 clearfix">
						<div class="sidebar-title color-1 py-2 mb-md-2">
							<h6 class="text-center text-white"><span class="fa fa-clock-o"> </span> Daily attendance</h6>
						</div>
						<div class="sidebar-body">
							<form  method="post" action="<?= base_url(); ?>home/emp_attendance">
							   <div class="form-group">
								  <input class="date-picker form-control" id="teacher_att" type="text" name="startdate" placeholder="YY-MM-DD" />
							   </div>
							   <div class="form-group">
								  <input type="submit" class="btn btn-block btn-info" value="Teacher Attendance">
							   </div>
							</form>
							<br>
							<form method="post" action="<?= base_url(); ?>home/emp_attendance">
							   <div class="form-group">
								  <input class="date-picker form-control" id="student_att" type="text" name="startdate" placeholder="YY-MM-DD" />
							   </div>
							   <div class="form-group">
								  <input type="submit" class="btn btn-block btn-info" value="Student Attendance">
							   </div>
							</form>
						</div>
					</div>
				</div>