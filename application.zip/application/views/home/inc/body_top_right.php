				<div class="col-md-2">					
					<div class="left-sidebar mb-3 clearfix">
						<div class="sidebar-title color-1 p-2 mb-md-2">
							<h6 class="text-white"><span class="fa fa-microphone"></span> Result</h6>
						</div>
						<ul class="list-group">
							<li class="list-group-item"><a href="<?= base_url(); ?>home/schoolresult">Academic Result</a></li>
							<li class="list-group-item"><a href="<?= base_url(); ?>home/JSCresult">JSC Result</a></li>
							<li class="list-group-item"><a href="<?= base_url(); ?>home/SSCresult">SSC Result</a></li>
						</ul>
					</div>
					
					<div class="left-sidebar mt-3 clearfix">
						<div class="sidebar-title color-1 p-2 mb-md-2">
							<h6 class="text-white"><span class="fa fa-microphone"></span> Celebration</h6>
						</div>
						<ul class="list-group">
							<li class="list-group-item"><a href="javascript:void(0)">Events Celebrate</a></li>
							<li class="list-group-item"><a href="javascript:void(0)">Sports Events</a></li>
							<li class="list-group-item"><a href="javascript:void(0)">Doa Mahfil</a></li>
							<li class="list-group-item"><a href="javascript:void(0)">Books Fair</a></li>
							<li class="list-group-item"><a href="javascript:void(0)">Mother Language Day</a></li>
						</ul>
					</div>
					
					<div class="left-sidebar mt-3 clearfix">
						<div class="sidebar-title color-1 p-2 mb-md-2">
							<h6 class="text-white"><span class="fa fa-th"></span> Multimedia</h6>
						</div>
						<ul class="list-group">
							<li class="list-group-item"><a href="javascript:void(0)">Bengali</a></li>
							<li class="list-group-item"><a href="javascript:void(0)">Good to Know</a></li>
							<li class="list-group-item"><a href="javascript:void(0)">English</a></li>
						</ul>
					</div>
					
					<div class="left-sidebar mt-3 clearfix">
						<div class="sidebar-title color-1 p-2 mb-md-2">
							<h6 class="text-center text-white"><span class="fa fa-th"></span> Other Programme</h6>
						</div>
						<ul class="list-group">
							<li class="list-group-item"><a href="<?= base_url(); ?>home/classroutine">Class Routine</a></li>
							<li class="list-group-item"><a href="<?= base_url(); ?>home/examroutine">Exam Routine</a></li>
							<li class="list-group-item"><a href="javascript:void(0)">Construction of all facilities</a></li>
							<li class="list-group-item"><a href="<?= base_url(); ?>home/schoolresult">Academic Schedule</a></li>
						</ul>
					</div>
					<div class="left-sidebar mt-3 clearfix">
						<div class="sidebar-title color-1 p-2 mb-md-2">
							<h6 class="text-white"><i class="fa fa-camera" aria-hidden="true"></i> Gallery</h6>
						</div>
						<ul class="list-group">
							<li class="list-group-item"><a href="<?= base_url(); ?>home/gallery">Video Gallery</a></li>
							<li class="list-group-item"><a href="<?= base_url(); ?>home/gallery">Photo Gallery</a></li>
						</ul>
					</div>			  
				</div>