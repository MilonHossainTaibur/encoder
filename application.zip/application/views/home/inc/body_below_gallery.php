				<div class="col-md-12">
					<div class="photo-gallery bg-white">
						<div class="section-title color-2 p-2 my-2">
							<h5 class="text-white"><i class="fa fa-camera" aria-hidden="true"></i> <a class="text-white" href="<?= base_url(); ?>home/gallery">Photo Gallery</a></h5>
						</div>
						<div id="school-gallery" class="school-gallery p-2">
							<?php foreach($gallery_images as $gimg){ ?>
							<div class="gallery-item"><img src="<?= base_url() ?>upload/photo_gallery/<?= $gimg['gallery_image_name']; ?>" alt=""></div>
							<?php } ?>
						</div>
					</div>
				</div>