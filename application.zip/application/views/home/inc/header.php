<!Doctype html>
<html lang="en-gb">
   <head> 
      <meta charset="utf-8">
      <meta content-type ="text/html">
      <meta http-equiv="Content-Language" content="en-US">
      <meta name="viewport" content="width=device-width, initial-scale=1">
     <title><?php if ($title){echo $title; }
    else
        { 
            echo 'Telihaty High School'; 
        }
     ?>       
</title>
      <link rel="icon" type="image/png" sizes="16x16" href="favicon/favicon-16x16.png">
      <meta name="keywords" content="Education, IMS"/>
      <meta name="description" content="150 words"/>
      <meta name="robots" content="index,follow" />
      <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no"/>
      <meta property="og:title" content="" />
      <meta property="og:description" content=""/>
      <meta property="og:type" content="" />
      <meta property="og:url" content="index" />
      <meta property="og:image" content="schoolupload/logo/logo.jpg" />
      <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
      <![endif]-->
      <link rel="stylesheet" type="text/css" href="<?= base_url() ?>template/css/jquery-ui.min.css"/>
       <link href="<?= base_url() ?>template/css/font-awesome.min.css" type="text/css" rel="stylesheet" />
       <link href="<?= base_url() ?>template/font-interstate/font-interstate.css" type="text/css" rel="stylesheet" />
      <link href="<?= base_url() ?>template/css/slicknav.min.css" type="text/css" rel="stylesheet" />
      <link href="<?= base_url() ?>template/css/bootstrap.min.css" type="text/css" rel="stylesheet" />
      <link href="<?= base_url() ?>template/css/owl.carousel.min.css" type="text/css" rel="stylesheet" />
      <link href="<?= base_url() ?>template/css/telihaty.css" type="text/css" rel="stylesheet" />
      <script src="<?= base_url() ?>template/js/jquery.min.js" type="text/javascript"></script>
      <script type='text/javascript'>
         baseUrl = '<?= base_url() ?>';
      </script>
      <style>
      .megamenu {
         position: static;
         }
         .megamenu .dropdown-menu {
         background: none;
         border: none;
         width: 100%;
         }

         @font-face {
    font-family: 'SutonnyMJ';
    src: url('<?= base_url() ?>template/fonts/SutonnyOMJ.ttf') format('truetype');
}
.bangla {
    font-family: "adobegaramondw01-regula";
}
.bangla-bd,.school-title-bn {
    font-family: "SolaimanLipi";
}
.intro-section{
   position: relative;
}


    .text-red{
        color:red!important;
    }
      </style>
      <!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-159623435-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-159623435-1');
</script>

   </head>
   <body>
      <div class="header-top bg-dark py-md-2 d-none d-sm-block">
         <div class="container">
            <div class="row">
               <div class="col-6 col-md-6">
                  <ul class="list-unstyled list-inline float-sm-none float-lg-left header-ul">
                     <li class="list-inline-item text-white"> <i class="fa fa-user"></i><a class="text-white"  target="_blank" href="<?= base_url(); ?>home/login"> Parents Login</a></li>
                     <li class="list-inline-item text-white"><i class="fa fa-user-md"></i><a class="text-white" target="_blank" href="<?= base_url(); ?>login"> Teacher Login</a></li>
                     <li class="list-inline-item text-white"><i class="fa fa-print" aria-hidden="true"></i><a class="text-white"  target="_blank" href="<?= base_url(); ?>"> Admit card</a></li>
                  </ul>
               </div>
               <div class="col-6 col-md-6">
                  <ul class="list-unstyled list-inline float-sm-none float-lg-right header-ul">
                     <li class="list-inline-item text-white"><i class="fa fa-info-circle" aria-hidden="true"></i>
                        <a class="text-white" href="<?= base_url(); ?>home/admission">Admission Information</a>
                     </li>
                     <li class="list-inline-item text-white"> <a class="text-white" target="_blank" href="<?= base_url(); ?>home/admission_form"><i class="fa fa-leaf" aria-hidden="true"></i>
 Apply Online</a></li>
                  </ul>
               </div>
            </div>
         </div>
      </div>

      <div id="header-wrapper" class="">
         <header class="header">
            <div class="school-info" style="background: linear-gradient(to bottom, #6b82b6 0%, #3b5998 100%);">
               <div class="container py-md-3">
               <div class="row">
                  <div class="col-md-12 col-sm-12 col-lg-12 col-12">
                     <div class="intro-section mt-sm-2">
                        <a href="<?= base_url(); ?>" title="Telihaty High School">
                           <h1 class="py-1 text-sm-center text-md-center text-capitalize text-white school-title">Telihaty High School</h1>
                           <h1 class="py-1 text-sm-center text-md-center text-capitalize text-white bangla school-title-bn">তেলিহাটি উচ্চ বিদ্যালয়</h1>
                        </a>
                        <h4 class="py-1 text-sm-center text-md-center text-capitalize text-white school-address">Telihaty, Sreepur, Gazipur</h4>
                        <h5 class="py-1 text-sm-center text-md-center text-capitalize text-white school-eiin">EIIN NO: 109354, MPO Code: 2705031302, School Code: 2127,Established: 1968</h5>
                        <div class="header-logo">
                        <a href="<?= base_url(); ?>" title="Telihaty High School">  
                        <img height="auto" class="img-fluid main-logo"  src="<?= base_url();?>template/assets/images/logo.png"/> 
                        </a>
                     </div>
                     </div>
                  </div>
               </div>
            </div>
            </div>
            
            <div class="shadow-sm bg-white menu-content">
               <div class="container">
                  <nav class="navbar navbar-expand-lg navbar-light py-sm-2 py-md-0 menu-ul">
                     <a href="#" class="navbar-brand font-weight-bold d-block d-lg-none">Menu</a>
                     <button type="button" data-toggle="collapse" data-target="#navbarContent" aria-controls="navbars" aria-expanded="false" aria-label="Toggle navigation" class="navbar-toggler">
                     <span class="navbar-toggler-icon"></span>
                     </button>
                     <div id="navbarContent" class="collapse navbar-collapse main-menu">
                        <ul class="navbar-nav">
                           <li class="nav-item font-weight-bold text-white <?php if($this->uri->uri_string()==base_url()){ echo 'active'; } ?>"><a class="nav-link" href="<?= base_url(); ?>">Home</a></li>
                           <!-- Megamenu-->
                           <li class="nav-item p-sm-1 dropdown megamenu  <?php if($this->uri->uri_string() == 'home/landinfo' || $this->uri->uri_string() == 'home/buildinnginfo' || $this->uri->uri_string() == 'home/PresidentMessage' || $this->uri->uri_string() == 'home/headmasterMessage' || $this->uri->uri_string() == 'home/about' || $this->uri->uri_string() == 'home/founder' || $this->uri->uri_string() == 'home/head_master_list' || $this->uri->uri_string() == 'home/donnor_list'){ echo 'active'; } ?>">
                              <a id="megamneu" href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link dropdown-toggle font-weight-bold">Institutions</a>
                              <div aria-labelledby="megamneu" class="dropdown-menu border-0 p-0 m-0">
                                 <div class="container">
                                    <div class="megamenu-wrapper">

                                           <div class="p-4 bg-white rounded-0 m-0 shadow-sm">
                                             <div class="row">
                                                <div class="col-lg-4 mb-2">
                                                   <h6 class="font-weight-bold text-uppercase py-2">Information</h6>
                                                   <ul class="list-unstyled">
                                                      <li class="nav-item p-2"><a href="<?= base_url(); ?>home/about">Introduction</a></li>
                                                      <li class="nav-item p-2"><a href="<?= base_url(); ?>home/founder">Founder</a></li>
                                                      <li class="nav-item p-2"><a href="<?= base_url(); ?>home/head_master_list">Head Master's List</a></li>
                                                      <li class="nav-item p-2 text-dark"><a href="<?= base_url(); ?>home/donnor_list">Donor Members</a></li>
                                                   </ul>
                                                </div>
                                                <div class="col-lg-4 mb-4">
                                                   <h6 class="font-weight-bold text-uppercase py-2">Message</h6>
                                                   <ul class="list-unstyled">
                                                      <li class="nav-item p-2"><a class="" href="<?= base_url(); ?>home/PresidentMessage">President's Message</a></li>
                                                      <li class="nav-item p-2"><a class="" href="<?= base_url(); ?>home/headmasterMessage">Head Teacher's Message</a></li>
                                                   </ul>
                                                </div>
                                                <div class="col-lg-4 mb-4">
                                                   <h6 class="font-weight-bold text-uppercase py-2">infrastructure</h6>
                                                   <ul class="list-unstyled">
                                                      <li class="nav-item p-2"><a class="" href="<?= base_url(); ?>home/landinfo">Land Information</a></li>
                                                      <li class="nav-item p-2"><a class="" href="<?= base_url(); ?>home/buildinnginfo">General Information</a></li>
                                                      <li class="nav-item p-2"><a class="" href="<?= base_url(); ?>home/other_assets">Other Resources</a></li>
                                                      <li class="nav-item p-2"><a class="" href="<?= base_url(); ?>home/computer_lab">Computer Lab</a></li>
                                                   </ul>
                                                </div>
                                             </div>
                                          </div>
                                   </div>
                                 </div>
                              </div>
                           </li>


                           <li class="nav-item dropdown megamenu  <?php if($this->uri->uri_string() == 'home/studentinfo' || $this->uri->uri_string() == 'home/meritstudent' || $this->uri->uri_string() == 'home/digital_classroom' || $this->uri->uri_string() == 'home/emp_attendance' || $this->uri->uri_string() == 'home/attendance' || $this->uri->uri_string() == 'home/academic_schedule' || $this->uri->uri_string() == 'home/attendance'  || $this->uri->uri_string() == 'home/emp_attendance'){ echo 'active'; } ?>">
                              <a id="megamneu" href="" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="nav-link dropdown-toggle font-weight-bold">Academic</a>
                              <div aria-labelledby="megamneu" class="dropdown-menu border-0 p-0 m-0">
                                 <div class="container">
                                    <div class="megamenu-wrapper">
                                       <div class="row bg-white rounded-0 m-0 shadow-sm p-4">
                                       <div class="col-lg-4 mb-4">
                                          <h6 class="font-weight-bold text-uppercase py-2">Student</h6>
                                          <ul class="list-unstyled">
                                             <li class="nav-item"><a class="p-2" href="<?= base_url(); ?>home/studentinfo">Student Information</a></li>
                                             <li class="nav-item"><a class="p-2" href="<?= base_url(); ?>home/meritstudent">Student Achievement</a></li>
                                          </ul>
                                       </div>
                                       <div class="col-lg-4 mb-4">
                                          <h6 class="font-weight-bold text-uppercase py-2">Classroom</h6>
                                          <ul class="list-unstyled">
                                             <li class="nav-item"><a class="p-2" href="<?= base_url(); ?>home/digital_classroom">Multimedia Content</a></li>
                                             <li class="nav-item"><a class="p-2" href="<?= base_url(); ?>home/academic_schedule">Academic Schedule</a></li>
                                          </ul>
                                       </div>
                                       <div class="col-lg-4 mb-4">
                                          <h6 class="font-weight-bold text-uppercase py-2">Daily Attendance</h6>
                                          <ul class="list-unstyled">
                                             <li class="nav-item"><a class="p-2" href="<?= base_url(); ?>home/attendance">Student Attendance</a></li>
                                             <li class="nav-item"><a class="p-2" href="<?= base_url(); ?>home/emp_attendance">Teacher Attendance</a></li>
                                          </ul>
                                       </div>
                                    </div>
                                    </div>
                                 </div>
              </div>
                           </li>



                           <li class="nav-item dropdown <?php if($this->uri->uri_string() == 'home/managing_commettee' || $this->uri->uri_string() == 'home/Teacher'){ echo 'active'; } ?>">
                              <a class="nav-link dropdown-toggle font-weight-bold" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              Employees
                              </a>
                              <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                 <li><a class="dropdown-item" href="<?= base_url(); ?>home/managing_commettee">Managing Committee</a></li>
                                 <li><a class="dropdown-item" href="<?= base_url(); ?>home/Teacher">Teachers</a></li>
                              </ul>
                           </li>
                           <li class="nav-item dropdown <?php if($this->uri->uri_string() == 'home/classroutine' || $this->uri->uri_string() == 'home/examroutine'){ echo 'active'; } ?>">
                              <a class="nav-link dropdown-toggle font-weight-bold" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              Routine
                              </a>
                              <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                 <li><a class="dropdown-item" href="<?= base_url(); ?>home/classroutine">Class Routine</a></li>
                                 <li><a class="dropdown-item" href="<?= base_url(); ?>home/examroutine">Exam routine</a></li>
                              </ul>
                           </li>
                           <li class="nav-item dropdown <?php if($this->uri->uri_string() == 'home/schoolresult' || $this->uri->uri_string() == 'home/admissionresult' || $this->uri->uri_string() == 'home/JSCresult' || $this->uri->uri_string() == 'home/SSCresult'){ echo 'active'; } ?>">
                              <a class="nav-link dropdown-toggle font-weight-bold" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              Results
                              </a>
                              <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                 <li><a class="dropdown-item" href="<?= base_url(); ?>home/schoolresult">Academic Results</a></li>
                                 <li><a class="dropdown-item" href="<?= base_url(); ?>home/admissionresult">Admission Results</a></li>
                                 <li><a class="dropdown-item" href="<?= base_url(); ?>home/JSCresult"> JSC Results</a></li>
                                 <li><a class="dropdown-item" href="<?= base_url(); ?>home/SSCresult"> SSC Results</a></li>
                              </ul>
                           </li>

                            <li class="nav-item dropdown <?php if($this->uri->uri_string() == 'home/gallery' || $this->uri->uri_string() == 'home/video_gallery' ){ echo 'active'; } ?>">
                              <a class="nav-link dropdown-toggle font-weight-bold" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              Gallery
                              </a>
                              <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                 <li><a class="dropdown-item" href="<?= base_url(); ?>home/gallery">Photo Gallery</a></li>
                                 <li><a class="dropdown-item" href="<?= base_url(); ?>home/video_gallery">Video Gallery</a></li>
                              </ul>
                           </li>

                           <li class="nav-item dropdown <?php if($this->uri->uri_string() == 'home/notice' || $this->uri->uri_string() == 'home/career'){ echo 'active'; } ?>">
                              <a class="nav-link dropdown-toggle font-weight-bold" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                              Notice
                              </a>
                              <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                 <li><a class="dropdown-item" href="<?= base_url(); ?>home/notice">Notice</a></li>
                                 <li><a class="dropdown-item" href="<?= base_url(); ?>home/career">Recruitment Notice</a></li>
                              </ul>
                           </li>
                           <li class="nav-item dropdown font-weight-bold <?php if($this->uri->uri_string() == 'home/contact_us') { echo 'active'; } ?>">
                              <a class="nav-link" href="<?= base_url(); ?>home/contact_us">Contact</a>
                           </li>
                        </ul>
                     </div>
                  </nav>
                  <div class="menu-pos"></div>
               </div>
            </div>
         </header>
         <!-- **Header - End** -->
      </div>
   
