				<div class="col-md-8">
					<div class="row">
						<div class="col-md-6">
							<div class="home-section mb-3 card border p-1 overflow-hidden" style="height: 400px">
							   <div class="section-title color-2 p-2 mb-1">
								  <h5 class="text-center text-white">Student Notice</h5>
							   </div>
							   <div class="section-body card-body">
								  <div class="student-notice">
									 <ul class="list-unstyled notice-list">
										<?php if($student_notice){
										   $bangel_month=array('','জানুয়ারি', 'ফেব্রুয়ারী','মার্চ','এপ্রিল','মে','জুন','জুলাই','আগস্ট','সেপ্টেম্বর','অক্টোবর','নভেম্বর','ডিসেম্বর') ;
										   $bangel_day=array('০','১','২','৩','৪','৫','৬','৭','৮','৯','১০','১১','১২','১৩','১৪','১৫','১৬','১৭','১৮','১৯','২০','২১','২২','২৩','২৪','২৫','২৬','২৭','২৮','২৯','৩০','৩১') ;  
											?>
										<?php foreach($student_notice as $student){ ?>
										<?php if($student['notice_attachment']): ?>
										<li class="">
										   <a class="bangla" target="_blank" href="<?= base_url();?>upload/notice_file/<?= $student['notice_attachment'] ?>"><?= $student['notice_heading'] ?> </a>
										</li>
										<?php endif;?>
										<?php }} else{ ?>
										<li>No Notice Available</li>
										<?php } ?>
									 </ul>
								  </div>
							   </div>
							   <!--div class="card-footer">
								  <a href="" class="btn btn-sm text-white btn-2"><i class="fa fa-angle-double-right" aria-hidden="true"></i>
								  Show More</a>
							   </div-->
							</div>
						</div>
						<div class="col-md-6 ">
							<div class="home-section mb-3 card border p-1" style="height: 400px">
							   <div class="section-title color-2 p-2 mb-1">
								  <h5 class="text-center text-white">General Notice</h5>
							   </div>
							   <div class="section-body card-body">
								  <div class="student-notice">
									 <ul class="list-unstyled notice-list">
										<?php if($general_notice){
										   $bangel_month=array('','জানুয়ারি', 'ফেব্রুয়ারী','মার্চ','এপ্রিল','মে','জুন','জুলাই','আগস্ট','সেপ্টেম্বর','অক্টোবর','নভেম্বর','ডিসেম্বর') ;
										   $bangel_day=array('০','১','২','৩','৪','৫','৬','৭','৮','৯','১০','১১','১২','১৩','১৪','১৫','১৬','১৭','১৮','১৯','২০','২১','২২','২৩','২৪','২৫','২৬','২৭','২৮','২৯','৩০','৩১') ;  
											?>
										<?php foreach($general_notice as $nl){ ?>
										<?php if($nl['notice_attachment']): ?>
										<li class="">
										   <a class="bangla" target="_blank" href="<?= base_url();?>upload/notice_file/<?= $nl['notice_attachment'] ?>"><?= $nl['notice_heading'] ?> </a>
										</li>
										<?php endif;?>
										<?php }} else{ ?>
										<li>No Notice Available</li>
										<?php } ?>
									 </ul>
								  </div>
							   </div>
							   <!--div class="card-footer">
								  <a href="" class="float-right btn btn-sm btn-success text-white"><i class="fa fa-angle-double-right" aria-hidden="true"></i>
								  Show More</a>
							   </div-->
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-6">
							<div class="home-section card p-1 institution-msg pb-sm-3 border overflow-hidden">
								<div class="section-title color-2 p-2 mb-1 card-header">
									<h5 class="text-center text-white">Institution</h5>
								</div>
								<div class="section-body p-2 card-body body-middle-text">					 
									<h3 class="py-md-2 text-center text-sm-left">Welcome to Our School Site</h3>
									<div class="float-left pr-2">
										<img class="img-fluid img-thumbnail msg-img" style="width: 180px; height: 160px;" src="<?= base_url() ?>upload/message/<?= $about['about_image'];?>">
									</div>
									<p class="text-justify">
										<?php echo word_limiter($about['about_details'], 100); ?>
									</p>	   
								</div>
								<div class="card-footer">
									<a target="_blank" class="float-right btn btn-sm text-white color-2 btn-2" href="<?= base_url(); ?>home/about" >Read More <i class="fa fa-chevron-right" aria-hidden="true"></i>
</a> 
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="home-section card p-1 president-msg pb-sm-3 border overflow-hidden">
							   <div class="section-title color-2 p-2 mb-1 card-header">
								  <h5 class="text-center text-white">President</h5>
							   </div>
								<div class="section-body p-2 card-body body-middle-text">					 
									<h3 class="py-md-2 text-center text-sm-left">President's Message</h3>
									<div class="float-left pr-2">
										<img class="img-fluid img-thumbnail msg-img" style="width: auto; height: 150px;" src="<?= base_url() ?>upload/message/<?= $chairman['image'];?>">
									</div>
									<?php if(!empty($chairman['summary'])) { ?>
									<p class="text-justify">
										<?php echo word_limiter($chairman['summary'], 100); ?>
									</p>	

								<?php }else{ ?>
									<p class="text-justify">
										<?php echo word_limiter($chairman['message'], 100); ?>
									</p>
									<?php }; ?>	   
								</div>
								<div class="card-footer">
									<a target="_blank" class="float-right btn btn-sm text-white color-2 btn-2" href="<?= base_url(); ?>home/about" > Read More <i class="fa fa-chevron-right" aria-hidden="true"></i>
</a>
								</div>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-md-12" style="padding-top:20px;">
							<div class="home-section card p-1 pb-sm-3 border overflow-hidden">
								<div class="section-title color-2 p-2 mb-1 card-header">
									 <h5 class="text-center text-white">Head Teacher Message</h5>
								</div>
								<div class="section-body p-2 card-body body-middle-text">
									<div class="float-left pr-2">
										<img width="120px;" class="img-fluid img-thumbnail msg-img" src="<?= base_url() ?>upload/message/<?= $headmaster['image'];?>" >
									</div>

									<?php if(!empty($headmaster['summary'])) { ?>
									<p class="text-justify">
										<?php echo word_limiter($headmaster['summary'], 100); ?>
									</p>	

								    <?php }else{ ?>
									<p class="text-justify">
										<?php echo word_limiter($headmaster['message'], 100); ?>
									</p>
									<?php }; ?>	   
								</div>								
								<div class="card-footer">
									<a target="_blank" class="float-right btn btn-sm text-white color-2 btn-2" href="<?= base_url(); ?>home/headmasterMessage" >Read More <i class="fa fa-chevron-right" aria-hidden="true"></i>
</a> 
								</div>
							</div>
						</div>
					</div>
                  <!--row-->
				</div>