 <!-- **Footer** -->
<footer id="footer">
   <div class="footer-wrapper py-4" style="background-color: #343A40;">
      <div class="container">
         <div class="row">
            <div class="col-md-3 col-sm-3 col-12">
               <div class="footer-text">
                  <h4 class="text-white text-sm-center text-md-left text-lg-left py-2"><span class="fa fa-map-marker">  </span> Our Address </h4>
                  <p class="text-white text-sm-center text-md-left text-lg-left"><i class="fa fa-home"></i> <span>Post: Telihaty, Upozila: Sreepur, Zila: Gazipur</span>  </p>
                  <div class="footer-link">
                  <ul class="list-unstyled">
                  <li class="text-sm-center text-md-left text-white"> <i class="fa fa-phone"></i> 01711511147, 01511125125</li>
                  <li class="text-sm-center text-md-left text-white"> <i class="fa fa-envelope"></i> telihatyhighschool@yahoo.com</li>
                  <li class="text-sm-center text-md-left text-white"><a class="text-white" href="http://thsict.edu.bd/"><i class="fa fa-globe"></i> www.thsict.edu.bd/</a></li>
                  <li class="text-sm-center text-md-left text-white"><a class="text-white" href="https://www.facebook.com/THS.Edu.Bd" target="_blank"><i class="fa fa-facebook-square"></i> Get us on Facebook</a></li>
                  <li class="text-sm-center text-md-left text-white"><a class="text-white" href="https://www.facebook.com/telihatyhighschool" target="_blank"> <i class="fa fa-facebook-square"></i> Facebook Official Page</a></li>
               </ul>
            </div>
               </div>
            </div>
            <div class="col-md-3 col-sm-3 col-12">
                  <h3  class="text-sm-center text-md-left text-white py-2"><span class="fa fa-link"></span>Usefull Link </h3>
                  <div class="footer-link">
                     <ul class="list-unstyled">
                  <li class="text-md-left text-sm-center "><a href="http://www.banbeis.gov.bd/" target="_blank"><i class="fa fa-external-link-square" aria-hidden="true"></i> BANBEIS</a></li>
                   <li class="text-sm-center text-md-left"><a href="http://www.dshe.gov.bd/" target="_blank"><i class="fa fa-external-link-square" aria-hidden="true"></i> DSHSE</a></li>
                   <li class="text-sm-center text-md-left"> <a href="http://www.educationboard.gov.bd/" target="_blank"><i class="fa fa-external-link-square" aria-hidden="true"></i> Bangladesh Education Board</a> </li>
                   <li class="text-sm-center text-md-left"><a href="http://eff.teletalk.com.bd/" target="_blank"><i class="fa fa-external-link-square" aria-hidden="true"></i> eFF</a></li>
                  <li class="text-sm-center text-md-left"><a href="http://esif.teletalk.com.bd/" target="_blank"><i class="fa fa-external-link-square" aria-hidden="true"></i> eSIF</a></li>
                   <li class="text-sm-center text-md-left"><a href="http://application.emis.gov.bd:4040/adminLogin.aspx" target="_blank"><i class="fa fa-external-link-square" aria-hidden="true"></i> MPO- Login </a></li>
                   <li class="text-sm-center text-md-left"><a href="http://www.educationboardresults.gov.bd/regular/index.php" target="_blank"><i class="fa fa-external-link-square" aria-hidden="true"></i> Board Results</a></li>
                   <li class="text-sm-center text-md-left"><a href="http://www.dhakaeducationboard.gov.bd/" target="_blank"><i class="fa fa-external-link-square" aria-hidden="true"></i> Dhaka Education Board</a></li>
               </ul>
               </div>
            </div>
            <div class="col-md-3 col-sm-3 col-12">
               <aside class="widget widget_tweetbox">
                  <h3 class="text-sm-center text-md-left text-white"><span class="fa fa-link"></span> Board Links </h3>
                  <div class="footer-link">
                     <ul class="list-unstyled">
                        <li class="text-sm-center text-md-left"><a class="" href="http://www.educationboard.gov.bd/chittagong/" target="_blank"><i class="fa fa-external-link-square" aria-hidden="true"></i> Chittagong Board</a></li>
                        <li class="text-sm-center text-md-left"><a href="http://www.educationboard.gov.bd/comilla/index.html" target="_blank"><i class="fa fa-external-link-square" aria-hidden="true"></i> Comilla Board</a></li>
                        <li class="text-sm-center text-md-left"><a href="http://www.educationboard.gov.bd/barisal/index.html" target="_blank"><i class="fa fa-external-link-square" aria-hidden="true"></i> Barisal Board</a></li>
                        <li class="text-sm-center text-md-left"><a href="http://www.educationboard.gov.bd/sylhet/index.html" target="_blank"><i class="fa fa-external-link-square" aria-hidden="true"></i> Sylhet Board</a></li>
                        <li class="text-sm-center text-md-left"><a href="http://www.educationboard.gov.bd/rajshahi/index.html" target="_blank"><i class="fa fa-external-link-square" aria-hidden="true"></i> Rajshahi Board</a></li>
                        <li class="text-sm-center text-md-left"><a href="http://www.educationboard.gov.bd/jessore/index.html" target="_blank"><i class="fa fa-external-link-square" aria-hidden="true"></i> Jessore Board</a></li>
                        <li class="text-sm-center text-md-left"><a href="http://www.bmeb.gov.bd/" target="_blank"><i class="fa fa-external-link-square" aria-hidden="true"></i> Madrasah Board</a></li>
                        <li class="text-sm-center text-md-left"><a href="http://www.bteb.gov.bd/" target="_blank"><i class="fa fa-external-link-square" aria-hidden="true"></i> Technical Board</a></li>
                     </ul>
     
                  </div>
               </aside>
            </div>
            <div class="col-md-3 col-sm-3 col-12">
				<div class="py-2">
					<h4 class="text-white py-2"> <span class="fa fa-cog fa-spin"></span> Social :</h4>
					<div class="social">
						<ul class="list-unstyled list-inline">
							<li class="list-inline-item"><a href="https://www.facebook.com/telihatyhighschool" target="__blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
							<li class="list-inline-item"> <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
							<li class="list-inline-item"> <a href="https://www.youtube.com/channel/UCH0A8gS4ZPnjT_aqtJK9E7w"><i class="fa fa-youtube" aria-hidden="true"></i></a></li>
							<li class="list-inline-item"> <a href="https://www.instagram.com/telihatyhighschool/"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
						</ul>
					</div>
					<!--div class="py-3">
						<li class="py-1"><a class="text-white" href="<?= base_url() ?>"><i class="fa fa-home" aria-hidden="true"></i> Home</a></li>
					</div-->
					<div class="lisitemap-section pt-2">
						<ul class="counter-list list-unstyled">
                            <li class="p-2 border-bottom bg-light"><i class="fa fa-check" aria-hidden="true"></i> Today Visitors<div class="badge badge-success float-right"><?php if(!empty($v_counter['today_visitor'])){ echo $v_counter['today_visitor'];}?></div></li>
                            <li class="p-2 border-bottom bg-white"><i class="fa fa-check" aria-hidden="true"></i> Yesterday Visitors<div class="badge badge-light float-right"><?php if(!empty($v_counter['yesterday_visitor'])) {echo $v_counter['yesterday_visitor'];}?></div></li>
                            <li class="p-2 border-bottom bg-white"><i class="fa fa-check" aria-hidden="true"></i> Weekly Visitors<div class="badge badge-light float-right"><?php if(!empty($v_counter['weekly_visitor'])) { echo $v_counter['weekly_visitor'];}?></div></li>
                            <li class="p-2 border-bottom bg-white"> <i class="fa fa-check" aria-hidden="true"></i> Monthly Visitors<div class="badge badge-light float-right"><?php if(!empty($v_counter['month_visitor'])) { echo $v_counter['month_visitor'];}?></div></li>
                            <li class="p-2 border-bottom bg-white"> <i class="fa fa-check" aria-hidden="true"></i> Yearly Visitors<div class="badge badge-light float-right"><?php if(!empty($v_counter['yearly_visitor'])) {  echo $v_counter['yearly_visitor'];}?></div></li>
                            <li class="p-2 border-bottom bg-white"><i class="fa fa-check" aria-hidden="true"></i> All Time Visitor<div class="badge badge-light float-right"><?php if(!empty($v_counter['total_hit_inc'])) { echo $v_counter['total_hit_inc'];}?></div></li>
                        </ul> 
                    </div>
 <style>
.lisitemap-section ul>li {
    padding: 5px;
    font-size: 17px;
    background: #3b5998;  /* fallback for old browsers */
    background: -webkit-linear-gradient(to right, rgb(29, 161, 200), #3b5998);  /* Chrome 10-25, Safari 5.1-6 */
    background: linear-gradient(to right, rgb(29, 161, 200), #3b5998); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
    list-style: none;
    margin: 1px;
    cursor: pointer;
}
.lisitemap-section ul>li {
    color: #fff;
}
.lisitemap-section ul>li:hover {
   /* color: #29ad3a;*/
   background-color: rgb(29, 161, 200)!important;
   opacity: .9;
}
                            </style>

				</div>
            </div>
         </div>
      </div>
   </div>
   <!-- **footer-widgets-wrapper - End** -->
   <div class="copyright py-2 bg-dark border border-left-0 border-bottom-0 border-right-0">
      <div class="container">
        <div class="row">
          <div class="col-md-6">
            <p class="float-left text-white">
            Technical Support: <a class="text-white" target="_blank" href="http://weblinkltd.com">Weblink Communications LTD</a>
         </p>
          </div>
          <div class="col-md-6">
            <p class="float-right text-white">
            All rights recognized &copy; Telihaty High School
         </p>
          </div>
        </div>
      </div>
   </div>
</footer>
<script src="<?= base_url() ?>template/js/bootstrap.min.js" type="text/javascript"></script>
<script src="<?= base_url();?>template/js/slicknav.min.js"></script>
<script src="<?= base_url() ?>template/js/owl.carousel.min.js" type="text/javascript"></script>
<script src="<?= base_url() ?>template/js/owl-custom.js" type="text/javascript"></script>
</body>
</html>