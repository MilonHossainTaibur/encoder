<?php include 'application/views/home/inc/header.php';?>
<!-- Primary Starts -->
<section  class="content-full-width grey1">
      <div class="container min-height py-4 bg-white">
      <div class="row">
         <div class="col-md-12">
            <div class="card">
               <div class="card-header hr-title dt-sc-hr-invisible-small curl">
                  <h3><i class="fa fa-calendar" aria-hidden="true"></i>
 Notice Board</h3>
         <div class="title-sep"> </div>
                  
               </div>
               <div class="card-body">
                 <div class="table-responsive">
                     
                     <table class="table table-bordered" >
               <tr>
                  <th>Notice</th>
                  <th>Description</th>
                  <th>Download</th>
                  <th>Published Date</th>
               </tr>
               <?php foreach($notice_list as $ntl) { ?>
				<tr>
					<td>
						<a href="<?= base_url()?>home/single_notice/<?= $ntl['notice_id'] ?>"><?= $ntl['notice_heading'] ?></a>      
					</td>
					<td><a href="<?= base_url()?>home/single_notice/<?= $ntl['notice_id'] ?>">Details.....</a></td>
					<td><?php if($ntl['notice_attachment']): ?>
						<a href="<?= base_url();?>upload/notice_file/<?= $ntl['notice_attachment'] ?>" class="pull-left print_button"><i class="fa fa-download"></i><b>Click Here....</b></a>
						<?php endif; ?>
					</td>
                  <td><?= date('d M, Y',strtotime($ntl['publish_date'])) ?> </td>
                  
               </tr>
               <?php } ?>
            </table>
                 </div>
               </div>
            </div>
         </div>  
      </div>
   </div>
</section>
<?php include 'application/views/home/inc/footer.php';?>

