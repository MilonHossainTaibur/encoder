<?php include 'application/views/home/inc/header.php';?>
<!-- Primary Starts -->

<section id="primary" class="content-full-width grey1">
   <div class="container min-height py-4 bg-white">
    <div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-header hr-title dt-sc-hr-invisible-small curl">
                    <h3 class="">Exam Routine</h3>
         <div class="title-sep"></div>
                </div>
                <div class="card-body">
                    <div class="form-group">
                                    <div class="row">
                                        <div class="col-sm-4" >
                                            <label>Exam <span style="color:red;">*</span></label>
                                            <select class="form-control" name="term_id" id="term_id">
                                                <option value="">----Select Exam----</option>
                                                <?php foreach($term_list as $tl){ ?>
                                                <option value="<?php echo $tl['term_id'];?>"><?php echo $tl['term'];?></option>   
                                                <?php    } ?>
                                            </select>
                                        </div>
                                        <div class="col-sm-4" >
                                            <label>Class <span style="color:red;">*</span></label>
                                            <select class="form-control" name="class_id" id="class_id" onchange="get_class_section_list(this.value); get_class_group_list(this.value)">
                                                <option value="">----Select Class----</option>
                                                <?php foreach($class_list as $cl){ ?>
                                                <option value="<?= $cl['class_id'];?>"><?= $cl['class_name'];?></option>   
                                                <?php    } ?>
                                            </select>
                                        </div>
                                        <div class="col-sm-6 col-md-3">
                                            <label>Section</label>
                                            <select class="form-control" name="section_id" id="section_id">
                                                <option value="all">----Select Section----</option>
                                            </select>
                                        </div>
                                        <div class="col-sm-6 col-md-3">
                                            <label>Group</label>
                                            <select class="form-control" name="group_id" id="group_id">
                                                <option value="all">----Select Group----</option>
                                            </select>
                                        </div>
                                        <div class="col-sm-4" >
                                            <label>Session <span style="color:red;">*</span></label>
                                            <select class="form-control" name="session_id" id="session_id">
                                                <option value="">----Select Session----</option>
                                                <?php foreach($session_list as $sl){ ?>
                                                    <option value="<?php echo $sl['session_id']; ?>"><?php echo $sl['session_name']; ?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <button type="button" class="btn btn-primary" onclick="exam_routine_json();">Get Routine</button>
                                        </div>
                                    </div>
                                </div>
                                <hr>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-sm-12" id="display">
                                            <!-- routine will be displayed here -->
                                        </div>
                                    </div>
                                </div>
                </div>
            </div>
        </div>
    </div>
   </div>
</section>
<?php include 'application/views/home/inc/footer.php';?>
<script type="text/javascript">
function get_day(exam_date,id)
{
	 var dayNames = new Array( 'Sunday' , 'Monday' , 'Tuesday' , 'Wednesday' , 'Thursday' , 'Friday' , 'Saturday' );
     var nData = new Date (exam_date);
	 $('.date'+id).next('td').html(dayNames[nData.getDay()]);
}

function exam_routine_json(term_id,class_id,section_id,group_id,session_id)
{
	var term_id		= $('#term_id').val();
	var class_id 	= $('#class_id').val();
	var section_id 	= $('#section_id').val();
	var group_id 	= $('#group_id').val();
	var session_id	= $('#session_id').val();
	$.ajax({
        url: baseUrl+'home/exam_routine_json',
        data:
            {                  
                'term_id':term_id,
				'class_id':class_id,
				'section_id':section_id,
				'group_id':group_id,
				'session_id':session_id
            },
            dataType: 'json',
            success: function(data)
            {
                //alert(responce);
                result                = ''+data['result']+'';
                mainContent           = ''+data['mainContent']+'';

                if(result == 'success')
                {      
                    $('#display').html(mainContent);  
					// call the routine if created before
					//get_old_exam_routine(term_id,class_id,section_id,group_id,session_id);
                }                
            }
        });
        return false; // keeps the page from not refreshing     
}

function get_old_exam_routine(term_id,class_id,section_id,group_id,session_id)
{
	
	 $.getJSON(//6
				baseUrl + 'home/get_old_exam_routine_by_term',
				{ 
					'exam_term_id':term_id,
					'class_id':class_id,
					'section_id':section_id,
					'group_id':group_id,
					'session_id':session_id
				},
				function(jd) {
						
				for(i=0; i<jd.length; i++)
				{
					$("td[id='"+jd[i].row_no+"'] input.timerange").val(jd[i].exam_date);
					$("td[id='wkday"+jd[i].row_no+"']").html(jd[i].exam_day);
					$("td[id='"+jd[i].row_no+jd[i].column_no+"'] select").val(jd[i].exam_subject_id);
				}
									
			});					
}

window.onload=function(){
	
	get_class_section_list(<?=$this->session->userdata('class_id')?>);
	get_class_group_list(<?=$this->session->userdata('class_id')?>);
}
function get_class_section_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'home/section_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#section_id').html(html_data);
			$("#section_id").val($("#section_id option:first").val('all'));
			document.getElementById('section_id').value = '<?=$this->session->userdata('section_id')?>';
        }
    }
    });  
}
function get_class_group_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'home/group_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#group_id').html(html_data);
			$("#group_id").val($("#group_id option:first").val('all'));
			document.getElementById('group_id').value = '<?=$this->session->userdata('group_id')?>';
        }
    }
    });  
}

function printPageArea(areaID){
		var printContent = document.getElementById(areaID);
		var WinPrint = window.open('', '', 'width=900,height=650');
		WinPrint.document.write('<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" crossorigin="anonymous">')
		WinPrint.document.write('<style type="text/css" media="print"> @page { size: landscape; font-size:12px; } table{font-size:12px;}.table { width: 100%; margin-bottom: 1rem;color: #212529;} table td{padding:3px;} .print_button{ display:none;} </style>')
		WinPrint.document.write(printContent.innerHTML);
		WinPrint.document.close();
		WinPrint.focus();
		WinPrint.print();
		WinPrint.close();
	}
</script>

