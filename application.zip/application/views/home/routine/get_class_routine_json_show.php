<style>
.table thead th {
	vertical-align: bottom;
    border-bottom: 1px solid #000;
}

.table-bordered td, .table-bordered th {
    border: 1px solid #000;
}
</style>
<div style="margin:10px auto; width:50%; text-align:center;">
	<h2>Telihaty High School</h2>
	<h4>Telihaty, Sreepur, Gazipur</h4>
	<h4>Class Routine <?php echo date('Y');?></h4>
	<h5>Class : <?php print_r($class_name[0]['class_name']);?>; Section : <?php print_r($section_name[0]['section_name']);?>; Group : <?php print_r($group_name[0]['group_name']);?>;</h5>
</div>
<table class="table table-bordered">
	<thead>
        <tr>
          <th scope="col">Class Time</th>
            <?php foreach($class_time as $ct){?>
            <th scope="col"><?php echo $ct['start_time'].'-'.$ct['close_time'];?></th>  
            <?php }?>
        </tr>
    </thead>
    <tbody>
		<tr>
            <td>Period</td>
            <?php foreach($class_time as $ct){ ?>
				<td id='clperiod'><?php echo $ct['period'];?></td>  
            <?php }?>
        </tr>
                                                
        <?php foreach($week as $wk){ ?>
        <tr>
			<td id='wkday'><?php echo ucwords($wk['day']);?></td>
            <?php for($i=0; $i<count($class_time); $i++){ ?>
            <td id="<?php echo $wk['day'];?>">
                <div class="<?= 'div'.$i.$wk['day'];?>">
					<span id="<?= 'tid'.$i;?>"></span>                
                    <span id="<?= 'cid'.$i;?>"></span>
                </div>
			</td>  
            <?php }?>
        </tr>  
        <?php }?>
    </tbody>
</table>
<div style="margin:5px auto;" class="print_button">
  <button type="button" class="btn btn-primary" title="Print This Routine" onclick="printPageArea('display')"> Print </button>
</div>
<script>
function new_box_old_routine(i,wk,id)
  {
    $('div.div'+i+wk).append('<span id="classtid'+id+'" style="border:none;"></span><span class="subject_name" style="border:none;" id="classcid'+id+'"></span>');
  }
</script>