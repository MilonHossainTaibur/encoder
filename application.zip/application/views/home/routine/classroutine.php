<?php include 'application/views/home/inc/header.php';?>
<section id="primary" class="content-full-width grey1">
<div class="container py-4 min-height bg-white">
  <div class="row">
    <div class="col-md-12">
		<div class="card">
			<div class="card-header hr-title dt-sc-hr-invisible-small curl">
			  <h3 class="">Class Routine</h3>
			   <div class="title-sep"></div>
			</div>
			<div class="card-body">
				<div class="form-group">
				<div class="row">
						<div class="col-sm-4">
							<label>Class</label>
							<select class="form-control" name="class_id" id="class_id" onchange="get_class_section_list(this.value); get_class_group_list(this.value);">
								<option value="">----Select Class----</option>
								<?php
									foreach($class_list as $cl){ ?>
									<option value="<?php echo $cl['class_id'];?>"><?php echo $cl['class_name'];?></option>   
								<?php    } ?>
							</select>
						</div>
						<div class="col-sm-4">
							<label>Section</label>
							<select class="form-control" name="section_id" id="section_id" />
								<option value="">Select</option>
							</select>
						</div>
						<div class="col-sm-4">
						   <label>Group</label>
							<select class="form-control" name="group_id" id="group_id" required />
								<option value="">Select</option>
							</select>
						</div>
						<div class="col-sm-4">
							<label>Shift</label>
							<select class="form-control" name="shift_id" id="shift_id" required />
								<option value="">Select</option>
								<?php foreach($shift_list as $sl){ ?>
									<option value="<?php echo $sl['shift_id'];?>"><?php echo $sl['shift_name'];?></option>   
								<?php } ?>
							</select>
						</div>
					</div>
				</div>
				<div class="form-group">
					<div class="row">
					   <div class="col-sm-4">
						  <button type="button" class="button btn btn-info" onclick="get_class_routine_json()">Submit</button>
					   </div>
					</div>
				</div>	 
			</div>
		</div><!--card-->
		<div id="display" style="background-color:#dfe4ef">
		<!-- content will display here -->
		</div>
      </div><!--col-md-12-->
    </div><!--row-->
  </div><!--container-->
</section>
<?php include 'application/views/home/inc/footer.php';?>
<script type="text/javascript">
   function get_class_section_list(class_id)
   {
      $.ajax({
       type: "POST",
       url: baseUrl + 'home/section_list_ajax',
       data:
       {
           'class_id':class_id
       }, 
       success: function(html_data)
       {
           if (html_data != '')
           {
               $('#section_id').html(html_data);
           }
       }
       });
   }
   
   function get_class_group_list(class_id)
   {
      $.ajax({
       type: "POST",
       url: baseUrl + 'home/group_list_ajax',
       data:
       {
           'class_id':class_id
       }, 
       success: function(html_data)
       {
           if (html_data != '')
           {
               $('#group_id').html(html_data);
           }
       }
       });  
   }
   
   // get the student list and fees list 
function get_class_routine_json(class_id,section_id,group_id,shift_id)
    {

      var class_id=$("#class_id").val();
      var section_id=$("#section_id").val();
      var group_id=$("#group_id").val();
      var shift_id=$("#shift_id").val();

       $.ajax({ 
       url: baseUrl+'home/get_class_routine_json_show',
       data:{

            class_id:class_id,
             section_id:section_id,
             group_id:group_id,
             shift_id:shift_id,
                        
             },
           
            dataType: "json",   //expect html to be returned                
            success: function(data){                    
                 result                = ''+data['result']+'';
                   mainContent           = ''+data['mainContent']+'';
   
                   if(result == 'success')
                   {      
                       $('#display').html(mainContent);  
            
            // call the routine if created before
            get_old_class_routine();
               } 
           }
        });
        return false; // keeps the page from not refreshing  

  
       }
    
   
   function get_old_class_routine()
   {
    $.getJSON( baseUrl + 'home/get_old_routine_by_section_class_show',
        {
          'class_id':$('#class_id').val(),
          'section_id':$('#section_id').val(),
          'group_id':$('#group_id').val(),
          'shift_id':$('#shift_id').val()
        },
        function(jd) {
          for(i=0; i<jd.length; i++)
          {
            var multycolumn_no=jd[i].column_no.split(",");
            var multyteacher_name=jd[i].teacher_name.split(",");
            var multysubject_name=jd[i].subject_name.split(",");
            var multyteacher_id=jd[i].teacher_id.split(",");
            var multysubject_id=jd[i].subject_id.split(",");
              
            if(multycolumn_no.length > 1 )
            {
              for(mb=0; mb < multycolumn_no.length; mb++)
              {
                if(mb < 1)
                {
                  $("td[id='"+jd[i].day+"'] span#tid"+multycolumn_no[mb]).html(multyteacher_name[mb]);
                  $("td[id='"+jd[i].day+"'] span#cid"+multycolumn_no[mb]).html(' ('+multysubject_name[mb]+')');
                }
                else
                {
                  // call function from json file to add new routine box
                  new_box_old_routine(multycolumn_no[mb] , jd[i].day,multyteacher_id[mb]+multysubject_id[mb]);
                  
                  $("td[id='"+jd[i].day+"'] span#classtid"+multyteacher_id[mb]+multysubject_id[mb]).html('<br/><br/>'+multyteacher_name[mb]);
                  $("td[id='"+jd[i].day+"'] span#classcid"+multyteacher_id[mb]+multysubject_id[mb]).html(' ('+multysubject_name[mb]+')');
                }
              }
            }
            else
            {
              $("td[id='"+jd[i].day+"'] span#tid"+jd[i].column_no).html(jd[i].teacher_name);
              $("td[id='"+jd[i].day+"'] span#cid"+jd[i].column_no).html(' ('+jd[i].subject_name+')');
            }
          }
          }
        );
            
        var clPeriod=new Array();  
        var iclPeriod=0;
        $( "td#clperiod").each(function() {
          clPeriod[iclPeriod]=$(this).html();
                  
          if($(this).html()=="tiffin")
          {//alert(iclPeriod);
            $('span#tid'+iclPeriod).html("<br/><span style=''>Break</span>");
            $('span#cid'+iclPeriod).html("");
          }
          iclPeriod++;
        });           
   }
   
   function printPageArea(areaID){
      var printContent = document.getElementById(areaID);
      var WinPrint = window.open('', '', 'width=900,height=650');
      WinPrint.document.write('<link rel="stylesheet" type="text/css" href="<?= base_url();?>template/bootstrap-print/bootstrap-print.min.css" media="print" />')
      WinPrint.document.write('<style type="text/css" media="print"> @page { size: landscape; font-size:12px; } table{font-size:12px;} table td{padding:3px;} .print_button{ display:none;} </style>')
      WinPrint.document.write(printContent.innerHTML);
      WinPrint.document.close();
      WinPrint.focus();
      WinPrint.print();
      WinPrint.close();
    }
</script>

