
<div class=" bg-white">
<div class="row">
    <div class="col-md-12">
        <div class="exam-routine">
            <h2 class="text-center" style="color: #000000;text-align:center;text-transform:uppercase;"><?= $school['school_name']; ?></h2>
            <h4 class="text-center" style="text-align:center;"><?= $school['address']; ?>, <?= $school['post_office']; ?>, <?= $school['district']; ?></h4>
            <!--div class="text-center">
                <span style="padding:4px 18px; font-size:12px;background-color: #6595E9;color: #fff;font-weight: 700;text-transform: uppercase;border:1px solid #000;font-family: Arial;">Exam Routine</span>
            </div-->
            <h4 class="text-center" style="text-align:center;">Email: <?= $school['email']; ?></h4>
            <h4 class="text-center" style="text-align:center;">Website: <?= $school['website']; ?></h4>
            <h4 class="text-center" style="text-align:center;text-transform:uppercase;">Name of the Exam : <?php echo $term[0]['term'].'   '.$session[0]['session_name'] ?></h4>
            <div class="routine-logo">
                        <img src="<?= base_url(); ?>upload/institute_logo/<?= $school['logo'];?>" alt="" height="auto" width="100" />
                    </div>
        </div>

    </div>
</div>

			<div class="row">
       <div class="col-md-12">
           <h3 style="text-align: center;">Exam Time (<?php print_r($exam_routine[0][0]['examtime']); ?>)</h3>
           <br>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Date & Day</th>
                        <th>Subject</th>
                        <th>Date & Day</th>
                        <th>Subject</th>
                    </tr>
                </thead>
 
                <?php foreach($exam_routine as $routine_array_chunk){ //print_r($routine_array_chunk); exit();?>
                <tr>
                    <?php $r_flag=0; foreach($routine_array_chunk as $routine){ ?>

                        <?php
                        if($routine['subject_id']==5 || $routine['subject_id']==6 || $routine['subject_id']==7 || $routine['subject_id']==8){
echo "<td>".date('d/M/Y (D)',strtotime($routine['exam_date'],$routine['examtime']))."</td>";
                            if($r_flag==0){
                             
                            echo "<td>Religion & Moral Education</td>";$r_flag=1;
                                
                            }
                        
                    }
                        else{
                            echo "<td>".date('d/M/Y (D)',strtotime($routine['exam_date']))."</td>";
                            echo "<td>".$routine['subject_name']."</td>";
                        
                         ?>
                         <?php } ?>
                     <?php } ?>
                </tr>
                <?php } ?>
            </table>

       </div>         
            </div>


<style>

/* on-screen styles */
@media screen {
  .exam-routine{
        position: relative;

    }
    .routine-logo{
        position: absolute;
        left: 20%;
        top: 0;
    }
    table{
        background-color: #fff!important;
    }
}

@media print {
     .exam-routine{
        position: relative;

    }
    .routine-logo{
        position: absolute;
        left: 13%;
        top: 0;
    }
    table{
        background-color: #fff!important;
    }
    table {
    border-collapse: collapse;
}
  .table {
    width: 100%;
    margin-bottom: 1rem;
    color: #212529;
}
.table thead th {
    vertical-align: bottom;
    border-bottom: 2px solid #dee2e6;
    background: #4FC3F7; 
	color: #fff; 
	font-weight: bold;
	text-transform:uppercase;
	-webkit-print-color-adjust: exact; /*chrome & webkit browsers*/
    color-adjust: exact; /*firefox & IE */
}
.table td, .table th {
    padding: .75rem;
    vertical-align: top;
    border-top: 1px solid #dee2e6;
    text-align:left;
}
.table-bordered {
    border: 1px solid #dee2e6;
}
h1,h2,h3,h4,h5,h6{
    padding:0px;
    margin-top: 5px;
    margin-bottom: 5px
    
}
.table-bordered td, .table-bordered th {
    border: 1px solid #dee2e6;
}
tbody tr:nth-of-type(odd) {
    background-color: rgba(0,0,0,.05);
}


}

@page {
  size: A4;
margin: 30px 20px ;
border: initial;
border-radius: initial;
width: initial;
min-height: initial;
box-shadow: initial;
background: initial;
page-break-after: always;
}
@media print {
  html, body {
    width: 210mm;
    height: 297mm;
  }
  /* ... the rest of the rules ... */
}
</style>
            <div class="print_button" style="padding-left:20px;"><button type="submit" class="button btn btn-info" value="Print" name="searchBtnclass_result" onclick="printPageArea('display')"><i class="fa fa-print" aria-hidden="true"></i> Print</button>
	
</div>