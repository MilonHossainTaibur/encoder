<?php include 'application/views/home/inc/header.php';?>
<!-- **Full-width-section - Starts** -->
<div class="full-width-section">
   <div class="container min-height py-4 bg-white">
            <div class="card">
               <div class="card-header hr-title dt-sc-hr-invisible-small curl">
                   <h3> <i class="fa fa-user-o"></i> Former Headmasters</h3>
         <div class="title-sep"> </div>
               </div>
               <div class="card-body">
                  <div class="table-responsive">



         <table class="table table-striped">
            <tbody>
               <tr>
                  <th>Name</th>
                  <th>Qualification</th>
                  <th>From-To</th>
                  <th>Photo</th>
               </tr>
                <?php foreach($teachers as $teacher) { ?>
               <tr>
                  <td><?= $teacher['name'];?></td>
                  <td><?= $teacher['qualification'];?></td>
                  <td><?= $teacher['period'];?></td>
                  <td><img class="img-thumbnail" width="100px" src="<?= base_url();?>upload/teacher_image/<?= $teacher['photo'];?>"></td>
               </tr>
               <?php } ?>
               
            </tbody>
         </table>



         <!--table class="table table-striped">
            <tbody>
               <tr>
                  <th>Sl</th>
                  <th>Name</th>
                  <th>Qualification</th>
                  <th>From</th>
                  <th>To</th>
               </tr>
               <tr>
                  <td>1</td>
                  <td>Md. Samsul Haque</td>
                  <td>B.A</td>
                  <td>06/01/1968</td>
                  <td>31/12/1968</td>
               </tr>
               <tr>
                  <td>2</td>
                  <td>Md. Abdul Halim</td>
                  <td>B.A</td>
                  <td>01/01/1969</td>
                  <td>31/12/1969</td>
               </tr>
               <tr>
                  <td>3</td>
                  <td>Md. Tofazzol Hossain</td>
                  <td>B.A</td>
                  <td>01/01/1970</td>
                  <td>09/08/1973</td>
               </tr>
               <tr>
                  <td>4</td>
                  <td>Md. Abul Hasem(in-charge)</td>
                  <td>B.A</td>
                  <td>01/08/1974</td>
                  <td>25/01/1974</td>
               </tr>
               <tr>
                  <td>5</td>
                  <td>Md. Abul Hasem</td>
                  <td>B.A</td>
                  <td>26/01/1974</td>
                  <td>29/11/1979</td>
               </tr>
               <tr>
                  <td>6</td>
                  <td>Md. Mojibor Rahman</td>
                  <td>B.A B.ED</td>
                  <td>30/11/1979</td>
                  <td>23/11/1980</td>
               </tr>
               <tr>
                  <td>7</td>
                  <td>Md. Kolim Uddin Mollah</td>
                  <td>M.A.</td>
                  <td>24/11/1980</td>
                  <td>19/03/1983</td>
               </tr>
               <tr>
                  <td>8</td>
                  <td>Md. Mohabbat Ali</td>
                  <td>B.A B.ED</td>
                  <td>20/03/1983</td>
                  <td>27/03/2003</td>
               </tr>
               <tr>
                  <td>9</td>
                  <td>Md. Maniruzzaman(in-charge)</td>
                  <td>B.Sc B.ED</td>
                  <td>28/03/2003</td>
                  <td>30/06/2003</td>
               </tr>
               <tr>
                  <td>10</td>
                  <td>Md. Mohabbat Ali</td>
                  <td>B.A B.ED</td>
                  <td>01/07/2003</td>
                  <td>04/02/2005</td>
               </tr>
               <tr>
                  <td>11</td>
                  <td>Md. Ali Monsur Manik(in-charge)</td>
                  <td>B.A. M.ED</td>
                  <td>05/02/2005</td>
                  <td>28/08/2005</td>
               </tr>
               <tr>
                  <td>12</td>
                  <td>Md. Islam Uddin(in-charge)</td>
                  <td>I.A. P.T.A</td>
                  <td>29/09/2005</td>
                  <td>09/08/2008</td>
               </tr>
               <tr>
                  <td>13</td>
                  <td>Md. Ali Monsur Manik(in-charge)</td>
                  <td>B.A. M.ED</td>
                  <td>10/08/2008</td>
                  <td>27/06/2010</td>
               </tr>
               <tr>
                  <td>14</td>
                  <td>Md. Maniruzzaman(in-charge)</td>
                  <td>B.Sc B.ED</td>
                  <td>26/06/2010</td>
                  <td>11/07/2010</td>
               </tr>
               <tr>
                  <td>15</td>
                  <td>Md. Ali Monsur Manik</td>
                  <td>B.A. M.ED</td>
                  <td>12/07/2010</td>
                  <td></td>
               </tr>
            </tbody>
         </table-->
      </div>
               </div>
            </div>    
</div>
   </div>

<?php include 'application/views/home/inc/footer.php';?>

