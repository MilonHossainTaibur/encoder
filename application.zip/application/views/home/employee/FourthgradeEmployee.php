<?php include 'application/views/home/inc/header.php';?>
<section class="content-full-width grey1">
<div class="container min-height py-4 bg-white">
	<div class="row">
		<div class="col-md-12">
            <div class="card">
               <div class="card-header hr-title dt-sc-hr-invisible-small curl">
               	<h3></h3>
         <div class="title-sep"></div>
               </div>
               <div class="card-body">
               	<div class="table-responsive">
               		<table class="table table-condensed" >
              
      					</table>
               	</div>
               </div>
            </div>
		</div>
	</div>
   </div>
</section>
<?php include 'application/views/home/inc/footer.php';?>

