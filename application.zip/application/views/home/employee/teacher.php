
<?php include 'application/views/home/inc/header.php';?> 
<link rel="stylesheet" href="<?= base_url() ?>template/css/magnific-popup.css" type="text/css" media="all" />
<script src="<?= base_url() ?>template/js/jquery.magnific-popup.min.js" type="text/javascript"></script>
<script src="<?= base_url() ?>template/js/masonry.min.js" type="text/javascript"></script>
<script src="https://unpkg.com/imagesloaded@4/imagesloaded.pkgd.min.js"></script>
<script src="https://unpkg.com/isotope-layout@3/dist/isotope.pkgd.min.js"></script>
<div class="full-width-section grey1">
   <div class="container py-4 min-height bg-white">
      <div class="row">
         <div class="col-md-12">
            <div class="card">
               <div class="card-header hr-title dt-sc-hr-invisible-small curl">
                  <h3><i class="fa fa-users" aria-hidden="true"></i> Teachers</h3>
         <div class="title-sep"> </div>
               </div>
               <div class="card-body">

                  <div class="row">
                     <?php foreach($teacher_list as $teacher){ ?>
                     <div class="col-md-3 mb-3">
                        <div class="teacher-box border">
                           <div class="teacher-img overflow-hidden">
                              <a  href="<?= base_url() ?>upload/teacher_image/<?= $teacher['teacher_image']?>" title="<?= $teacher['teacher_name']?>"><img class="img-fluid"src="<?= base_url() ?>upload/teacher_image/<?= $teacher['teacher_image']?>" width="100%" alt="<?= $teacher['teacher_name']?>"/></a>
                           </div>
                           <div class="teacher-des py-2">
                              <h5 class="teacher-name text-center"> <a href=""><?= $teacher['teacher_name']?></a></h5>
                              <h6  class="py-1 text-center"><?= $teacher['designation_name']?></h6>
                           </div>
                        </div>
                     </div>
                     <?php } ?> 
                  </div>
            </div>
         </div>
      </div>

      </div>
   </div>
</div>

<script>
   $(document).ready(function() {
   $('.teacher-img').magnificPopup({
      delegate: 'a',
      type: 'image',
      closeOnContentClick: false,
      closeBtnInside: false,
      mainClass: 'mfp-with-zoom mfp-img-mobile',
      image: {
         verticalFit: true,
         titleSrc: function(item) {
            return item.el.attr('title') + ' &middot; <a class="image-source-link" href="'+item.el.attr('data-source')+'" target="_blank"><?= $images['photo_caption']?></a>';
         }
      },
      gallery: {
         enabled: true
      },
      zoom: {
         enabled: true,
         duration: 300, 
         opener: function(element) {
            return element.find('img');
         }
      }
      
   });
});


</script>
<script>
  // external js: isotope.pkgd.js

// init Isotope
var $grid = $('.grid').isotope({
  itemSelector: '.element-item',
  layoutMode: 'fitRows'
});
// filter functions
var filterFns = {
  // show if number is greater than 50
  numberGreaterThan50: function() {
    var number = $(this).find('.number').text();
    return parseInt( number, 10 ) > 50;
  },
  // show if name ends with -ium
  ium: function() {
    var name = $(this).find('.name').text();
    return name.match( /ium$/ );
  }
};
// bind filter button click
$('.filters-button-group').on( 'click', 'button', function() {
  var filterValue = $( this ).attr('data-filter');
  // use filterFn if matches value
  filterValue = filterFns[ filterValue ] || filterValue;
  $grid.isotope({ filter: filterValue });
});
// change is-checked class on buttons
$('.button-group').each( function( i, buttonGroup ) {
  var $buttonGroup = $( buttonGroup );
  $buttonGroup.on( 'click', 'button', function() {
    $buttonGroup.find('.is-checked').removeClass('is-checked');
    $( this ).addClass('is-checked');
  });
});

</script>


<?php include 'application/views/home/inc/footer.php';?>

