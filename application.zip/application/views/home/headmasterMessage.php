<?php include 'application/views/home/inc/header.php';?>
<div class="full-width-section">
<div class="container my-4 min-height bg-white">
   <div class="row">
      <div class="col-md-12">
         <div class="card">
            <div class="card-header hr-title dt-sc-hr-invisible-small curl">
               <h2><i class="fa fa-comment" aria-hidden="true"></i>Headmaster's Message</h2>
      <div class="title-sep"> </div>
            </div>
            <div class="card-body">
               <div class="column first justify">
      <div class="column dt-sc-full" style="margin-right:20px;">
         <img class="img-thumbnail" width="150px" src="<?= base_url();?>upload/message/<?= $messages['image'];?>">
      </div>
      <div class="text-dark py-3">
         <?= $messages['message'];?>
      </div>
   </div>
            </div>
         </div>
      </div>
   </div>   
</div>
<?php include 'application/views/home/inc/footer.php';?>

