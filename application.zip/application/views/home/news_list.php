<?php include 'application/views/home/inc/header.php';?>
<link rel="stylesheet" href="<?= base_url() ?>template/css/magnific-popup.css" type="text/css" media="all" />
<script src="<?= base_url() ?>template/js/jquery.magnific-popup.min.js" type="text/javascript"></script>
<!-- Primary Starts -->
<section  class="content-full-width grey1">
      <div class="container min-height py-3 bg-white">
      <div class="row">
         <div class="col-md-12">
          <div class="section-title p-md-2 color-2 hr-title dt-sc-hr-invisible-small curl p-2 border">
            <h4 class="text-white"><i class="fa fa-calendar" aria-hidden="true"></i> <a class="text-white" href="">News & Events</a></h4>
            <div class="title-sep"> </div>
                  
          </div>
                 
                     <div class="news-gallery ">
                        <div class="row">
                   <?php foreach($news as $new) { ?>
                   <div class="col-md-3 mb-3">
                   <div class="news-main overflow-hidden border bg-white">
                      <div class="news-body">
                         <div class="image-box overflow-hidden">
                            <a href="<?= base_url();?>home/news_details/<?= $new['id'];?>">
                      <img class="img-fluid" src="<?= base_url()?>upload/news/<?= $new['image'];?>" alt="">
                      </a>
                    
                         </div>

                    <div class="news-wrpper p-2">
                      <div class="news-title">
                    <h4 class="py-1"><a class="" href="<?= base_url();?>home/news_details/<?= $new['id'];?>"><?= $new['title'];?></a></h4>

                    </div>
                    <div class="time">
                      <h6 class="py-1"><span class="news-icon"><i class="fa fa-clock-o" aria-hidden="true"></i></span> <?= date("d-M-y", strtotime($new['news_date']));?></h6>
                    </div>
                    <div class="time">
                      <h6 class="py-1"><span class="news-icon"><i class="fa fa-clock-o" aria-hidden="true"></i></span> <?= $new['news_time'];?></h6>
                    </div>
                    <div class="location">
                      <h6 class="py-1"><span class="news-icon"><i class="fa fa-map-marker" aria-hidden="true"></i></span> <?= $new['venue'];?></h6>
                    </div>
                    </div>
                      </div>

                   </div>
                    </div>

                    <?php } ?>

           
                  </div>
               </div>


               

         </div>  
      </div>
   </div>
</section>
<script>
$(document).ready(function() {
   $('.popup-youtube').magnificPopup({
      disableOn: 700,
      type: 'iframe',
      mainClass: 'mfp-fade',
      removalDelay: 160,
      preloader: false,

      fixedContentPos: false
   });
});
</script>

<?php include 'application/views/home/inc/footer.php';?>

