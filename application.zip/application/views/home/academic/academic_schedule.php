<?php include 'application/views/home/inc/header.php';?>
<link href="<?= base_url();?>template/plugins/fullcalendar/fullcalendar.css" rel="stylesheet">
<script src="<?= base_url();?>template/plugins/fullcalendar-1.6.2/fullcalendar/fullcalendar.min.js"></script>
<!-- Primary Starts -->
<section class="content-full-width grey1">
   <div class="container min-height py-4 bg-white">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
          <div class="card-header hr-title dt-sc-hr-invisible-small curl">
            <h3><i class="fa fa-list" aria-hidden="true"></i> Academic Schedule</h3>
         <div class="title-sep"></div>
          </div>
          <div class="card-body">
            <div class="dt-sc-tabs-frame-content">
         <div class="chart-box orange-bg">
            <div id="calendar" class="admin_panel_calander">
               <!-- Calander will be displyed here -->  
            </div>
            <!-- calander description start -->
            <div id="fullCalModal" class="modal fade">
               <div class="modal-dialog">
                  <div class="modal-content">
                     <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span> <span class="sr-only">close</span></button>
                        <h3 id="modalTitle" class="modal-title"></h3>
                     </div>
                     <div id="modalBody" class="modal-body"></div>
                  </div>
               </div>
            </div>
         </div>
         <!-- calander description end -->  
      </div>
          </div>
        </div>
      </div>
    </div>
    
   </div>
</section>
<?php include 'application/views/home/inc/footer.php';?>
<script>
   function CalendarInit() {
    "use strict";
   ;
       var date = new Date();
       var d = date.getDate();
       var m = date.getMonth();
       var y = date.getFullYear();
   
       var hdr = {};
   
       if ($(window).width() <= 767) {
           hdr = { left: 'prev,next', center: 'title', right: '' };
       } else {
           hdr = { left: 'prev,next', center: 'title', right: 'today,month' };
       }
   
       
   
   
       /* initialize the calendar
        -----------------------------------------------------------------*/
   
       $('#calendar').fullCalendar({
           header: hdr,
           buttonText: {
               prev: '<i class="fa fa-angle-double-left"></i>',
               next: '<i class="fa fa-angle-double-right"></i>'
           },
           editable: false,
      events: baseUrl + 'home/get_event',
   
           windowResize: function (event, ui) {
               $('#calendar').fullCalendar('render');
           },
      renderEvent: function (copiedEventObject){
      alert(copiedEventObject.start)
      },
      eventAfterRender: function (event, element) {
           $(element).tooltip({title:"Click me to see description.", container: "body"});
      },
      eventClick: function(event, element) {alert("a");
        $('#calendar').fullCalendar('renderEvent', event, true);
        $('#modalTitle').html(event.title);
               $('#modalBody').html(event.description);
        
               $('#fullCalModal').modal();
        
      }
      
       });
    //$(".fc-widget-content").css({"background-color": event.color});
   }
   // calendar initialize
   CalendarInit();
   
</script>

