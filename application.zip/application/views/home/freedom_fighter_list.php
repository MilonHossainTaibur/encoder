?php include 'application/views/home/inc/header.php';?>
<div class="full-width-section">
<div class="container  min-height">
      </div>
</div>
<?php include 'application/views/home/inc/footer.php';?>

