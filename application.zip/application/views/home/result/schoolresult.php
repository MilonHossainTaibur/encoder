<?php include 'application/views/home/inc/header.php';?>
<section id="primary" class="content-full-width grey1">
<div class="container py-4 min-height bg-white">
   <div class="row">
      <div class="col-md-12">
      	<div class="card">
      		<div class="card-header hr-title dt-sc-hr-invisible-small curl">
      			<h3><i class="fa fa-info" aria-hidden="true"></i>  Academic Result</h3>
         <div class="title-sep"> </div>
      			
      		</div>
      		<div class="card-body">
      			<div class="form-group row">
      				<div class="col-sm-3 col-md-3 col-12">
                        <label>Class <span>*</span></label>
						<select class="form-control" name="class_id" id="class_id" onchange="get_class_section_list(this.value);get_class_group_list(this.value);">
							<option value="">----Select Class----</option>
							<?php foreach($class_list as $cl){ ?>
							<option value="<?php echo $cl['class_id'];?>"><?php echo $cl['class_name'];?></option>   
							<?php } ?>
						</select>
                     </div>
                     <div class="col-sm-3 col-md-3 col-12">
                        <label>Section <span>*</span></label>
						<select class="form-control" name="section_id" id="section_id"/>
							<option value="">----Section----</option>
						</select>
                     </div>
                      <div class="col-sm-3 col-md-3 col-12">
					   <label>Group <span>*</span></label>
						<select class="form-control" name="group_id" id="group_id" >
							<option value="">-----Select Group-----</option>
						</select>
					</div>
					<?php if($shift_list): ?>
						<div class="col-sm-3 col-md-3 col-12">
							<label>Shift <span style="color:red;">*</span></label>
							<select class="form-control" name="shift_id" id="shift_id" >
								<option value="">-----Select Shift-----</option>
								<?php foreach($shift_list as $shl){ ?>
								<option value="<?php echo $shl['shift_id'];?>"><?php echo $shl['shift_name'];?></option>
								<?php    } ?>
							</select>
						</div>
						<?php else: ?>
								<input type="hidden" id="shift_id" value="0" />
						<?php endif; ?>

      			</div>
      			<div class="form-group row">
      				<div class="col-sm-4 col-md-4 col-12">
                        <label>Session <span style="color:red;">*</span></label>
                        <select class="form-control" name="session_id" id="session_id" onChange="get_student_list_marksheet(this.value)">
							<option value="">-----Select Session-----</option>
							<?php foreach($session_list as $sl){ ?>
							<option value="<?= $sl['session_id'];?>"><?= $sl['session_name'];?></option>
							<?php } ?>
						</select>
                     </div>
                      <div class="col-sm-4 col-md-4 col-12">
                        <label>Student ID <span style="color:red;">*</span></label>
                        <select name="student_id" required id="student_id" class="form-control">
							<option value="">-----Select student-----</option>
						</select>
                        <div id="validation_stu" class="validation_js" style="display: none;">Please select a student.</div>
                     </div>
                     <div class="col-sm-4 col-md-4 col-12">
                        <label>Term Name <span style="color:red;">*</span></label>
                        <select class="form-control" required name="term_id" id="term_id" onchange="term_marks_json()">
							<option value="">Select</option>
							<?php foreach($term_list as $tl){ ?>
							<option value="<?php echo $tl['term_id'];?>"><?php echo $tl['term'];?></option>
							<?php } ?>
						</select>
                     </div>

      			</div>

      			<div class="form-group row">
      				<div class="col-md-12">
      					<button class="button btn btn-info float-right" onclick="mark_sheet_json()" type="button"> Result View </button>
      				</div>
      			</div>
      		</div>
      	</div>
         <div class="card">		
            <div class="card-body">
				<div id="display">
                  
				</div>
            </div>
         </div>
      </div>
   </div>
</div>
</section>
<?php include 'application/views/home/inc/footer.php';?>
<!--Check department name based on class id-->
<script>
	$("#search").keyup(function(){
		var str			= $("#search").val();
		var term_id 	= $('#s_term_id').val();
		var term_name 	= $('#s_term_id option:selected').text();
		
		if(!term_id)
		{
			$('#s_term_id').after("<div id='validation_ct' class='validation_js'>Please select a term.</div>")
				$('#validation_ct').delay(3000).hide('slow');
				return;
			
		}
		
		if(str == "") {
			$( "#display" ).html("<b>Students will be listed here...</b>");//$('#display').html(mainContent);
		}else {
			$( "#display" ).html("");
			if (str.length > 6){
				$.ajax({ 
				url: baseUrl+'home/mark_sheet_json',
				data:
					{                  
						'student_id':str,
						'search_type':'id_wise',
						'term_id':term_id,
						'term_name':term_name
					}, 
					dataType: 'json',					
					beforeSend: function() {
						// setting a timeout
						$('.panel-body').hide();
						$('.panel-status').html('<h3>Please Wait!  Processing... </h3>');
					},
					success: function(data)
					{
						result                = ''+data['result']+'';
						mainContent           = ''+data['mainContent']+'';

						if(result == 'success')
						{            
							$('.panel-status').html('');
							$('.panel-body').show();
							$('#display').html(mainContent);     
						}                
					},
					error: function(xhr) { // if error occured
						$('.panel-status').html('Student not found!!!');
						$('.panel-body').show();
					}
				});
				return false; // keeps the page from not refreshing 
			}
		}
	});



function get_class_section_list(class_id)
   {
      $.ajax({
       type: "POST",
       url: baseUrl + 'home/section_list_ajax',
       data:
       {
           'class_id':class_id
       }, 
       success: function(html_data)
       {
           if (html_data != '')
           {
               $('#section_id').html(html_data);
           }
       }
       });
   }
   
	function get_class_group_list(class_id)
	{
	   $.ajax({
		type: "POST",
		url: baseUrl + 'home/group_list_ajax',
		data:
		{
			'class_id':class_id
		}, 
		success: function(html_data)
		{
			if (html_data != '')
			{
				$('#group_id').html(html_data);
			}
		}
		});  
	}
	
   function get_student_list_marksheet(session_id){
		var class_id = $('#class_id').val();
		var section_id = $('#section_id').val();
		var group_id = $('#group_id').val();
		var shift_id = $('#shift_id').val();
	   $.ajax({
		type: "POST",
		url: baseUrl + 'home/get_student_list_marksheet',
		data:
		{
			'class_id':class_id,
			'section_id':section_id,
			'group_id':group_id,
			'shift_id':shift_id,
			'session_id':session_id
		}, 
		success: function(html_data)
		{
			if (html_data != '')
			{
				$('#student_id').html(html_data);
			}
		}
		});  
	}
	function mark_sheet_json()
		{
			var class_id = $('#class_id').val();
			var class_short_form = $('#class_id :selected').attr('id');
			var section_id = $('#section_id').val();
			var group_id = $('#group_id').val();
			var shift_id = $('#shift_id').val();
			var session_id = $('#session_id').val();
			var student_id = $('#student_id').val();
			var term_id = $('#term_id').val();
			var term_name = $('#term_id option:selected').text();
			var session = $('#session_id option:selected').text();
			
			$('.panel-status').html('');
			//alert(class_id+group_id);
			
			if(!class_id)
			{
				$('#class_id').after("<div id='validation_class' class='validation_js'>Please select a class.</div>")
					$('#validation_class').delay(3000).hide('slow');
					return;
				
			}
			if(!section_id)
			{
				$('#section_id').after("<div id='validation_sec' class='validation_js'>Please select a section.</div>")
					$('#validation_sec').delay(3000).hide('slow');
					return;
				
			}
			if(!group_id)
			{
				$('#group_id').after("<div id='validation_grp' class='validation_js'>Please select a group.</div>")
					$('#validation_grp').delay(3000).hide('slow');
					return;
				
			}
			if(!shift_id)
			{
				$('#shift_id').after("<div id='validation_shift' class='validation_js'>Please select a shift.</div>")
					$('#validation_shift').delay(3000).hide('slow');
					return;
				
			}
			if(!session_id)
			{
				$('#session_id').after("<div id='validation_ses' class='validation_js'>Please select a session.</div>")
					$('#validation_ses').delay(3000).hide('slow');
					return;
				
			}
			if(!student_id)
			{
				$('#student_id').after("<div id='validation_stu' class='validation_js'>Please select a student.</div>")
					$('#validation_stu').delay(3000).hide('slow');
					return;
				
			}
			if(!term_id)
			{
				$('#term_id').after("<div id='validation_ct' class='validation_js'>Please select a term.</div>")
					$('#validation_ct').delay(3000).hide('slow');
					return;
				
			}
		
			$.ajax({ 
			url: baseUrl+'home/mark_sheet_json',
			data:
				{                  
					'class_id':class_id,
					'class_short_form':class_short_form,
					'section_id':section_id,
					'group_id':group_id,
					'shift_id':shift_id,
					'session_id':session_id,
					'student_id':student_id,
					'term_id':term_id,
					'term_name':term_name,
					'session':session
				}, 
				dataType: 'json',
				success: function(data)
				{
					result                = ''+data['result']+'';
					mainContent           = ''+data['mainContent']+'';
	
					if(result == 'success')
					{            
						$('#display').html(mainContent);     
					}                
				}
			});
		}
		
		function printPageArea(areaID){
		var printContent = document.getElementById(areaID);
		var WinPrint = window.open('', '', 'width=900,height=650');
		WinPrint.document.write('<link rel="stylesheet" type="text/css" href="<?= base_url();?>template/bootstrap-print/bootstrap-print.min.css" media="print" />')
		WinPrint.document.write('<style type="text/css" media="print"> @page { size: landscape; font-size:12px; } table{font-size:12px;} table td{padding:3px;} .print_button{ display:none;} </style>')
		WinPrint.document.write(printContent.innerHTML);
		WinPrint.document.close();
		WinPrint.focus();
		WinPrint.print();
		WinPrint.close();
	}
</script> 



