<?php include 'application/views/home/inc/header.php';?>
<div class="full-width-section grey1">
   <div class="container min-height py-4 bg-white">
      <div class="card">
         <div class="card-header hr-title dt-sc-hr-invisible-small curl">
            <h3><i class="fa fa-list" aria-hidden="true"></i> SSC Result</h3>
         <div class="title-sep"></div>
         </div>
         <div class="card-body">
            <div class="table-responsive">
         <table class="table table-bordered table-striped" width="100%">
            <thead>
               <tr>
                  <th colspan="8"></th>
                  <th colspan="3">GPA</th>
               </tr>
               <tr>
                  <th rowspan="2">Year</th>
                  <th colspan="3">SSC Examinee</th>
                  <th colspan="3"> Pass</th>
                  <th>Percentage</th>
                  <th colspan="3">GPA 5</th>
               </tr>
            </thead>
            <tbody>
               <tr>
                  <td></td>
                  <td>Boy</td>
                  <td>Girl</td>
                  <td>Total</td>
                  <td>Boy</td>
                  <td>Girl</td>
                  <td>Total</td>
                  <td></td>
                  <td>Boy</td>
                  <td>Girl</td>
                  <td>Total</td>
               </tr>
               <tr>
                  <td>2016</td>
                  <td>171</td>
                  <td>164</td>
                  <td>355</td>
                  <td>161</td>
                  <td>151</td>
                  <td>312</td>
                  <td>93%</td>
                  <td></td>
                  <td></td>
                  <td>29</td>
               </tr>
               <tr>
                  <td>2015</td>
                  <td>162</td>
                  <td>131</td>
                  <td>293</td>
                  <td>149</td>
                  <td>115</td>
                  <td>264</td>
                  <td>90%</td>
                  <td></td>
                  <td></td>
                  <td>21</td>
               </tr>
               <tr>
                  <td>2014</td>
                  <td>129</td>
                  <td>123</td>
                  <td>252</td>
                  <td>124</td>
                  <td>121</td>
                  <td>245</td>
                  <td>97%</td>
                  <td></td>
                  <td></td>
                  <td>53</td>
               </tr>
               <tr>
                  <td>2013</td>
                  <td>84</td>
                  <td>81</td>
                  <td>165</td>
                  <td>82</td>
                  <td>80</td>
                  <td>162</td>
                  <td>98%</td>
                  <td></td>
                  <td></td>
                  <td>14</td>
               </tr>
               <tr>
               <tr>
                  <td>2012</td>
                  <td>103</td>
                  <td>75</td>
                  <td>178</td>
                  <td>103</td>
                  <td>74</td>
                  <td>177</td>
                  <td>99%</td>
                  <td></td>
                  <td></td>
                  <td>26</td>
               </tr>
               <tr>
                  <td>2011</td>
                  <td>53</td>
                  <td>49</td>
                  <td>108</td>
                  <td>58</td>
                  <td>49</td>
                  <td>107</td>
                  <td>99%</td>
                  <td></td>
                  <td></td>
                  <td>36</td>
               </tr>
               <tr>
                  <td>2010</td>
                  <td>62</td>
                  <td>69</td>
                  <td>131</td>
                  <td>56</td>
                  <td>62</td>
                  <td>118</td>
                  <td>90</td>
                  <td></td>
                  <td></td>
                  <td>11</td>
               </tr>
               <tfoot></tfoot>
            </tbody>
         </table>
         <br>
      </div>
         </div>
      </div>
      
   </div>
</div>

<?php include 'application/views/home/inc/footer.php';?>

