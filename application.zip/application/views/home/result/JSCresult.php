<?php include 'application/views/home/inc/header.php';?>
<div class="full-width-section grey1">
   <div class="container min-height py-4 bg-white">
      <div class="row">
         <div class="col-md-12">
            

            <div class="card">
               <div class="card-header hr-title dt-sc-hr-invisible-small curl">
                  <h3><i class="fa fa-list" aria-hidden="true"></i> JSC Result</h3>
         <div class="title-sep"></div>
               </div>
               <div class="card-body">
                  <div class="table-responsive">
         <table class="table table-bordered table-striped">
            <thead>
               <tr>
                  <th colspan="7"></th>
                  <th colspan="5">Number of Scholarships</th>
               </tr>
               <tr>
                  <th rowspan="2">Year</th>
                  <th colspan="2"> Number of Examinee</th>
                  <th colspan="2"> Pass</th>
                  <th>Total </th>
                  <th>Percentage</th>
                  <th colspan="2">Talentpool</th>
                  <th colspan="2">General</th>
                  <th>Total</th>
               </tr>
            </thead>
            <tbody>
               <tr>
                  <td></td>
                  <td>Boys</td>
                  <td>Girls</td>
                  <td>Boys</td>
                  <td>Girls</td>
                  <td></td>
                  <td></td>
                  <!--td colspan="2"></td-->
                  <td>Boys</td>
                  <td>Girls</td>
                  <td>Boys</td>
                  <td>Girls</td>
                  <td></td>
               </tr>
               <tr>
                  <td>2016</td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
                  <td></td>
               </tr>
               <tr>
                  <td>2015</td>
                  <td>168</td>
                  <td>145</td>
                  <td>161</td>
                  <td>142</td>
                  <td>303</td>
                  <td>98%</td>
                  <td>01</td>
                  <td>03</td>
                  <td>08</td>
                  <td>06</td>
                  <td>18</td>
               </tr>
               <tr>
                  <td>2014</td>
                  <td>197</td>
                  <td>190</td>
                  <td>171</td>
                  <td>180</td>
                  <td>351</td>
                  <td>99%</td>
                  <td>02</td>
                  <td>08</td>
                  <td>03</td>
                  <td>04</td>
                  <td>17</td>
               </tr>
               <tr>
                  <td>2013</td>
                  <td>195</td>
                  <td>163</td>
                  <td>188</td>
                  <td>155</td>
                  <td>343</td>
                  <td>95%</td>
                  <td>01</td>
                  <td>02</td>
                  <td>08</td>
                  <td>08</td>
                  <td>19</td>
               </tr>
               <tr>
               <tr>
                  <td>2012</td>
                  <td>135</td>
                  <td>128</td>
                  <td>133</td>
                  <td>124</td>
                  <td>257</td>
                  <td>98%</td>
                  <td>02</td>
                  <td>12</td>
                  <td>01</td>
                  <td>04</td>
                  <td>09</td>
               </tr>
               <tr>
                  <td>2011</td>
                  <td>115</td>
                  <td>125</td>
                  <td>115</td>
                  <td>125</td>
                  <td>240</td>
                  <td>100%</td>
                  <td>05</td>
                  <td>14</td>
                  <td>14</td>
                  <td>07</td>
                  <td>40</td>
               </tr>
               <tr>
                  <td>2010</td>
                  <td>91</td>
                  <td>103</td>
                  <td>91</td>
                  <td>81</td>
                  <td>172</td>
                  <td>89.11%</td>
                  <td>05</td>
                  <td>04</td>
                  <td>03</td>
                  <td>10</td>
                  <td>22</td>
               </tr>
            </tbody>
         </table>
         <br>
      </div>
               </div>
            </div>
         </div>
      </div>

      
   </div>

</div>

<?php include 'application/views/home/inc/footer.php';?>
