<div class="col-md-8">
	<div class="row">
		<div class="col-md-12">
			<div class="card">
				<div class="card-header hr-title dt-sc-hr-invisible-small curl" style="margin-bottom:0px">
					<h3><i class="fa fa-info" aria-hidden="true"></i>  Admission Result</h3>
					<div class="title-sep"></div>					
				</div>
				<div class="card-body">
					<div class="form-group row">
						<div class="col-sm-3 col-md-3">
							<label>Class <span style="color:red;">*</span></label>
							<select class="form-control" name="class_id" id="class_id">
								<option value="">-----Select Class-----</option>
								<?php foreach($class_list as $cl){ ?>
								<option value="<?= $cl['class_id'];?>" id="<?= $cl['class_short_form'];?>"><?php echo $cl['class_name'];?></option>
								<?php } ?>
							</select>
						</div>
						<div class="col-sm-3 col-md-3">
							<label>Year <span style="color:red;">*</span></label>
							<select class="form-control" name="year_id" id="year_id">
								<option value="">----Select Year----</option>
								<?php foreach($stusession_id as $cl){ ?>
								<option value="<?= $cl['session_name'];?>" ><?= $cl['session_name'];?></option>
								<?php } ?>
							</select>
						</div>
					</div>
					<div class="form-group row">
						<div class="col-md-12">
							<button class="button btn btn-info float-right" onclick="student_class_roll_json()" type="button"> Result View </button>
						</div>
					</div>
				</div>
			</div>
			<div class="card">		
				<div class="card-body">
					<div id="display">
					  
					</div>
				</div>
			</div>
		</div>
	</div>
	<!--row-->
	<script>
	function student_class_roll_json(){
		$('#display').html('');
		var class_id = $('#class_id').val();
		var class_name = $('#class_id :selected').text();
		var year_id = $('#year_id').val();
		var year = $('#year_id option:selected').text();

		if(!class_id)
		{
			$('#class_id').after("<div id='validation_class' class='validation_js'>Please select a class.</div>")
				$('#validation_class').delay(3000).hide('slow');
				return;

		}
		if(!year_id)
		{
			$('#year_id').after("<div id='validation_year_id' class='validation_js'>Please select a year.</div>")
				$('#validation_year_id').delay(3000).hide('slow');
				return;

		}

		$.ajax({
		url: baseUrl+'home/admission_result_json',
		data:
			{
				'class_id':class_id,
				'class_name':class_name,
				'year_id':year_id,
				'year':year
			},
			dataType: 'json',
			success: function(data)
			{
				result                = ''+data['result']+'';
				mainContent           = ''+data['mainContent']+'';

				if(result == 'success')
				{
					$('#display').html(mainContent);
				}
			}
		});
	}

	function PrintElem(elem)
	{
		var mywindow = window.open('', 'PRINT', 'width=650,height=900');

		mywindow.document.write('<html><head><title>' + document.title  + '</title>');
		mywindow.document.write('</head><body >');
		//mywindow.document.write('<span>' + document.title  + '</span>');
		mywindow.document.write(document.getElementById(elem).innerHTML);
		mywindow.document.write('</body></html>');

		mywindow.document.close(); // necessary for IE >= 10
		mywindow.focus(); // necessary for IE >= 10*/

		mywindow.print();
		mywindow.close();

		return true;
	}
	</script>
</div>