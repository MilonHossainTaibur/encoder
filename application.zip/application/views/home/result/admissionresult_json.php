<?php
	if($details['class_id'] == 1){$c_name1='Seven';$c_value1='2';$c_name2='Six';$c_value2='1';}
	else if($details['class_id'] == 2){$c_name1='Eight';$c_value1='3';$c_name2='Seven';$c_value2='2';}
	else if($details['class_id'] == 3){$c_name1='Nine';$c_value1='4';$c_name2='Eight';$c_value2='3';}
	else if($details['class_id'] == 4){$c_name1='Ten';$c_value1='5';$c_name2='Nine';$c_value2='4';}
?>
<div class="table-responsive" id="print_area">

	<div class="container" style="text-align: center;width: 100%;">
		<div class="tabu-header">
			<h4 style="font-weight: 700;font-size: 25px;"><?= $school_info[0]['school_name'] ?></h4>
			<h5 style="font-size: 18px;"><?= 'Admission Result'; ?></h5>
			<h5 style="font-size: 18px;"><?= $details['class_name']; ?> - <?= $details['exam_year']; ?></h5>
			<h5 style="margin-bottom: 10px!important;font-size: 18px;">Total Student: <?php echo count($student_list);?></h5>
		</div>
	</div>

	<style>
		table {
			border-collapse: collapse;
		}

		table, td{
			border: 1px solid black;
		}

		th {
			text-transform: uppercase;
		}
		.no-border{
			border:0!important;
		}
		.center{
			text-align:center;}
		.tb tr td {
			height: 30px;
		}
		.tabu-header h2,.tabu-header h3,.tabu-header h4,.tabu-header h5{
			padding: 0px!important;
			margin-top: 0px!important;
			margin-bottom: 0px!important;
		}
		span.fail{
			width:100%;
			border-bottom:5px solid #CD0000;
			color:#000;
		}
	</style>
	<style type="text/css">
		@page
		{
			size: portrait;
		}
		@media print{
			@page {
				size: portrait;
			}
		}
		@media print{
			.class-name{
			@page{
				size:portrait;
			}
		}
		}
		table thead tr>th{
			text-align: center;
			/*font-size: 15px;*/
			font-weight: 600;
			border: 1px solid black;
			padding: 10px 0;
			color: #fff;
			background-color:#8F3A84;
		}
		table  tr>td{
			font-weight: 400;
			/*font-size: 15px;*/
		}
	</style>
	<style type="text/css" media="print">
		@page { size: portrait; }
		table tr>td{
			border-color: #95a5a6;
		}
		table thead tr{
			text-align: center;
			font-size: 14px!important;
			font-weight: 500;
			border:1px solid #95a5a6;
			border-color: #95a5a6;
		}
		table thead tr>th{

			border:1px solid #95a5a6;

		}
		table  tr>td{
			font-weight: 400;
			font-size: 15px;
		}
		.hid{
			display: none;
			visibility: hidden;
		}
	</style>
	<table width="100%">
		<thead>
		<tr>
			<th>Merit</th>
			<th>Exam Roll</th>
			<th style="min-width: 140px">Applicant's Name</th>
			<th>Father's Name</th>
			<th>Mark</th>
			<th>Result</th>
		</tr>
		</thead>
		<tbody class="center tb" >
		<?php
		usort($student_list, function($a,$b){	$c = $b['mark'] <=> $a['mark']; $c.=$a['exam_roll'] - $b['exam_roll']; return $c;});
		//print_r($student_list);exit;
		foreach($student_list as $i=>$outval){
			?>
			<tr>
				<td><?php print_r($i+1);?></td>
				<td><?php print_r($outval['exam_roll']);?></td>
				<td><?php print_r(ucwords($outval['applicant_name']));?></td>
				<td><?php print_r(ucwords($outval['applicant_father']));?></td>
				<td><?php print_r(ucwords($outval['mark']));?></td>
				<td><?php if($outval['mark']>=33){echo 'Pass';}else{echo 'Fail';}?></td>
			</tr>
		<?php }?>
		</tbody>
	</table>
	<div class="print_button">
		<br/>
		<input type="button" class="button btn btn-info float-right hid" onClick="PrintElem('print_area')" value="Print"/>
	</div>
</div>
