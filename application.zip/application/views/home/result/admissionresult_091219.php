<?php include 'application/views/home/inc/header.php';?>
<style>
    .table > tbody > tr > td, .table > tbody > tr > th, .table > tfoot > tr > td, .table > tfoot > tr > th, .table > thead > tr > td, .table > thead > tr > th {
        padding-left: 5px;
        vertical-align: middle;
        font-size:14px;
    }
    .table {
        border-collapse: collapse;
        border-spacing: 0;
        width: 100%;
        max-width: 100%;
        margin-bottom: 0px;
    }
    td, th {
        border: 1px solid #000;
        padding: 5px;
    }
    .table {
        border-collapse: collapse;
        border-spacing: 0;
        width: 100%;
        max-width: 100%;
        margin-bottom: 0px;
    }
    .no-border td {
        border: 0px!important;
    }

    .uppercase {
        text-transform: uppercase;
    }
    .name {
        font-size: 25px;
        padding-bottom: 10px;
    }

    .center {
        text-align: center!important;
    }
    .left {
        text-align: left!important;
    }
    .right{
        text-align: right!important;
    }
    .student-info {
        width: 60%;
        float: left;
        min-height: 100px;
        clear: both;
    }
    .remark span{
        position: absolute;
        bottom: -2px;
    }
    .gpa-info {
        width: 40%;
        float: right;
    }
    .mark-col-1,.mark-col-3,.mark-col-2 {
        float: left;
        overflow: hidden;
        border-right: 1px dotted #000;
        min-height:80px;
    }
    .mark-col-3{
        border-right: 0px;
    }
    .mark-col-4{
        float: left;
        overflow: hidden;
        min-height:80px;
    }

    .transcript-title {
        /*background-color: rgba(24, 137, 203, .5);*/
        font-weight: 600;
        font-size: 20px;
        border-bottom: 2px solid #000;
        width: 270px;

    }
    .info p {
        padding-bottom: 5px;
    }
    .col-1 p,
    .col-2 p,
    .col-3 p,
    .col-4 p {
        border-top:2px solid #000;
        margin-top: 90px;
        padding-top: 5px;
        text-align: center;

    }

    .transcript-bottom {
        margin-top: 5px;
    }

    .col-1 {
        width: 18%;
        float: left;
        min-height: 110px;
        margin-left: 1%;
        margin-right: 1%;
    }

    .col-2 {
        width: 18%;
        float: left;
        min-height: 110px;
        margin-left: 1%;
        margin-right: 1%;
    }

    .col-4 {
        width: 18%;
        float: right;
        height: 110px;
        margin-left: 1%;
        margin-right: 1%;
    }

    .col-3 {
        width: 36%;
        height: 110px;
        margin-left: 2%;
        margin-right: 2%;
    }

    .col-1,
    .col-2,
    .col-3,
    .col-4 {
        display: inline-block;
        position: relative;
    }

    .gpa-info {
        float: right;
    }
    .info {
        width: 40%;
        float: left;
    }

    .student-info {
        width: 60%;
        min-height: 100px;
        clear: both;

        position:relative;
    }
    @page {
        size:  21.0cm 29.7cm ;
    }
    .school-info{
        position:relative;
        text-align:center;}

    .logo {
        position: absolute;
        top: 10px;

    }
    .student-photo {
    position: absolute;
    right: 0;
    top: 30px;
}
    .logo img {
        width: 100px;
        height: 100px;
        
    }
    .student-photo img {
        width: 100px;
        height: 110px;
    }
    .main-content {
        float:left;
        width: 100%;
    }
    .print_break{
        page-break-after: always;
    }


</style>
<section id="primary" class="content-full-width grey1">
<div class="container py-4 min-height">
	<div class="row">
		<div class="col-md-12">
			
		</div>
	</div>
   <div class="row">
      <div class="col-md-12">
         <div class="card widget-main">
    		
			<div class="card-header panel-status hr-title dt-sc-hr-invisible-small curl">
				<div class="">
         <h3><i class="fa fa-info" aria-hidden="true"></i>   Admission Result</h3>
         <div class="title-sep"> </div>
      </div>
			</div>
			<div class="card-body" id="display">			
				<div class="main-content">
						<div class="school-info pb-2" style="width:100%">

							<div class="info" style="width:100%;">
								<h2 style="text-transform:uppercase;line-height:20px; margin:0 auto;font-weight: 600;text-align:center;"><?= $school_info['school_name'];?></h2>
								<h3 style="line-height:27px; margin:0 auto;font-size: 18px;font-weight: 500;text-align:center;">
									<?= $school_info['address'];?>, <?= $school_info['district'];?>.</h3>
								<h4 style="line-height:22px; margin:0 auto;font-size: 18px;font-weight: 400;text-align:center;">E-mail:
									<?= $school_info['email'];?></h4>
								<h5 style="line-height:20px; margin:0 auto;font-size: 16px;font-weight: 400;text-align:center;"><?= $school_info['website'];?></h5>
								<h2 class="transcript-title" style="margin:0 auto;line-height:25px;padding-bottom: 8px;text-align:center;">Admission Result</h2>
							</div>
							<div class="logo" style="">
								<img src="<?= base_url(); ?>upload/institute_logo/<?= $school_info['logo'];?>" alt="" height="100" width="100" style="position:absolute;left:20%;top:10px;z-index:9999;" />
							</div>
							<?php if(!isset($public_flag)){
								if(!empty($student_info['student_image'])){$std_img = 'upload/student_image/'.$student_info['student_image'];}
								else{$std_img = 'template/assets/images/no_image.png';}
								?>
								<div class="student-photo" style="">
									<img style="border: 2px solid gray;" src="<?php echo base_url().$std_img;?>" alt="Student Photo">
								</div>
							<?php }?>
						</div>
			
					<table class="table table-striped table-bordered" cellspacing="0" border="1" width="100%">
						<thead>
							<tr>
								<th class="center" style="width:10%;text-align:center;">Serial</th>
								<th class="center" style="width:10%;text-align:center;">Exam Roll No</th>
								<th style="max-width:35px;text-align:center;" class="center">Full Marks</th>
								<th style="max-width:35px;text-align:center;" class="center">Pass Marks</th>
								<th class="center" style="text-align:center;">Total</th>
								<th style="max-width:40px;;text-align:center;" class="center">Status</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach($results as $k=>$sl){?>
							<tr>
								<td class="center" style="text-align:center;"><?php echo $k+1;?></td>
								<td class="center" style="text-align:center;"><?php echo $sl['exam_roll'];?></td>
								<td class="center" style="text-align:center;"><?php echo $sl['total_mark'];?></td>
								<td class="center" style="text-align:center;"><?php echo $sl['pass_mark'];?></td>
								<td class="center" style="text-align:center;"><?php echo $sl['get_mark'];?></td>
								<td class="center" style="text-align:center;"><?php if($sl['get_mark']>=$sl['pass_mark']){ echo 'Pass';}else{echo 'Fail';}?></td>
							</tr>
							<?php }?>
							
						</tbody>
					</table>
					<hr>
					<div class="print_button pull-left padding" style="float:left; width: 100%">
    <input type="button " class="btn btn-primary " onClick="printPageArea('display') " value="Print"/>
    <br/>
</div>
					
					
				</div>
            </div>
			
         </div>
      </div>
   </div>
</div>
</section>
<?php include 'application/views/home/inc/footer.php';?>
<!--Check department name based on class id-->
<script>
	$("#search").keyup(function(){
		var str			= $("#search").val();
		var term_id 	= $('#s_term_id').val();
		var term_name 	= $('#s_term_id option:selected').text();
		
		if(!term_id)
		{
			$('#s_term_id').after("<div id='validation_ct' class='validation_js'>Please select a term.</div>")
				$('#validation_ct').delay(3000).hide('slow');
				return;
			
		}
		
		if(str == "") {
			$( "#display" ).html("<b>Students will be listed here...</b>");//$('#display').html(mainContent);
		}else {
			$( "#display" ).html("");
			if (str.length > 6){
				$.ajax({ 
				url: baseUrl+'home/mark_sheet_json',
				data:
					{                  
						'student_id':str,
						'search_type':'id_wise',
						'term_id':term_id,
						'term_name':term_name
					}, 
					dataType: 'json',					
					beforeSend: function() {
						// setting a timeout
						$('.panel-body').hide();
						$('.panel-status').html('<h3>Please Wait!  Processing... </h3>');
					},
					success: function(data)
					{
						result                = ''+data['result']+'';
						mainContent           = ''+data['mainContent']+'';

						if(result == 'success')
						{            
							$('.panel-status').html('');
							$('.panel-body').show();
							$('#display').html(mainContent);     
						}                
					},
					error: function(xhr) { // if error occured
						$('.panel-status').html('Student not found!!!');
						$('.panel-body').show();
					}
				});
				return false; // keeps the page from not refreshing 
			}
		}
	});



function get_class_section_list(class_id)
   {
      $.ajax({
       type: "POST",
       url: baseUrl + 'home/section_list_ajax',
       data:
       {
           'class_id':class_id
       }, 
       success: function(html_data)
       {
           if (html_data != '')
           {
               $('#section_id').html(html_data);
           }
       }
       });
   }
   
	function get_class_group_list(class_id)
	{
	   $.ajax({
		type: "POST",
		url: baseUrl + 'home/group_list_ajax',
		data:
		{
			'class_id':class_id
		}, 
		success: function(html_data)
		{
			if (html_data != '')
			{
				$('#group_id').html(html_data);
			}
		}
		});  
	}
	
   function get_student_list_marksheet(session_id){
		var class_id = $('#class_id').val();
		var section_id = $('#section_id').val();
		var group_id = $('#group_id').val();
		var shift_id = $('#shift_id').val();
	   $.ajax({
		type: "POST",
		url: baseUrl + 'home/get_student_list_marksheet',
		data:
		{
			'class_id':class_id,
			'section_id':section_id,
			'group_id':group_id,
			'shift_id':shift_id,
			'session_id':session_id
		}, 
		success: function(html_data)
		{
			if (html_data != '')
			{
				$('#student_id').html(html_data);
			}
		}
		});  
	}
	function mark_sheet_json()
		{
			var class_id = $('#class_id').val();
			var class_short_form = $('#class_id :selected').attr('id');
			var section_id = $('#section_id').val();
			var group_id = $('#group_id').val();
			var shift_id = $('#shift_id').val();
			var session_id = $('#session_id').val();
			var student_id = $('#student_id').val();
			var term_id = $('#term_id').val();
			var term_name = $('#term_id option:selected').text();
			var session = $('#session_id option:selected').text();
			
			$('.panel-status').html('');
			//alert(class_id+group_id);
			
			if(!class_id)
			{
				$('#class_id').after("<div id='validation_class' class='validation_js'>Please select a class.</div>")
					$('#validation_class').delay(3000).hide('slow');
					return;
				
			}
			if(!section_id)
			{
				$('#section_id').after("<div id='validation_sec' class='validation_js'>Please select a section.</div>")
					$('#validation_sec').delay(3000).hide('slow');
					return;
				
			}
			if(!group_id)
			{
				$('#group_id').after("<div id='validation_grp' class='validation_js'>Please select a group.</div>")
					$('#validation_grp').delay(3000).hide('slow');
					return;
				
			}
			if(!shift_id)
			{
				$('#shift_id').after("<div id='validation_shift' class='validation_js'>Please select a shift.</div>")
					$('#validation_shift').delay(3000).hide('slow');
					return;
				
			}
			if(!session_id)
			{
				$('#session_id').after("<div id='validation_ses' class='validation_js'>Please select a session.</div>")
					$('#validation_ses').delay(3000).hide('slow');
					return;
				
			}
			if(!student_id)
			{
				$('#student_id').after("<div id='validation_stu' class='validation_js'>Please select a student.</div>")
					$('#validation_stu').delay(3000).hide('slow');
					return;
				
			}
			if(!term_id)
			{
				$('#term_id').after("<div id='validation_ct' class='validation_js'>Please select a term.</div>")
					$('#validation_ct').delay(3000).hide('slow');
					return;
				
			}
		
			$.ajax({ 
			url: baseUrl+'home/mark_sheet_json',
			data:
				{                  
					'class_id':class_id,
					'class_short_form':class_short_form,
					'section_id':section_id,
					'group_id':group_id,
					'shift_id':shift_id,
					'session_id':session_id,
					'student_id':student_id,
					'term_id':term_id,
					'term_name':term_name,
					'session':session
				}, 
				dataType: 'json',
				success: function(data)
				{
					result                = ''+data['result']+'';
					mainContent           = ''+data['mainContent']+'';
	
					if(result == 'success')
					{            
						$('#display').html(mainContent);     
					}                
				}
			});
		}
		
		function printPageArea(areaID){
		var printContent = document.getElementById(areaID);
		var WinPrint = window.open('', '', 'width=900,height=650');
		WinPrint.document.write('<link rel="stylesheet" type="text/css" href="<?= base_url();?>template/bootstrap-print/bootstrap-print.min.css" media="print" />')
		WinPrint.document.write('<style type="text/css" media="print"> @page { size: landscape; font-size:12px; } table{font-size:12px;} table td{padding:3px;} .print_button{ display:none;} </style>')
		WinPrint.document.write(printContent.innerHTML);
		WinPrint.document.close();
		WinPrint.focus();
		WinPrint.print();
		WinPrint.close();
	}
</script> 



