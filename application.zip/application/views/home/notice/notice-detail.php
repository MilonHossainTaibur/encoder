<?php include 'application/views/home/inc/header.php';?>
<section  class="content-full-width grey1">

   <div class="container py-4 min-height bg-white">
      <div class="row">
         <div class="col-md-12">
            <div class="card">
               <div class="card-header hr-title dt-sc-hr-invisible-small curl">
      <h2><i class="fa fa-comment" aria-hidden="true"></i>Notice</h2>
      <div class="title-sep"> </div>
   </div>
   <div class="card-body">
      <div class="notice-title">
        <h5><span class="fa fa-tag"> <?= $notice_info['notice_heading']; ?> </span> <span class="pull-right"> Date: <?= $notice_info['publish_date']; ?></span></h5> 
      </div>

         <?php if($notice_info['notice_attachment']): ?>
                  <a href="<?= base_url();?>upload/notice_file/<?= $notice_info['notice_attachment'] ?>" class="pull-left print_button"><i class="fa fa-download"></i> <b>Get the attachment file</b></a>
               <?php endif;?>
      <div class="notice-body bangla">
         <?= $notice_info['notice_details'] ?>
      </div>
      
   </div>
            </div>
         </div>
      </div>
   </div>
</section>
<?php include 'application/views/home/inc/footer.php';?>

