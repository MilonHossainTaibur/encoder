<?php include 'application/views/home/inc/header.php';?>
<section id="primary" class="content-full-width grey1">
      <div class="container min-height py-4 bg-white">
            <div class="card">
               <div class="card-header hr-title dt-sc-hr-invisible-small curl">
                  <h3>Career</h3>
            <div class="title-sep"> </div>
               </div>
               <div class="card-body">

               </div>
            </div>


            

      </div>

</section>
<!-- **Footer** -->
<?php include 'application/views/home/inc/footer.php';?>

