<?php include 'application/views/home/inc/header.php';?>
<link rel="stylesheet" href="<?= base_url() ?>template/css/magnific-popup.css" type="text/css" media="all" />
<script src="<?= base_url() ?>template/js/jquery.magnific-popup.min.js" type="text/javascript"></script>
<style>
   mfp-fade.mfp-bg {
   opacity: 0;
   -webkit-transition: all 0.15s ease-out; 
   -moz-transition: all 0.15s ease-out; 
   transition: all 0.15s ease-out;
}
.mfp-fade.mfp-bg.mfp-ready {
   opacity: 0.8;
}
.mfp-fade.mfp-bg.mfp-removing {
   opacity: 0;
}

.mfp-fade.mfp-wrap .mfp-content {
   opacity: 0;
   -webkit-transition: all 0.15s ease-out; 
   -moz-transition: all 0.15s ease-out; 
   transition: all 0.15s ease-out;
}
.mfp-fade.mfp-wrap.mfp-ready .mfp-content {
   opacity: 1;
}
.mfp-fade.mfp-wrap.mfp-removing .mfp-content {
   opacity: 0;
}
</style>
<!-- Primary Starts -->
<section  class="content-full-width grey1">
      <div class="container min-height py-3 bg-white">
         <div class="card">
               <div class="card-header hr-title dt-sc-hr-invisible-small curl">
                <h3 class="text-dark"><i class="fa fa-video-camera" aria-hidden="true"></i> Video gallery</h3>
         <div class="title-sep"></div>
               </div>
            </div>
        
      <div class="row">
         <div class="col-md-12">
                      <div class="video-gallery py-3">
                        <div class="row">
                   <?php foreach($videos as $video) { ?>
                   <div class="col-md-4">
                   <div class="card border">
                      <div class="card-body ">
                         <div class="video-box">
                            <iframe width="100%" height="320" src="https://www.youtube.com/embed/<?= $video['video_url'];?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                         </div>
                      </div>
                      <div class="card-footer">
                         <h5 class="p-2"> <a class="popup-youtube" href="https://www.youtube.com/watch?v=<?= $video['view_url'];?>"><?= $video['title'];?></a></h5>
                      </div>
                   </div>
                    </div>
                    <?php } ?>          
                  </div>
               </div>
         </div>  
      </div>
   </div>
</section>
<script>
$(document).ready(function() {
   $('.popup-youtube').magnificPopup({
      disableOn: 700,
      type: 'iframe',
      mainClass: 'mfp-fade',
      removalDelay: 160,
      preloader: false,

      fixedContentPos: false
   });
});
</script>

<?php include 'application/views/home/inc/footer.php';?>

