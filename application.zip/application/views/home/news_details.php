<?php include 'application/views/home/inc/header.php';?>
<section class="content-full-width grey1">
<div class="container min-height pt-4 bg-white">
    <div class="card-header hr-title dt-sc-hr-invisible-small curl">
        <h3> <i class="fa fa-file-text-o"></i> News & Events</h3>
         <div class="title-sep"></div>
    </div>
  <div class="row">
    <div class="col-md-12">
      
      <div class="row">
        <div class="col-md-8">
          <div class="card">
               <div class="news-wrapper">
                  <div class="news-image">
                  <img class="img-fluid" src="<?= base_url()?>upload/news/<?= $news['image'];?>" alt="">
                </div>
                
                <div class="news-body p-md-2 p-sm-1">
                  <div class="news-title my-1">
                  <h3 class="news-title"><?= $news['title'];?></h3>
                </div>
                <div class="news-time my-">
                  <h5><i class="fa fa-clock-o" aria-hidden="true"></i> Date & Time  <?= date("d-M-y", strtotime($news['news_date']));?>  <?= $news['news_time'];?></h5>
                 
                </div>
                  <div class="news-text my-2">
                    <?= $news['body'];?>
                  </div>
                  <div class="location my-1">
                      <h5 class="py-1"><span class="news-icon"><i class="fa fa-map-marker" aria-hidden="true"></i></span> <?= $news['venue'];?></h5>
                    </div>
                </div>
<div class="social p-3">
  <h5>Share</h5>

  <a href="http://www.facebook.com/sharer.php?u=<?=  urlencode(current_url());?>" target="_blank">share</a>
  <hr>
            <ul class="list-unstyled list-inline">
              <li class="list-inline-item"><a href="https://www.facebook.com/telihatyhighschool" target="__blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
              <li class="list-inline-item"> <a href="#"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
              <li class="list-inline-item"> <a href="https://www.youtube.com/channel/UCH0A8gS4ZPnjT_aqtJK9E7w"><i class="fa fa-youtube" aria-hidden="true"></i></a></li>
              <li class="list-inline-item"> <a href="https://www.instagram.com/telihatyhighschool/"><i class="fa fa-instagram" aria-hidden="true"></i></a></li>
            </ul>
          </div>
               </div>
              
                
                


               
            </div>

        </div>
        <div class="col-md-4">
            
          <div class="e-class bg-white">
                <div class="section-title p-md-2 p-sm-2 color-1">
                  <h4 class="text-white"><i class="fa fa-youtube-play" aria-hidden="true"></i> <a class="text-white" href="<?= base_url();?>home/video_gallery">Online Class</a></h4>
                </div>
                <?php foreach($videos as $video){ ?>
                <div class="card border">
                  <div class="video-body">
                    <div class="online-video p-md-2 mt-2">
                  <iframe width="100%" height="320" src="<?= $video['video_url'];?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
                </div>
                  </div>
                  <div class="card-title video-title p-2">
                    <h5><?= $video['title'];?></h5>
                  </div>
                </div>
                <?php    } ?>
              </div>
              

        </div>
      </div>

            

             <div class="other-event p-2">
                  <h4>Related Events</h4>
                  <hr>
                </div>




                <div class="row">
                   <?php foreach($other_news as $new) { ?>

                  <div class="col-md-3">
                <div class="card border">
                  
                  <div class="card-body">
                    <div class="news-image">
                      <a href="<?= base_url();?>home/news_details/<?= $new['id'];?>">
                  <img class="img-fluid card-img-top" src="<?= base_url()?>upload/news/<?= $new['image'];?>" alt="">
                </a>
                </div>

                
                  </div>
                  <div class="card-title">
                    <div class="news-title card-title">
                  <h4 class="p-2"><a href="<?= base_url();?>home/news_details/<?= $new['id'];?>"><?= $new['title'];?> </a></h4>
                </div>
                  </div>
                </div>
                  
                  </div>

                  <?php } ?>

                </div>
    </div>
  </div>
   </div>
</section>
<?php include 'application/views/home/inc/footer.php';?>

