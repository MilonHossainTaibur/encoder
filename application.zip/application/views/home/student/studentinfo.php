<?php include 'application/views/home/inc/header.php';?>
<section id="primary" class="content-full-width grey1">
      <div class="container min-height py-4">
            <div class="card">
               <div class="card-header hr-title dt-sc-hr-invisible-small curl">
                  <h3>Students Information</h3>
            <div class="title-sep"> </div>
               </div>
               <div class="card-body">
                  <div class="table-responsive">
               <table  class="table table-condensed" >
                  <thead>
                     <tr>
                        <th>#SL</th>
                        <th class="">Class</th>
                        <th class="">Section</th>
                        <th class="">Session</th>
                        <th class="">Shift</th>
                        <th class="">Nomber Of Students</th>
                     </tr>
                  </thead>
                  <tbody>
                     <tr>
                        <?php $i=1; foreach($student_count as $sc) { ?>
                        <td><?= $i ?></td>
                        <td><?= $sc['class_name'] ?></td>
                        <td><?= $sc['section_name'] ?></td>
                        <td><?= $sc['session_name'] ?></td>
                        <td><?= $sc['shift_name'] ?></td>
                        <td><?= $sc['ts'] ?></td>
                     </tr>
                     <?php $i++; } ?>
                  </tbody>
               </table>
            </div>
               </div>
            </div>


            

      </div>

</section>
<!-- **Footer** -->
<?php include 'application/views/home/inc/footer.php';?>

