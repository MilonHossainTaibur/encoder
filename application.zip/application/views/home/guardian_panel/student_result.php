<div class="row  bg-white">
      <div class="col-md-12">
      	<div class="card">
               <div class="card-header  hr-title dt-sc-hr-invisible-small curl">
               	<h3> পরীক্ষার ফলাফল </h3>
               	<div class="title-sep"> </div>
               </div>
               <div class="card-body">
               	 <div class="panel widget-main">
            <div class="panel-body">
               <div class="form-group">
                  <div class="row">
                     <div class="col-sm-3 col-md-3">
                        <label>Session <span style="color:red;">*</span></label>
                        <select class="form-control" name="session_id" id="session_id" onChange="get_student_list_marksheet(this.value)">
							<option value="">-----Select Session-----</option>
							<?php foreach($session_list as $sl){ ?>
							<option value="<?= $sl['session_id'];?>"><?= $sl['session_name'];?></option>
							<?php } ?>
						</select>
                     </div>
                     <div class="col-sm-3 col-md-3">
                        <label>Term Name <span style="color:red;">*</span></label>
                        <select class="form-control" required name="term_id" id="term_id" onchange="term_marks_json()">
							<option value="">Select</option>
							<?php foreach($term_list as $tl){ ?>
							<option value="<?php echo $tl['term_id'];?>"><?php echo $tl['term'];?></option>
							<?php } ?>
						</select>
                     </div>
                  </div>
               </div>
               <br>
               <button class="button btn btn-info" onclick="mark_sheet_json()" type="button"> Result View </button>
               <hr>
				<div id="display">
				</div>
            </div>
         </div>
               </div>
            </div>        
      </div>
   </div>

<!--Check department name based on class id-->
<script>
	function mark_sheet_json()
		{
			var session_id = $('#session_id').val();
			var session = $('#session_id option:selected').text();
			var term_id = $('#term_id').val();
			var term_name = $('#term_id option:selected').text();
			
			if(!session_id)
			{
				$('#session_id').after("<div id='validation_ses' class='validation_js'>Please select a session.</div>")
					$('#validation_ses').delay(3000).hide('slow');
					return;
				
			}
			if(!term_id)
			{
				$('#term_id').after("<div id='validation_ct' class='validation_js'>Please select a term.</div>")
					$('#validation_ct').delay(3000).hide('slow');
					return;
				
			}
		
			$.ajax({ 
			url: baseUrl+'guardian_panel/mark_sheet_json',
			data:
				{
					'session_id':session_id,
					'session':session,
					'term_name':term_name,
					'term_id':term_id
				}, 
				dataType: 'json',
				success: function(data)
				{
					result                = ''+data['result']+'';
					mainContent           = ''+data['mainContent']+'';
	
					if(result == 'success')
					{            
						$('#display').html(mainContent);     
					}                
				},
			error: function(e){
			   alert(e.message);
			}
			});
		}
		
		function printPageArea(areaID){
		var printContent = document.getElementById(areaID);
		var WinPrint = window.open('', '', 'width=900,height=650');
		WinPrint.document.write('<link rel="stylesheet" type="text/css" href="<?= base_url();?>template/bootstrap-print/bootstrap-print.min.css" media="print" />')
		WinPrint.document.write('<style type="text/css" media="print"> @page { size: landscape; font-size:12px; } table{font-size:12px;} table td{padding:3px;} .print_button{ display:none;} </style>')
		WinPrint.document.write(printContent.innerHTML);
		WinPrint.document.close();
		WinPrint.focus();
		WinPrint.print();
		WinPrint.close();
	}
</script> 



