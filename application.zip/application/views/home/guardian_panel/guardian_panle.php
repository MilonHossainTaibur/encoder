<?php include 'application/views/home/inc/header.php';?>
<style>
.tab-pane{
	min-height:300px;
}
</style>
	<div class="container min-height bg-white">
        <div class="row">
            <div class="col-md-12"> 
            <div class="card">
               <div class="card-header"></div>
               <div class="card-body">
               	<div class="panel widget-main">
            		<div class="panel-heading"><h1>অভিভাবক প্যানেল <span class="pull-right"><a class="btn btn-danger" href="<?= base_url() ?>home/logout">লগআউট</a></span></h1></div>	 	
            		<div class="panel-body">
						<ul class="nav nav-pills" style="font-size:20px;">
							<li class="active studentinfo" onclick="get_data('student_data')"><a data-toggle="pill" href="#student_data"> ছাত্র / ছাত্রী তথ্য </a></li>
							<li onclick="get_data('attendance')"><a data-toggle="pill" href="#attendance">উপস্থিতি</a></li>
							<li onclick="get_data('fees_info')"><a data-toggle="pill" href="#fees_info">ফিস তথ্য</a></li>
							<li onclick="get_data('student_result')"><a data-toggle="pill" href="#student_result">পরীক্ষা ফলাফল</a></li>
							<li onclick="get_data('teacher_comment')"><a data-toggle="pill" href="#teacher_comment">শিক্ষক/শিক্ষিকা বার্তা</a></li>
						  </ul>
						  
						  <div class="tab-content">
							<div id="student_data" class="tab-pane fade in active">
								 <div class="cssload-thecube">
									<div class="cssload-cube cssload-c1"></div>
									<div class="cssload-cube cssload-c2"></div>
									<div class="cssload-cube cssload-c4"></div>
									<div class="cssload-cube cssload-c3"></div>
								</div>
							</div>
							<div id="attendance" class="tab-pane fade">
								<div class="cssload-thecube">
									<div class="cssload-cube cssload-c1"></div>
									<div class="cssload-cube cssload-c2"></div>
									<div class="cssload-cube cssload-c4"></div>
									<div class="cssload-cube cssload-c3"></div>
								</div>
							</div>
							<div id="fees_info" class="tab-pane fade">
								<div class="cssload-thecube">
									<div class="cssload-cube cssload-c1"></div>
									<div class="cssload-cube cssload-c2"></div>
									<div class="cssload-cube cssload-c4"></div>
									<div class="cssload-cube cssload-c3"></div>
								</div>
							</div>
							<div id="student_result" class="tab-pane fade">
								<div class="cssload-thecube">
									<div class="cssload-cube cssload-c1"></div>
									<div class="cssload-cube cssload-c2"></div>
									<div class="cssload-cube cssload-c4"></div>
									<div class="cssload-cube cssload-c3"></div>
								</div>
							</div>
							<div id="teacher_comment" class="tab-pane fade">
								<div class="cssload-thecube">
									<div class="cssload-cube cssload-c1"></div>
									<div class="cssload-cube cssload-c2"></div>
									<div class="cssload-cube cssload-c4"></div>
									<div class="cssload-cube cssload-c3"></div>
								</div>
							</div>
						  </div>
					</div>
				</div>
               </div>

            </div>





				
			</div>
	     </div> <!--//.row -->
	</div> <!--//.container -->
  <script>
  window.onload=function(){
	 $('.studentinfo').click();
  }
    function get_data(tab_content){
		
		$.ajax({
		type: 'GET',			
        url: baseUrl+'guardian_panel/'+tab_content,
        data:
            {
                
            }, 
            dataType: 'json',
            success: function(data)
            {
                result                = ''+data['result']+'';
                mainContent           = ''+data['mainContent']+'';

                if(result == 'success')
                {   
                    $('#'+tab_content).html(mainContent);     
                }                
            },
			error: function(e){
			   alert(e.message);
			}
			
        });
        return false; // keeps the page from not refreshing     		
	}
  </script>
<?php include 'application/views/home/inc/footer.php';?>