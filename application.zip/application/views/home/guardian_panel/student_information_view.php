<style>
table, th, td {
    border: 0px solid rgba(0, 0, 0, 0.1);
	padding:2px;
}
table tbody tr td{
	font-size:16px;
}
.table>thead>tr>th, .table>tbody>tr>th, .table>tfoot>tr>th, .table>thead>tr>td, .table>tbody>tr>td, .table>tfoot>tr>td {
    border-top: 0px !important;
	padding-bottom:0px !important;
}
label{
	font-size:18px;
}
</style>
<div class="row">
	<div class="col-sm-12 col-md-12">
		<div class="widget bg-white" style="min-height:500px;">
			<div class="widget-content padding">
				<div class="student_form">
					<div class="form-group">
						<div class="row">
							<div class="col-sm-2">
								<img src="<?= base_url(); ?>upload/institute_logo/<?= $school_info['logo'];?>" alt="" height="100" width="100"/>
							</div>
							<div class="col-sm-8" style="text-align: center">
								<p>
									<b style="font-size:20px;"><?= $school_info['school_name'];?></b>
								</p>
								<p><?= $school_info['address'];?>, <?= $school_info['post_office'];?>, <?= $school_info['district'];?></p>
								<p>Contact : <?= $school_info['contact_no'];?><br> E-mail: <?= $school_info['email'];?><br> Website: <?= $school_info['website'];?></p>
							</div>
							<div class="col-sm-2">
								<img src="<?= base_url();?>upload/student_image/<?= $student_info['student_image'];?>" alt="" width="200"/>
							</div>
						</div>
					</div>
					<div class="form-group">
						<div class="row">
							<div class="col-sm-12">
								<center>
									<h3>Student Details</h3>
								</center>
							</div>
						</div>
					</div>
				</div>
				
				<legend><i class="icon32 icon-square-plus"></i> A. Personal Details</legend>
					<h3> 1. Applicant Particulars</h3>
					<table width="100%">
						<tr>
							<td width="150px"><label>Student Name:</label></td>
							<td style="border-bottom:1px dotted #000" ><?= $student_info['student_name'];?></td>
						</tr>
						<tr>
							<td colspan="2" style="padding-left:0px;">
								<table width="100%" border="0" style="margin-bottom:0px; padding-left:0px">
									<tr>
										<td width="130px"><label>Date of Birth: </label></td>
										<td style="border-bottom:1px dotted #000"><?= date('d F, Y',strtotime($student_info['birth_date']));?></td>
										<td width="50px"><label>Age: </label></td>
										<td style="border-bottom:1px dotted #000"><?= $student_info['age'];?></td>
										<td width="135px"><label>Birth Cert No: </label></td>
										<td style="border-bottom:1px dotted #000"><?= $student_info['birth_cert_no'];?></td>
									</tr>
								</table>
							</td>
						</tr>
						<tr>
							<td colspan="2" style="padding-left:0px; padding-top:0px;">
								<table width="100%" border="0" style="margin-bottom:0px; padding-left:0px; padding-top:0px;">
									<tr>
										<td width="120px"><label>Nationality: </label></td>
										<td style="border-bottom:1px dotted #000"><?= $student_info['nationality'];?></td>
										<td width="50px"><label>Religion: </label></td>
										<td style="border-bottom:1px dotted #000"><?php $religion=array('111'=>'Islam','112'=>'Hinduism','113'=>'Christianity','114'=>'Buddhism'); ?>
											<?= $religion[$student_info['religion']];?></td>
										<td width="50px"><label>Gender: </label></td>
										<td style="border-bottom:1px dotted #000"><?= $student_info['gender'];?></td>
									</tr>
								</table>
							</td>
						</tr>
					</table>
		
					<table width="100%" border="0">
						<tr>
							<td colspan="6"><h4> <b style="border-bottom:2px solid #000">Present Address</b></h4></td>
						</tr>
						<tr>
							<td colspan="6">
								<table width="100%" border="0" style="padding-left:0px !important;margin-bottom:0px;">
									<tr>
										<td width="200px"><label>Village/Town/Road/House/Flat: </label></td>
										<td style="border-bottom:1px dotted #000"><?= $student_info['present_address'];?></td>
									</tr>
								</table>
							</td>
						</tr>
						<tr>
							<td width="120px"><label>&nbsp;&nbsp;&nbsp;&nbsp;Post Office: </label></td>
							<td style="border-bottom:1px dotted #000"><?= $student_info['present_po'];?></td>
							<td width="110px"><label>Post Code: </label></td>
							<td style="border-bottom:1px dotted #000"><?= $student_info['present_pc'];?></td>
							<td width="150px"><label>P.S./Upazila: </label></td>
							<td style="border-bottom:1px dotted #000">
							<?php foreach($upazila_list as $ul){ if($student_info['present_upazila']==$ul['id'])echo $ul['u_name'];}?>
							</td>
						</tr>
						<tr>
							<td width="150px"><label>&nbsp;&nbsp;&nbsp;&nbsp;District: </label></td>
							<td style="border-bottom:1px dotted #000">
							<?php foreach($district_list as $disl){ if($student_info['present_district']==$disl['id'])echo $disl['d_name'];}?>
							</td>
							<td width="100px"><label>Division: </label></td>
							<td style="border-bottom:1px dotted #000">
							<?php foreach($division_list as $divl){ if($student_info['present_division']==$divl['id'])echo $divl['name'];}?>
							</td>
						</tr>
					</table>
			
					<table width="100%" border="0">
						<tr>
							<td colspan="6"><h4> <b style="border-bottom:2px solid #000">Permanent Address</b></h4></td>
						</tr>
						<tr>
							<td colspan="6">
								<table width="100%" style="padding-left:0px !important;margin-bottom:0px;">
									<tr>
										<td width="200px"><label>Village/Town/Road/House/Flat: </label></td>
										<td style="border-bottom:1px dotted #000"><?= $student_info['permanent_address'];?></td>
									</tr>
								</table>
							</td>
						</tr>
						<tr>
							<td width="120px"><label>&nbsp;&nbsp;&nbsp;&nbsp;Post Office: </label></td>
							<td style="border-bottom:1px dotted #000"><?= $student_info['permanent_po'];?></td>
							<td width="100px"><label>Post Code: </label></td>
							<td style="border-bottom:1px dotted #000"><?= $student_info['permanent_pc'];?></td>
							<td width="150px"><label>P.S./Upazila: </label></td>
							<td style="border-bottom:1px dotted #000">
							<?php foreach($upazila_list as $ul){ if($student_info['permanent_upazila']==$ul['id'])echo $ul['u_name'];}?>
							</td>
						</tr>
						<tr>
							<td width="150px"><label>&nbsp;&nbsp;&nbsp;&nbsp;District: </label></td>
							<td style="border-bottom:1px dotted #000">
							<?php foreach($district_list as $disl){ if($student_info['permanent_district']==$disl['id'])echo $disl['d_name'];}?>
							</td>
							<td width="100px"><label>Division: </label></td>
							<td style="border-bottom:1px dotted #000">
							<?php foreach($division_list as $divl){ if($student_info['permanent_division']==$divl['id'])echo $divl['name'];}?>
							</td>
						</tr>
					</table>
						
					<h3> 2. Parents' Particulars</h3>
					<table width="100%">
						<tr>
							<td colspan="6"><h4> <b style="border-bottom:2px solid #000">Father's</b></h4></td>
						</tr>
						<tr>
							<td width="120px"><label>&nbsp;&nbsp;&nbsp;&nbsp;Name: </label></td>
							<td style="border-bottom:1px dotted #000"><?= $student_info['father_name'];?></td>
							<td width="50px"><label>Occupation: </label></td>
							<td style="border-bottom:1px dotted #000"><?= $student_info['father_occupation'];?></td>
							<td width="50px"><label>NID: </label></td>
							<td style="border-bottom:1px dotted #000"><?= $student_info['father_nid'];?></td>
						</tr>
						<tr>
							<td width="50px">&nbsp;&nbsp;&nbsp;&nbsp;<label>Education: </label></td>
							<td style="border-bottom:1px dotted #000"><?= $student_info['father_education'];?></td>
							<td width="50px"><label>Contact: </label></td>
							<td style="border-bottom:1px dotted #000"><?= $student_info['father_home_contact'];?></td>
							<td width="50px"><label>Email: </label></td>
							<td style="border-bottom:1px dotted #000"><?= $student_info['father_email'];?></td>
						</tr>
					</table>
					<table width="100%" style="margin-bottom:0px;">
						<tr>
							<td colspan="6"><h4> <b style="border-bottom:2px solid #000">Mother's</b></h4></td>
						</tr>
						<tr>
							<td width="120px"><label>&nbsp;&nbsp;&nbsp;&nbsp;Name: </label></td>
							<td style="border-bottom:1px dotted #000"><?= $student_info['mother_name'];?></td>
							<td width="50px"> <label>Occupation:  </label></td>
							<td style="border-bottom:1px dotted #000"><?= $student_info['mother_occupation'];?></td>
							<td width="50px"><label>NID: </label></td>
							<td style="border-bottom:1px dotted #000"><?= $student_info['mother_nid'];?></td>
						</tr>
						<tr>
							<td width="50px">&nbsp;&nbsp;&nbsp;&nbsp;<label>Education:  </label></td>
							<td style="border-bottom:1px dotted #000"><?= $student_info['mother_education'];?></td>
							<td width="50px"><label>Contact:  </label></td>
							<td style="border-bottom:1px dotted #000"><?= $student_info['mother_home_contact'];?></td>
							<td width="50px"><label>Email:  </label></td>
							<td style="border-bottom:1px dotted #000"><?= $student_info['mother_email'];?></td>
						</tr>
					</table>
					<table width="100%">
						<tr>
							<td width="200px">&nbsp;&nbsp;&nbsp;<label>SMS/Contact Number: </label></td>
							<td style="border-bottom:1px dotted #000"><?= $student_info['mobile_contact'];?></td>
						</tr>
					</table>
			
					<h3> 3. Guardians' Particulars</h3><br/>
					<table width="100%" style="margin-bottom:0px;">
						<tr>
							<td width="150px">&nbsp;&nbsp;&nbsp;<label>Guardian Name: </label></td>
							<td style="border-bottom:1px dotted #000"><?= $student_info['guardian_1_name'];?></td>
							<td width="100px"><label>Relation: </label></td>
							<td style="border-bottom:1px dotted #000"><?= $student_info['guardian_1_relation'];?></td>
							<td width="100px"><label>Occupation: </label></td>
							<td style="border-bottom:1px dotted #000"><?= $student_info['guardian_1_occupation'];?></td>
						</tr>
					</table>
					<table width="100%">
						<tr>
							<td width="150px">&nbsp;&nbsp;&nbsp;<label>Yearly Income: </label></td>
							<td style="border-bottom:1px dotted #000"><?= $student_info['guardian_1_yearly_income'];?></td>
							<td width="80px"><label>Mobile: </label></td>
							<td style="border-bottom:1px dotted #000"><?= $student_info['guardian_1_mobile'];?></td>
							<td width="80px"><label>Email: </label></td>
							<td style="border-bottom:1px dotted #000"><?= $student_info['guardian_1_email'];?></td>
						</tr>
					</table>
				
					<h3> 4. Particulars of siblings studying in this institution</h3><br/> 
					<table width="100%">
						<tr>
							<td width="120px">&nbsp;&nbsp;&nbsp;<label>Siblings ID: </label></td>
							<td style="border-bottom:1px dotted #000"><?= $student_info['siblings_1_id'];?></td>
							<td width="120px"><label>Siblings ID: </label></td>
							<td style="border-bottom:1px dotted #000"><?= $student_info['siblings_2_id'];?></td>
							<td width="120px"><label>Siblings ID: </label></td>
							<td style="border-bottom:1px dotted #000"><?= $student_info['siblings_3_id'];?></td>
							<td width="120px"><label>Siblings ID: </label></td>
							<td style="border-bottom:1px dotted #000"><?= $student_info['siblings_4_id'];?></td>
						</tr>
					</table></br>

					<legend><i class="icon32 icon-square-plus"></i>D. Other Info</legend>
					<table width="100%">
						<tr>
							<td width="120px">&nbsp;&nbsp;&nbsp;<label>Class: </label></td>
							<td style="border-bottom:1px dotted #000"><?php echo $student_info['class_name'];?></td>
							<td width="120px"><label>Section: </label></td>
							<td style="border-bottom:1px dotted #000"><?php echo $student_info['section_name'];?></td>
							<td width="120px"><label>Group: </label></td>
							<td style="border-bottom:1px dotted #000">
							<?php foreach($group_list as $gl){ if($student_info['group_id']==$gl['group_id'])echo $gl['group_name'];}?></td>
						</tr>
						<tr>
							<td width="120px">&nbsp;&nbsp;&nbsp;<label>Session: </label></td>
							<td style="border-bottom:1px dotted #000"><?php echo $student_info['session_name'];?></td>
							<td width="120px"><label>Class Roll: </label></td>
							<td style="border-bottom:1px dotted #000"><?php echo $student_info['roll_no'];?></td>
							<td width="120px"><label>Shift: </label></td>
							<td style="border-bottom:1px dotted #000">
							<?php foreach($shift_list as $sl){ if($student_info['shift_id']==$sl['shift_id'])echo $sl['shift_name'];}?>
							</td>
						</tr>
						<tr>
							<td width="130px">&nbsp;&nbsp;&nbsp;<label>Blood Group: </label></td>
							<td style="border-bottom:1px dotted #000"><?php echo $student_info['blood_group'];?></td>
							<td></td>
							<td></td>
							<td></td>
							<td></td>
						</tr>
					</table>
					
					<legend><i class="icon32 icon-square-plus"></i>E. Financial Aid Details</legend>
					<table width="100%">
						<tr>
							<td width="130px">&nbsp;&nbsp;&nbsp;<label>Financial Aid: </label></td>
							<td style="border-bottom:1px dotted #000">
							<?php if($student_info['financial_aid']==1) echo "Yes"; elseif($student_info['financial_aid']==2) echo "No"; elseif($student_info['financial_aid']==3) echo "Full Free"; ?></td>
							<td width="170px"><label>Fees Aid: </label></td>
							<td style="border-bottom:1px dotted #000">
							<?php foreach($fees_list as $fl){ if($student_info['fees_aid']==$fl['fees_cat_id'])echo $fl['fees_particulars'];}?> </td>
							<td width="150px"><label>Aid Amount: </label></td>
							<td style="border-bottom:1px dotted #000"><?= $student_info['aid_amount'];?></td>
						</tr>
					</table>
                </div>
            </div>
        </div>
    </div>