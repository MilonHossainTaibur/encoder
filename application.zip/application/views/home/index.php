<?php include 'application/views/home/inc/header.php';?>
<link href="<?= base_url() ?>template/css/jquery-ui.min.css" type="text/css" rel="stylesheet" />
<div class="main" style="background: linear-gradient(to bottom, #e9edee 0%, #3b5998 100%);">
	<div class="container wrapper bg-white">
		<div class="">
			<!-- news and cover image slide part -->
			<?php include 'application/views/home/inc/news_slide.php';?>
        <section class="py-3">
            <div class="row">
				<!-- body's top left side part -->
				<?php include 'application/views/home/inc/body_top_left.php';?>
				<!---col-2 left-->
				<!-- body's top middle side part -->
				<?php echo $d_content;?>               
				<?php //include 'application/views/home/inc/body_top_middle.php';?>               
				<!---col-8 middle-->
				<!-- body's top middle side part -->
				<?php include 'application/views/home/inc/body_top_right.php';?>               
				<!---col-2 right-->
            </div>
        </section>
        <section class="news-section my-4 p-2" style="background-color: #DFE4EF;">
        	<div class="row">
        	<div class="col-md-7">
        	<div class="section-title p-md-2 p-sm-2 color-2">
        		<h4 class="text-white"><i class="fa fa-calendar" aria-hidden="true"></i> <a class="text-white" href="<?= base_url();?>home/news_list">News & Events</a> <a class="float-right text-white" href=""><i class="fa fa-angle-double-right" aria-hidden="true"></i></a></h4>
        	</div>
        	<?php foreach($news as $new){ ?>
        	<div class="news-main border my-2 bg-white overflow-hidden p-2">
        			<div class="row">
        				<div class="col-md-4">
        					<div class="news-img position-relative overflow-hidden p-sm-4 p-md-0">
        						<a href="<?= base_url();?>home/news_details/<?= $new['id'];?>">
        							<img class="img-fluid" src="<?= base_url()?>upload/news/<?= $new['image'];?>" alt="">
        						</a>

        						<div class="event_date">
									<span class="event_date_mon"><?= date("M", strtotime($new['news_date']));?></span>
								 	<span class="event_date_day"><?= date("d", strtotime($new['news_date']));?></span>				 
								</div>
        					</div>
        				</div>
        				<div class="col-md-8">
        					<div class="news-container ml-md-2">
        						<div class="news-title">
        						<h4 class="py-1"><a class="" href="<?= base_url();?>home/news_details/<?= $new['id'];?>"><?= $new['title'];?></a></h4>

        						</div>
        						<div class="time">
        							<h5 class="py-1"><span class="news-icon"><i class="fa fa-clock-o" aria-hidden="true"></i></span> <?= $new['news_time'];?></h5>
        						</div>
        						<div class="location">
        							<h5 class="py-1"><span class="news-icon"><i class="fa fa-map-marker" aria-hidden="true"></i></span> <?= $new['venue'];?></h5>
        						</div>
        					</div>
        				</div>
        			</div>
        	</div>
        	<?php    } ?>
        	</div>
        		<div class="col-md-5 col-sm-12">
        			<div class="e-class bg-white">
        				<div class="section-title p-md-2 p-sm-2 color-1">
        					<h4 class="text-white"><i class="fa fa-youtube-play" aria-hidden="true"></i> <a class="text-white" href="<?= base_url();?>home/video_gallery">Online Class</a><a class="float-right text-white" href=""><i class="fa fa-angle-double-right" aria-hidden="true"></i></a></h4>
        				</div>
        				<div class="online-video p-md-2 mt-2">
        					<iframe width="100%" height="320" src="https://www.youtube.com/embed/<?= $video[0]['video_url'];?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        				</div>
        			</div>
        		</div>
        	</div>
        </section>
        <section class="gallery-section">
			<div class="row">
				<!-- body's bellow gallery part -->
				<?php include 'application/views/home/inc/body_below_gallery.php';?>
			</div>
        </section>
		</div>
	</div>
   <!--container-->
</div>
<!--main-->
<script src="<?= base_url() ?>template/js/jquery-ui.min.js" type="text/javascript"></script>
<script>
	$( function() {
		$( "#teacher_att" ).datepicker();
	});
    $( function() {
		$( "#student_att" ).datepicker();
	});   
</script>
<?php include 'application/views/home/inc/footer.php';?>