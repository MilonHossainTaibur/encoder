<?php include 'application/views/home/inc/header.php';?>
<section id="primary" class="content-full-width grey1">
   <div class="full-width-section">
   <div class="container min-height py-4 bg-white">
   <div class="row">
      <div class="col-md-12">
         <div class="card">
            <div class="card-header hr-title dt-sc-hr-invisible-small curl">
               <h3>Online Admission Application</h3>
            </div>
            <div class="card-body">
               <form role="form" id="registerForm" name="registerForm" method="POST" action="" enctype="multipart/form-data">
               <div class="form-group">
                  <label>Official Name (as in Birth Registration or in the Passport) <span style="color:red;">*</span> </label>
                  <input type="text" class="form-control" name="student_name" id="student_name"  required >
               </div>
               <div class="form-group">
                  <div class="row">
                     <div class="col-sm-4">
                        <label> Date of Birth <span style="color:red;">*</span></label>
                        <input type="text" class="form-control datepicker-input" placeholder="yyyy-mm-dd" name="birth_date" id="birth_date" />
                     </div>
                     <div class="col-sm-4">
                        <label> Age</label>
                        <input type="text" class="form-control" name="age" id="age" onClick="myAgeValidation()" onFocus="myAgeValidation()" readonly="" />
                        <input type="hidden" name="cur_date" value="<?= date('Y-m-d') ?>" />
                     </div>
                     <div class="col-sm-4">
                        <label> Birth Cert No</label>
                        <input type="text" class="form-control" name="birth_cert_no" />
                     </div>
                  </div>
               </div>
               <div class="form-group">
                  <div class="row">
                     <div class="col-sm-4">
                        <label>Nationality <span style="color:red;">*</span></label>
                        <input type="text" class="form-control" name="nationality" id="nationality" value="Bangladeshi" >
                     </div>
                     <div class="col-sm-4">
                        <label>Religion <span style="color:red;">*</span></label>
                        <select class="form-control" name="religion" id="religion" >
                           <option value="">Select</option>
                           <option value="111" selected>Islam</option>
                           <option value="112">Hinduism</option>
                           <option value="113">Christianity</option>
                           <option value="114">Buddhism</option>
                        </select>
                     </div>
                     <div class="col-sm-4">
                        <label>Gender <span style="color:red;">*</span></label>
                        <select class="form-control" name="gender" id="gender" >
                           <option value="">Select</option>
                           <option value="Male" selected>Male</option>
                           <option value="Female">Female</option>
                        </select>
                     </div>
                  </div>
               </div>
               <div class="form-group">
                  <div class="row">
                     <div class="col-sm-6">
                        <label>Student Image</label>
                        <input type="file" class="btn btn-default" title="Browse Picture" name="student_image" id="student_image">
                        <output id="list"></output>
                     </div>
                  </div>
               </div>
               <hr />
               <h4> Present Address</h4>
               <div class="form-group">
                  <div class="row">
                     <div class="col-sm-12">
                        <label>Village/Town/Road/House/Flat</label>
                        <input type="text" class="form-control" name="present_address" id="present_address">
                     </div>
                     <div class="col-sm-3">
                        <label>Division</label>
                        <select class="form-control" name="present_division" onchange="get_district(this.value,'present_district')">
                           <option value="">----Select Division----</option>
                           <?php if($division_list):
                              foreach($division_list as $div_list):?>
                           <option value="<?= $div_list['id']?>"><?= $div_list['name']?></option>
                           <?php endforeach; endif; ?>
                        </select>
                     </div>
                     <div class="col-sm-3">
                        <label>District</label>
                        <select class="form-control" name="present_district" onchange="get_upazila(this.value,'present_upazila')">
                           <option value="">----Select District----</option>
                        </select>
                     </div>
                     <div class="col-sm-3">
                        <label>P.S./Upazila</label>
                        <select class="form-control" name="present_upazila">
                           <option value="">----Select Upazila----</option>
                        </select>
                     </div>
                     <div class="col-sm-3">
                        <label>Post Office</label>
                        <input type="text" class="form-control" name="present_po">
                     </div>
                     <div class="col-sm-3">
                        <label>Post Code</label>
                        <input type="text" class="form-control" name="present_pc">
                     </div>
                  </div>
               </div>
               <hr />

               <h4> Permanent Address</h4>
               <label class="checkbox-inline pull-right" style="color:red;">
                  <input type="checkbox" name="check_address" id="check_address" value="1">Same as present address.</label>
               <div class="form-group permanent_address">
                  <div class="row">
                     <div class="col-sm-12">
                        <label>Village/Town/Road/House/Flat</label>
                        <input type="text" class="form-control" name="permanent_address">
                     </div>
                     <div class="col-sm-3">
                        <label>Division</label>
                        <select class="form-control" name="permanent_division" onchange="get_district(this.value,'permanent_district')">
                           <option value="">----Select Division----</option>
                           <?php if($division_list):
                              foreach($division_list as $div_list):?>
                           <option value="<?= $div_list['id']?>"><?= $div_list['name']?></option>
                           <?php endforeach; endif; ?>
                        </select>
                     </div>
                     <div class="col-sm-3">
                        <label>District</label>
                        <select class="form-control" name="permanent_district" onchange="get_upazila(this.value,'permanent_upazila')">
                           <option value="">----Select District----</option>
                        </select>
                     </div>
                     <div class="col-sm-3">
                        <label>P.S./Upazila</label>
                        <select class="form-control" name="permanent_upazila">
                           <option value="">----Select Upazila----</option>
                        </select>
                     </div>
                     <div class="col-sm-3">
                        <label>Post Office</label>
                        <input type="text" class="form-control" name="permanent_po">
                     </div>
                     <div class="col-sm-3">
                        <label>Post Code</label>
                        <input type="text" class="form-control" name="permanent_pc">
                     </div>
                  </div>
               </div>
               <hr />
               <h4> 2. Parents' Particulars</h4>
               <div class="form-group">
                  <div class="row">
                     <div class="col-sm-6">
                        <label>Father's Name <!--span style="color:red;">*</span--></label>
                        <input type="text" class="form-control" name="father_name" id="father_name" />
                     </div>
                     <div class="col-sm-6">
                        <label>Mother's Name <!--span style="color:red;">*</span--></label>
                        <input type="text" class="form-control" name="mother_name" id="mother_name" />
                     </div>
                  </div>
               </div>
               <div class="form-group">
                  <div class="row">
                     <div class="col-sm-6">
                        <label>Father's NID</label>
                        <input type="text" class="form-control" name="father_nid" />
                     </div>
                     <div class="col-sm-6">
                        <label>Mother's NID</label>
                        <input type="text" class="form-control" name="mother_nid" />
                     </div>
                  </div>
               </div>
               <div class="form-group">
                  <div class="row">
                     <div class="col-sm-6">
                        <label>Father's Occupation</label>
                        <input type="text" class="form-control" name="father_occupation" id="father_occupation">
                     </div>
                     <div class="col-sm-6">
                        <label>Mother's Occupation</label>
                        <input type="text" class="form-control" name="mother_occupation" id="mother_occupation">
                     </div>
                  </div>
               </div>
               <div class="form-group">
                  <div class="row">
                     <div class="col-sm-6">
                        <label>Father's Education</label>
                        <select class="form-control" name="father_education" id="father_education">
                           <option value="">Select</option>
                           <option value="Pre-Graduate">Pre-Graduate</option>
                           <option value="Graduate">Graduate</option>
                           <option value="Post-Graduate">Post-Graduate</option>
                        </select>
                     </div>
                     <div class="col-sm-6">
                        <label>Mother's Education</label>
                        <select class="form-control" name="mother_education" id="mother_education">
                           <option value="">Select</option>
                           <option value="Pre-Graduate">Pre-Graduate</option>
                           <option value="Graduate">Graduate</option>
                           <option value="Post-Graduate">Post-Graduate</option>
                        </select>
                     </div>
                  </div>
               </div>
               <div class="form-group">
                  <div class="row">
                     <div class="col-sm-6">
                        <label>Father's Contact(Home)</label>
                        <input type="text" class="form-control" name="father_home_contact" value="88">
                     </div>
                     <div class="col-sm-6">
                        <label>Mother's Contact(Home)</label>
                        <input type="text" class="form-control" name="mother_home_contact" value="88">
                     </div>
                  </div>
               </div>
               <div class="form-group">
                  <div class="row">
                     <div class="col-sm-6">
                        <label>Father's Email</label>
                        <input type="text" class="form-control" name="father_email" id="exampleInputEmail1"/>
                     </div>
                     <div class="col-sm-6">
                        <label>Mother's Email</label>
                        <input type="text" class="form-control" name="mother_email" id="exampleInputEmail1"/>
                     </div>
                  </div>
               </div>
               <div class="form-group">
                  <div class="row">
                     <div class="col-sm-6">
                        <label>SMS/Contact number</label>
                        <input type="text" class="form-control" name="mobile_contact" value="8801" />
                     </div>
                  </div>
               </div>
               <hr />
               <h4> 3. Guardians' Particulars</h4>
               <div class="form-group">
                  <div class="row">
                     <div class="col-sm-6">
                        <label>Guardian Name</label>
                        <input type="text" class="form-control" name="guardian_1_name" />
                     </div>
                     <div class="col-sm-6">
                        <label>Relation</label>
                        <input type="text" class="form-control" name="guardian_1_relation" />
                     </div>
                  </div>
               </div>
               <div class="form-group">
                  <div class="row">
                     <div class="col-sm-6">
                        <label>Occupation</label>
                        <input type="text" class="form-control" name="guardian_1_occupation" />
                     </div>
                     <div class="col-sm-6">
                        <label>Yearly Income</label>
                        <input type="text" class="form-control" name="guardian_1_yearly_income" />
                     </div>
                  </div>
               </div>
               <div class="form-group">
                  <div class="row">
                     <div class="col-sm-6">
                        <label>Mobile</label>
                        <input type="text" class="form-control" name="guardian_1_mobile" />
                     </div>
                     <div class="col-sm-6">
                        <label>Email</label>
                        <input type="text" class="form-control" name="guardian_1_email" />
                     </div>
                  </div>
               </div>
               <h4> 4. Particulars of siblings studying in this institution</h4>
               <div class="form-group">
                  <div class="row">
                     <div class="col-sm-3">
                        <label>Siblings ID </label>
                        <input type="text" class="form-control" name="siblings_1_id" />
                     </div>
                     <div class="col-sm-3">
                        <label>Siblings ID </label>
                        <input type="text" class="form-control" name="siblings_2_id" />
                     </div>
                     <div class="col-sm-3">
                        <label>Siblings ID </label>
                        <input type="text" class="form-control" name="siblings_3_id" />
                     </div>
                     <div class="col-sm-3">
                        <label>Siblings ID </label>
                        <input type="text" class="form-control" name="siblings_4_id" />
                     </div>
                  </div>
               </div>
               <hr />
               <legend><i class="icon32 icon-square-plus"></i> B. Academic Background</legend>
               <h4> 1. Previous School</h4>
               <div class="form-group">
                  <div class="row">
                     <div class="col-sm-6">
                        <label>Name of School</label>
                        <input type="text" class="form-control" name="previous_school_name" id="previous_school_name"/>
                     </div>
                     <div class="col-sm-6">
                        <label>Start Date</label>
                        <input type="text" class="form-control datepicker-input" placeholder="yyyy-mm-dd" name="previous_start_date" id="previous_start_date"/> 
                     </div>
                  </div>
               </div>
               <div class="form-group">
                  <div class="row">
                     <div class="col-sm-6">
                        <label>Finish Date</label>
                        <input type="text" class="form-control datepicker-input" placeholder="yyyy-mm-dd" name="previous_finish_date" id="previous_finish_date"/> 
                     </div>
                     <div class="col-sm-6">
                        <label>Finish Class</label>
                        <input type="text" class="form-control" name="previous_finish_class" id="previous_finish_class"/>
                     </div>
                  </div>
               </div>
               <h4> 2. Board Exam Info</h4>
               <div class="form-group">
                  <div class="row">
                     <div class="col-sm-3">
                        <label>Exam Name</label>
                        <input type="text" class="form-control" name="exam_name[]" value="" />
                     </div>
                     <div class="col-sm-3">
                        <label>Regi. No</label>
                        <input type="text" class="form-control" name="exam_regi[]" />
                     </div>
                     <div class="col-sm-3">
                        <label>Roll No</label>
                        <input type="text" class="form-control" name="exam_roll[]" />
                     </div>
                     <div class="col-sm-3">
                        <label>GPA</label>
                        <input type="text" class="form-control" name="exam_gpa[]" />
                     </div>
                  </div>
               </div>
               <div class="form-group">
                  <div class="row">
                     <div class="col-sm-3">
                        <input type="text" class="form-control" name="exam_name[]" />
                     </div>
                     <div class="col-sm-3">
                        <input type="text" class="form-control" name="exam_regi[]" />
                     </div>
                     <div class="col-sm-3">
                        <input type="text" class="form-control" name="exam_roll[]" />
                     </div>
                     <div class="col-sm-3">
                        <input type="text" class="form-control" name="exam_gpa[]" />
                     </div>
                  </div>
               </div>
               <div class="form-group">
                  <div class="row">
                     <div class="col-sm-3">
                        <input type="text" class="form-control" name="exam_name[]" />
                     </div>
                     <div class="col-sm-3">
                        <input type="text" class="form-control" name="exam_regi[]" />
                     </div>
                     <div class="col-sm-3">
                        <input type="text" class="form-control" name="exam_roll[]" />
                     </div>
                     <div class="col-sm-3">
                        <input type="text" class="form-control" name="exam_gpa[]" />
                     </div>
                  </div>
               </div>
               <hr />
               <legend><i class="icon32 icon-square-plus"></i>D. Other Info</legend>
               <div class="form-group">
                  <div class="row">
                     <div class="col-sm-4">
                        <label>Blood group</label>
                        <select class="form-control" name="blood_group" id="blood_group" />
                           <option value="">select</option>
                           <option value="AB+">AB+</option>
                           <option value="AB−">AB−</option>
                           <option value="B+">B+</option>
                           <option value="B−">B−</option>
                           <option value="A+">A+</option>
                           <option value="A−">A−</option>
                           <option value="O+">O+</option>
                           <option value="O−">O−</option>
                        </select>
                     </div>
                     <div class="col-sm-4">
                        <label>Class <span style="color:red;">*</span></label>
                        <select class="form-control" name="class_id" id="class_id" onchange="get_class_section_list(this.value); get_class_group_list(this.value);" required>
                           <option value="">----Select Class----</option>
                           <?php foreach($class_list as $cl){ ?>
                           <option value="<?= $cl['class_id'];?>"><?= $cl['class_name'];?></option>
                           <?php } ?>
                        </select>
                     </div>
                     <div class="col-sm-4">
                        <label>Section <span style="color:red;">*</span></label>
                        <select class="form-control" name="section_id" id="section_id" required>
                           <option value="">----Select Section----</option>
                        </select>
                     </div>
                  </div>
               </div>
               <div class="form-group">
                  <div class="row">
                     <div class="col-sm-4">
                        <label>Group <span style="color:red;">*</span></label>
                        <select class="form-control" name="group_id" id="group_id" required>
                           <option value="">----Select Group----</option>
                        </select>
                     </div>
                     <div class="col-sm-4">
                        <label>Session <span style="color:red;">*</span></label>
                        <select class="form-control" name="session_id" id="session_id" required>
                           <option value="">----Select Session----</option>
                           <?php
                              foreach($session_list as $sel){ ?>
                           <option value="<?= $sel['session_id']; ?>" <?php if($sel['session_id']==5) echo "selected"; ?>><?= $sel['session_name']; ?></option>
                           <?php } ?>
                        </select>
                     </div>
                     <div class="col-sm-4">
                        <label>Class Roll </label>
                        <input type="text" class="form-control" name="roll_no" id="roll_no">
                     </div>
                  </div>
               </div>
               <div class="form-group">
                  <div class="row">
                     <div class="col-sm-4">
                        <label>Shift <span style="color:red;">*</span></label>
                        <select class="form-control" name="shift_id" id="shift_id" required>
                           <?php foreach($shift_list as $sl){ ?>
                           <option value="<?= $sl['shift_id'];?>" <?php if($sl['shift_id']==1) echo 'selected'; ?>><?= $sl['shift_name'];?></option>
                           <?php } ?>
                        </select>
                     </div>
                  </div>
               </div>
               <legend><i class="icon32 icon-square-plus"></i>F. Authentication</legend>
               <div class="form-group">
                  <div class="row">
                     <div class="col-sm-4">
                        <label>Password</label>
                        <input type="text" class="form-control" name="password" id="password" value="123456" />
                     </div>
                  </div>
               </div>
               <button type="submit" class="btn btn-primary">Register</button>
            </form>
            </div>
         </div>
      </div>
   </div>
   <div class="">
</section>
<script type="text/javascript">
   function get_class_section_list(class_id)
   {
      $.ajax({
       type: "POST",
       url: baseUrl + 'admin/section_list_ajax',
       data:
       {
           'class_id':class_id
       }, 
       success: function(html_data)
       {
           if (html_data != '')
           {
               $('#section_id').html(html_data);
              // document.getElementById('section_id').value = '1';
           }
       }
       });  
   }
   function get_class_group_list(class_id)
   {
      $.ajax({
       type: "POST",
       url: baseUrl + 'academic/group_list_ajax',
       data:
       {
           'class_id':class_id
       }, 
       success: function(html_data)
       {
           if (html_data != '')
           {
               $('#group_id').html(html_data);
              //document.getElementById('group_id').value = '4';
           }
       }
       });  
   }
   function get_district(div_id,name)
   {
      $.ajax({
       type: "POST",
       url: baseUrl + 'admin/district_list_ajax',
       data:
       {
           'div_id':div_id
       }, 
       success: function(html_data)
       {
           if (html_data != '')
           {
               $('[name='+name+']').html(html_data);
           }
       }
       });  
   }
   function get_upazila(dis_id,name)
   {
      $.ajax({
       type: "POST",
       url: baseUrl + 'admin/upazila_list_ajax',
       data:
       {
           'dis_id':dis_id
       }, 
       success: function(html_data)
       {
           if (html_data != '')
           {
               $('[name='+name+']').html(html_data);
           }
       }
       });  
   }
</script>
<!--For only numeric value can be typeable-->      
<script type="text/javascript">
   var specialKeys = new Array();
   specialKeys.push(8); //Backspace
   function IsNumeric(e) {
      var keyCode = e.which ? e.which : e.keyCode
      var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
      return ret;
   }
</script>
<!--For Calculating Age---->
<script> 
   function myAgeValidation() { 
       var lre = /^\s*/;
       var datemsg = "";    
       var inputDate = document.registerForm.birth_date.value;
       inputDate = inputDate.replace(lre, "");
       document.registerForm.birth_date.value = inputDate;
       datemsg = isValidDate(inputDate);
           if (datemsg != "") {
               alert(datemsg);
               return;
           }
           else {
               //Now find the Age based on the Birth Date
               getAge(new Date(inputDate));
           }
   }
    
   function getAge(birth) { 
       var today = new Date();
       var nowyear = today.getFullYear();
       var nowmonth = today.getMonth();
       var nowday = today.getDate();
    
       var birthyear = birth.getFullYear();
       var birthmonth = birth.getMonth();
       var birthday = birth.getDate();
    
       var age = nowyear - birthyear;
       var age_month = nowmonth - birthmonth;
       var age_day = nowday - birthday;
       
       if(age_month < 0 || (age_month == 0 && age_day <0)) {
               age = parseInt(age) -1;
           }      
       //alert(age);
      document.getElementById('age').value=age; 
   }
    
   function isValidDate(dateStr) {
       var msg = "";    
       var datePat = /^\d{4}-((0\d)|(1[012]))-(([012]\d)|3[01])$/;
    
       var matchArray = dateStr.match(datePat); // is the format ok?
       if (matchArray == null) {
         //  msg = "Date is not in a valid format.";
           return msg;
       }
       crt_date=dateStr.split('-')
       year = crt_date[0]; 
       month = crt_date[1]; // parse date into variables
       day = crt_date[2];
       
       if (month < 1 || month > 12) { // check month range
           msg = "Month must be between 1 and 12.";
           return msg;
       }
    
       if (day < 1 || day > 31) {
           msg = "Day must be between 1 and 31.";
           return msg;
       }
    
       if ((month==4 || month==6 || month==9 || month==11) && day==31) {
           msg = "Month "+month+" doesn't have 31 days!";
           return msg;
       }
    
       if (month == 2) { // check for february 29th
       var isleap = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
       if (day>29 || (day==29 && !isleap)) {
           msg = "February " + year + " doesn't have " + day + " days!";
           return msg;
       }
       }
    
       if (day.charAt(0) == '0') day= day.charAt(1);
       return msg;  // date is valid
   }
    window.onload=function(){
      $('#check_address').click(function() {
         if(this.checked){
         $('.permanent_address').hide('slow');
         }
         else{
            $('.permanent_address').show('slow');
         }
      });
      //get_class_section_list('1');
      //get_class_group_list('4');
    }
    
    function handleFileSelect(evt) {
       var files = evt.target.files; // FileList object
   
       // Loop through the FileList and render image files as thumbnails.
       for (var i = 0, f; f = files[i]; i++) {
   
         // Only process image files.
         if (!f.type.match('image.*')) {
           continue;
         }
   
         var reader = new FileReader();
   
         // Closure to capture the file information.
         reader.onload = (function(theFile) {
           return function(e) {
             // Render thumbnail.
             var span = document.createElement('span');
             span.innerHTML = ['<img class="thumb" height="200" width="200" src="', e.target.result,
                               '" title="', escape(theFile.name), '"/>'].join('');
             document.getElementById('list').innerHTML=span.innerHTML;
           };
         })(f);
   
         // Read in the image file as a data URL.
         reader.readAsDataURL(f);
       }
     }
   
     document.getElementById('student_image').addEventListener('change', handleFileSelect, false);
</script>
<?php include 'application/views/home/inc/footer.php';?>