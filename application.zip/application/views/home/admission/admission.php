<?php include 'application/views/home/inc/header.php';?>
<!-- Primary Starts -->
<section id="primary" class="content-full-width grey1">

  <div class="container py-4 min-height bg-white">
     <div class="row">
        <div class="col-md-12">
           <div class="card">
              <div class="card-header hr-title dt-sc-hr-invisible-small curl">
      <h2><i class="fa fa-list" aria-hidden="true"></i> Admission Information</h2>
      <div class="title-sep"></div>

              </div>
              <div class="card-body">
                 
              </div>
           </div>
        </div>
     </div>
  </div>

</section>
<?php include 'application/views/home/inc/footer.php';?>

