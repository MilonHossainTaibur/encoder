<?php include 'application/views/home/inc/header.php';?>
<style>
   .tab-pane{
   min-height:300px;
   }
</style>
<section class="content-full-width">
<div class="container min-height py-4 bg-white">   
   <div class="row">
      <div class="col-md-12">
              <div class="card">
               <div class="card-header hr-title dt-sc-hr-invisible-small curl">
                 <h1>Guardian Panel<span class="pull-right"><a class="btn btn-danger" href="<?= base_url() ?>home/logout">Logout</a></span></h1>
               </div>
               <div class="card-body">
                 <div class="panel widget-main">
            <div class="panel-heading">
            <div class="">
               
            </div></div>
            <div class="panel-body">
               <ul class="nav nav-pills" style="font-size:20px;">
                  <li class="active studentinfo" onclick="get_data('stu_info')"><a data-toggle="pill" href="#stu_info">Student Information </a></li>
                  <li onclick="get_data('attendance')"><a data-toggle="pill" href="#attendance">Attendence</a></li>
                  <li onclick="get_data('fees_info')"><a data-toggle="pill" href="#fees_info">Fees</a></li>
                  <li onclick="get_data('result')"><a data-toggle="pill" href="#result">Result</a></li>
                  <li onclick="get_data('teacher_comment')"><a data-toggle="pill" href="#teacher_comment">Teachers Comment</a></li>
               </ul>
               <div class="tab-content">
                  <div id="stu_info" class="tab-pane fade in active">
                     <div class="cssload-thecube">
                        <div class="cssload-cube cssload-c1"></div>
                        <div class="cssload-cube cssload-c2"></div>
                        <div class="cssload-cube cssload-c4"></div>
                        <div class="cssload-cube cssload-c3"></div>
                     </div>
                  </div>
                  <div id="attendance" class="tab-pane fade">
                     <div class="cssload-thecube">
                        <div class="cssload-cube cssload-c1"></div>
                        <div class="cssload-cube cssload-c2"></div>
                        <div class="cssload-cube cssload-c4"></div>
                        <div class="cssload-cube cssload-c3"></div>
                     </div>
                  </div>
                  <div id="fees_info" class="tab-pane fade">
                     <div class="cssload-thecube">
                        <div class="cssload-cube cssload-c1"></div>
                        <div class="cssload-cube cssload-c2"></div>
                        <div class="cssload-cube cssload-c4"></div>
                        <div class="cssload-cube cssload-c3"></div>
                     </div>
                  </div>
                  <div id="result" class="tab-pane fade">
                     <div class="cssload-thecube">
                        <div class="cssload-cube cssload-c1"></div>
                        <div class="cssload-cube cssload-c2"></div>
                        <div class="cssload-cube cssload-c4"></div>
                        <div class="cssload-cube cssload-c3"></div>
                     </div>
                  </div>
                  <div id="teacher_comment" class="tab-pane fade">
                     <div class="cssload-thecube">
                        <div class="cssload-cube cssload-c1"></div>
                        <div class="cssload-cube cssload-c2"></div>
                        <div class="cssload-cube cssload-c4"></div>
                        <div class="cssload-cube cssload-c3"></div>
                     </div>
                  </div>
               </div>
            </div>
               </div>
            </div>


         
         </div>
      </div>
   </div>
</section>
<script>
   window.onload=function(){
   $('.studentinfo').click();
   }
     function get_data(tab_content){
   $.ajax({
   type: 'GET',			
         url: baseUrl+'guardian_panel/student_data',
         data:
             {
                 
             }, 
             dataType: 'json',
             success: function(data)
             {
                 result                = ''+data['result']+'';
                 mainContent           = ''+data['mainContent']+'';
   
                 if(result == 'success')
                 {   
                     $('#stu_info').html(mainContent);     
                 }                
             },
   	error: function(e){
   	   alert(e.message);
   	}
   	
         });
         return false; // keeps the page from not refreshing     		
   }
</script>
<?php include 'application/views/home/inc/footer.php';?>

