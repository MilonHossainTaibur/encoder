<?php include 'application/views/home/inc/header.php';?>
<link href="<?= base_url() ?>template/css/jquery-ui.min.css" type="text/css" rel="stylesheet" />
<section id="primary" class="content-full-width grey1">
   <div class="container min-height py-4 bg-white">
    <div class="row">
      <div class="col-md-12">
                    <div class="card">
               <div class="card-header hr-title dt-sc-hr-invisible-small curl">
                 <h3>Student Attendance</h3>
            <div class="title-sep"> </div>
               </div>
               <div class="card-body">


         <div class="">


                        <form class="dt-sc-search-form" method="post" action="">
                          <div class="form-group row">
                            <div class="col-md-12">
                              <input class="form-control" id="student_att" type="text" name="input_date" placeholder="YY-MM-DD"/>
                            </div>
                          </div>
                          <div class="form-group row">
                            <div class="col-md-12">
                            <button style="color:#FFF;" class="button btn btn-info btn-block" value="Check available time" type="button"  onclick="student_for_att_report_daily_json()">Search  </button>
                          </div>
                          </div>
                           
                           
                        </form>


         </div>
         <hr/>
         <div class="widget-content padding">
            <div id="display">
            </div>
         </div>
      </div>
      

            </div>
      </div>
    </div>

      
   </div>
</section>
<script src="<?= base_url() ?>template/js/jquery-ui.min.js" type="text/javascript"></script>
<script>
   $( function() {
    $( "#student_att" ).datepicker();
  } );

</script>
<?php include 'application/views/home/inc/footer.php';?>
<script>
   // get the student daily att report
   	function student_for_att_report_daily_json()
   	{
   		var att_date = $('[name=input_date]').val();
   		
           $.ajax({ 
           url: baseUrl+'home/student_for_att_report_daily_json',
           data:
               {                  
                   'att_date':att_date
               }, 
               dataType: 'json',
               success: function(data)
               {
                   result                = ''+data['result']+'';
                   mainContent           = ''+data['mainContent']+'';
   
                   if(result == 'success')
                   {            
                       $('#display').html(mainContent);     
                   }                
               },
   			error: function(e){
   			   alert(e.message);
   			}
           });
           return false; // keeps the page from not refreshing     
       }
       
       //print all report
   	function printPageArea(areaID){
   		var printContent = document.getElementById(areaID);
   		var WinPrint = window.open('', '', 'width=900,height=650');
   		WinPrint.document.write('<link rel="stylesheet" type="text/css" href="<?= base_url();?>template/libs/bootstrap/css/bootstrap.min.css" media="print" />');
   		WinPrint.document.write('<style type="text/css" media="print"> @page { font-size:12px; } table{font-size:12px;} table td{padding:3px;} .print_button{ display:none;} .header-div-box{display:inline-block;} .header-div-box.box-left{float:left; margin-bottom:10px;} .header-div-box.box-right{float:right;}</style>');
   		WinPrint.document.write(printContent.innerHTML);
   		WinPrint.document.close();
   		WinPrint.focus();
   		WinPrint.print();
   		WinPrint.close();
   	}
   	
</script>

