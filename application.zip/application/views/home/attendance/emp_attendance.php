<?php include 'application/views/home/inc/header.php';?>
<link href="<?= base_url() ?>template/css/jquery-ui.min.css" type="text/css" rel="stylesheet" />
<section class="content-full-width grey1">
      <div class="container min-height py-4 bg-white">
        <div class="row">
          <div class="col-md-12">
                 <div class="card">
               <div class="card-header hr-title dt-sc-hr-invisible-small curl">
                 <h2>Teacher's Attendence</h2>
            <div class="title-sep"> </div>
               </div>
               <div class="card-body">
                 <div class="">

  
                        <form method="post" action="">
                          <div class="form-group row">
                            <div class="col-md-12">
                              <label for="teacher_att"> Date (YY-MM-DD)</label>
                              <input class="form-control" id="teacher_att" type="text" name="input_date" placeholder="YY-MM-DD" />

                            </div>
                          </div>
                          <div class="form-group row">
                            <div class="col-md-12">
                              <button style="color:#FFF;" class="button btn btn-info btn-block" value="Check available time" type="button"  onclick="teacher_att_report_json('d')">Search Teacher Attendance </button>

                            </div>
                          </div>

                           
                        </form>


         </div>
         <hr/>
         <div class="widget-content padding">
            <div id="display">
               <!---JSON Content will be displayed here--->
            </div>
         </div>
               </div>

            </div>
          </div>
        </div>
      </div>
</section>
<script src="<?= base_url() ?>template/js/jquery-ui.min.js" type="text/javascript"></script>
<script>

  $( function() {
    $( "#teacher_att" ).datepicker();
  } );
</script>
<?php include 'application/views/home/inc/footer.php';?>
<script>
   // get the student monthly report
    function teacher_att_report_json(report_type)
    {
      var input_date = $('[name=input_date]').val();
      var month_id = $('#month_id').val();
      var teacher_id = $('#teacher_id').val();
      var teacher_name = $( "#teacher_id option:selected" ).text();
      var month_name = $( "#month_id option:selected" ).text();
      //var teacher_name_json=<?= json_encode($teacher_list); ?>;
      //alert(teacher_name_json); 
           $.ajax({ 
           url: baseUrl+'home/teacher_att_report_json',
           data:
               {                  
                   'att_date':input_date,
                   'month_id':month_id,
                   'teacher_id':teacher_id,
                   'teacher_name':teacher_name,
                   'month_name':month_name,
                   //'teacher_name_json':teacher_name_json,
      'report_type':report_type
               }, 
               dataType: 'json',
               success: function(data)
               {
                   result                = ''+data['result']+'';
                   mainContent           = ''+data['mainContent']+'';
   
                   if(result == 'success')
                   {  //alert(mainContent);          
                       $('#display').html(mainContent);     
                   }                
               }
           });
           return false; // keeps the page from not refreshing     
       }
    
    //print all report
    function printPageArea(areaID){
      var printContent = document.getElementById(areaID);
      var WinPrint = window.open('', '', 'width=900,height=650');
      WinPrint.document.write('<link rel="stylesheet" type="text/css" href="<?= base_url();?>template/libs/bootstrap/css/bootstrap.min.css" media="print" />');
      WinPrint.document.write('<style type="text/css" media="print"> @page { font-size:12px; } table{font-size:12px;} table td{padding:3px;} .print_button{ display:none;} .header-div-box{display:inline-block;} .header-div-box.box-left{float:left; margin-bottom:10px;} .header-div-box.box-right{float:right;}</style>');
      WinPrint.document.write(printContent.innerHTML);
      WinPrint.document.close();
      WinPrint.focus();
      WinPrint.print();
      WinPrint.close();
    }
</script>

