<?php include 'application/views/home/inc/header.php';?> 
<!-- **Full-width-section - Starts** -->
<div class="full-width-section grey1">
   <div class="container py-4 min-height bg-white">
      <div class="card">
         <div class="card-header hr-title dt-sc-hr-invisible-small curl">
            <h3>Managing Committee</h3>
         <div class="title-sep"> </div>
         </div>
         <div class="card-body">
            <table class="table table-striped table-bordered">
               <thead>
                  <tr>
                     <th>SL</th>
                  <th>Name</th>
                  <th>Designation</th>
                  <th>Photo</th>
                  </tr>
               </thead>
               <tbody>
                  <?php foreach($member_list as $key=>$member){ ?>
                  <tr>
                     <td><?=$key+1  ?></td>
                     <td><?= $member['member_name']?></td>
                     <td><?= $member['member_desig']?></td>
                     <td><img class="img-fluid" src="<?= base_url() ?>upload/managing_committee/<?= $member['member_image']?>" width="100" alt="<?= $member['member_name']?>"/></td>
                  </tr>
                  <?php } ?>  
               </tbody>
            </table>
      </div>     
      </div>
   </div>
</div>
<!-- **Full-width-section - Ends** -->
<?php include 'application/views/home/inc/footer.php';?>

