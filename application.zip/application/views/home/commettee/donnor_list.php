<?php include 'application/views/home/inc/header.php';?>
<div class="full-width-section">
<div class="container min-height py-4 bg-white">
   <div class="row">
      <div class="col-md-12">
         
            <div class="card">
               <div class="card-header hr-title dt-sc-hr-invisible-small curl">
                  <h3><i class="fa fa-list-ul" aria-hidden="true"></i>Donor List</h3>
         <div class="title-sep"> </div>
               </div>
               <div class="card-body">
                  <div class="table-responsive">
         <table class="table table-striped table-hover">
            <thead>
               <tr>
                  <th>Member Name</th>
                  <th>Phone Number</th>
                  <th>Address</th>
               </tr>
            </thead>
            <tbody>
               <?php foreach($donor_list as $sl){ ?>
               <tr>
                  <td><?= $sl['donnor_name'];?></td>
                  <td><?= $sl['donnor_phone'];?></td>
                  <td><?= $sl['donnor_address'];?></td>
               </tr>
               <?php    } ?>        
            </tbody>
         </table>
      </div>
               </div>

            </div>
      </div>
   </div>
</div>
<?php include 'application/views/home/inc/footer.php';?>

