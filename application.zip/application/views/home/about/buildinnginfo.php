<?php include 'application/views/home/inc/header.php';?>
<!-- **Full-width-section - Starts** -->       
<div class="full-width-section">
   <div class="container py-4 min-height bg-white">
      <div class="row">
         <div class="col-md-12">
            
            <div class="card">
               <div class="card-header hr-title dt-sc-hr-invisible-small curl">
                   <h3><i class="fa fa-info" aria-hidden="true"></i>Building Information</h3>
         <div class="title-sep"> </div>
               </div>
               <div class="card-body">
                  <div class="table-responsive">
      <table class="table table-striped">
         <thead>
            <tr>
               <th>Name of Building</th>
               <th>Total</th>
               <th>Number of Rooms</th>
            </tr>
         </thead>
         <tbody>
            <tr>
               <td>Administrative Building</td>
               <td>1</td>
               <td>4</td>
            </tr>
            <tr>
               <td>Academic Building</td>
               <td>1</td>
               <td>4</td>
            </tr>
            <tr>
               <td>Auditorium</td>
               <td>1</td>
               <td>1</td>
            </tr>
            <tr>
               <td>Science/Computer lab</td>
               <td>1</td>
               <td>2</td>
            </tr>
            <tr>
               <td>Library</td>
               <td>1</td>
               <td>1</td>
            </tr>
         </tbody>
      </table>
      </div>
               </div>

            </div>
         </div>
      </div>
   </div>

</div>
<!-- **Full-width-section - Ends** --> 
<?php include 'application/views/home/inc/footer.php';?>

