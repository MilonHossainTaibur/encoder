<?php include 'application/views/home/inc/header.php';?>
<div class="full-width-section">
   <div class="container py-4 min-height  bg-white">
      <div class="row">
         <div class="col-md-12">
            <div class="card">
         <div class="card-header hr-title dt-sc-hr-invisible-small curl">
            <h3><i class="fa fa-user-circle" aria-hidden="true"></i>
            History
         </h3>
          <div class="title-sep"> </div>
         </div>
         <div class="card-body">
            <div class="float-left mr-2 mb-2">
            <img class="img-fluid img-thumbnail msg-img" src="<?= base_url() ?>upload/message/<?= $about['about_image'];?>">
            <?php echo $about['about_details']; ?>
         </div>
         <!-- **column - Ends**
         -->
         <!--p class="text-dark">
            The establishment of the school started at the last of 1967 but class activities began in January 1968.
            After the first steps as pioneer to establish the school had been taken by Late Abdul Khalek Member (The Founder of the School),
            Late Abdul Baten Pramanik Donated 17.50 acres of Lands for the school with black and white as first donor.
           <br>
         </p>
          <br><br>
         <hr>
         <p class="text-dark"> Many honourable and well wiser Persons were involved to go on the work especially those who are:</p>
         <ul class="list-unstyled text-dark">
            <li>1.Md. Ashraf Ali Sarkar,</li>
            <li>2. Md. Asrab Ali</li>
            <li>3.Md. Abdul Kadir Prodhan</li>
            <li>4.Md. Kuddos Sarkar</li>
            <li>5. Md. Abul Kashem Pramanik</li>
            <li>6. Md. Abdul Kadir Pramanik</li>
            <li>7. Md. Oazed Pramanik</li>
            <li>8. Md. Ashaduzzaman Pramanik</li>
            <li>9.Md. Kuddos Pramanik</li>
            <li>10. MD. Ahammad Ali Kazi</li>
            <li>11. Md. Shiraj Uddin </li>
         </ul>
         <hr>
         <p class="text-dark">
   With the Spontaneous help of mentioned above all and the people of the all around,
         it had been possible to establish the school. The school has been run under 
         the Leadership of several brilliant and experienced head teachers and worthy
         managing committee since 1968, Just after the birth. The present head teacher
         Mr. Ali Monsur Manik took the liability of the school in 12/07/2010. 
</p>
         <p class="text-dark">
            The result of all public exams including J.S.C and S.S.C are very excellent.
         The head teacher is always very serious about the school. Under his sensible 
         and wisely leadership and for the active participation of all the teachers 
         and Jobholders, the school is now in its golden age with the achievements in 
         the field of results, infrastructure, games and sports, cultural activities
         and so on.
         </p-->
            
         </div>
      </div>
         </div>
      </div>

      <!-- **column - Starts** -->
      <div class="column first justify">
         
       <div>
         
        
          
       </div>


      </div>
   </div>
</div>

<?php include 'application/views/home/inc/footer.php';?>

