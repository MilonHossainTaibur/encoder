<?php include 'application/views/home/inc/header.php';?>
<!-- **Full-width-section - Starts** -->       
<div class="full-width-section grey1">
  <div class="container py-4 min-height bg-white">
    <div class="card">
      <div class="card-header hr-title dt-sc-hr-invisible-small curl">
        <h3><i class="fa fa-desktop" aria-hidden="true"></i> Computer Lab</h3>
      <div class="title-sep"> </div>
      </div>
      <div class="card-body">
        <div class="table-responsive">
          <table class="table table-striped">
    <thead>
      <tr>
      <th>SL</th>
        <th>Description</th>
        <th>Amount</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>1</td>
        <td>Desktop Computers</td>
        <td>6</td>
      </tr>
      <tr>
        <td>2</td>
        <td>Laptop Computers</td>
        <td>9</td>
      </tr>
       <tr>
        <td>3</td>
        <td>Projector</td>
        <td>2</td>
      </tr>
       <tr>
        <td>4</td>
        <td>Speakers</td>
        <td>8</td>
      </tr>
    </tbody>
  </table>
        </div>
        
      </div>
    </div>


  </div>
</div>
<!-- **Full-width-section - Ends** --> 
<?php include 'application/views/home/inc/footer.php';?>