<?php include 'application/views/home/inc/header.php';?>
<section id="primary" class="content-full-width grey1">
   <div class="container py-4 min-height bg-white">
      <div class="row">
         <div class="col-md-12">
            <div class="hr-title dt-sc-hr-invisible-small curl p-2 color-2">
            <h3 class="text-white"><i class="fa fa-envelope-o" aria-hidden="true"></i> Write Your Message</h3>
            <div class="title-sep">
            </div>
         </div>
            <div class="row">
               <div class="col-md-4">
            <div class="">
            <div class="bg-white px-2 py-3 border mb-1 bg-white">
               <h5 class="py-2"><i class="fa fa-address-book" aria-hidden="true"></i>&nbsp; Address</h5>

               <p class="text-dark">
                  Postoffice: Telihaty, Upozila: Sreepur, Zila: Gazipur
               </p>
            </div>
            <div class="contact-icon px-2 py-3 border mb-1 bg-white">
               <p class="text-dark"><span class="fa fa-phone"></span>&nbsp; +880 1511-125125</p>
            </div>
            <div class="contact-icon px-2 py-3 border mb-1 bg-white">
               <p class="text-dark"><span class="fa fa-envelope"></span> &nbsp; 
                  <a href="mailto:kapasia@gmail.com">telihaty@gmail.com</a>.<br>
               </p>
            </div>
            <div class="contact-icon px-2 py-3 mb-1 border bg-white">
               <p class="text-dark"><span class="fa fa-globe"></span> <a href="http://thsict.edu.bd"> http://thsict.edu.bd</a></p>
            </div>
         </div>
         </div>
         <div class="col-md-8">      
         <form method="post" class="dt-sc-contact-form" action="" >
            <div class="form-group row">
               <div class="col-md-4">
                  <input type="text" placeholder="Name*" name="data[p_name]" value="" required class="form-control"/>
               </div>
               <div class="col-md-4">
                  <input type="email" placeholder="Email*" name="data[p_email]" value="" required  class="form-control"/>
               </div>
               <div class="col-md-4">
                  <input type="text" placeholder="Phone*" name="data[p_phone]" required value=""  class="form-control"/>
               </div>
               
            </div>
            <div class="form-group row">
               <div class="col-md-12">
                  <textarea placeholder="Write Your Message" value="" placeholder="" name="data[p_text]" cols="10" rows="10" required  class="form-control"></textarea>
               </div>
            </div>
            <div class="form-group row">
               <div class="col-md-12 m-auto">
                  <input type="submit" class="btn btn-info btn-block" value="Send" name="submit" />
               </div>
            </div>
         </form>
         <div id="ajax_contact_msg"></div>
         </div>
            </div>
         </div>       
      </div>
      <div class="map py-4">
         <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3637.2429548702935!2d90.42127711499127!3d24.26824318433667!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x375670ef4a40ddf9%3A0x3871f628d29cbcb7!2sTelihaty+High+School!5e0!3m2!1sen!2s!4v1492417926487" width="100%" height="500" frameborder="0" style="border:0" allowfullscreen></iframe>   
      </div>  
   </div>    
</section>
<?php include 'application/views/home/inc/footer.php';?>

