<?php include 'application/views/home/inc/header.php';?>
<!-- **Full-width-section - Starts** -->       
<div class="full-width-section grey1">
  <div class="container py-4 min-height bg-white">
    <div class="row">
      <div class="col-md-12">
        <div class="card">
        <div class="card-header hr-title dt-sc-hr-invisible-small curl">
          <h3> Land Information</h3>
      <div class="title-sep"> </div>
        </div>
        <div class="card-body">
        </div>
      </div>
      </div>
    </div>
  </div>
</div>
<!-- **Full-width-section - Ends** --> 
<?php include 'application/views/home/inc/footer.php';?>

