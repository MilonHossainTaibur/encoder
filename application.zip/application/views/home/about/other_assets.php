<?php include 'application/views/home/inc/header.php';?>
<!-- **Full-width-section - Starts** -->       
<div class="full-width-section grey1">
  <div class="container min-height py-4 bg-white">

    <div class="row">
      <div class="col-md-12">
        

            <div class="card">
               <div class="card-header hr-title dt-sc-hr-invisible-small curl">
                 <h3> Details of other Assets </h3>
                 <div class="title-sep"> </div>
               </div>
               <div class="card-body">
                 <div class="table-responsive">
                   <table class="table table-striped">
    <thead>
      <tr>
      <th>SL</th>
        <th>Details</th>
        <th>Amount </th>
        
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>1</td>
        <td>Table</td>
        <td>34</td>
        
      </tr>
      <tr>
        <td>1</td>
        <td>Chair</td>
        <td>48</td>
        
      </tr>
      <tr>
        <td>2</td>
        <td>Pair Bench</td>
        <td>250</td>
        
      </tr>
      <tr>
        <td>3</td>
        <td>Sophaseta</td>
        <td>3</td>
        
      </tr>
      <tr>
        <td>4</td>
        <td>shop</td>
        <td>2</td>
        
      </tr>
      <tr>
        <td>5</td>
        <td>Generator</td>
        <td>1</td>
        
      </tr>
      <tr>
        <td>6</td>
        <td>IPS</td>
        <td>1</td>
        
      </tr>
      <tr>
        <td>7</td>
        <td>UPS</td>
        <td>1</td>
        
      </tr>
      <tr>
        <td>8</td>
        <td>Water Filters</td>
        <td>1</td>
      </tr>
      <tr>
        <td>9</td>
        <td>Globe</td>
        <td>5</td>
      </tr>
       <tr>
        <td>10</td>
        <td>Map</td>
        <td>10</td>
      </tr>
       <tr>
        <td>11</td>
        <td>Geometry Sets</td>
        <td>5</td>
      </tr>
     <tr>
        <td>12</td>
        <td>Scientific Instruments Sets</td>
        <td>2</td>
      </tr>
      <tr>
        <td>13</td>
        <td>Playground Equipment Set</td>
        <td>4</td>
      </tr>
       <tr>
        <td>14</td>
        <td>Electric fan</td>
        <td>80</td>
      </tr>
       <tr>
        <td>15</td>
        <td>Television Sets</td>
        <td>1</td>
      </tr>
       <tr>
        <td>16</td>
        <td>Type Writer</td>
        <td>1</td>
      </tr>
       <tr>
        <td>17</td>
        <td>Watch</td>
        <td>32</td>
      </tr>
        <tr>
        <td>18</td>
        <td>Music Instrument</td>
        <td>2</td>
      </tr>
        <tr>
        <td>19</td>
        <td>Water Pump</td>
        <td>3</td>
      </tr>
    </tbody>
  </table>
                 </div>
               </div>

            </div>
      </div>
    </div>
  </div>
</div>
<!-- **Full-width-section - Ends** --> 
<?php include 'application/views/home/inc/footer.php';?>