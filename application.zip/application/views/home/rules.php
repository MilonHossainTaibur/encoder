<?php include 'application/views/home/inc/header.php';?>
<!-- **Full-width-section - Starts** -->
<div class="full-width-section">
   <div class="container min-height py-4 bg-white">
            <div class="card">
               <div class="card-header hr-title dt-sc-hr-invisible-small curl">
                   <h3> <i class="fa fa-list" aria-hidden="true"></i>
 Rules & Regulations</h3>
         <div class="title-sep"> </div>
               </div>
               <div class="card-body">
                  <h4><?=$rules['information_heading'] ?></h4>
                  <div class="card-text">
                     <?=$rules['information_details'] ?>
                  </div>
               </div>

            </div>    
</div>
   </div>

<?php include 'application/views/home/inc/footer.php';?>

