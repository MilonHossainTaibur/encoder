<?php include 'application/views/home/inc/header.php';?>
<div class="full-width-section">
   
 <div class="container bg-white">
    <div class="row">
        <div class="col-md-12">
                      <div class="card">
               <div class="card-header hr-title dt-sc-hr-invisible-small curl">
                   <h3>Students Taking Part in the Liberation War in 1971</h3>
                        <div class="title-sep"> </div>
               </div>
               <div class="card-body">
                   <div class="portfolio-container with-space  class="gallery clearfix"">
                         <?php foreach($freedom_fighter as $fl){ ?>
                        <div class="portfolio dt-sc-one-fifth with-space column all-sort <?= $images['catagory_id']?>">
                            <div class="portfolio-thumb">
                                <img class="lazy" data-original="<?= base_url()?>upload/freedom_fighter/<?= $fl->f_photo ;?>" src="<?= base_url()?>upload/freedom_fighter/<?= $fl->f_photo ;?>" alt="<?= $fl->f_name;?>"/>
                                <div class="image-overlay">
                                    <a class="zoom" href="<?= base_url()?>upload/freedom_fighter/<?= $fl->f_photo ;?>" data-gal="prettyPhoto[gallery]" title="<?= $fl->f_name;?>"><span class="fa fa-search-plus"></span></a>
                                </div>
                            </div>
                            <div class="portfolio-detail">
                                <div class="portfolio-title">
                                    <p><?= $fl->f_name;?></p>
                     <p><?= $fl->f_address;?></p>
                                </div>
                            </div>
                        </div>
                         <?php } ?>
                    </div>
               </div>
            </div>
        </div>
    </div>
       </div>  
<?php include 'application/views/home/inc/footer.php';?>

