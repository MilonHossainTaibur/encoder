<?php include 'application/views/home/inc/header.php';?>
 
<div class="full-width-section">
<div class="container py-4 min-height bg-white">
   <div class="row">
      <div class="col-md-12">
         <div class="card">
            <div class="card-header hr-title dt-sc-hr-invisible-small curl">
               <h3 class=""><i class="fa fa-comment" aria-hidden="true"></i>
        <?= $messages['name'];?>
      </h3>
      <div class="title-sep"> </div>
            </div>
            <div class="card-body">
               <div class="column first justify">
      <div class="column dt-sc-full" style="margin-right:20px;">
         <img class="img-fluid" width="150px" src="<?= base_url();?>upload/message/<?= $messages['image'];?>">
      </div>
      <div class="text-dark">
         <?= $messages['message'];?>
      </div>
   </div>
            </div>
         </div>
      </div>
   </div>
   </div>
<?php include 'application/views/home/inc/footer.php';?>

