<div class="table-responsive">
	<form class='form-horizontal' role='form' method="POST" action="<?php echo base_url();?>fees/fees_management_edit">
			<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="60%">
				<thead>
					<tr>
						<th>Fees Cat ID</th>
						<th>Particulars</th>
						<th>Amount</th>
						<th>period</th>
					</tr>
				</thead>

			   <tbody>
					<?php
						foreach($fee_management as $fl){ ?>
						<tr>
							<td><input type="text" class="form-control" name="fees_cat_id[]" id="fees_cat_id" value="<?= $fl['fees_cat_id'];?>" readonly></td>
							<td><?php echo $fl['fees_particulars'];?></td>
							<td>
							<input type="text" class="form-control" name="fees_amount[]" id="fees_amount" value="<?php echo $fl['amount'];?>">
							</td>
							<td>	
								<select class="form-control" name="period[]" id="period">
									<?php
                                    foreach($fees_type as $ftl){ ?>
									<option value="<?= $ftl['id']; ?>" <?php if($ftl['id'] == $fl['period']){ echo "selected"; } ?>> <?= $ftl['type'] ?></option>
								<?php } ?>
								</select>
								
							</td>
							</tr>
						   <tr> 
						   
						    <input type="hidden" class="form-control" name="fees_cat_id[]" id="fees_cat_id" value="<?php echo $fl['fees_cat_id'];?>">
						   
						    <input type="hidden" class="form-control" name="fee_mngt_id[]" id="fee_mngt_id" value="<?php echo $fl['fee_mngt_id'];?>">
						   
						    
						   
						</tr>
					<?php 	} ?>
					 
				</tbody>
			</table>
							<input type="hidden" class="form-control" name="class_id[]" id="class_id" value="<?php echo $fl['class_id'];?>">
						   
						    <input type="hidden" class="form-control" name="school_id" id="school_id" value="<?php echo $fl['school_id'];?>">
			<br/>
			<button type="submit" class="btn btn-primary" style="margin-top:3px;margin-left:10px;">Update</button>
	</form>
</div>