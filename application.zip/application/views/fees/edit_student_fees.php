<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
<style>
.btn span.glyphicon {    			
	opacity: 0;				
}
.btn.active span.glyphicon {				
	opacity: 1;				
}
</style>
</div>
<div class="content-page">			
    <div class="content">
        <!-- Page Heading Start -->
        <div class="page-heading">
            <h1><i class='fa fa-check'></i> Student Fees Edit</h1>
        </div>
        <!-- Page Heading End-->
        <!-- Your awesome content goes here -->
        <div class="row">
            <div class="col-sm-12">
                <div class="widget" style="min-height:300px;">
                    <div class="widget-content padding">
                        <form role="form" id="registerForm" method="POST" action="<?= base_url();?>fees/student_fees_edit_save">
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-sm-3">
                                        <label>Billing ID</label>
                                        <input type="text" class="form-control" name="billing_id" value="<?php print_r($fees_details[0]['billing_id']);  ?>" readonly />
                                    </div>
                                    <div class="col-sm-3">
                                        <label>Student ID</label>
                                        <input type="text" class="form-control" name="student_id" value="<?php print_r($fees_details[0]['student_id']);  ?>" readonly />
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-sm-12 col-md-6">
                                        <label>Fees Type :</label>
                                        <table class="table table-striped table-bordered" cellspacing="0" width="100%">
                                            <thead>
                                                <tr>
                                                    <td>Fees Name</td>
                                                    <td>Fees amount</td>
                                                    <td>Applied</td>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
													foreach($fee_management as $ftl):
														$checked='';
														$fees_id='0';
														$amount=$ftl['amount'];
												?>
                                                <tr>
                                                    <td>
                                                        <?php 
															foreach($fees_details as $fdlc):
																if($fdlc['fees_cat_id']==$ftl['fees_cat_id']):
																	$checked='checked';
																	$fees_id=$fdlc['fees_id'];
																	$amount=$fdlc['amount'];
                                                                endif;
															endforeach;
														?>
                                                        <label onClick="fees_change_status(<?= $ftl['fees_cat_id'];?>,<?= $amount;?>,<?= $fees_id ?>)">
															<input type="checkbox" <?= $checked; ?> value="<?= $ftl['fees_cat_id'];?>,<?= $ftl['amount'];?>" class="checkbox<?= $ftl['fees_cat_id'];?>"> <?= $ftl['fees_particulars'];?>
                                                        </label>
                                                    </td>
                                                    <td><label><?= $ftl['amount'];?></label></td>
                                                    <td id="amount_box<?= $ftl['fees_cat_id'];?>">
                                                        <?php foreach($fees_details as $fdl):
                                                                if($fdl['fees_cat_id']==$ftl['fees_cat_id']):
                                                        ?>
                                                            <input type="text" name="amount[]" value="<?= $fdl['amount'];?>" class="form-control amount" onKeyUp="total_fees()"/>
                                                            <input type="hidden" name="fees_cat_id[]" value="<?= $fdl['fees_cat_id'];?>" class="form-control"/>
                                                            <input type="hidden" name="fees_id[]" value="<?= $fdl['fees_id'];?>" class="form-control"/>
                                                        <?php endif; endforeach; ?>
                                                    </td>
                                                </tr>
                                                <?php endforeach; ?>
                                                <tr>
                                                    <td></td>
                                                    <td><label>Total</label></td>
                                                    <td id="amount_total"></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-sm-2"></div>
                                    <div class="col-sm-4">
                                        <input type="hidden" name="class_id" value="<?php print_r($fees_details[0]['class_id']);  ?>" />
                                        <input type="hidden" name="group_id" value="<?php print_r($fees_details[0]['group_id']);  ?>" />
										<input type="hidden" name="shift_id" value="<?php print_r($fees_details[0]['shift_id']);  ?>" />
                                        <input type="hidden" name="session_id" value="<?php print_r($fees_details[0]['session_id']);  ?>" />
                                        <input type="hidden" name="school_id" value="<?php print_r($fees_details[0]['school_id']);  ?>" />
                                        <input type="hidden" name="fees_date" value="<?php print_r($fees_details[0]['fees_date']);  ?>" />
                                        <input type="hidden" name="status" value="<?php print_r($fees_details[0]['status']);  ?>" />
                                        <button type="submit" class="btn btn-primary">Update</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
		<footer> <!-- Footer Start -->
			<?php
				$sql = "SELECT * FROM tbl_school_information LIMIT 1";
				$query = $this->db->query($sql);
				$sc_info = $query->row_array();
			?>
			<center>
				<img src="<?= base_url();?>template/images/logo.png" alt="Copotronic" height="50" width="100" style="margin-bottom: -35px;;"/> 
				<p style="display: block;margin-bottom: -30px;margin-top: 35px;">
					© <?= $sc_info['school_name'];?>, <?= $sc_info['district'];?> 2016.
				</p>                   
			</center>
		</footer>
            <!-- Footer End -->			
    </div><!-- End content here -->
</div><!-- End right content -->
</div>
	<div id="contextMenu" class="dropdown clearfix">
		<ul class="dropdown-menu" role="menu" aria-labelledby="dropdownMenu" style="display:block;position:static;margin-bottom:5px;">
		    <li><a tabindex="-1" href="javascript:;" data-priority="high"><i class="fa fa-circle-o text-red-1"></i> High Priority</a></li>
		    <li><a tabindex="-1" href="javascript:;" data-priority="medium"><i class="fa fa-circle-o text-orange-3"></i> Medium Priority</a></li>
		    <li><a tabindex="-1" href="javascript:;" data-priority="low"><i class="fa fa-circle-o text-yellow-1"></i> Low Priority</a></li>
		    <li><a tabindex="-1" href="javascript:;" data-priority="none"><i class="fa fa-circle-o text-lightblue-1"></i> None</a></li>
		</ul>
	</div>
	<!-- End of page -->
		<!-- the overlay modal element -->
	<div class="md-overlay"></div>
	<!-- End of eoverlay modal -->
<script>
		var resizefunc = [];
</script>
	
	<script src="<?php echo base_url();?>template/libs/jquery/jquery-1.11.1.min.js"></script>
	<script src="<?php echo base_url();?>template/libs/bootstrap/js/bootstrap.min.js"></script>
	<script src="<?php echo base_url();?>template/libs/jqueryui/jquery-ui-1.10.4.custom.min.js"></script>
	<script src="<?php echo base_url();?>template/libs/jquery-ui-touch/jquery.ui.touch-punch.min.js"></script>
	<script src="<?php echo base_url();?>template/libs/jquery-detectmobile/detect.js"></script>
	<script src="<?php echo base_url();?>template/libs/jquery-animate-numbers/jquery.animateNumbers.js"></script>
	<script src="<?php echo base_url();?>template/libs/ios7-switch/ios7.switch.js"></script>
	<script src="<?php echo base_url();?>template/libs/fastclick/fastclick.js"></script>
	<script src="<?php echo base_url();?>template/libs/jquery-blockui/jquery.blockUI.js"></script>
	<script src="<?php echo base_url();?>template/libs/bootstrap-bootbox/bootbox.min.js"></script>
	<script src="<?php echo base_url();?>template/libs/jquery-slimscroll/jquery.slimscroll.js"></script>
	<script src="<?php echo base_url();?>template/libs/jquery-sparkline/jquery-sparkline.js"></script>
	<script src="<?php echo base_url();?>template/libs/nifty-modal/js/classie.js"></script>
	<script src="<?php echo base_url();?>template/libs/nifty-modal/js/modalEffects.js"></script>
	<script src="<?php echo base_url();?>template/libs/sortable/sortable.min.js"></script>
	<script src="<?php echo base_url();?>template/libs/bootstrap-fileinput/bootstrap.file-input.js"></script>
	<script src="<?php echo base_url();?>template/libs/bootstrap-select/bootstrap-select.min.js"></script>
	
	

	<!-- Demo Specific JS Libraries -->
	<script src="<?php echo base_url();?>template/libs/prettify/prettify.js"></script>

	<script src="<?php echo base_url();?>template/js/init.js"></script>


</body>
</html>

<script>
	// this will be called when page loaded
	total_fees();
		
		/* this will change amount 0 if this field is blank
		$( ".amount" ).change(function() {
		  if($(this).val()=='')
		  	$(this).val(0);
		});*/

	// prepare the variable before sent to get the json data
    function fees_change_status(fees_cat_id, amount, fees_id)
    {
		if ($('.checkbox'+fees_cat_id).is(":checked")){
			$('#amount_box'+fees_cat_id).html('<input type="text" name="amount[]" onKeyUp="total_fees()" value="'+amount+'" class="form-control amount"/><input type="hidden" name="fees_cat_id[]" value="'+fees_cat_id+'" class="form-control"/><input type="hidden" name="fees_id[]" value="'+fees_id+'" class="form-control"/>');
			}
		else
			{
				$('#amount_box'+fees_cat_id).html('<input type="hidden" name="amount[]" value="0" class="form-control amount"/><input type="hidden" name="fees_cat_id[]" value="0" class="form-control"/><input type="hidden" name="fees_id[]" value="'+fees_id+'" class="form-control"/>');
			}
		total_fees();
	}
	
	
	// count the total fees
	function total_fees()
	{
		$('#amount_total').html('');
		var total_fees=0;
		$('.amount').each(function(){
				if($(this).val())
				{
					value=parseInt($(this).val());
				}
				else{ value=0; }
				 total_fees+=value;
				
		})
		
		$('#amount_total').html('<label>'+total_fees+'</label>');
	}
	
	
</script>