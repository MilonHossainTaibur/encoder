<div class="table-responsive">
	<div class="col-md-12 padding">
    	<label> Check for all student :</label><br/>
		<?php foreach($fees_mngt_details as $fee_mngt): ?>
              <label class="checkbox-inline">
              <input type="checkbox" class="bulk_check_class<?= $fee_mngt['fees_cat_id']; ?>" onClick="bulk_check('<?= $fee_mngt['fees_cat_id']; ?>')">
                    <?= $fee_mngt['fees_particulars'];?>
              </label>
         <?php endforeach; ?>
         <hr/>
     </div>
	<form role="form" id="registerForm" method="POST" action="<?= base_url();?>fees/fees_generate">
	<input type="hidden" name="class_id" value="<?= $class_id;?>" />
        <input type="hidden" name="group_id" value="<?= $_GET['group_id'];?>" />
        <input type="hidden" name="shift_id" value="<?= $_GET['shift_id'];?>" />
        <input type="hidden" name="session_id" value="<?= $_GET['session_id'];?>" />
        <input type="hidden" name="fees_date" value="<?= $fees_date;?>" />
		<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
			<thead>
				<tr>
					<th style="width:10%;">Student ID</th>
					<th style="width:10%;">Name</th>
					<th style="width:35%;">Fees Name</th>
                    <th style="width:35%;">Fees ID | Amount</th>
                    <th style="width:10%;">Total</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach($student_list as $sl){
					if($old_gen_fees[array_search($sl['student_id'], array_column($old_gen_fees, 'student_id'))]['student_id']!=$sl['student_id']){
				?>
				<tr>
					<td><?= $sl['student_id'];?>
                    	<input type="hidden" name="student_iddfsd[]" id="student_id" value="<?= $sl['student_id'];?>">
                    </td>
					<td> <?= $sl['student_name'];?> </td>
					<td>
                    	<?php foreach($fees_mngt_details as $fee_mngt): ?>
                    	<label class="checkbox-inline">
            				<input name="fees_<?= $sl['student_id'];?>[]" class="fees_<?= $fee_mngt['fees_cat_id'];?> fees_class_<?= $sl['student_id'];?>" type="checkbox" value="<?= $fee_mngt['fees_cat_id'];?>+<?= $fee_mngt['fees_particulars'];?>+<?= $fee_mngt['amount'];?>" onClick="amount('<?= $sl['student_id'];?>','<?= $sl['fees_aid'];?>','<?= $sl['aid_amount'];?>')">
							<?= $fee_mngt['fees_particulars'];?> ( <?= $fee_mngt['fees_cat_id'];?> )
                        </label>
                        <?php endforeach; ?>
					</td>
                    <td><div class="row" id="amount_html<?= $sl['student_id'];?>"></div></td>
                    <td><div class="row" id="amount_total<?= $sl['student_id'];?>"></div></td>
				</tr>
					<?php } } ?>
					<input type="submit" class="btn btn-primary" name="fees_gen" value="Generate Fees"/><br/>	
			</tbody>
		</table>
        
	</form>
</div>