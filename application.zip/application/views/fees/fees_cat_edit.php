<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">			
            <div class="content">
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i> Fees Category Edit</h1>
                </div>
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="widget" style="min-height:300px;">
                           
                            <div class="widget-content padding">
                                <form role="form" id="registerForm" method="POST" action="<?= base_url();?>fees/fees_cat_edit_save" enctype="multipart/form-data">
                                    <br/><br/><br/>
                                    
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-2"></div>
                                            <div class="col-sm-4">
                                                <label>Fees Particulars Name </label>
                                                <input type="text" class="form-control" name="fees_particulars_name" id="fees_particulars_name" value="<?= $fees_particulars['fees_particulars']; ?>">
                                                <input type="hidden" class="form-control" name="fees_cat_id" id="fees_cat_id" value="<?= $fees_particulars['fees_cat_id']; ?>">
                                            </div>
											<div class="col-sm-4">
                                                <label>Acc Head <span style="color:red;">*</span></label>
												<select class="selectpicker" id="acc_head" required name="acc_head" >
													<option value="">-----Select Head-----</option>
													<?php foreach($acc_head as $ah){ ?>
													<option id="<?= $ah['bkdn_code']?>" value="<?= $ah['fcoa_bkdn_id'];?>" <?php if($fees_particulars['acc_head']==$ah['fcoa_bkdn_id']) {echo "selected";}; ?>>
														<?= $ah['bkdn_code'];?>-<?= $ah['fcoa_bkdn'];?>
													</option>
													<?php } ?>
												</select>
												<input type="hidden" name="acc_head_code" id="ahc" value="<?= $fees_particulars['acc_head_code']; ?>">
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-2"></div>
                                            <div class="col-sm-4">
                                                <button type="submit" class="btn btn-primary">Update</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
<?php include 'application/views/includes/footer.php';?>
<script>
window.onload = function () {
	$("#acc_head").change(function() {
	  $('#ahc').val($(this).children(":selected").attr("id"));
	});
};
</script>