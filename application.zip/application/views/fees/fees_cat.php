<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
<div class="content-page">			
    <div class="content">
        <!-- Page Heading Start -->
        <div class="page-heading">
            <h1><i class='fa fa-check'></i> Fees Category</h1>
        </div>
    	<!-- Page Heading End-->
        <?php if($this->session->flashdata('message')):?>
			<?=$this->session->flashdata('message')?>
		<?php endif?>
        <!-- Your awesome content goes here -->
        <div class="row">
            <div class="col-sm-12">
				<div class="widget" style="min-height:500px;">
					<div class="widget-content padding">
						<div class="row">
							<div class="col-md-12">
								<div class="widget">
									<div class="widget-content padding"><a class="btn btn-info" href="javascript:void(0);" onclick="toggle_insertion_box(); return false;"><i class="fa fa-plus" aria-hidden="true"></i>
Add New Fee Category</a>
										<div class="insertion_div">
											<form class='form-horizontal' role='form' method="POST" action="<?php echo base_url();?>fees/fees_cat_save">
												<div class="form-group">
													<div class="row">
														<div class="col-sm-1 col-md-1"></div>
														<div class="col-sm-5 col-md-4" style="margin-right:10px;">
															<div class="form-group">
																<label>Fees Particulars <span style="color:red;">*</span></label>
                                                                <input type="text" class="form-control" name="fees_particulars_name" id="fees_particulars_name" required />
                                                            </div>
														</div>
														<div class="col-sm-6 col-md-5" style="margin-right:10px;">
                                                            <div class="form-group">
																<label>Acc Head <span style="color:red;">*</span></label>
																<select class="selectpicker" id="acc_head" required name="acc_head" >
																	<option value="">-----Select Head-----</option>
																	<?php foreach($acc_head as $ah){ ?>
																	<option id="<?= $ah['bkdn_code']?>" value="<?= $ah['fcoa_bkdn_id'];?>"><?= $ah['bkdn_code'];?>-<?= $ah['fcoa_bkdn'];?></option>
																	<?php } ?>
																</select>
																<input type="hidden" name="acc_head_code" id="ahc">
                                                            </div>
														</div><br/>
                                                        <button type="submit" class="btn btn-primary" style="margin-top:3px;margin-left:10px;">Save</button>
                                                    </div>
												</div>
											</form>
                                        </div>
                                    </div>
                                            
                                    <div class="widget-content">
                                        <table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="90%">
                                            <thead>
                                                <tr>
													<th>Fees ID</th>
                                                    <th>Acc Head</th>
                                                    <th>Particulars</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if($fees_cat): foreach($fees_cat as $tl): ?>
                                                <tr>
                                                    <td><?= $tl['fees_cat_id'];?></td>
                                                    <td><?= $tl['bkdn_code'];?>-<?= $tl['fcoa_bkdn'];?></td>
                                                    <td><?= $tl['fees_particulars'];?></td>
                                                    <td>
                                                        <a href="<?= base_url();?>fees/fees_cat_edit/<?= $tl['fees_cat_id'];?>" title="Edit"><i class="fa fa-edit"></i></a> | 
                                                        <?=anchor("fees/fees_cat_delete/".$tl['fees_cat_id'],"<i class=\"fa fa-remove\"></i>",array('onclick' => "return confirm('Do you want delete this record')"))?>
                                                    </td>
                                                </tr>
                                                <?php endforeach; endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php include 'application/views/includes/footer.php';?>

<script>
window.onload = function () {
	$("#acc_head").change(function() {
	  $('#ahc').val($(this).children(":selected").attr("id"));
	});
};
</script>