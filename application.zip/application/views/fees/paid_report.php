<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
	<div class="content-page">
		<!-- ============================================================== -->
		<!-- Start Content here -->
		<!-- ============================================================== -->
		<div class="content">
			<div class="page-heading">
            	<h1><i class='fa fa-table'></i> Paid Fees Report</h1>
			</div>
			<div class="row">
            	<div class="col-md-12">
                    <div class="widget" style="min-height: 400px">
                        <div class="widget-content">
                            <form role="form" id="registerForm" method="POST">
                                <div class="widget-content padding">
                                    <div class="form-group">
                                    	<div class="row">
                                            <div class="col-sm-4">
                                                <label>Class</label>
                                                    <select class="form-control" name="class_id" id="class_id" onchange="get_class_group_list(this.value);">
                                                        <option value="">-----Select Class-----</option>
                                                        <?php foreach($class_list as $cl){ ?>
                                                        <option value="<?php echo $cl['class_id'];?>"><?php echo $cl['class_name'];?></option>
                                                        <?php  } ?>
                                                    </select>
                                            </div>
                                            <div class="col-sm-4">
                                             	<label>Group</label>
                                                	<select class="form-control" name="group_id" id="group_id" required />
                                                    	<option value="">-----Select Group-----</option>
                                                    </select>
                                            </div>
                                            <div class="col-sm-4">
                                            	<label>Session</label>
                                                <select class="form-control" name="session_id" id="session_id">
                                                	<option value="">-----Select Session-----</option>
                                                    <?php
                                                    	foreach($session as $sl){ ?>
                                                    <option value="<?= $sl['session_id'];?>"><?= $sl['session_name'];?></option>
                                                    <?php    } ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                    	<div class="row">
                                            <div class="col-sm-4">
                                            <?php
												$month=array(1=>"January",2=>"February",3=>"March",4=>"April",5=>"May",6=>"June",7=>"July",8=>"August",9=>"September",10=>"October",11=>"November",12=>"December");
												$currentmonth = date("m");
											?>
                                            	<label>Month</label>
                                                	<select class="form-control" name="fees_month" id="fees_month">
                                                    	<?php foreach($month as $key => $value): ?>
														<option value="<?= $key;?>" <?php if($key==$currentmonth) echo "selected"?> > <?= $value;?> </option>
														<?php endforeach; ?>
                                                    </select>
                                            </div>
                                            <div class="col-sm-4">
                                            	<?php  $currentDate = date("Y"); 
														for ($edb=0; $edb<=1; $edb++)
															 {
																 $examdate[$edb]=$currentDate-$edb;
															 }
														$examdate=array_reverse($examdate);
														$count=6;
														for ($eda=1; $eda<=1; $eda++)
															{
																$examdate[$count]=$currentDate+$eda;
																$count++; 
															}
												?>
												<label>Year</label>
													<select class="form-control" required name="fees_year" id="fees_year">
														<option value="">Select</option>
														<?php foreach($examdate as $ed): ?>
														<option value="<?php echo $ed;?>"<?php if($ed==$currentDate) echo "selected"?>><?php echo $ed;?></option>
														<?php endforeach ?>
													</select>
                                            </div>
                                        </div>
                                    </div>
                                     
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <button type="button" class="btn btn-primary" onclick="fees_collect_paid_report_json()">Show Students</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
								 <hr/>
                                                                    
                                <div id="display">
                                	<!---JSON Content will be displayed here--->
                                </div>
                            </div>
                        </div>
                    </div>
				</div>

				
				
<?php include 'application/views/includes/footer.php';?>

<script>
	function get_class_group_list(class_id)
	{
	   $.ajax({
		type: "POST",
		url: baseUrl + 'academic/group_list_ajax',
		data:
		{
			'class_id':class_id
		}, 
		success: function(html_data)
		{
			if (html_data != '')
			{
				$('#group_id').html(html_data);
			}
		}
		});  
	}

	// get the student list and fees list 
	function fees_collect_paid_report_json()
	{
		var class_id = $('#class_id').val();
		var group_id = $('#group_id').val();
		var session_id = $('#session_id').val();
		var fees_month = $('#fees_month').val();
		var fees_year = $('#fees_year').val();
        $.ajax({ 
        url: baseUrl+'fees/fees_collect_paid_report_json',
        data:
            {                  
                'session_id':session_id,
				'class_id':class_id,
				'group_id':group_id,
				'fees_month':fees_month,
				'fees_year':fees_year
            }, 
            dataType: 'json',
            success: function(data)
            {
                result                = ''+data['result']+'';
                mainContent           = ''+data['mainContent']+'';

                if(result == 'success')
                {            
                    $('#display').html(mainContent);     
                }                
            }
        });
        return false; // keeps the page from not refreshing     
    }

	
	function printPageArea(areaID){
		var printContent = document.getElementById(areaID);
		var WinPrint = window.open('', '', 'width=900,height=650');
		WinPrint.document.write('<link rel="stylesheet" type="text/css" href="<?= base_url();?>template/libs/bootstrap/css/bootstrap.min.css" media="print" />')
		WinPrint.document.write(printContent.innerHTML);
		WinPrint.document.close();
		WinPrint.focus();
		WinPrint.print();
		WinPrint.close();
	}

</script>