<div class="pull-left col-sm-4">
<label> Bulk Paid/Unpaid (Effected on checked row)</label><br/>
<button type="button" class="btn btn-danger" title="Change all checked row to unpaid" onclick="fees_change_status_bulk('0')">Unpaid</button>
<button type="button"  title="Change all checked row to paid"  class="btn btn-info" onclick="fees_change_status_bulk('1')">Paid</button>
<hr/>
</div>
<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
	<thead>
		<tr>
        	<th><label><input type="checkbox" id="bulk_check"></label></th>
            <th>Billing ID</th>
            <th>Student ID</th>
            <th>Month-Year</th>
			<th>Fee Details</th>
            <th>Total</th>
            <th>Status</th>
            <th>Change Status To</th>
            <th>Actions</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach($fees_details as $fdl): ?>
		<tr>
        	<th><input type="checkbox" class="bulk_check" value="<?= $fdl['billing_id'] ?>"></th>
			<td><?= $fdl['billing_id'] ?></td>
            <td><?= $fdl['student_id'] ?></td>
            <td><?= date('M-Y',strtotime($fdl['fees_date'])) ?></td>
            <td><?= $fdl['fees_details'] ?></td>
            <td><?= $fdl['total_amount'] ?></td>
             <td class="status<?= $fdl['billing_id'] ?>">
				<?php if($fdl['status']==0): ?>
                	<label>Unpaid</label>
                <?php else: ?>
                	<label>Paid</label>
                <?php endif; ?>
            </td>
            <td id="status_change<?= $fdl['billing_id'] ?>">
				<?php if($fdl['status']==1): ?>
                	<button type="button" class="btn btn-danger" onclick="fees_change_status('0','<?= $fdl['billing_id'] ?>')">Unpaid</button>
                <?php else: ?>
                	<button type="button" class="btn btn-info" onclick="fees_change_status('1','<?= $fdl['billing_id'] ?>')">Paid</button>
                <?php endif; ?>
            </td>
            <td><?php if($_GET['edit_option']==1): ?>
            	<a href="<?= base_url();?>fees/edit_student_fees/<?= $fdl['billing_id'] ?>/<?= $_GET['class_id'] ?>/<?= $_GET['group_id'] ?>/<?= $_GET['shift_id'] ?>/<?= $_GET['session_id'] ?>" title="Edit"><i class="fa fa-edit"></i></a>
				<?php endif; ?>
		<a href="#" onclick="get_fees_recept('','<?= $fdl['billing_id'] ?>','<?= $fdl['mobile_contact'] ?>','<?= $fdl['total_amount']?>')"><i class="fa fa-print"></i></a>
        	</td>
		</tr>
		<?php endforeach; ?>
	</tbody>
</table>

<script>
// check all checkbox just one click
$("#bulk_check").change(function(){
    var status = $(this).is(":checked") ? true : false;
    $(".bulk_check").prop("checked",status);
});

</script>