<!--- Admin Header -->
<?php include 'application/views/includes/school_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/school_sidebar.php';?>
</div>
       
	<div class="content-page">
		<!-- ============================================================== -->
		<!-- Start Content here -->
		<!-- ============================================================== -->
		<div class="content">
			<div class="page-heading">
                            <h1><i class='fa fa-table'></i> CT Marks Entry</h1>
			</div>            	
			<div class="row">
                            <div class="col-md-12">
                                <div class="widget" style="min-height: 400px">
                                    <div class="widget-content">
                                        <form role="form" id="registerForm" method="POST">
                                            <div class="widget-content padding">
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-sm-4">
                                                            <label>Class<span style="color:red;">*</span></label>
                                              <select class="form-control" name="class_id" id="class_id"  onchange="get_class_section_list(this.value); get_class_group_list(this.value);">
                                                                <option value="">Select</option>
                                                                <?php
                                                                    foreach($class_list as $cl){ ?>
                                                                <option value="<?php echo $cl['class_id'];?>"><?php echo $cl['class_name'];?></option>
                                                                <?php    } ?>
                                                            </select>
                                                        </div>
														
														
														<div class="col-sm-4">
                                                <label>Section <span style="color:red;">*</span></label>
                                                <select class="form-control" name="section_id" id="section_id">
                                                    <option value="">Select</option>
                                                </select>
															</div>
											 <div class="col-sm-4">
                                               <label>Group <span style="color:red;">*</span></label>
                                                <select class="form-control" name="group_id" id="group_id" >
                                                    <option value="">Select</option>
                                                </select>
                                            </div>
												
                                              <div class="col-sm-4">
                                              <br />
											<br />

                                               <label>Shift <span style="color:red;">*</span></label>
                                                <select class="form-control" name="shift_id" id="shift_id" required >
                                                    <option value="">Select</option>
                                                     <?php
                                                        foreach($shift_list as $sl){ ?>
                                                         <option value="<?php echo $sl['shift_id'];?>"><?php echo $sl['shift_name'];?></option>   
                                                    <?php    }
                                                    ?>
                                                </select>
                                            </div>
                                                  
                                            <div class="col-sm-4"><br>
											<br>

                                                <label>Term Name <span style="color:red;">*</span></label>
                                                            <select class="form-control" name="term_id" id="term_id" onChange="get_sub_list(this.value);" >
                                                                <option value="">Select</option>
                                                                
                                                                 <?php
                                                                    foreach($term_list as $tl){ ?>
                                                                <option value="<?php echo $tl['term_id'];?>"><?php echo $tl['term'];?></option>
                                                                <?php    } ?>
                                                            </select>
													</div>
													
													
                                                    <div class="col-sm-4"><br>
<br>

                                                <label>Subject <span style="color:red;">*</span></label>
                                                <select class="form-control" name="sub_id" id="sub_id">
                                                    <option value="">Select</option>
                                                </select>
													</div>
                                                       
														 <div class="col-sm-4">
                                                         <br /><br />
                                                         

                                                         <?php  $currentDate = date("Y"); 
														 //echo $currentDate+6;
														// $examdate[]='';
														 for ($edb=0; $edb<=5; $edb++)
														 {
															 $examdate[$edb]=$currentDate-$edb;
														 }
														 $examdate=array_reverse($examdate);
														 $count=6;
														 for ($eda=1; $eda<=5; $eda++)
														 {
															 $examdate[$count]=$currentDate+$eda;
															 $count++; 
														 }
														 ?>
                                                <label>Exam Year <span style="color:red;">*</span></label>
                                                <select class="form-control" name="exam_year" id="exam_year">
                                                    <option value="">Select</option>
                                                    
                                                     <?php
                                                                    foreach($examdate as $ed){ ?>
                                                                <option value="<?php echo $ed;?>"<?php if($ed==$currentDate) echo "selected"?>><?php echo $ed;?></option>
                                                                <?php    } ?>
                                                </select>
													</div>
														
                                                    </div>
                                                </div>


                                                <div class="form-group">
														<div class="row">
															<div class="col-sm-4"><br>
<br>

																<button type="button" class="btn btn-primary" onclick="CT_marks_json()">Show Students</button>
															</div>
														</div>
													</div>
                                            </div>
                                        </form>

                                        <hr/>
                                            
                                        <div id="display">
                                            
                                            <!---JSON Content will be displayed here--->
                                            
                                        </div>
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                    </div>
                                </div>
                            </div>
			</div>

				
				
<?php include 'application/views/includes/footer.php';?>

<script>

function get_class_section_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'school/section_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#section_id').html(html_data);
        }
    }
    });  
}

function get_class_group_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'school/group_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#group_id').html(html_data);
        }
    }
    });  
}

function get_sub_list()
{
	var class_id=$('#class_id').val();
	var group_id = $('#group_id').val();  
   $.ajax({
    type: "POST",
    url: baseUrl + 'school/subject_list_ajax_ct',
    data:
    {
        'class_id':class_id,
		'group_id':group_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
			$('#sub_id').html(html_data);
        }
    }
    });  
}

    function CT_marks_json()
    {
        var class_id = $('#class_id').val();        
		var section_id = $('#section_id').val();
		var group_id = $('#group_id').val();
		var shift_id = $('#shift_id').val(); 
		var subject_id = $('#sub_id').val();  
		var term_id = $('#term_id').val();
		var exam_year = $('#exam_year').val();
		
		
		if(!class_id)
		{
			$('#class_id').after("<div id='validation_class' style='position:absolute; background-color:#7ECCAD; width:auto; color:#fff; font-size:14px; font-weight:bold; border-radius:0px 15px 0px 15px; box-shadow:1px 1px 1px 1px #5DAF8F; padding:8px 8px 8px 8px; alignment-adjust:central; text-shadow:#FFE1FF;'> Please select a class name </div>")
						$('#validation_class').fadeToggle(5000);
						return;
			
		}
		if(!section_id)
		{
			$('#section_id').after("<div id='validation_section' style='position:absolute; background-color:#7ECCAD; width:auto; color:#fff; font-size:14px; font-weight:bold; border-radius:0px 15px 0px 15px; box-shadow:1px 1px 1px 1px #5DAF8F; padding:8px 8px 8px 8px; alignment-adjust:central; text-shadow:#FFE1FF;'> Please select a section name </div>")
						$('#validation_section').fadeToggle(5000);
						return;
			
		}
		if(!group_id)
		{
			$('#group_id').after("<div id='validation_group' style='position:absolute; background-color:#7ECCAD; width:auto; color:#fff; font-size:14px; font-weight:bold; border-radius:0px 15px 0px 15px; box-shadow:1px 1px 1px 1px #5DAF8F; padding:8px 8px 8px 8px; alignment-adjust:central; text-shadow:#FFE1FF;'> Please select a group name </div>")
						$('#validation_group').fadeToggle(5000);
						return;
			
		}
		if(!shift_id)
		{
			$('#shift_id').after("<div id='validation_shift' style='position:absolute; background-color:#7ECCAD; width:auto; color:#fff; font-size:14px; font-weight:bold; border-radius:0px 15px 0px 15px; box-shadow:1px 1px 1px 1px #5DAF8F; padding:8px 8px 8px 8px; alignment-adjust:central; text-shadow:#FFE1FF;'> Please select a shift name </div>")
						$('#validation_shift').fadeToggle(5000);
						return;
			
		}
		if(!sub_id)
		{
			$('#sub_id').after("<div id='validation_sid' style='position:absolute; background-color:#7ECCAD; width:auto; color:#fff; font-size:14px; font-weight:bold; border-radius:0px 15px 0px 15px; box-shadow:1px 1px 1px 1px #5DAF8F; padding:8px 8px 8px 8px; alignment-adjust:central; text-shadow:#FFE1FF;'> Please select a subject name </div>")
						$('#validation_sid').fadeToggle(5000);
						return;
			
		}
		if(!term_id)
		{
			$('#term_id').after("<div id='validation_tid' style='position:absolute; background-color:#7ECCAD; width:auto; color:#fff; font-size:14px; font-weight:bold; border-radius:0px 15px 0px 15px; box-shadow:1px 1px 1px 1px #5DAF8F; padding:8px 8px 8px 8px; alignment-adjust:central; text-shadow:#FFE1FF;'> Please select a Term name </div>")
						$('#validation_tid').fadeToggle(5000);
						return;
			
		}
		if(!exam_year)
		{
			$('#exam_year').after("<div id='validation_et' style='position:absolute; background-color:#7ECCAD; width:auto; color:#fff; font-size:14px; font-weight:bold; border-radius:0px 15px 0px 15px; box-shadow:1px 1px 1px 1px #5DAF8F; padding:8px 8px 8px 8px; alignment-adjust:central; text-shadow:#FFE1FF;'> Please select a exam name </div>")
						$('#validation_et').fadeToggle(5000);
						return;
			
		}
		
		
        $.ajax({ 
        url: baseUrl+'school/get_student_list_for_ct_json',
        data:
            {                  
               'class_id':class_id,
				'section_id':section_id,
				'group_id':group_id,
				'shift_id':shift_id,
				'subject_id':subject_id,
				'term_id':term_id,
				'exam_year':exam_year
            }, 
            dataType: 'json',
            success: function(data)
            {
                result                = ''+data['result']+'';
                mainContent           = ''+data['mainContent']+'';

                if(result == 'success')
                {            
                    $('#display').html(mainContent);     
                }                
            }
        });
        return false; // keeps the page from not refreshing     
    }
</script>>>>>