<div class="table-responsive">
	<form role="form" id="registerForm" method="POST" action="<?php echo base_url();?>school/term_marks_save">
				
					<div class="form-group">
                                        <div class="row">
                                           
                                            <div class="col-sm-11" style="text-align: center;font-size:20px;font-weight:bold;">
                                                <p> Term: <?php echo $term_details['term'];?></p>
                                                 <?php $subject_box = $subject_info['marks_type'];
												if($subject_box==1)
												{ ?>
                                                <p>Subjective Marks: <span class="full_marks"><?php if($sml['subjective_marks']){echo $sml['subjective_marks'];} else {echo "0";}?></span>&nbsp;&nbsp;
                                                <?php }
                        elseif($subject_box==2)
						{ ?>
                                                <p>Subjective Marks: <span class="full_marks"><?php if($sml['subjective_marks']){echo $sml['subjective_marks'];} else {echo "0";}?></span>&nbsp;&nbsp;
                                                Objective Marks: <span class="full_marks"><?php if($sml['objective_marks']){echo $sml['objective_marks'];} else {echo "0";} ?></span>&nbsp;&nbsp;
                                                 <?php } 
                        else
						{ ?>
                                                <p>Subjective Marks: <span class="full_marks"><?php if($sml['subjective_marks']){echo $sml['subjective_marks'];} else {echo "0";}?></span>&nbsp;&nbsp;
                                                Objective Marks: <span class="full_marks"><?php if($sml['objective_marks']){echo $sml['objective_marks'];} else {echo "0";} ?></span>&nbsp;&nbsp;
                                                Practical Marks: <span class="full_marks"><?php if($sml['practical_marks']){echo $sml['practical_marks'];} else {echo "0";}?></span>&nbsp;&nbsp;
                                                 <?php } ?>
												&nbsp;&nbsp;Subject Name: <?php echo $subject_name['subject_name'];?></p>
												
                                            <input type='hidden' name='class_id' value='<?php echo $details['class']; ?>' />
											<input type='hidden' name='section_id' value='<?php echo $details['section']; ?>' />
											<input type='hidden' name='term_id' value='<?php echo $details['term']; ?>' />
                                            <input type='hidden' name='group_id' value='<?php echo $details['group_id']; ?>' />
                                            <input type='hidden' name='shift_id' value='<?php echo $details['shift_id']; ?>' />
                                            <input type='hidden' name='subject_id' value='<?php echo $details['subject_id']; ?>' />
                                            <input type='hidden' name='exam_year' value='<?php echo $details['exam_year']; ?>' />
                                            <input type='hidden' name='subject_type' value='<?php echo $subject_info['marks_type'] ?>' />
											</div>
                                        </div>
                                    </div>
						
	<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
				<thead>
					<tr>
						<th>Student ID</th>
						<th>Roll No</th>
                        <th>Student Name</th>
                       <?php $subject_box = $subject_info['marks_type'];
						if($subject_box==1)
						{ ?>
						<th>Subjective Marks</th>
                        <?php }
                        elseif($subject_box==2)
						{ ?>
						<th>Subjective Marks</th>
                        <th>Objective Marks</th>
                        <?php } 
                        else
						{ ?>
						<th>Subjective Marks</th>
                        <th>Objective Marks</th>
                        <th>Practical Marks</th>
                        <?php } ?>
						<th>Remarks</th>
					</tr>
				</thead>
				<tbody>
					<?php
						foreach($student_list as $sl){ ?>
						<tr>
							<td>
							<input type="hidden" readonly class="form-control" name="student_iddfsd[]" id="student_id" value="<?php echo $sl['student_id'];?>">
                            <?php echo $sl['student_id'];?>
							</td>
							<td>
							<?php echo $sl['roll_no'];?>
							</td>
                            <td>
							<?php echo $sl['student_name'];?>
							</td>
							<?php
							$ss =$sl['student_id'];
							$class_id=$details['class'];
							$section_id=$details['section'];
							$group_id=$details['group_id'];
							$shift_id=$details['shift_id'];
							$section_id=$details['section'];
							$term_id=$details['term'];
							$subject_id=$details['subject_id'];
							$exam_year=$details['exam_year'];
		$sql = "SELECT * FROM tbl_term_marks where student_id='$ss' and class_id='$class_id' and section_id='$section_id' and term_id='$term_id' and sub_id='$subject_id' and exam_year='$exam_year' and group_id='$group_id' and shift_id='$shift_id'";
		$query = mysql_query($sql);
        $row= mysql_fetch_array($query);
							?>
                             <?php $subject_box = $subject_info['marks_type'];
						if($subject_box==1)
						{ ?>
							<td>
			<input type="text" class="form-control" name="subjective_marks[]" id="obtain_marks<?php echo $sl['student_id'];?>" value="<?php echo $row['subjective_marks'];?>" onchange="validation(this.value,<?php echo $sl['student_id']; ?>,<?php echo $sml['subjective_marks'];?>)" />
							</td>
                            <?php }
                        elseif($subject_box==2)
						{ ?>
                        	<td>
			<input type="text" class="form-control" name="subjective_marks[]" id="obtain_marks<?php echo $sl['student_id'];?>" value="<?php echo $row['subjective_marks'];?>" onchange="validation(this.value,<?php echo $sl['student_id']; ?>,<?php echo $sml['subjective_marks'];?>)" />
							</td>
                            <td>
			<input type="text" class="form-control" name="objective_marks[]" id="objective_marks<?php echo $sl['student_id'];?>" value="<?php echo $row['objective_marks'];?>" onchange="validation_obj(this.value,<?php echo $sl['student_id']; ?>,<?php echo $sml['objective_marks']; ?>)" />
							</td>
                             <?php } 
                        else
						{ ?>
                        	<td>
			<input type="text" class="form-control" name="subjective_marks[]" id="obtain_marks<?php echo $sl['student_id'];?>" value="<?php echo $row['subjective_marks'];?>" onchange="validation(this.value,<?php echo $sl['student_id']; ?>,<?php echo $sml['subjective_marks'];?>)" />
							</td>
                            <td>
			<input type="text" class="form-control" name="objective_marks[]" id="objective_marks<?php echo $sl['student_id'];?>" value="<?php echo $row['objective_marks'];?>" onchange="validation_obj(this.value,<?php echo $sl['student_id']; ?>,<?php echo $sml['objective_marks']; ?>)" />
							</td>
                            <td>
			<input type="text" class="form-control" name="practical_marks[]" id="practical_marks<?php echo $sl['student_id'];?>" value="<?php echo $row['practical_marks'];?>"  onchange="validation_prac(this.value,<?php echo $sl['student_id']; ?>,<?php echo $sml['practical_marks']; ?>)" />
							</td>
                             <?php } ?>
							<td>
							<input type="text" class="form-control" name="remarks[]" id="remarks<?php echo $sl['student_id'];?>" >
							</td>
						</tr>
					<?php 	} ?>
					<tr>
                     <td></td>
                     <td></td>
					<td>
					 <?php if($row['status']!=0) { 
					echo "<strong>NB :</strong>You are not allowed to save or edit marks";
					}
					else{
					?>
					<input type="submit" class="btn btn-primary" name="fees_gen" value="Save"/>
                    <?php } ?>
					</td>
					</tr>
				</tbody>
			</table>
  	</form>
</div>
<style>
{
	margin:auto auto;
}
</style>
<script>
function validation(number,student_id,marks)
{
	///var full_marks =parseInt($('.full_marks').text());
	var numbers=/^([0-9.]*)$/;
		if (numbers.test(number))
			{
				if(number>marks)
				{
					$('#obtain_marks'+student_id).after("<div id='validation"+student_id+"' style='position:absolute; background-color:#7ECCAD; height:25px; width:auto; color:#fff; font-size:12px; font-weight:bold; border-radius:0px 15px 0px 15px; box-shadow:1px 1px 1px 1px #5DAF8F; padding:3px 3px 1px 3px; alignment-adjust:central; text-shadow:#FFE1FF;'>This number is more than Full Marks</div>")
						$('#validation'+student_id).fadeToggle(5000);
						
					$('#obtain_marks'+student_id).val("");
				}
			}
		else
			{
				
				$('#obtain_marks'+student_id).after("<div id='validation"+student_id+"' style='position:absolute; background-color:#7ECCAD; height:25px; width:auto; color:#fff; font-size:12px; font-weight:bold; border-radius:0px 15px 0px 15px; box-shadow:1px 1px 1px 1px #5DAF8F; padding:3px 3px 1px 3px; alignment-adjust:central; text-shadow:#FFE1FF;'>Please enter number only</div>")
						$('#validation'+student_id).fadeToggle(5000);
				$('#obtain_marks'+student_id).val("");
			}
	
	
}
function validation_obj(number,student_id,marks)
{
	///var full_marks =parseInt($('.full_marks').text());
	var numbers=/^([0-9.]*)$/;
		if (numbers.test(number))
			{
				if(number>marks)
				{
					$('#objective_marks'+student_id).after("<div id='validation_obj"+student_id+"' style='position:absolute; background-color:#7ECCAD; height:25px; width:auto; color:#fff; font-size:12px; font-weight:bold; border-radius:0px 15px 0px 15px; box-shadow:1px 1px 1px 1px #5DAF8F; padding:3px 3px 1px 3px; alignment-adjust:central; text-shadow:#FFE1FF;'>This number is more than Full Marks</div>")
						$('#validation_obj'+student_id).fadeToggle(5000);
						
					$('#objective_marks'+student_id).val("");
				}
			}
		else
			{
				
				$('#objective_marks'+student_id).after("<div id='validation_obj"+student_id+"' style='position:absolute; background-color:#7ECCAD; height:25px; width:auto; color:#fff; font-size:12px; font-weight:bold; border-radius:0px 15px 0px 15px; box-shadow:1px 1px 1px 1px #5DAF8F; padding:3px 3px 1px 3px; alignment-adjust:central; text-shadow:#FFE1FF;'>Please enter number only</div>")
						$('#validation_obj'+student_id).fadeToggle(5000);
				$('#objective_marks'+student_id).val("");
			}
	
	
}
function validation_prac(number,student_id,marks)
{
	///var full_marks =parseInt($('.full_marks').text());
	var numbers=/^([0-9.]*)$/;
		if (numbers.test(number))
			{
				if(number>marks)
				{
					$('#practical_marks'+student_id).after("<div id='validation_prac"+student_id+"' style='position:absolute; background-color:#7ECCAD; height:25px; width:auto; color:#fff; font-size:12px; font-weight:bold; border-radius:0px 15px 0px 15px; box-shadow:1px 1px 1px 1px #5DAF8F; padding:3px 3px 1px 3px; alignment-adjust:central; text-shadow:#FFE1FF;'>This number is more than Full Marks</div>")
						$('#validation_prac'+student_id).fadeToggle(5000);
						
					$('#practical_marks'+student_id).val("");
				}
			}
		else
			{
				
				$('#practical_marks'+student_id).after("<div id='validation_prac"+student_id+"' style='position:absolute; background-color:#7ECCAD; height:25px; width:auto; color:#fff; font-size:12px; font-weight:bold; border-radius:0px 15px 0px 15px; box-shadow:1px 1px 1px 1px #5DAF8F; padding:3px 3px 1px 3px; alignment-adjust:central; text-shadow:#FFE1FF;'>Please enter number only</div>")
						$('#validation_prac'+student_id).fadeToggle(5000);
				$('#practical_marks'+student_id).val("");
			}
	
	
}
</script>