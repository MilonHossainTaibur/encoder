<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.3/toastr.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.3/toastr.css" />
</div>

<div class="content-page">
<!-- Start Content here -->
<div class="content">
<?php if($this->session->flashdata('message')):?>
<?=$this->session->flashdata('message')?>
<?php endif?>
<div class="page-heading">
   <h1><i class='fa fa-table'></i> Managing Committee</h1>
</div>
<hr>					
<div class="row">
   <div class="col-md-12">
      <div class="widget">
         <div class="widget-content">
            <div class="">
			<form method="POST" action="<?= base_url() ?>sms_notice/managing_committee_sms_notice">
			<div class="form-group">
									<div class="row">
										<div class="col-sm-4">
											<textarea name="msg" id="note" cols="25" rows="5" style="width:100%;resize:none" placeholder ="Write Message" onkeyup="count_total_c(this.value)"></textarea>
											<div class="total_character"> </div>
											<br>
											<button type="submit" class="btn btn-success" onclick="return confirm('Are You Want to Send SMS?' );">Send SMS</button>
										</div>
									</div>
								</div>
								<div class="pull-right">
									<h4>
										<b class="pull-left"><div class="alert alert-warning">Total Member: <?= count($member_list); ?> </div></b>
										<b class="pull-right"><div class="alert alert-success">Total SMS contact: <span class="smscon"></span> </div></b>
									</h4>
								</div>
               <table id="" class="table table-bordered table-striped" cellspacing="0" width="100%">
                  <thead>
                     <tr>
                        <th>Name</th>
                        <th>Designation</th>
                        <!--th>Photo</th-->
                        <!--th>Status</th-->
                        <th>Mobile No.</th>
                        <th><label><input type="checkbox" id="bulk_check"></label></th>
                     </tr>
                  </thead>
                  <tbody>
                     <?php foreach($member_list as $sl){ ?>
                     <tr>
                        <td><?= $sl['member_name'];?></td>
                        <td><?= $sl['member_desig'];?></td>
                        <!--td><img width="60px;" height="auto" class=" man_image img-circle center-block zoom-image" src="<?= base_url()?>upload/managing_committee/<?= $sl['member_image'];?>" alt=""></td-->
                        
                        <td><?= $sl['mobile_no'];?></td>
                        <td>
											<?php if(strlen($sl['mobile_no'])==13){ $i++; ?>
												<input type="checkbox" name="mang_cont[]" class="bulk_check" value="<?= $sl['mobile_no'];?>">
											<?php  } ?>
											</td>
                     </tr>
                     <?php 	} ?>
                  </tbody>
				  </form>
               </table>
            </div>
         </div>
      </div>
   </div>
</div>
<?php include 'application/views/includes/footer.php';?>


<script>
window.onload=function(){
	$('.smscon').text(<?= $i ?>);
	get_class_section_list(<?=$this->session->userdata('class_id')?>);
	get_class_group_list(<?=$this->session->userdata('class_id')?>);
	
	
// check all checkbox just one click
$("#bulk_check").change(function(){
    var status = $(this).is(":checked") ? true : false;
    $(".bulk_check").prop("checked",status);
});

}
function get_class_section_list(class_id){
   $.ajax({
    type: "POST",
    url: baseUrl + 'admin/section_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#section_id').html(html_data);
			$("#section_id").val($("#section_id option:first").val('all'));
			document.getElementById('section_id').value = '<?=$this->session->userdata('section_id')?>';
        }
    }
    });  
}
function get_class_group_list(class_id){
   $.ajax({
    type: "POST",
    url: baseUrl + 'academic/group_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#group_id').html(html_data);
			$("#group_id").val($("#group_id option:first").val('all'));
			document.getElementById('group_id').value = '<?=$this->session->userdata('group_id')?>';
        }
    }
    });  
}
function count_total_c(val){
	var tc=val.length;
	var sms_count=Math.floor(tc/160) +1;
	
		var left_chr=(160*sms_count)-tc;
	
	$('.total_character').html('SMS '+sms_count+'<br>Character Left '+left_chr);
}

</script>