<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
<div class="content-page">			
    <div class="content">
        <?php if($this->session->flashdata('message')):?>
			<?=$this->session->flashdata('message')?>
		<?php endif?>
        <!-- Page Heading Start -->
        <div class="page-heading">
            <h1><i class='fa fa-check'></i> Teacher List</h1>
        </div>
        <!-- Page Heading End-->
        <!-- Your awesome content goes here -->
        <div class="row">
            <div class="col-sm-12">
                <div class="widget" style="min-height:500px;">
                    <div class="widget-content padding">
                        <div class="row">				
                            <div class="col-md-12">
                                <div class="widget">
                                    <div class="widget-content">
                                        <form role="form" id="send_sms" method="POST" action="<?= base_url();?>sms_notice/teacher_sms_notice">
									
											<div class="form-group">
												<div class="row">
													<div class="col-sm-12 col-md-4">
														<textarea name="msg" id="note" cols="25" rows="5" style="width:80%;resize:none" placeholder ="Write Message" onkeyup="count_total_c(this.value)"></textarea>
														<div class="total_character"> </div>
														<br>
														<button type="submit" class="btn btn-success" onclick="return confirm('Are You Want to Send SMS?' );">Send SMS</button>
													</div>
												</div>
											</div>
											<div class="pull-right">
												<h4>
													<b class="pull-left"><div class="alert alert-warning">Total Teacher & Staff: <?= count($teacher_list); ?> </div></b>
													<b class="pull-right"><div class="alert alert-success">Total SMS contact: <span class="smscon"></span> </div></b>
												</h4>
											</div>
                                            <table class="table table-striped table-bordered" cellspacing="0" width="100%">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Name</th>
                                                        <th>Department</th>
                                                        <th>Designation</th>
                                                        <th>Mobile</th>
                                                        <th><label><input type="checkbox" id="bulk_check"></label></th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $i=0; foreach($teacher_list as $tl){ ?>
                                                    <tr>
                                                        <td><?php echo $tl['teacher_id'];?></td>
                                                        <td><?php echo $tl['teacher_name'];?></td>
                                                        <td><?php echo $tl['department_name'];?></td>
                                                        <td><?php echo $tl['designation_name'];?></td>
                                                        <td><?php echo $tl['present_contact'];?></td>
														<td>
														<?php if(strlen($tl['present_contact'])==13){ $i++; ?>
															<input type="checkbox" name="sms_contact[]" class="bulk_check" value="<?= $tl['present_contact'];?>">
														<?php  } ?>
														</td>
                                                    </tr>
                                                    <?php } ?>
                                                </tbody>
                                            </table>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php include 'application/views/includes/footer.php';?>
<script>
window.onload=function(){
	$('.smscon').text(<?= $i ?>);
	// check all checkbox just one click
	$("#bulk_check").change(function(){
		var status = $(this).is(":checked") ? true : false;
		$(".bulk_check").prop("checked",status);
	});

}
function count_total_c(val){
	var tc=val.length;
	var sms_count=Math.floor(tc/160) +1;
	
		var left_chr=(160*sms_count)-tc;
	
	$('.total_character').html('SMS '+sms_count+'<br>Character Left '+left_chr);
}
</script>