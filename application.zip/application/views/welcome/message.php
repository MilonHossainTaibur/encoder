<?php require 'application/views/welcome/includes/header.php';?>    

    <!-- ******CONTENT****** --> 
        <div class="content container">
            <div class="page-wrapper">
                <header class="page-heading clearfix">
                    <h1 class="heading-title pull-left">
                        <?= $messages['type']; ?>
                    </h1>
                    <div class="breadcrumbs pull-right">
                        <ul class="breadcrumbs-list">
                            <li class="breadcrumbs-label">You are here:</li>
                            <li><a href="<?php echo base_url();?>">Home</a><i class="fa fa-angle-right"></i></li>
                            <li class="current">
                            <?= $messages['type']; ?>
                        </li>
                        </ul>
                    </div><!--//breadcrumbs-->
                </header> 
                <div class="page-content">
                    <div class="row">
                        <article class="contact-form col-md-12 col-sm-12  page-row">
                            <section class="principal_message">
                        <h1 class="section-heading text-highlight"><span class="line"><?= $messages['type']==1; ?></span></h1>
                            <img src="<?php echo base_url();?>template/upload/message_image/<?php echo $messages['image'];?>" alt="" />
                            <?php echo $messages['message'];?>
                    </section><!--//course-finder-->        
                        </article><!--//contact-form-->
                        
                    </div><!--//page-row-->
                </div><!--//page-content-->
            </div><!--//page-wrapper--> 
        </div><!--//content-->
    
<?php require 'application/views/welcome/includes/footer.php';?>    