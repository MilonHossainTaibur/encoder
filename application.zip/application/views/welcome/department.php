<?php require 'application/views/welcome/includes/header.php';?>    

    <!-- ******CONTENT****** --> 
        <div class="content container">
            <div class="page-wrapper">
                <header class="page-heading clearfix">
                    <h1 class="heading-title pull-left">Department</h1>
                    <div class="breadcrumbs pull-right">
                        <ul class="breadcrumbs-list">
                            <li class="breadcrumbs-label">You are here : </li>
                            <li><a href="<?php echo base_url();?>">Home</a><i class="fa fa-angle-right"></i></li>
                            <li class="current">Department</li>
                        </ul>
                    </div><!--//breadcrumbs-->
                </header> 
                <div class="page-content">
                    <div class="row">
                        <?php 
                                    foreach($class_list as $cl){  
                                    $class_id = $cl['class_id'];
                                    $class_query = "SELECT * FROM tbl_class where class_id = $class_id limit 1";
                                    $class = $this->db->query($class_query);
                                    $class_list= $class->row_array();
                                ?>
                        <article class="contact-form col-md-1 col-sm-1  page-row"></article>
                        <article class="contact-form col-md-5 col-sm-5  page-row">
                            <article class="news-item" style="min-height: 200px;">
                                
                                 
                                
                                
                                <h3 class="has-divider text-highlight"><?php echo $class_list['class_name'];?></h3> 
                                    
                                    <h4>ডিপার্টমেন্ট নাম</h4>
                                    <ul>
                                        <?php
                                            $cl=  "SELECT * FROM tbl_class_assign where class_id = $class_id order by class_assign_id asc";
                                            $cl_query = $this->db->query($cl);
                                            $cl_list= $cl_query->result_array();
                                            foreach($cl_list as $cl_l){ 
                                                $department_id = $cl_l['department_id']; 
                                                $department_query = "SELECT * FROM tbl_group where group_id = $department_id limit 1";
                                                $department= $this->db->query($department_query);
                                                $department_list= $department->row_array();
                                                echo "<li>".$department_list['group_name']."</li>";
                                                } ?>
                                    </ul>                                    
                                   <hr />
                                    <br/>
                            </article><!--//news-item-->
                        </article><!--//contact-form-->
                        <?php   } ?>
                        
                    </div><!--//page-row-->
                </div><!--//page-content-->
            </div><!--//page-wrapper--> 
        </div><!--//content-->
       <?php require 'application/views/welcome/includes/footer.php';?>  