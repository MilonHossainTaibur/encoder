<?php require 'application/views/welcome/includes/header.php';?>    

    <!-- ******CONTENT****** --> 
        <div class="content container" style="width:95%; margin:0px auto; background-color:#FFF; ">
            <div class="page-wrapper">
                <header class="page-heading clearfix">
                    <h1 class="heading-title pull-left"> 
                     <?php
                            echo $rules_list['information_heading'];
                        ?>
                    </h1>
                    <div class="breadcrumbs pull-right">
                        <ul class="breadcrumbs-list">
                            <li class="breadcrumbs-label">You are here:</li>
                            <li><a href="<?php echo base_url();?>">Home </a><i class="fa fa-angle-right"></i></li>
                            <li class="current"> <?php
                            echo $rules_list['information_heading'];
                        ?> </li>
                        </ul>
                    </div><!--//breadcrumbs-->
                </header> 
                      
                
                
                <div class="page-content">
                    <div class="row page-row">
                        <div class="news-wrapper col-md-10 col-sm-10 ">
                            <article class="news-item">
                                <p class="meta text-muted">By: <a href="#">Admin</a> | Published on: 
                                    <?php
                                    $post=$notice_info['created_on'];
                                    $ddmmyy_format = date('d-m-Y',strtotime($post));
                                    echo $ddmmyy_format; 
                                    ?>
                                </p>
                                <div class="notice_view">
                                    <?php
                                        echo $notice_info['notice_details'];
                                    ?>
                                </div>
                                <center>
                                    <br />
                                    <?php
                                        if($notice_info['notice_attachment']!=''){ ?>
                                            <a href="<?php echo base_url();?>template/upload/notice_file/<?php echo $notice_info['notice_attachment'];?>" target="_blank" title="Attachment File"><i class="fa fa-paperclip" style="font-size:50px;"></i></a>
                                    <?php    } ?>
                                </center>
                                
                            </article><!--//news-item-->
                        </div><!--//news-wrapper-->
                        <aside class="page-sidebar  col-md-3 col-md-offset-1 col-sm-4 col-sm-offset-1 col-xs-12">
                        </aside>
                    </div><!--//page-row-->
                </div><!--//page-content-->
                
                
                
                
            </div><!--//page-wrapper--> 
        </div><!--//content-->
        <?php require 'application/views/welcome/includes/footer.php';?>
