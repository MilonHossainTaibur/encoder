<!DOCTYPE html>
<html>
	
<?php
    $sql = "SELECT * FROM tbl_school_information where status=2 LIMIT 1";
    $query = $this->db->query($sql);
    $sc_info = $query->row_array();
?>
<head>
		<!-- Basic -->
		<meta charset="utf-8">
		<title><?= $sc_info['school_name'];?></title>
		<meta name="keywords" content="Material Education, Events, News, Learning Centre & Kid School MultiPurpose HTML5 Template" />
		<meta name="description" content=" Material Education, Events, News, Learning Centre & Kid School MultiPurpose HTML5 Template">
		<meta name="author" content="">
		<!-- Mobile Metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<!-- Favicon -->
        <link rel="shortcut icon" href="<?= base_url();?>template/front_end/images/default/favicon.png">
		<!-- Web Fonts  -->
		<link href='https://fonts.googleapis.com/css?family=Roboto:400,100,100italic,300,300italic,400italic,500,500italic,700,700italic,900,900italic' 
		rel='stylesheet' type='text/css'>

		<!-- Lib CSS -->
		<link rel="stylesheet" href="<?= base_url();?>template/front_end/css/lib/bootstrap.min.css">
		<link rel="stylesheet" href="<?= base_url();?>template/front_end/css/lib/animate.min.css">
		<link rel="stylesheet" href="<?= base_url();?>template/front_end/css/lib/font-awesome.min.css">
		<link rel="stylesheet" href="<?= base_url();?>template/front_end/css/lib/univershicon.css">
		<link rel="stylesheet" href="<?= base_url();?>template/front_end/css/lib/owl.carousel.css">
		<link rel="stylesheet" href="<?= base_url();?>template/front_end/css/lib/prettyPhoto.css">
		<link rel="stylesheet" href="<?= base_url();?>template/front_end/css/lib/menu.css">
		<link rel="stylesheet" href="<?= base_url();?>template/front_end/css/lib/timeline.css">
		
		<!-- Revolution CSS -->
		<link rel="stylesheet" href="<?= base_url();?>template/front_end/revolution/css/settings.css">
		<link rel="stylesheet" href="<?= base_url();?>template/front_end/revolution/css/layers.css">
		<link rel="stylesheet" href="<?= base_url();?>template/front_end/revolution/css/navigation.css"> 
		
		<!-- Theme CSS -->
		<link rel="stylesheet" href="<?= base_url();?>template/front_end/css/theme.css">
		<link rel="stylesheet" href="<?= base_url();?>template/front_end/css/theme-responsive.css">
		
		<!--[if IE]>
			<link rel="stylesheet" href="css/ie.css">
		<![endif]-->
		
		<!-- Head Libs -->
		<script src="<?= base_url();?>template/front_end/js/lib/modernizr.js"></script>
		
		<script type="text/javascript" src="<?= base_url();?>template/front_end/extensions/revolution.extension.video.min.js"></script>
		<script type="text/javascript" src="<?= base_url();?>template/front_end/extensions/revolution.extension.slideanims.min.js"></script>
		<script type="text/javascript" src="<?= base_url();?>template/front_end/extensions/revolution.extension.actions.min.js"></script>
		<script type="text/javascript" src="<?= base_url();?>template/front_end/extensions/revolution.extension.layeranimation.min.js"></script>
		<script type="text/javascript" src="<?= base_url();?>template/front_end/extensions/revolution.extension.kenburn.min.js"></script>
		<script type="text/javascript" src="<?= base_url();?>template/front_end/extensions/revolution.extension.navigation.min.js"></script>
		<script type="text/javascript" src="<?= base_url();?>template/front_end/extensions/revolution.extension.migration.min.js"></script>
		<script type="text/javascript" src="<?= base_url();?>template/front_end/extensions/revolution.extension.parallax.min.js"></script>
		 <script>var baseUrl = "<?php echo base_url();?>";</script> 
		<!-- Skins CSS -->
		<link rel="stylesheet" href="<?= base_url();?>template/front_end/css/skins/default.css">
		
		<!-- Theme Custom CSS -->
		<link rel="stylesheet" href="<?= base_url();?>template/front_end/css/custom.css">
	</head>
<body>

<!-- Page Loader -->
<div id="pageloader">
	<div class="loader-inner">
		<img src="<?= base_url();?>template/front_end/images/default/preloader.gif" alt="">
	</div>
</div><!-- Page Loader -->

<!-- Back to top -->
<a href="#0" class="cd-top">Top</a>




<!-- Header Begins -->	
<header id="header" class="default-header colored flat-menu">
	<div class="header-top">
		<div class="container">
			<nav>
				<ul class="nav nav-pills nav-top">
					<li class="phone">
						<span><i class="fa fa-envelope"></i>info@weblinkltd.com</span>					</li>
					<li class="phone">
						<span><i class="fa fa-phone"></i><?= $sc_info['contact_no'];?></span>					</li>
				</ul>
			</nav>
			<ul class="social-icons color">
				<li class="googleplus"><a title="googleplus" target="_blank" href="http://www.googleplus.com/">googleplus</a></li>
				<li class="facebook"><a href="http://www.facebook.com/" target="_blank" title="Facebook">Facebook</a></li>
				<li class="twitter"><a href="http://www.twitter.com/" target="_blank" title="Twitter">Twitter</a></li>
				<li class="pinterest"><a title="pinterest" target="_blank" href="http://www.pinterest.com/">pinterest</a></li>
				<li class="rss"><a title="rss" target="_blank" href="http://www.rss.com/">rss</a></li>
			</ul>
		</div>
	</div>
	<div class="container">
		<div class="logo">
			<a href="index.html">
				 <img alt="Universh" width="211" height="40" data-sticky-width="150" data-sticky-height="28" src="<?= base_url();?>upload/institute_logo/mylogo.jpg">
            </a>
        </div>
		<button class="btn btn-responsive-nav btn-inverse" data-toggle="collapse" data-target=".nav-main-collapse">
			<i class="fa fa-bars"></i>
        </button>
	</div>
	<div class="navbar-collapse nav-main-collapse collapse">
		<div class="container">
			<nav class="nav-main mega-menu">
				<ul class="nav nav-pills nav-main" id="mainMenu">
					<li>
						<a href="<?php echo base_url();?>">
							Home
							<i class="fa fa-home"></i>
                        </a>
					</li>
					<li class="dropdown">
						<a class="dropdown-toggle" href="#">
							Institute
							<i class="fa fa-caret-down"></i>
                         </a>
                        
						<ul class="dropdown-menu">
							<li><a href="<?php echo base_url();?>about_college">About Institute</a></li>
                            <li><a href="<?php echo base_url();?>">Class Wise Subject</a></li>
                            <li><a href="<?php echo base_url();?>">Cultural Information</a></li>
                            <li><a href="<?php echo base_url();?>">Managing Committee</a></li>
						</ul>
					</li>
                    <li class="dropdown">
						<a class="dropdown-toggle" href="#">
							Institutional Activities
							<i class="fa fa-caret-down"></i>
                         </a>
                        
						<ul class="dropdown-menu">
							 <li><a href="<?php echo base_url();?>welcome/library">Library</a></li>
                             <li><a href="#">Attendance Report </a></li>
                             <li><a href="#">Account Report</a></li>
						</ul>
					</li>
					<li class="dropdown mega-menu-item mega-menu-fullwidth">
						<a class="dropdown-toggle" href="#">
							Academic
							<i class="fa fa-caret-down"></i>
                        </a>
						<ul class="dropdown-menu">
							<li>
								<div class="mega-menu-content">
									<div class="row">
										<div class="col-md-3">
											<ul class="sub-menu menu-border">
												<li>
													<span class="mega-menu-sub-title">Routine</span>
													<ul class="sub-menu">
														<li><a href="<?php echo base_url();?>class_routine">Class Routine</a></li>
                                                        <li><a href="<?php echo base_url();?>central_routine">Central Routine</a></li>
                                                        <li><a href="<?php echo base_url();?>exam_routine">Exam Routine</a></li>
													</ul>
												</li>
											</ul>
										</div>
										<div class="col-md-3">
											<ul class="sub-menu menu-border">
												<li>
													<span class="mega-menu-sub-title">Exam Results</span>
													<ul class="sub-menu">
														<li><a href="<?php echo base_url();?>welcome/result_view">Combined Result</a></li> 
                                                        <li><a href="<?php echo base_url();?>welcome/mark_sheet">Individual Result</a></li>
                                                        <li><a href="#">Marti List</a></li>
													</ul>
												</li>
											</ul>
										</div>
										<div class="col-md-3">
											<ul class="sub-menu menu-border">
												<li>
													<span class="mega-menu-sub-title">Rules & Others</span>
													<ul class="sub-menu">
														 <li><a href="<?php echo base_url();?>rules_regulations">Institutional Rules & Regulation</a></li>
                                                		 <li><a href="<?php echo base_url();?>facilities">Institutional Facilities</a></li>
                                                 		 <li><a href="<?php echo base_url();?>steps">Clark & Other Employees List</a></li>
													</ul>
												</li>
											</ul>
										</div>
										<div class="col-md-3">
											<ul class="sub-menu menu-border">
												<li>
													<span class="mega-menu-sub-title">Holidays & Other</span>
													<ul class="sub-menu">
														<li><a href="#">Testimonial & T.C</a></li>
                                                		<li><a href="<?php echo base_url();?>welcome/academic_calendar">Academic Calendar</a></li>
                                        				<li><a href="<?php echo base_url();?>">Annual Holiday List</a></li>                          
													</ul>
												</li>
											</ul>
										</div>
									</div>
								</div>
							</li>
						</ul>
					</li>
					<li class="dropdown">
						<a class="dropdown-toggle" href="#">
							Panel
							<i class="fa fa-caret-down"></i>
                        </a>
						<ul class="dropdown-menu">
							<li class="dropdown-submenu">
								<a href="#">Teachers</a>
								<ul class="dropdown-menu">
									<li><a href="<?php echo base_url();?>teacher">Teachers Information</a></li>
                                    <li><a href="<?php echo base_url();?>welcome/vacant_post">Vacancy for Teachers</a></li>
                                    <li><a href="<?php echo base_url();?>welcome/teacher_panel">Teachers Panel</a></li>
                                    <li><a href="<?php echo base_url();?>welcome/teacher_archive">Teachers Archive</a></li>
								</ul>
							</li>
							<li class="dropdown-submenu">
								<a href="#">Students</a>
								<ul class="dropdown-menu">
									<li><a href="<?php echo base_url();?>student">Student's Information</a></li>
                                    <li><a href="<?php echo base_url();?>welcome/student_panel">Student's Panel</a></li>
                                    <li><a href="<?php echo base_url();?>welcome/guardian_panel">Guardian Panel</a></li>
								</ul>
							</li>
						</ul>
					</li>
                    <li class="dropdown">
						<a class="dropdown-toggle" href="#">
							eService
							<i class="fa fa-caret-down"></i>
                         </a>
                        
						<ul class="dropdown-menu">
							 <li><a href="http://onlineadmission.eductg.gov.bd/">Online Admission</a></li>
                             <li><a href="#">Online Payment</a></li>
						</ul>
					</li>
                    <li class="dropdown">
						<a class="dropdown-toggle" href="#">
							Notice
							<i class="fa fa-caret-down"></i>
                         </a>
                        
						<ul class="dropdown-menu">
							  <li><a href="<?php echo base_url();?>general_notice">General Notices</a></li>
                              <li><a href="<?php echo base_url();?>admission_notice">Admission Notices</a></li>
                              <li><a href="<?php echo base_url();?>">Circular</a></li>
						</ul>
					</li>
                    <li>
						<a href="<?php echo base_url();?>photo_gallery">
							Photo Gallery
							<i class="fa fa-picture-o"></i>
                        </a>
					</li>
				</ul>
			</nav>
		</div>
	</div>
</header><!-- Header Ends -->