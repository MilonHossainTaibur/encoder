<!-- Footer -->
<footer id="footer" class="footer-1">
	<div class="main-footer widgets-dark typo-light">
		<div class="container">
			<div class="row">
				<!-- Widget Column -->
				<div class="col-md-3">
					<!-- Widget -->
					<div class="widget subscribe no-box">
						<h5 class="widget-title">Address<span></span></h5>
						<p class="form-message1" style="display: none;"></p>
						<div class="clearfix"></div>
						<b><?php echo $sc_info['school_name'];?></b><br/>
                        <b><?php echo $sc_info['address'];?>, <?php echo $sc_info['post_office'];?></b><br/>
                        <b><?php echo $sc_info['police_station'];?> <?php echo $sc_info['district'];?></b><br/>
					</div><!-- Widget -->
                    <!-- Widget -->
					<div class="widget no-box">
						<h5 class="widget-title">Follow Us<span></span></h5>
						<!-- Social Icons Color -->
						<ul class="social-icons color">
							<li class="facebook"><a href="http://www.facebook.com/" target="_blank" title="Facebook">Facebook</a></li>
							<li class="twitter"><a href="http://www.twitter.com/" target="_blank" title="Twitter">Twitter</a></li>
							<li class="linkedin"><a href="http://www.linkedin.com/" target="_blank" title="Linkedin">Linkedin</a></li>
							<li class="digg"><a href="http://www.digg.com/" target="_blank" title="digg">digg</a></li>
							<li class="flickr"><a href="http://www.flickr.com/" target="_blank" title="flickr">flickr</a></li>
							<li class="forrst"><a href="http://www.forrst.com/" target="_blank" title="forrst">forrst</a></li>
							<li class="googleplus"><a href="http://www.googleplus.com/" target="_blank" title="googleplus">googleplus</a></li>
						</ul>	
					</div><!-- Widget -->
				</div><!-- Column -->
				
				<!-- Widget Column -->
				
				
				<!-- Widget Column -->
				<div class="col-md-3">
					<!-- Widget -->
					<div class="widget no-box">
						<h5 class="widget-title">Imporatnt Links<span></span></h5>
						<ul class="tag-widget">
							<li><a href="http://www.moedu.gov.bd/" target="_blank">Educational Ministry </a></li>
                            <li><a href="http://infokosh.gov.bd/" target="_blank">Info Kosh</a></li>
                            <li><a href="http://www.ebook.gov.bd/" target="_blank">eBook</a></li>
                            <li><a href="http://www.lekhaporabd.com/" target="_blank">Lekha-Pora</a></li>
                            <li><a href="http://forms.portal.gov.bd/" target="_blank">Bd Portal</a></li>
                            <li><a href="http://services.portal.gov.bd/" target="_blank">Services Portal</a></li>
                            <li><a href="http://www.teachers.gov.bd/" target="_blank">Teacher's Window</a></li>
                            <li><a href="http://eductg.gov.bd/" target="_blank">Ctg DC</a></li>
                            <li><a href="http://www.dshe.gov.bd/" target="_blank" title="Directorate of Secondary and Higher Education">DSHE</a></li>
                            <li><a href="http://www.nctb.gov.bd/" target="_blank">NCTB</a></li>

						</ul>
					</div><!-- Widget -->
					
				</div><!-- Column -->
				
				<!-- Widget Column -->
				<div class="col-md-3">
					<!-- Widget -->
					<div class="widget no-box">
						<h5 class="widget-title">Connect us<span></span></h5>
							<input class="form-control" type="text" value="" placeholder="EMAIL">
                            <br/>
                			<textarea rows="3" class="form-control" placeholder="MESSAGE"></textarea>
                            <br/>
                            <button type="submit" class="btn">Send</button>
					</div><!-- Widget -->
				</div><!-- Column -->
				
			</div><!-- Row -->
		</div><!-- Container -->		
	</div><!-- Main Footer -->
	
	<!-- Footer Copyright -->
	<div class="footer-copyright">
		<div class="container">
			<div class="row">
				<!-- Copy Right Logo -->
				<div class="col-md-2">
					<a class="logo" href="index.html">
						<img src="images/default/logo-footer.png" width="211" height="40"  class="img-responsive" alt="Universh Education HTML5 Website Template">
					</a>
				</div><!-- Copy Right Logo -->
				<!-- Copy Right Content -->
				<div class="col-md-6">
					<p>&copy; Copyright 2016. All Rights Reserved. | By <a href="#" title="<?= $sc_info['school_name'];?>"><?= $sc_info['school_name'];?></a></p>
				</div><!-- Copy Right Content -->
				<!-- Copy Right Content -->
				<div class="col-md-4">
					<nav class="sm-menu">
						<ul>
							<li><a href="page-faq.html">FAQ's</a></li>
							<li><a href="page-sitemap.html">Sitemap</a></li>
							<li><a href="contact.html">Contact</a></li>
						</ul>
					</nav><!-- Nav -->
				</div><!-- Copy Right Content -->
			</div><!-- Footer Copyright -->
		</div><!-- Footer Copyright container -->
	</div><!-- Footer Copyright -->
</footer>
<!-- Footer -->

  <!-- library -->
<script src="<?= base_url();?>template/front_end/js/lib/jquery.js"></script>
<script src="<?= base_url();?>template/front_end/js/lib/bootstrap.min.js"></script>
<script src="<?= base_url();?>template/front_end/js/lib/bootstrapValidator.min.js"></script>
<script src="<?= base_url();?>template/front_end/js/lib/jquery.appear.js"></script>
<script src="<?= base_url();?>template/front_end/js/lib/jquery.easing.min.js"></script>
<script src="<?= base_url();?>template/front_end/js/lib/owl.carousel.min.js"></script>
<script src="<?= base_url();?>template/front_end/js/lib/countdown.js"></script>
<script src="<?= base_url();?>template/front_end/js/lib/counter.js"></script>
<script src="<?= base_url();?>template/front_end/js/lib/isotope.pkgd.min.js"></script>
<script src="<?= base_url();?>template/front_end/js/lib/jquery.easypiechart.min.js"></script>
<script src="<?= base_url();?>template/front_end/js/lib/jquery.mb.YTPlayer.min.js"></script>
<script src="<?= base_url();?>template/front_end/js/lib/jquery.prettyPhoto.js"></script>
<script src="<?= base_url();?>template/front_end/js/lib/jquery.stellar.min.js"></script>
<script src="<?= base_url();?>template/front_end/js/lib/menu.js"></script>



<!-- Revolution Js -->
<script src="<?= base_url();?>template/front_end/revolution/js/jquery.themepunch.tools.min838f.js?rev=5.0"></script>
<script src="<?= base_url();?>template/front_end/revolution/js/jquery.themepunch.revolution.min838f.js?rev=5.0"></script>
<script src="<?= base_url();?>template/front_end/js/lib/theme-rs.js"></script>
<script type="text/javascript" src="<?= base_url();?>template/front_end/extensions/revolution.extension.video.min.js"></script>
<script type="text/javascript" src="<?= base_url();?>template/front_end/extensions/revolution.extension.slideanims.min.js"></script>
<script type="text/javascript" src="<?= base_url();?>template/front_end/extensions/revolution.extension.actions.min.js"></script>
<script type="text/javascript" src="<?= base_url();?>template/front_end/extensions/revolution.extension.layeranimation.min.js"></script>
<script type="text/javascript" src="<?= base_url();?>template/front_end/extensions/revolution.extension.kenburn.min.js"></script>
<script type="text/javascript" src="<?= base_url();?>template/front_end/extensions/revolution.extension.navigation.min.js"></script>
<script type="text/javascript" src="<?= base_url();?>template/front_end/extensions/revolution.extension.migration.min.js"></script>
<script type="text/javascript" src="<?= base_url();?>template/front_end/extensions/revolution.extension.parallax.min.js"></script>

<script src="<?= base_url();?>template/front_end/js/lib/modernizr.js"></script>
<script src="<?= base_url();?>template/front_end/js/lib/modernizr.js"></script>
<!-- Theme Base, Components and Settings -->
<script src="<?= base_url();?>template/front_end/js/theme.js"></script>

<!-- Theme Custom -->
<script src="<?= base_url();?>template/front_end/js/custom.js"></script>

</body>


</html>