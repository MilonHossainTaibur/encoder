<?php
    if($result_type['result_type']==1){ 
        /**This is for HSC Result**/
        foreach($result_list as $rl){
            $total_gpa = number_format($rl['gpa']/$rl['subject'],2);
            if($total_gpa>=5){
                echo "<h1>The Following Student goten 'A+'</h1>";
                echo $rl['student_id']." = ".$rl['gpa']." = Subject ".$rl['subject']." = GPA =".$total_gpa."<br/>";
            }
            elseif($total_gpa>=4 AND $total_gpa<5){
                echo "<h1>The Following Student goten 'A'</h1>";
                echo $rl['student_id']." = ".$rl['gpa']." = Subject ".$rl['subject']." = GPA =".$total_gpa."<br/>";
            }
            
            elseif($total_gpa>=3.5 AND $total_gpa<4){
                echo "<h1>The Following Student goten 'A-'</h1>";
                echo $rl['student_id']." = ".$rl['gpa']." = Subject ".$rl['subject']." = GPA =".$total_gpa."<br/>";
            }
            elseif($total_gpa>=3 AND $total_gpa<3.5){
                echo "<h1>The Following Student goten 'B'</h1>";
                echo $rl['student_id']." = ".$rl['gpa']." = Subject ".$rl['subject']." = GPA =".$total_gpa."<br/>";
            }
            elseif($total_gpa>=2 AND $total_gpa<3){
                echo "<h1>The Following Student goten 'C'</h1>";
                echo $rl['student_id']." = ".$rl['gpa']." = Subject ".$rl['subject']." = GPA =".$total_gpa."<br/>";
            }
            elseif($total_gpa>=1 AND $total_gpa<2){
                echo "<h1>The Following Student goten 'D'</h1>";
                echo $rl['student_id']." = ".$rl['gpa']." = Subject ".$rl['subject']." = GPA =".$total_gpa."<br/>";
            }
            else{
                echo "Fail";
            }
            
            
            ?>
        

    <?php    }
        ?>
        

    <?php }
    else{ 
        /**This is for degree result**/
        ?>
        
<?php    }
?>
  