<?php require 'application/views/welcome/includes/header.php';?>    

    <!-- ******CONTENT****** --> 
        <div class="content container" style="width:95%; margin:0px auto; background-color:#FFF; ">
            <div class="page-wrapper">
                <header class="page-heading clearfix">
                    <h1 class="heading-title pull-left"> Library
                    </h1>
                    <div class="breadcrumbs pull-right">
                        <ul class="breadcrumbs-list">
                            <li class="breadcrumbs-label">You are here :</li>
                            <li><a href="<?php echo base_url();?>">Home </a><i class="fa fa-angle-right"></i></li>
                            <li class="current"> Library </li>
                        </ul>
                    </div><!--//breadcrumbs-->
                </header> 
                
                  <div class="breadcrumbs pull-right">	
									
			<div class="col-sm-12">
			<select class="form-control" placeholder="Category" data-placement="bottom" title="Category" name="category_id" id="category_id" required onChange="check_book_list(this.value)">
				<option value='' SELECTED='selected'>Select a category</option>
				<?php
				foreach($category_list as $r){ ?>
				<option value='<?php echo $r['category_id'];?>'><?php echo $r['category_name']; ?></option>
				<?php }
				?>
				</select>
				     
				</div>
				</div>
                
                <div class="page-content" id='display'>
                    <div class="row page-row">
                        <div class="news-wrapper col-md-12 col-sm-12 ">
                            <article class="news-item" style="min-height: 200px;">
                                <div class="table-responsive">
                                    <table class="table table-condensed">
                                        <thead>
                                            <tr>
                                                <th>Register No</th>
                                                <th>Register SL No</th>
                                                <th>Book Name</th>
                                                <th>Writer Name</th>
                                                <th>Category Name</th>
                                                <th>Remarks</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                foreach($book_list as $tl){ ?>
                                                <tr>
                                                	<td><?php echo $tl['register_no'];?></td>
                                                    <td><?php echo $tl['register_sl_no'];?></td>
                                                    <td><?php echo $tl['book_name'];?></td>
                                                    <td><?php echo $tl['writer_name'];?></td>
                                                    <td>
                                                    <?php
                                                    $cat_id = $tl['category_id']; 
                                                    		$sql = "SELECT category_name FROM tbl_book_category WHERE category_id = '$cat_id' LIMIT 1";
			                                        $query = $this->db->query($sql);
			                                        $row = $query->row_array();
                                                    		echo $row['category_name'];
                                                    ?>
                                                    </td>
                                                    <td><?php echo $tl['remarks'];?></td>
                                                </tr>
                                            <?php    }
                                            ?>
                                            

                                        </tbody>
                                    </table><!--//table-->
                                </div><!--//table-responsive-->
                               <hr />
                                <br/>
                             
                            </article><!--//news-item-->
                        </div><!--//news-wrapper-->
                        <aside class="page-sidebar  col-md-3 col-md-offset-1 col-sm-4 col-sm-offset-1 col-xs-12">
                        </aside>
                    </div><!--//page-row-->
                </div><!--//page-content-->
            </div><!--//page-wrapper-->
        </div><!--//content-->
    <?php require 'application/views/welcome/includes/footer.php';?> 
    
<script>
    function check_book_list(category_id)
    {//alert(category_id)
        //var category_id = $('#category_id').val();
       // document.write(category_id);
        if(category_id==0){
            alert("Select Category First");
        }
        
        $.ajax({ 
        url: baseUrl+'welcome/get_book_list_by_category_id',
        data:
            {                  
                'category_id':category_id,
             
            }, 
            dataType: 'json',
            success: function(data)
            {
                result                = ''+data['result']+'';
                mainContent           = ''+data['mainContent']+'';
                if(result == 'success')
                {    
				$('#display').html(mainContent);  				
                }                
            }
        });
        return false; // keeps the page from not refreshing     
    }
</script> 
