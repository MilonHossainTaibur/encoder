<?php require 'application/views/welcome/includes/header.php';?>    

    <!-- ******CONTENT****** --> 
        <div class="content container">
            <div class="page-wrapper">
                <header class="page-heading clearfix">
                    <h1 class="heading-title pull-left">Result</h1>
                    <div class="breadcrumbs pull-right">
                        <ul class="breadcrumbs-list">
                            <li class="breadcrumbs-label">You are here:</li>
                            <li><a href="<?php echo base_url();?>">Home</a><i class="fa fa-angle-right"></i></li>
                            <li class="current">Result</li>
                        </ul>
                    </div><!--//breadcrumbs-->
                </header> 
                
                
                
                
                <div class="page-content">
                    <div class="row page-row">
                        <div class="news-wrapper col-md-10 col-sm-10 ">
                            <article class="news-item" style="min-height: 200px;">
                                
                                <div class="section-content">
                                    
                                    <div class="row page-row">
                                        <div class="col-md-6 col-sm-6 ">
                                            <select name="class_id" id="class_id" class="form-control" onchange="check_department_list(this.value), check_session_list(this.value), check_exam_list(this.value)">
                                                <option value="">Select Class</option>
                                                <?php
                                                foreach($class_list as $cl){ ?>       
                                                <option value="<?php echo $cl['class_id']; ?>"><?php echo $cl['class_name']; ?></option>
                                            <?php } ?>
                                            </select>
                                            <br />
                                        </div>
                                        
                                        
                                        <div class="col-md-6 col-sm-6 ">
                                            <select name="department_id" id="department_id" class="form-control">
                                                <option value="">Select Department</option>
                                            </select>
                                            <br />
                                        </div>
                                        
                                        
                                        <div class="col-md-6 col-sm-6 ">
                                            
                                            <select name="session_id" id="session_id" class="form-control">
                                                <option value="">Select Session</option>
                                            </select>                                           
                                        </div>
                                        <div class="col-md-6 col-sm-6 ">
                                            <select name="exam_id" id="exam_id" class="form-control">
                                                <option value="">Select Exam</option>
                                            </select>
                                        </div>
                                    </div>
                                    <button class="btn btn-primary btn-label-left" onclick="check_student_list(document.getElementById('class_id').selectedIndex, document.getElementById('department_id').selectedIndex, document.getElementById('session_id').selectedIndex, document.getElementById('exam_id').selectedIndex)" type="button"> Result View </button>
                                    
                                    <hr />
                                    <div id="display">
										
                                        
                                        
                                        
                                    </div>
                                    
                                </div><!--//section-content--> 
                                    
                            </article><!--//news-item-->
                        </div><!--//news-wrapper-->
                        <aside class="page-sidebar  col-md-3 col-md-offset-1 col-sm-4 col-sm-offset-1 col-xs-12">
                        </aside>
                    </div><!--//page-row-->
                </div><!--//page-content-->
            </div><!--//page-wrapper-->
        </div><!--//content-->
    
<?php require 'application/views/welcome/includes/footer.php';?>    

<!--Check department name based on class id--->
<script>
    function check_department_list()
    {
        var class_id = $('#class_id').val();        
        $.ajax({ 
        url: baseUrl+'welcome/get_department_list_by_class_id',
        data:
            {                  
                'class_id':class_id
            }, 
            dataType: 'json',
            success: function(data)
            {
                result                = ''+data['result']+'';
                mainContent           = ''+data['mainContent']+'';

                if(result == 'success')
                {            
                    $('#department_id').html(mainContent);     
                }                
            }
        });
        return false; // keeps the page from not refreshing     
    }
</script> 

<!--Check Session name based on class id--->
<script>
    function check_session_list()
    {
        var class_id = $('#class_id').val();        
        $.ajax({ 
        url: baseUrl+'welcome/get_session_list_by_class_id',
        data:
            {                  
                'class_id':class_id
            }, 
            dataType: 'json',
            success: function(data)
            {
                result                = ''+data['result']+'';
                mainContent           = ''+data['mainContent']+'';

                if(result == 'success')
                {            
                    $('#session_id').html(mainContent);     
                }                
            }
        });
        return false; // keeps the page from not refreshing     
    }
</script>


<!--Check Exam name based on class id--->
<script>
    function check_exam_list()
    {
        var class_id = $('#class_id').val();        
        $.ajax({ 
        url: baseUrl+'welcome/get_exam_list_by_class_id',
        data:
            {                  
                'class_id':class_id
            }, 
            dataType: 'json',
            success: function(data)
            {
                result                = ''+data['result']+'';
                mainContent           = ''+data['mainContent']+'';

                if(result == 'success')
                {            
                    $('#exam_id').html(mainContent);     
                }                
            }
        });
        return false; // keeps the page from not refreshing     
    }
</script> 


<script>
    function check_student_list()
    {
        var class_id = $('#class_id').val();
        var department_id = $('#department_id').val();
        var session_id = $('#session_id').val();
        var exam_id = $('#exam_id').val();
        if(class_id==0){
            alert("Select Class First");
        }
        
       
        $.ajax({ 
        url: baseUrl+'welcome/get_student_list_for_result_view',
        data:
            {                  
                'class_id':class_id,
                'department_id':department_id,
                'session_id':session_id,
                'exam_id':exam_id
            }, 
            dataType: 'json',
            success: function(data)
            {
                result                = ''+data['result']+'';
                mainContent           = ''+data['mainContent']+'';

                if(result == 'success')
                {            
                    $('#display').html(mainContent);     
                }                
            }
        });
        return false; // keeps the page from not refreshing     
    }
</script>  