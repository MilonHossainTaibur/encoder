<?php require 'application/views/welcome/includes/header.php';?>    
       
        <div class="content container" style="width:95%; margin:0px auto; background-color:#FFF; ">
            <div class="page-wrapper">
                <header class="page-heading clearfix">
                    <h1 class="heading-title pull-left"> 
                     Academic Calendar
                    </h1>
                    <div class="breadcrumbs pull-right">
                        <ul class="breadcrumbs-list">
                            <li class="breadcrumbs-label">You are here :</li>
                            <li><a href="<?php echo base_url();?>">Home </a><i class="fa fa-angle-right"></i></li>
                            <li class="current"> academic calendar</li>
                        </ul>
                    </div><!--//breadcrumbs-->
                </header> 
                
                <div class="page-content">
                    <div class="row page-row">
                         <div id="calendar" class="col-lg-12 col-md-12 col-sm-12 col-xs-12"></div>
                    </div><!--//page-row-->
                </div><!--//page-content-->
            </div><!--//page-wrapper--> 
        </div><!--//content-->
       

				
<?php require 'application/views/welcome/includes/footer.php';?>

<script src="<?php echo base_url();?>template/plugins/fullcalendar-1.6.2/fullcalendar/fullcalendar.min.js"></script>
<script>

function CalendarInit() {
	"use strict";

    var date = new Date();
    var d = date.getDate();
    var m = date.getMonth();
    var y = date.getFullYear();

    var hdr = {};

    if ($(window).width() <= 767) {
        hdr = { left: 'title', center: '', right: 'prev,today,month,agendaWeek,agendaDay,next' };
    } else {
        hdr = { left: '', center: 'title', right: 'prev,today,month,agendaWeek,agendaDay,next' };
    }

  
   
    /* initialize the external events
     -----------------------------------------------------------------*/

 
   
    /* initialize the calendar
     -----------------------------------------------------------------*/

    $('#calendar').fullCalendar({
        header: hdr,
        buttonText: {
            prev: '<i class="icon-chevron-left"></i>',
            next: '<i class="icon-chevron-right"></i>'
        },
      
		
	events: baseUrl + 'welcome/get_event',
        
		
        windowResize: function (event, ui) {
            $('#calendar').fullCalendar('render');
        },
		renderEvent: function (copiedEventObject){
		alert(copiedEventObject.start)
		}
		
    });
}
            CalendarInit();
        </script>
