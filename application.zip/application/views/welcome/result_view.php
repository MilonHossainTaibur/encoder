<?php require 'application/views/welcome/includes/header.php';?>    

    <!-- ******CONTENT****** --> 
        <div class="content container" style="width:95%; margin:0px auto; background-color:#FFF; ">
            <div class="page-wrapper">
                <header class="page-heading clearfix">
                    <h1 class="heading-title pull-left">Combined Result</h1>
                    <div class="breadcrumbs pull-right">
                        <ul class="breadcrumbs-list">
                            <li class="breadcrumbs-label">You are here : </li>
                            <li><a href="<?php echo base_url();?>">Home</a><i class="fa fa-angle-right"></i></li>
                            <li class="current">Combined Result</li>
                        </ul>
                    </div><!--//breadcrumbs-->
                </header> 
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                    <div class="row page-row">
                        <div class="news-wrapper col-md-10 col-sm-10 ">
                            <article class="news-item" style="min-height: 200px;">
            <form role="form" id="registerForm" method="POST" action="<?php echo base_url();?>academic/result_marks_save" enctype="multipart/form-data">               
                              <div class="form-group">
                                        <div class="row">
                                        <div class="col-md-4 col-sm-4 ">
                                        <label> Class </label>
                                            <select name="class_id" id="class_id" required class="form-control" onchange="get_class_section_list(this.value);" >
                                                <option value="">Select Class</option>
                                                <?php
                                                foreach($class_list as $cl){ ?>       
                                                <option value="<?php echo $cl['class_id']; ?>"><?php echo $cl['class_name']; ?></option>
                                            <?php } ?>
                                            </select>
                                            <br /><br />

                                        </div>
                                        
                                        
                                        <div class="col-md-4 col-sm-4 ">
                                        <label> Section</label>
                                            <select name="section_id" required id="section_id" class="form-control">
                                                <option value="">Select Section</option>
                                            </select>
                                            <br /><br />

                                        </div>
                                        
                                        <div class="col-md-4 col-sm-4 ">
                                           <label> Exam Term <span style="color:red;">*</span></label>
                                                            <select class="form-control" required name="term_id" id="term_id" onchange="term_marks_json()">
                                                                <option value="">Select</option>
                                                                
                                                                 <?php
                                                                    foreach($term as $tl){ ?>
                                                                <option value="<?php echo $tl['term_id'];?>"><?php echo $tl['term'];?></option>
                                                                <?php    } ?>
                                                            </select>                                         
                                        </div>
                                        </div>
                                        </div>
                                        
                                        
                                         <div class="form-group">
                                        <div class="row">
                                         <div class="col-sm-4">
                                                         <?php  $currentDate = date("Y"); 
														 //echo $currentDate+6;
														// $examdate[]='';
														 for ($edb=0; $edb<=5; $edb++)
														 {
															 $examdate[$edb]=$currentDate-$edb;
														 }
														 $examdate=array_reverse($examdate);
														 $count=6;
														 for ($eda=1; $eda<=5; $eda++)
														 {
															 $examdate[$count]=$currentDate+$eda;
															 $count++; 
														 }
														 ?>
                                                <label>Exam Year <span style="color:red;">*</span></label>
                                                <select class="form-control" required name="exam_year" id="exam_year">
                                                    <option value="">Select</option>
                                                    
                                                     <?php
                                                                    foreach($examdate as $ed){ ?>
                                                                <option value="<?php echo $ed;?>"<?php if($ed==$currentDate) echo "selected"?>><?php echo $ed;?></option>
                                                     <?php    } ?>
                                                </select>
													</div>
                                    </div>
                                    </div><br />
<br />

                                    <button class="btn btn-success btn-label-center" onclick="result_marks_json()" type="button"> ফলাফল দেখুন </button>
                                    
                                    <hr />
                                    <div id="display">
										
                                        
                                        
                                        
                                    </div>
                                    
                                </div><!--//section-content--> 
                                    
                            </article><!--//news-item-->
                        </div><!--//news-wrapper-->
                        <aside class="page-sidebar  col-md-3 col-md-offset-1 col-sm-4 col-sm-offset-1 col-xs-12">
                        </aside>
                    </div><!--//page-row-->
                </div><!--//page-content-->
            <?php require 'application/views/welcome/includes/footer.php';?>

<!--Check department name based on class id--->
<script>
   function get_class_section_list(class_id)
		{
		   $.ajax({
			type: "POST",
			url: baseUrl + 'welcome/section_list_ajax',
			data:
			{
				'class_id':class_id
			}, 
			success: function(html_data)
			{
				if (html_data != '')
				{
					$('#section_id').html(html_data);
				}
			}
			});  
		}

	function result_marks_json()
		{
			var class_id = $('#class_id').val();        
			var section_id = $('#section_id').val(); 
			var term_id = $('#term_id').val(); 
			var exam_year = $('#exam_year').val();
			
			if(!class_id)
		{
			$('#class_id').after("<div id='validation_class' style='position:absolute; background-color:#7ECCAD; width:auto; color:#fff; font-size:12px; font-weight:bold; border-radius:0px 15px 0px 15px; box-shadow:1px 1px 1px 1px #5DAF8F; padding:8px 8px 8px 8px; alignment-adjust:central; text-shadow:#FFE1FF;'>  Please select a class  </div>")
						$('#validation_class').fadeToggle(5000);
						return;
			
		}
		if(!section_id)
		{
			$('#section_id').after("<div id='validation_section' style='position:absolute; background-color:#7ECCAD; width:auto; color:#fff; font-size:12px; font-weight:bold; border-radius:0px 15px 0px 15px; box-shadow:1px 1px 1px 1px #5DAF8F; padding:8px 8px 8px 8px; alignment-adjust:central; text-shadow:#FFE1FF;'> Please select a section </div>")
						$('#validation_section').fadeToggle(5000);
						return;
			
		}
		
		if(!term_id)
		{
			$('#term_id').after("<div id='validation_term_id' style='position:absolute; background-color:#7ECCAD; width:auto; color:#fff; font-size:12px; font-weight:bold; border-radius:0px 15px 0px 15px; box-shadow:1px 1px 1px 1px #5DAF8F; padding:8px 8px 8px 8px; alignment-adjust:central; text-shadow:#FFE1FF;'>  Please select an exam term </div>")
						$('#validation_term_id').fadeToggle(5000);
						return;
			
		}
		if(!exam_year)
		{
			$('#exam_year').after("<div id='validation_exam_year' style='position:absolute; background-color:#7ECCAD; width:auto; color:#fff; font-size:12px; font-weight:bold; border-radius:0px 15px 0px 15px; box-shadow:1px 1px 1px 1px #5DAF8F; padding:8px 8px 8px 8px; alignment-adjust:central; text-shadow:#FFE1FF;'>  Please select an exam year  </div>")
						$('#validation_exam_year').fadeToggle(5000);
						return;
			
		}
			$.ajax({ 
			url: baseUrl+'welcome/result_marks_json',
			data:
				{                  
					'class_id':class_id,
					'section_id':section_id,
					'term_id':term_id,
					'exam_year':exam_year,
				}, 
				dataType: 'json',
				success: function(data)
				{
					result                = ''+data['result']+'';
					mainContent           = ''+data['mainContent']+'';
	
					if(result == 'success')
					{            
						$('#display').html(mainContent);     
					}                
				}
			});
		}
		
		

</script> 


