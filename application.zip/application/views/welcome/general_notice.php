<?php require 'application/views/welcome/includes/header.php';?>    

    <!-- ******CONTENT****** --> 
       <div class="content container" style="width:95%; margin:0px auto; background-color:#FFF; ">
            <div class="page-wrapper">
                <header class="page-heading clearfix">
                    <h1 class="heading-title pull-left"> 
                   General Notice
                    </h1>
                    <div class="breadcrumbs pull-right">
                        <ul class="breadcrumbs-list">
                            <li class="breadcrumbs-label">You are here :</li>
                            <li><a href="<?php echo base_url();?>">Home </a><i class="fa fa-angle-right"></i></li>
                            <li class="current">General Notice</li>
                        </ul>
                    </div><!--//breadcrumbs-->
                </header> 
                <div class="page-content">
                    <div class="row notice_view">
                        <?php
                            foreach($notice_list as $nl){ ?>
                            <article class="contact-form col-md-12 col-sm-12  page-row">                            
<!--                                <figure class="thumb col-md-2 col-sm-2 col-xs-2" style="height:200px;overflow:hidden">
                                    <img class="img-responsive" src="<?php echo base_url();?>template/images/notice/notice.jpg" alt="" height="120" width="120"/>
                                </figure>-->
                                <div class="details col-md-10 col-sm-10 col-xs-10">
                                    <h3 class="title"><a href="<?php echo base_url();?>welcome/single_notice/<?php echo $nl['notice_id'];?>"><?php echo $nl['notice_heading'];?></a></h3>
                                    
                                    <p>
                                        <?php 
                                           $string= $nl['notice_details'];
                                            if (strlen($string) > 300) {
                                            $stringCut = substr($string, 0, 300);

                                            $string = substr($stringCut, 0, strrpos($stringCut, ' '));
                                            }
                                            echo $string;
                                        ?>
                                    </p>
                                    <a class="btn btn-theme read-more" href="<?php echo base_url();?>welcome/single_notice/<?php echo $nl['notice_id'];?>">Read more<i class="fa fa-chevron-right"></i></a>
                                </div>
                            </article>
                        <hr />
                        <?php    } ?>
                    </div><!--//page-row-->
                </div><!--//page-content-->
            </div><!--//page-wrapper--> 
        </div><!--//content-->
        <?php require 'application/views/welcome/includes/footer.php';?>  
