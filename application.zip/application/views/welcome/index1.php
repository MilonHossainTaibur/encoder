<?php require 'application/views/welcome/includes/header.php';?>
    <!-- ******CONTENT****** --> 
        
    <?php require 'application/views/welcome/includes/slide.php';?>
    <div> 
           <!-- <div class="row cols-wrapper">-->
                <?php /*?><div class="col-md-3">
                    <section class="testimonials" style="height:300px;text-align:justify;overflow:hidden">
                            <h1 class="section-heading text-highlight">
                                <span class="line">Chairman Message</span>
                            </h1>

                            <div class="section-content">
                                <div id="principal_message" class="testimonials-carousel carousel slide">
                                    <?php echo $principal_message['principal_message'];?>
                                </div>
                            </div>
                        </section>
                        <section style="height: 25px;margin-bottom: 20px;margin-top: -30px;padding: 5px 5px 20px;">
                                <a href="<?php echo base_url();?>welcome/principal_message/<?php echo $principal_message['message_id'];?>"> Read More <i class="fa fa-chevron-right"></i></a>
                        </section> 
                        <section class="testimonials" style="height:300px;text-align:justify;overflow:hidden">
                            <h1 class="section-heading text-highlight">
                                <span class="line">Headmaster Message</span>
                            </h1>
							<div class="section-content">
                                <div id="principal_message" class="testimonials-carousel carousel slide">
                                    <?php echo $vice_principal_message['principal_message'];?>
                                </div>
                            </div>
                        </section>
					<section style="height: 25px;margin-bottom: 20px;margin-top: -30px;padding: 5px 5px 20px;">
						<a href="<?php echo base_url();?>welcome/principal_message/<?php echo $vice_principal_message['message_id'];?>"> Read More <i class="fa fa-chevron-right"></i></a>
					</section> <?php */?>
					
					<!--<section class="testimonials" style="min-height:100px;text-align:justify;  min-height: 140px;">
						<center>
							<div class="row">
								<br/>-->
								<?php /*?><div class="col-md-3">
									<!--  <a href="http://shikkhangon.com/smsgateway/institute/" target="_blank" >
										<img src="<?php echo base_url();?>template/images/sms.png" alt="" /> <br/>
										<h4 style="margin-top:0px;font-weight:bold"> SMS Gateway </h4>
									</a> -->
									<a href="<?php echo base_url();?>admin" target="_blank">
									 	<img src="<?php echo base_url();?>template/images/sms.png" alt="" /> <br/>
										<h4 style="margin-top:0px;font-weight:bold"> SMS Gateway </h4>
									</a>
								</div>
								<div class="col-md-3">
									<a href="http://shikkhangon.com/webmail" target="_blank">
										<img src="<?php echo base_url();?>template/images/webmail.png" alt="" /> <br/>
										<h4 style="margin-top:0px;font-weight:bold"> Webmail Login </h4>
									</a>
								</div><?php */?>
							<!--</div>
						</center>
					</section>	-->				
		 	<!--</div> --> 
								
				
				<div class="col-md-7">
                    <section class="principal_message" style="height:680px; overflow:hidden">
<!--                        <h1 class="section-heading text-highlight"><span class="line">About College</span></h1>-->
                            <?php echo $about['about_details'];?>
                    </section><!--//course-finder-->
					<section style="height:25px; margin-bottom:20px; margin-top: -30px;padding: 5px 5px 20px;">
						<a href="<?php echo base_url();?>about_college"> Read More <i class="fa fa-chevron-right"></i></a>
					</section>
                    
                               <div class="divider" style="border-right: 1px solid green;"></div>
                            <div class="col-md-20 pull-right">
                                          
                        <a target="_blank" href="http://infokosh.gov.bd/" style="padding:3px;">
                         <img src="<?php echo base_url();?>template/template/images/totho_kosh.png" alt="" height="65" width="200">
                                </a>
                                 <a target="_blank" href="http://www.ebook.gov.bd/" style="padding:3px;">
                <img src="<?php echo base_url();?>template/template/images/ebook_bangla.png" alt="" height="65" width="200"></a>
            
    <a target="_blank" href="http://dhakaeducationboard.gov.bd/" style="padding:3px;">
                 <img src="<?php echo base_url();?>template/template/images/Logo_copy.jpg" alt="" height="65" width="200" style="border-radius:5px;"></a>
    <a target="_blank" href="http://bise-ctg.gov.bd/" style="padding:3px;">
          <img src="<?php echo base_url();?>template/template/images/bise-ctg.gov.bd1.png" alt="" height="65" width="200" style="border-radius:5px;"></a>         <a target="_blank" href="http://forms.portal.gov.bd/" style="padding:3px;">
                 <img src="<?php echo base_url();?>template/template/images/forms_portal_logo.png" alt="" height="65" width="200" ></a>
            
    <a target="_blank" href="http://bangladesh.gov.bd/" style="padding:3px;">
                 <img src="<?php echo base_url();?>template/template/images/logo_bang.png" alt="" height="65" width="200"></a>
                          
    <a target="_blank" href="http://comillaboard.gov.bd/" style="padding:3px;">
          <img src="<?php echo base_url();?>template/template/images/comilla.jpg" alt="" height="65" width="200" style="border-radius:5px;"></a>       
    <a target="_blank" href="http://www.lekhaporabd.com/" style="padding:3px;">
          <img src="<?php echo base_url();?>template/template/images/lekha-pora1.jpg" alt="" height="65" width="200"></a> 
      
      <a target="_blank" href="http://services.portal.gov.bd/" style="padding:3px;">
          <img src="<?php echo base_url();?>template/template/images/services_portal_bn.png" alt="" height="65" width="200"></a>  
      <a target="_blank" href="http://www.teachers.gov.bd/" style="padding:3px;">
          <img src="<?php echo base_url();?>template/template/images/1link.jpg" alt="" height="65" width="200"></a> 
      <a target="_blank" href="http://eductg.gov.bd/" style="padding:3px;">
          <img src="<?php echo base_url();?>template/template/images/link-2.png" alt="" height="65" width="200"></a> 
      <a target="_blank" href="http://www.dshe.gov.bd/" style="padding:3px;">
          <img src="<?php echo base_url();?>template/template/images/link-3.jpg" alt="" height="65" width="200"></a>  
      <a target="_blank" href="http://www.moedu.gov.bd/" style="padding:3px;">
          <img src="<?php echo base_url();?>template/template/images/Link-4.jpg" alt="" height="65" width="200"></a>
      <a target="_blank" href="http://www.nctb.gov.bd/" style="padding:3px;">
          <img src="<?php echo base_url();?>template/template/images/Link-5.jpg" alt="" height="65" width="200"></a>
      
   <!-- <a target="_blank" href="http://mmc.e-service.gov.bd/">
          <img src="<?php echo base_url();?>template/template/images/main_header.gif" alt="" height="65" width="200" style="border-radius:5px;"></a> -->
           </div> 
                </div>
				
               <div class="col-md-2">
									
									<a href="<?php echo base_url();?>admin" target="_blank">
									 	<img src="<?php echo base_url();?>template/images/sms.png" alt="" /> <br/>
										<h4 style="margin-top:0px;font-weight:bold"> SMS Gateway </h4>
									</a>
								</div>
								<div class="col-md-2">
									<a href="http://shikkhangon.com/webmail" target="_blank">
										<img src="<?php echo base_url();?>template/images/webmail.png" alt="" /> <br/>
										<h4 style="margin-top:0px;font-weight:bold; padding-right:10px; text-align:left;">Webmail Login</h4>
									</a>
								</div>  
               
                      
                <div class="col-md-5">
                    <section class="testimonials" style="height:250px; width:80%; text-align:center; overflow:hidden">
                            <h4 class="section-heading text-highlight">
                                <span class="line">Chairman Message</span>
                            </h4>

                            <div class="section-content">
                                <div id="principal_message" class="testimonials-carousel carousel slide">
                                    <?php echo $principal_message['principal_message'];?>
                                </div>
                            </div>
                        </section>
                        <section style="height: 25px; width:80%; margin-bottom: 20px;margin-top: -30px;padding: 5px 5px 20px;">
                                <a href="<?php echo base_url();?>welcome/principal_message/<?php echo $principal_message['message_id'];?>"> Read More <i class="fa fa-chevron-right"></i></a>
                        </section> 
                        <section class="testimonials" style="height:250px; width:80%; text-align:center; overflow:hidden">
                            <h4 class="section-heading text-highlight">
                                <span class="line">Headmaster Message</span>
                            </h4>
							<div class="section-content">
                                <div id="principal_message" class="testimonials-carousel carousel slide">
                                    <?php echo $vice_principal_message['principal_message'];?>
                                </div>
                            </div>
                        </section>
					<section style="height: 25px; width:80%; margin-bottom: 20px;margin-top: -30px;padding: 5px 5px 20px;">
						<a href="<?php echo base_url();?>welcome/principal_message/<?php echo $vice_principal_message['message_id'];?>"> Read More <i class="fa fa-chevron-right"></i></a>
					</section>
                
					<!--<section class="testimonials" style="min-height:300px;text-align:justify">
                        <h1 class="section-heading text-highlight">
                            <span class="line">Important Links</span>
                        </h1>
						<ul>
							<li><a href="http://www.bise-ctg.gov.bd" target="_blank" title="Chittagong">Chittagong Education Board</a></li>
							<li><a href="http://www.bangladesh.gov.bd/" target="_blank">Bangladesh Portal</a></li>
							<li><a href="http://www.moedu.gov.bd/" target="_blank">Ministry of Education</a></li>
							<li><a href="http://www.mopa.gov.bd/" target="_blank" title="Ministry">Ministry of Public Administration</a></li>
							<li><a href="http://www.nu.edu.bd/" target="_blank" title="National">National University</a></li>
							<li><a href="http://www.dshe.gov.bd/" target="_blank">DSHE</a></li>
							<li><a href="http://www.nctb.gov.bd/" target="_blank">NCTB</a></li>
							<li><a href="http://www.banbeis.gov.bd/" target="_blank">BANBEIS</a></li>
							<li><a href="http://www.dia.gov.bd/" target="_blank">DIA</a></li>
							<li><a href="http://www.ugc.gov.bd/" target="_blank">UGC</a></li>
							<li><a href="http://www.bcc.net.bd/">BCC</a></li>
						</ul>
                    </section>--><!--//testimonials-->
					
					<section class="maps" style="max-height:250px; width:80%; text-align:center;">
                        <h4 class="section-heading text-highlight">
                            <span class="line"> Find Us On Map</span>
                        </h4>
						<div id="map"></div>
                    </section><!--//testimonials-->
                    <section class="maps" style="min-height:140px; width:80%; text-align:justify">
                        <h1 class="section-heading text-highlight">
                            <span class="line"> View Visitors Count</span>
                        </h1>
						<center>
						<!-- hitwebcounter Code START -->
<a href="http://www.hitwebcounter.com" target="_blank">
<img src="http://hitwebcounter.com/counter/counter.php?page=6125011&style=0019&nbdigits=7&type=page&initCount=0" title="http://www.hitwebcounter.com/" Alt="http://www.hitwebcounter.com/"   border="0" >
</a>                                        <br/>
                                        <!-- hitwebcounter.com --><a href="" title="" 
                                        target="_blank" style="font-family: Geneva, Arial, Helvetica; 
                                        font-size: 8px; color: #9F9F97; text-decoration: underline ;">
                                        </a>   
                            
   
    </center>


                    </section><!--//testimonials-->
                </div><!--//col-md-3-->
                                				
            <!--//cols-wrapper-->
        </div><!--//content-->
        
       
    <?php require 'application/views/welcome/includes/footer.php';?>    

        
    </div><!--//wrapper-->

 


<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script>
    <script type="text/javascript" src="<?php echo base_url();?>template/template/plugins/gmaps/gmaps.js"></script>            
    <script type="text/javascript" src="<?php echo base_url();?>template/template/js/map.js"></script>