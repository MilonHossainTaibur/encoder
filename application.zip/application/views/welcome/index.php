<?php require 'application/views/welcome/includes/header.php';?>
    <!-- ******CONTENT****** --> 
        
    <?php require 'application/views/welcome/includes/slide.php';?>
  
        
<!-- Section about -->
	<section class="pad-top-none typo-dark">
		<div class="container">
			<!-- Row -->
			<div class="row">
				<!-- Title -->
				<div class="col-sm-12">
					<div class="title-container sm">
						<div class="title-wrap">
							<h3 class="title">About School</h3>
							<span class="separator line-separator"></span>
						</div>
					</div>
				</div>
				<!-- Title -->
				
				<!-- Column -->
				<div class="col-sm-12">
					<!-- Course Wrapper -->
					<div class="course-wrapper">
						<!-- Course Detail -->
						<div class="course-detail-wrap">
							<!-- Course Teacher Detail 
							<div class="teacher-wrap">
								<img width="100" height="100" src="<?php echo base_url();?>template/upload/about_image/<?php echo $about['about_image'];?>" class="img-responsive" alt="school image">
							</div>--><!-- Course Teacher Detail -->
							<!-- Course Content -->
							<div class="course-content">
								 <?= $about['about_details'];?>
							</div><!-- Course Content -->
						</div><!-- Course Detail -->
					</div><!-- Course Wrapper -->
				</div><!-- Column -->
			</div><!-- Row -->
		</div><!-- Container -->
	</section><!-- Section about-->
    
<!-- Section -->
	<section class="bg-dark typo-light">
		<div class="container">
			<div class="row counter-sm">
				<!-- Title -->
				<div class="col-sm-12">
					<div class="title-container">
						<div class="title-wrap">
							<h3 class="title">Take A Look About Our School</h3>
							<span class="separator line-separator"></span>
						</div>
						<p class="description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur pellentesque neque eget diam</p>
					</div>
				</div>
				<!-- Title -->
				<div class="col-sm-6 col-md-3">
					<!-- Count Block -->
					<div class="count-block dark bg-verydark">
						<h5>Subjects</h5>
						<h3 data-count="452" class="count-number"><span class="counter">452</span></h3>
						<i class="uni-fountain-pen"></i>
					</div><!-- Counter Block -->
				</div><!-- Column -->
				<div class="col-sm-6 col-md-3">
					<!-- Count Block -->
					<div class="count-block dark bg-verydark">
						<h5>Modern lab</h5>
						<h3 data-count="97" class="count-number"><span class="counter">452</span></h3>
						<i class="uni-chemical"></i>
					</div><!-- Counter Block -->
				</div><!-- Column -->
				<div class="col-sm-6 col-md-3">
					<!-- Count Block -->
					<div class="count-block dark bg-verydark">
						<h5>Instructors</h5>
						<h3 data-count="300" class="count-number"><span class="counter">452</span></h3>
						<i class="uni-talk-man"></i>
					</div><!-- Counter Block -->
				</div><!-- Column -->
				<div class="col-sm-6 col-md-3">
					<!-- Count Block -->
					<div class="count-block dark bg-verydark">
						<h5>Students</h5>
						<h3 data-count="7985" class="count-number"><span class="counter">452</span></h3>
						<i class="uni-brain"></i>
					</div><!-- Counter Block -->
				</div><!-- Column -->
			</div><!-- Row -->
		</div><!-- Container -->
	</section><!-- Section -->

	<!-- Section -->
	<section class="bg-grey typo-dark">
		<div class="container">
			<div class="row">
				<!-- Title -->
				<div class="col-sm-12">
					<div class="title-container">
						<div class="title-wrap">
							<h3 class="title">Message</h3>
							<span class="separator line-separator"></span>
						</div>
					</div>
				</div><!-- Title -->
			</div><!-- Row -->
			
			<div class="row border-style">
            	<?php if($messages):
				foreach($messages as $message):
				 ?>
				<div class="col-sm-4">
					<!-- Member Wrap -->
					<div class="member-wrap">
						<!-- Member Image Wrap -->
						<div class="member-img-wrap">
							<img width="580" height="400" src="<?= base_url() ?>template/upload/message_image/<?= $message['image']; ?>" alt="<?= $message['type']; ?>" class="img-responsive">
						</div>
						<!-- Member detail Wrapper -->
						<div class="member-detail-wrap bg-white">
							<h5 class="member-name"><a href="#"><?= $message['name']; ?></a></h5>
							<span>Chairman’s message</span>
							<p><?php $pmsg= explode(' ' , $message['message']);
											for($i=0; $i<=18; $i++)
											{
											echo $pmsg[$i]." " ;
											}
											?>
                             <a href="<?php echo base_url();?>welcome/message/<?= $message['message_id'];?>" class="white nicdark_btn"><i class="icon-graduation-cap-1"></i> Read More ...</a>
                             </p>
						</div><!-- Member detail Wrapper -->
					</div><!-- Member Wrap -->
				</div><!-- Column -->
                <?php endforeach; endif; ?>
			</div><!-- Row -->
		</div><!-- Container -->
	</section><!-- Section -->
	
    <!-- Section -->
	<section id="gallery" class="bg-lgrey typo-dark">
		<div class="container">
			
			<div class="row">
				<!-- Title -->
				<div class="col-sm-12">
					<div class="title-container text-left">
						<div class="title-wrap">
							<h3 class="title">Gallery</h3>
							<span class="separator line-separator"></span>
						</div>
						<p class="description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur pellentesque neque eget diam</p>
					</div>
				</div><!-- Title -->
			</div><!-- Row -->
			
			<div class="row">
				<div class="col-md-12">
					<!-- Filters -->
					<div class="isotope-filters">
						<ul class="nav nav-pills">
                        <?php if($catagory_lists):
								foreach($catagory_lists as $catagory_list):
						 ?>
							<li><a href="#" data-filter=".<?= $catagory_list['catagory_id'] ?>" class="filter active"><?= $catagory_list['catagory_name'] ?></a></li>
                        <?php endforeach; endif; ?>
						</ul>
					</div><!-- Filters -->
					<!-- Gallery Block -->
					<div class="isotope-grid grid-three-column has-gutter-space" data-gutter="20" data-columns="3">
						<div class="grid-sizer"></div>
                        <?php if($gallery_images):
								foreach($gallery_images as $gallery_image):
						 ?>
						<!-- Portfolio Item -->
						<div class="item <?= $gallery_image['catagory_id'] ?>">
							<!-- Image Wrapper -->
							<div class="image-wrapper col-sm-3 col-xs-6">
								<!-- IMAGE -->
								<img src="<?= base_url();?>template/upload/photo_gallery/<?php echo $gallery_image['gallery_image_name'];?>" alt="" height="320"/>
								<!-- Gallery Btns Wrapper -->
								<div class="gallery-detail btns-wrapper">
									<a href="gallery-single.html" class="btn uni-upload-2"></a>
									<a href="<?= base_url();?>template/upload/photo_gallery/<?php echo $gallery_image['gallery_image_name'];?>" data-rel="prettyPhoto[portfolio]" class="btn uni-full-screen"></a>
								</div><!-- Gallery Btns Wrapper -->
							</div><!-- Image Wrapper -->
						</div><!-- Portfolio Item -->
                         <?php endforeach; endif; ?>
					</div><!-- Gallery Block -->
				</div><!-- Column -->
			</div><!-- Row -->
		</div><!-- Container -->
	</section><!-- Section -->
	
    <!-- Section -->
	<section class="typo-dark bg-grey">
		<div class="container">
			<div class="row">
				<!-- Title -->
				<div class="col-sm-12">
					<div class="title-container">
						<div class="title-wrap">
							<h3 class="title">Latest News & Notice</h3>
							<span class="separator line-separator"></span>
						</div>
						<p class="description">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Curabitur pellentesque neque eget diam</p>
					</div>
				</div><!-- Title -->
			</div><!-- Row -->
            
			<div class="row">
            	<div class="col-sm-12">
					<div class="owl-carousel" 
						data-animatein="" 
						data-animateout="" 
						data-items="1" 
						data-loop="true" 
						data-merge="true" 
						data-nav="false" 
						data-dots="true" 
						data-stagepadding="" 
						data-margin="10"
						data-mobile="1" 
						data-tablet="1" 
						data-desktopsmall="1"  
						data-desktop="3" 
						data-autoplay="true" 
						data-delay="3000" 
						data-navigation="true">
						
                        <!-- Item Begins -->
                 		<?php 
							foreach($notice_list as $nl):
								$string= $nl['notice_details'];
                                if (strlen($string) > 550)
									{
                                     	$stringCut = substr($string, 0, 550);
										$string = substr($stringCut, 0, strrpos($stringCut, ' '));
                                    }
                        ?>
                        <div class="col-sm-12 item">
                            <!-- Blog Grid Wrapper -->
                            <div class="blog-wrap">
                                <!-- Blog Detail Wrapper -->
                                <div class="blog-details">
                                    <h5><a href="<?= base_url();?>welcome/single_notice/<?= $nl['notice_id'];?>"><?= $nl['notice_heading'];?></a></h5>
                                    <p><?= $string ?></p>
                                    <a class="btn" href="<?php echo base_url();?>welcome/single_notice/<?php echo $nl['notice_id'];?>">Read More</a>
                                </div><!-- Blog Detail Wrapper -->
                            </div><!-- Blog Wrapper -->
                        </div><!-- Column -->
                
						<?php endforeach; ?>
                </div><!-- carousel -->
				</div><!-- Column -->
			</div><!-- Row -->
		</div><!-- Container -->
	</section><!-- Section -->

	<!-- Section -->
	<section class="relative bg-light typo-light bg-cover overlay" data-background="images/banner/bg-01.jpg">
		<div class="container parent-has-overlay">
			<div class="row">
				<!-- Column Begins -->
				<div class="col-sm-12">
					<div class="owl-carousel" 
						data-animatein="" 
						data-animateout="" 
						data-items="1" 
						data-loop="true" 
						data-merge="true" 
						data-nav="false" 
						data-dots="true" 
						data-stagepadding="" 
						data-margin="30"
						data-mobile="1" 
						data-tablet="1" 
						data-desktopsmall="1"  
						data-desktop="2" 
						data-autoplay="true" 
						data-delay="3000" 
						data-navigation="true">
						
						<!-- Item Ends -->
						<div class="item">
							<!-- Blockquote Wrapper -->
							<div class="quote-wrap dark">
								<blockquote>		
									<p>When you can earn more than you could ever imagine by doing something that you love.</p>
								</blockquote>
								<!-- Blockquote Author -->
								<div class="quote-author">
									<img width="80" height="80" src="images/default/thumb-01.jpg" class="img-responsive" alt="thumb">
									<!-- Blockquote Footer -->
									<div class="quote-footer">
										<h5 class="name"><a href="#">John Mathew</a></h5>
										<span>/ Parent</span>
									</div><!-- Blockquote Footer -->
								</div><!-- Blockquote Author -->
							</div><!-- Blockquote Wrapper -->
						</div><!-- Item Ends -->
						
						<!-- Item Ends -->
						<div class="item">
							<!-- Blockquote Wrapper -->
							<div class="quote-wrap dark">
								<blockquote>		
									<p>When you can earn more than you could ever imagine by doing something that you love.</p>
								</blockquote>
								<!-- Blockquote Author -->
								<div class="quote-author">
									<img width="80" height="80" src="images/default/thumb-02.jpg" class="img-responsive" alt="thumb">
									<!-- Blockquote Footer -->
									<div class="quote-footer">
										<h5 class="name"><a href="#">John Mathew</a></h5>
										<span>/ Parent</span>
									</div><!-- Blockquote Footer -->
								</div><!-- Blockquote Author -->
							</div><!-- Blockquote Wrapper -->
						</div><!-- Item Ends -->
						
						<!-- Item Ends -->
						<div class="item">
							<!-- Blockquote Wrapper -->
							<div class="quote-wrap dark">
								<blockquote>		
									<p>When you can earn more than you could ever imagine by doing something that you love.</p>
								</blockquote>
								<!-- Blockquote Author -->
								<div class="quote-author">
									<img width="80" height="80" src="images/default/thumb-03.jpg" class="img-responsive" alt="thumb">
									<!-- Blockquote Footer -->
									<div class="quote-footer">
										<h5 class="name"><a href="#">John Mathew</a></h5>
										<span>/ Parent</span>
									</div><!-- Blockquote Footer -->
								</div><!-- Blockquote Author -->
							</div><!-- Blockquote Wrapper -->
						</div><!-- Item Ends -->
						
						<!-- Item Ends -->
						<div class="item">
							<!-- Blockquote Wrapper -->
							<div class="quote-wrap dark">
								<blockquote>		
									<p>When you can earn more than you could ever imagine by doing something that you love.</p>
								</blockquote>
								<!-- Blockquote Author -->
								<div class="quote-author">
									<img width="80" height="80" src="images/default/thumb-04.jpg" class="img-responsive" alt="thumb">
									<!-- Blockquote Footer -->
									<div class="quote-footer">
										<h5 class="name"><a href="#">John Mathew</a></h5>
										<span>/ Parent</span>
									</div><!-- Blockquote Footer -->
								</div><!-- Blockquote Author -->
							</div><!-- Blockquote Wrapper -->
						</div><!-- Item Ends -->
                        
					</div><!-- carousel -->
				</div><!-- Column -->
			</div><!-- Row -->
		</div><!-- Container -->
	</section><!-- Section -->
       
    <?php require 'application/views/welcome/includes/footer.php';?>    