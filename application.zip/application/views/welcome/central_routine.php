<?php require 'application/views/welcome/includes/header.php';?>    
    <!-- ******CONTENT****** --> 
        <div class="content container" style="width:95%; margin:0px auto; background-color:#FFF; ">
            <div class="page-wrapper">
                <header class="page-heading clearfix">
                    <h1 class="heading-title pull-left"> Central Routine </h1>
                    <div class="breadcrumbs pull-right">
                        <ul class="breadcrumbs-list">
                            <li class="breadcrumbs-label">You are here :</li>
                            <li><a href="<?php echo base_url();?>">Home </a><i class="fa fa-angle-right"></i></li>
                            <li class="current"> Central Routine </li>
                        </ul>
                    </div><!--//breadcrumbs-->
                </header> 
                
                <div class="page-content">
                    <div class="row page-row">
                        <div class="news-wrapper col-md-12 col-sm-12 routine_view">
                            <article class="news-item" style="min-height: 200px;">
                                <div class="form-group" >
                                    <center>
                                        <div class="col-sm-12">                                            
                                            <h2><b><?php// echo $central_routine['heading']; ?></b></h2>
                                        </div>
                                    </center> 
                                    <div class="col-sm-12">
                                        <?php// echo $central_routine['details']; ?>
                                    </div>
                                </div>
                            </article><!--//news-item-->
                        </div><!--//news-wrapper-->
                        <aside class="page-sidebar  col-md-3 col-md-offset-1 col-sm-4 col-sm-offset-1 col-xs-12">
                        </aside>
                    </div><!--//page-row-->
                </div><!--//page-content-->
            </div><!--//page-wrapper-->
        </div><!--//content-->
    <?php require 'application/views/welcome/includes/footer.php';?> 
    
   
