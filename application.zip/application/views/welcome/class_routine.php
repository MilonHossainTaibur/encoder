<?php require 'application/views/welcome/includes/header.php';?>    

    <!-- ******CONTENT****** --> 
        <div class="content container" style="width:95%; margin:0px auto; background-color:#FFF; ">
            <div class="page-wrapper">
                <header class="page-heading clearfix">
                    <h2 class="heading-title pull-left">Calss Routine</h2>
                    <div class="breadcrumbs pull-right">
                        <ul class="breadcrumbs-list">
                            <li class="breadcrumbs-label">You are here : </li>
                            <li><a href="<?php echo base_url();?>">Home</a><i class="fa fa-angle-right"></i></li>
                            <li class="current">Calss Routine</li>
                        </ul>
                    </div><!--//breadcrumbs-->
                </header> 
                
                
 <div class="page-content">
                    <div class="row page-row">
                            
                                            <div class="widget-content padding">
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-sm-4">
                                                            <label>Class</label>
                                                            <select class="form-control" name="class_id" id="class_id" onchange="get_class_section_list(this.value); get_class_group_list(this.value);">
                                                                <option value="">----Select Class----</option>
                                                                <?php
                                                                    foreach($class_list as $cl){ ?>
                                                                    <option value="<?php echo $cl['class_id'];?>"><?php echo $cl['class_name'];?></option>   
                                                                <?php    } ?>
                                                            </select>
                                                        </div>
                                                     <div class="col-sm-4">
                                                            <label>Section</label>
                                                            <select class="form-control" name="section_id" id="section_id" />
                                                                <option value="">Select</option>
                                                            </select>
                                                        </div>
                                                         <div class="col-sm-4">
                                                           <label>Group</label>
                                                            <select class="form-control" name="group_id" id="group_id" required />
                                                                <option value="">Select</option>
                                                            </select>
                                                        </div>
                                                     </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-sm-4">
                                                           <label>Shift</label>
                                                            <select class="form-control" name="shift_id" id="shift_id" required />
                                                                <option value="">-----Select Shift-----</option>
                                                                 <?php
                                                                    foreach($shift_list as $sl){ ?>
                                                                     <option value="<?php echo $sl['shift_id'];?>"><?php echo $sl['shift_name'];?></option>   
                                                                <?php    }
                                                                ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                   
                                                
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-sm-4">
                                                            <button type="button" class="btn btn-primary" onclick="get_class_routine_json()">Get Routine Grid</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div id="display">
                                           

                                            </div>
                                            
                                    </div>
                                </div>
                            </div>
			</div>
			<?php require 'application/views/welcome/includes/footer.php';?>
                    
<script type="text/javascript">
function get_class_section_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'welcome/section_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#section_id').html(html_data);
        }
    }
    });
}

function get_class_group_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'welcome/group_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#group_id').html(html_data);
        }
    }
    });  
}

// get the student list and fees list 
	function get_class_routine_json()
	{
        $.ajax({ 
        url: baseUrl+'welcome/get_class_routine_json_show',
        data:
            {                  
                'class_id':$('#class_id').val(),
				'section_id':$('#section_id').val(),
				'group_id':$('#group_id').val(),
				'shift_id':$('#shift_id').val()
            }, 
            dataType: 'json',
            success: function(data)
            {
                result                = ''+data['result']+'';
                mainContent           = ''+data['mainContent']+'';

                if(result == 'success')
                {      
                    $('#display').html(mainContent);  
					// call the routine if created before
					get_old_class_routine();
                }                
            }
        });
        return false; // keeps the page from not refreshing     
    }
</script>
<script>
function get_old_class_routine()
{
	$.getJSON( baseUrl + 'welcome/get_old_routine_by_section_class_show',
				{
					'class_id':$('#class_id').val(),
					'section_id':$('#section_id').val(),
					'group_id':$('#group_id').val(),
					'shift_id':$('#shift_id').val()
				},
				function(jd) {
					for(i=0; i<jd.length; i++)
					{
						$("td[id='"+jd[i].day+"'] span#tid"+jd[i].column_no).html(jd[i].teacher_name);
						$("td[id='"+jd[i].day+"'] span#cid"+jd[i].column_no).html('('+jd[i].subject_name+')');
					}
				}
			);
					
			var clPeriod=new Array();  
			var iclPeriod=0;
			$( "td#clperiod").each(function() {
				clPeriod[iclPeriod]=$(this).html();
								
				if($(this).html()=="tiffin")
				{//alert(iclPeriod);
					$('span#tid'+iclPeriod).html("<br/><span style=''>Break</span>");
					$('span#cid'+iclPeriod).html("");
				}
				iclPeriod++;
			});					
}

function printPageArea(areaID){
		var printContent = document.getElementById(areaID);
		var WinPrint = window.open('', '', 'width=900,height=650');
		WinPrint.document.write('<link rel="stylesheet" type="text/css" href="<?= base_url();?>template/bootstrap-print/bootstrap-print.min.css" media="print" />')
		WinPrint.document.write('<style type="text/css" media="print"> @page { size: landscape;} table td{padding:3px;} table{font-size:12px;} .print_button{ display:none;} </style>')
		WinPrint.document.write(printContent.innerHTML);
		WinPrint.document.close();
		WinPrint.focus();
		WinPrint.print();
		WinPrint.close();
	}
</script>

    
