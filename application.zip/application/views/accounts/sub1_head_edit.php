<?php include 'application/views/includes/admin_header.php';?> <!--- Admin Header -->
<?php include 'application/views/includes/admin_sidebar.php';?> <!----Admin Sidebar -->
</div>
       
        <div class="content-page">			
            <div class="content">
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i>Sub1 Head Edit</h1>
                </div>
				
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="widget" style="min-height:500px;">
                            <div class="widget-content padding">
                                <form role="form" id="registerForm" name="registerForm" method="POST" action="<?php echo base_url();?>accounts/sub1_head_list" enctype="multipart/form-data">
									
									<div class="form-group">
										<ul class="list-inline">
											<li><a  href="<?php echo base_url();?>accounts/sub1_head_create" class="text-muted small btn btn-info">Sub1 Head Create</a> </li> |
											<li><a href="<?php echo base_url();?>accounts/sub1_head_list" class="text-muted small">Sub1 Head List</a> </li>
										</ul>
									</div>
									
									<div class="form-group">
                                        <div class="row">
										
											<div class="col-sm-6">
                                                <label>Master Head <span style="color:red;">*</span></label>
                                                
												<input type="text" class="form-control" value="<?php echo $sub1_head_edit['master_code']."-".$sub1_head_edit['fcoa_master'];?>" readonly>
												<input type="hidden" name="fcoa_master_id" value="<?php echo $sub1_head_edit['fcoa_master_id'];?>" />
											</div>
											
											<div class="col-sm-6">
                                                <label>Opening Balance</label>
                                                <input type="text" class="form-control" name="fcoa_balance" id="fcoa_balance" value="<?php echo $sub1_head_edit['fcoa_balance'];?>" onkeyup="removeChar(this)">
                                            </div>
											
										</div>
									</div>
									
									<div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <label>Sub1 Head Name <span style="color:red;">*</span></label>
                                                <input type="text" class="form-control" name="fcoa" id="fcoa" value="<?php echo $sub1_head_edit['fcoa'];?>" required />
                                            </div>
                                            
											<div class="col-sm-6">
                                                <label>Sub1 Head Code <span style="color:red;">*</span></label>
                                                <input type="text" class="form-control" name="fcoa_code" id="fcoa_code" value="<?php echo $sub1_head_edit['fcoa_code'];?>" onkeyup="removeChar(this)" required />
                                            </div>
                                        </div>
                                    </div>									
									
                                    
									<input type="hidden" name="fcoa_id" value="<?php echo $sub1_head_edit['fcoa_id'];?>" />
									<button type="submit" class="btn btn-primary">Update</button>
								</form>
                            </div>
                        </div>
                    </div>
                </div>
				
				
<?php include 'application/views/includes/footer.php';?>