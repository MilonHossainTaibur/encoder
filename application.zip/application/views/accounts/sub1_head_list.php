<?php include 'application/views/includes/admin_header.php';?>
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
	<div class="content-page">
		<!-- ============================================================== -->
		<!-- Start Content here -->
		<!-- ============================================================== -->
		<div class="content">
			<div class="page-heading">
				<h1><i class='fa fa-table'></i> Sub1 Head List</h1>
			</div>       
			
			<?php if($this->session->flashdata('message')):?>
			<div class="alert alert-success">
				<a href="#" class="close" data-dismiss="alert">&times;</a>
				<?=$this->session->flashdata('message')?>
			</div>
			<?php endif?>
				
			<div class="row">					
				<div class="col-md-12">
					<div class="widget">							
						<div class="widget-content">
							<div class="form-group" style="padding-left:10px;">
								<ul class="list-inline">
									<li><a class="btn btn-info" href="<?php echo base_url();?>accounts/sub1_head_create" class="text-muted small"><i class="fa fa-plus" aria-hidden="true"></i>
Sub1 Head Create</a> </li>
								</ul>
							</div>					
							<div class="table-responsive">
									
								<form class='form-horizontal' role='form'>	
								<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
										<thead>
											<tr>
												<th>SL #</th>
												<th>Master Head</th>
												<th>Sub1 Head</th>
												<th>Opening Balance</th>
												<th>Action</th>
											</tr>
										</thead>
								 
										<tfoot>
											<tr>
												<th>SL #</th>
												<th>Master Head</th>
												<th>Sub1 Head</th>
												<th>Opening Balance</th>
												<th>Action</th>
											</tr>
										</tfoot>
								 
										<tbody>
											<?php
												foreach($sub1_head_list as $row){ 
												
											?>
												<tr>
													<td><?php echo $row['fcoa_id'];?></td>
													<td><?php echo $row['master_code']."-".$row['fcoa_master'];?></td>
													<td><?php echo $row['fcoa_code']."-".$row['fcoa'];?></td>
													<td><?php echo $row['fcoa_balance'];?></td>
													<td>
														<a href="<?php echo base_url();?>accounts/sub1_head_edit/<?php echo $row['fcoa_id'];?>" title="Edit"><i class="fa fa-edit"></i></a> | <a onClick='return delete_alert("Are you sure Delete Sub1 Head ????");' href="<?php echo base_url();?>accounts/sub1_head_delete/<?php echo $row['fcoa_id'];?>" title="Delete"><i class="fa fa-remove"></i></a> 
													</td>
												</tr>
											<?php 	} ?>
										</tbody>
									</table>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
<?php include 'application/views/includes/footer.php';?>