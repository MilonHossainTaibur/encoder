<table id="" class="table table-striped table-bordered" style="text-align:center;">
	<thead >
    	<tr style="border-top:1px;">
        	<th style="min-width:125px;">Exam Date</th>
            <th style="min-width:125px;">Exam Day</th>
            	<?php  foreach($exam_time as $et){ ?>
    		<th style="min-width:125px;"><span ><?= $et['exam_time'];?></span>
            	<input type="hidden" class="class_time" value="<?= $et['id'] ?>" />
            </th>  
                  <?php }?>
        </tr>
    </thead>
    <tbody>
    	<?php   for($s=0; $s<count($subject); $s++){ ?>
        <tr>
            <td class="date<?= $s ?>" id="<?= $s ?>"><input type="text" class="timerange" onchange="get_day(this.value,<?php echo $s;?>)" /></td>
            <td class="wday" id="wkday<?= $s ?>"></td>
            <?php   for($i=0; $i<count($exam_time); $i++){ ?>
            <td id="<?= $s ?><?= $i ?>">
            	 <select class="form-control subject_name<?= $i ?>">
                 	<option value="">Select Subject</option>
                 	<?php  foreach($subject as $st){ ?>
                     <option value='<?= $st['subject_id'] ?>'><?= $st['subject_name'] ?></option>
                      <?php }?>
                 </select>
            </td>
            <?php }?>
        </tr>
         <?php }?>
    </tbody>
</table>
                                                    
 
                   <div class="col-sm-4">
                          <button type="button" class="btn btn-primary" onclick="save_class_routine()">save</button>
                   </div>
                   
 <script type="text/javascript">
function timerange(){
    $('input[class="timerange"]').daterangepicker({
        singleDatePicker: true,
        showDropdowns: true,
		locale: {
            format: 'YYYY-MM-DD'
        }
    });
}
timerange();
</script>