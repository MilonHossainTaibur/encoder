<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">			
            <div class="content">
			
            <?php if($this->session->flashdata('message')):?>
				<?=$this->session->flashdata('message')?>
			<?php endif?>
            
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i> Term List</h1>
                </div>
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">				
					<div class="col-md-12">
						<div class="widget">
                        	<div class="widget-content padding">
								<a class="btn btn-info" href="javascript:void(0);" onclick="toggle_insertion_box(); return false;"><i class="fa fa-plus" aria-hidden="true"></i>
Add New Term</a>
								<div class="insertion_div">
									<form role="form" id="hw_entry" name="hw_entry" method="POST" action="<?php echo base_url();?>exam/create_term_save">
                                   
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label>Term Name</label>
                                                <input type="text" class="form-control" name="term_name" id="term_name" required>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <div class="row">
											<div class="col-sm-4">
                                                <input type="checkbox" class="form-control" name="year_end_exam" value="1">
                                                <label>Year Ending Exam</label>
                                                <br/>
                                                <b>NB:</b> Check this if this is the final.
                                            </div>
                                        </div>
                                    </div>
									
									<button type="submit" class="btn btn-primary">Submit</button>
								</form>
                            </div>
                        </div>
						<div class="widget-content padding">
							<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
								<thead>
									<tr>
										<th>SLNO</th>
										<th>Name</th>
									    <th>Action</th>
									</tr>
								</thead>
								<tbody>
										<?php $ti=1; foreach($term_list as $tl){ ?>
									<tr>
										<td><?= $ti;?></td>
										<td><?= $tl['term'];?></td>
										<td>
											<a href="<?php echo base_url();?>exam/term_edit/<?= $tl['term_id'];?>" title="Edit"><i class="fa fa-edit"></i></a> | 
     										<?=anchor("exam/term_delete/".$tl['term_id'],"<i class=\"fa fa-remove\"></i>",array('onclick' => "return confirm('Do you want delete this record')"))?> 
										</td>
									</tr>
									<?php  $ti++;  } ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
	

				
<?php include 'application/views/includes/footer.php';?>
