<style>
    .td_style{
        font-size: 12px;
    }

</style>

<body style="width:100%">
<div  style="width:100%;height:50%;">
    <?php foreach($student_info as $sinfo){?>
        <div style="float: left;padding:10px; border-bottom:1px dashed black;border: 1px solid #000;margin-bottom: 15px">
            <table width="700px" style="padding-top: 15px;">
                <tr >
                    <td rowspan="4">
                    <div class="logo">
                        <img src="<?= base_url(); ?>upload/institute_logo/<?= $school['logo'];?>" alt="" height="100" width="100" />
                    </div>
                    </td>
                    <td style="text-align: center"><span style="font-size:18px;font-weight: 600;"><?= $school['school_name']; ?></span></td>
                    <td rowspan="4">
                        <div class="logo">
                            <img src="<?php echo base_url();?>upload/student_image/<?php echo $sinfo['student_image'];?>" alt="Student Image" width="80" height="100"/>
                        </div>
                    </td>
                </tr>
                <tr>
                    <td style="font-size:13px;text-align: center" ><?= $school['address']; ?>, <?= $school['post_office']; ?>, <?= $school['district']; ?></td>
                </tr>
                <tr>
                    <td style="font-size:13px;text-align: center;margin-bottom: 8px" >Email: <?= $school['email']; ?><br> Website: <?= $school['website']; ?></td>
                </tr>
                <tr>
                    <td style="text-align: center;padding: 10px" class="text-center">
                        <span style="padding:4px 18px; font-size:12px;background-color: #6595E9;color: #fff;font-weight: 700;text-transform: uppercase;border:1px solid #000;font-family: Arial;">Admit Card</span>
                    </td>
                </tr>
                <tr>
                    <td width=""><span style="font-size: 14px">Name of the Exam : </span></td>
                    <td width=""><span style="font-weight:bold;text-transform: capitalize;float: left;font-size: 14px"><?php echo $term[0]['term'].'   '.$session[0]['session_name'] ?></span></td>
                </tr>
            </table>
            <table width="100%">
                <tr>
                    <td width="80"><span class="td_style">Student Index</span></td>
                    <td width="130" style="border-bottom: 1px dashed #000;font-size: 13px">:<?php echo $sinfo['student_id']; ?></td>
                    <td width="50"><span class="td_style" style="padding-left: 15px;">Class </span></td>
                    <td width="130" style="border-bottom: 1px dashed #000;font-size: 13px;">: <?php echo $sinfo['class_name']; ?></td>
                </tr>
                <tr>
                    <td width="80"><span class="td_style">Student Name</span></td>
                    <td width="200" style="border-bottom: 1px dashed #000;text-transform: uppercase;font-size: 13px;font-weight: bold;">: <?php echo ucwords($sinfo['student_name']); ?></td>
                    <td width="50px"><span class="td_style" style="padding-left: 15px;">Roll</span></td>
                    <td style="border-bottom: 1px dashed #000;font-size: 13px;font-weight: bold;">: <?php echo $sinfo['roll_no']; ?></td>
                </tr>
                <tr>
                    <td width="80"><span class="td_style">Father Name</span></td>
                    <td style="border-bottom: 1px dashed #000;font-size: 13px;text-transform: capitalize;">: <?php echo ucwords($sinfo['father_name']); ?></td>
                    <td width="50"><span class="td_style" style="padding-left: 15px;">Group</span></td>
                    <td style="border-bottom: 1px dashed #000;font-size: 13px">: <span><?php echo ucwords($sinfo['group_name']); ?></span></td>
                </tr>
                <tr>
                    <td width="80"><span class="td_style">Mother Name</span></td>
                    <td style="border-bottom: 1px dashed #000;text-transform: capitalize;font-size: 13px">: <?php echo ucwords($sinfo['mother_name']); ?></td>
                    <td width="50"><span class="td_style" style="padding-left: 15px;">Section </span></td>
                    <td style="border-bottom: 1px dashed #000;font-size: 13px">: <?php echo ucwords($sinfo['section_name']); ?></td>
                </tr>
            </table>

<h5 style="text-align: center;border:1px solid #000;background-color: #D0DFF4;padding: 2px;margin: 8px 0px 0px;">Exam Routine (<?php print_r($exam_routine[0][0]['examtime']); ?>)</h5>
            <table width="100%" border="1" class="td_style" style="margin-bottom: 5px">
 
                <?php foreach($exam_routine as $routine_array_chunk){?>
                <tr>
                    <?php $r_flag=0; foreach($routine_array_chunk as $routine){ ?>

                        <?php
                        if($routine['subject_id']==5 || $routine['subject_id']==6 || $routine['subject_id']==7 || $routine['subject_id']==8){
echo "<td>".date('d/M/Y(D)',strtotime($routine['exam_date'],$routine['examtime']))."</td>";
							if($r_flag==0){
							 
							echo "<td>Religion & Moral Education</td>";$r_flag=1;
							    
							}
						
					}
						else{
						    echo "<td>".date('d/M/Y(D)',strtotime($routine['exam_date']))."</td>";
						   	echo "<td>".$routine['subject_name']."</td>";
                        
                         ?>
                         <?php } ?>
                     <?php } ?>
                </tr>
                <?php } ?>
            </table>

            <table class="table notice bangla" width="100%">
                <tr>
                    <td width="350" style="text-align: center;">
                        <span style="text-align: center;background-color: #750200;color: #fff;border-radius: 20px;font-weight: 700;padding: 5px;font-size: 14px">পরীক্ষা সংক্রান্ত নিয়মাবলী</span>
                    </td>

                    <td rowspan="5"></td>
                    <td rowspan="5"></td>
                </tr>
                <tr>
                    <td width="350" style="text-align: justify;">&#x2605; পরীক্ষা শুরু হওয়ার কমপক্ষে ৩০ মিনিট পূর্বে হলে আসতে হবে।</td>
                </tr>
                <tr>
                    <td width="350" style="text-align: justify;">&#x2605; প্রবেশপত্র ছাড়া কোন কাগজপত্র পরীক্ষার হলে বহন করা যাবে না।</td>
                </tr>
                <tr>
                    <td width="350" style="text-align: justify;">&#x2605; প্রত্যেক পরীক্ষার্থীকে প্রয়োজনীয় কলম, পেন্সিল ও জ্যামিতি বক্স আনতে হবে।</td>
                </tr>
                <tr>
                    <td width="350" style="text-align: justify;">&#x2605; পরীক্ষা শেষ হওয়ার পর পরিদর্শকের নির্দেশক্রমে পরীক্ষার্থী কেন্দ্র ত্যাগ করবে।</td>
                </tr>
                <tr>
                    <td width="350" style="text-align: justify;">&#x2605; কোন শিক্ষার্থী  অসৎ উপায় অবলম্বন করলে তার পরীক্ষা বাতিল বলে গন্য হবে</td>
                    <td style="text-align:center;"><h5 style="border-top: 1px dashed #000;font-size: 15px;padding:0px;margin:0px;">Assistant  Teacher</h5></td>
                    <td style="text-align:center;position: relative;"><h5 style="border-top: 1px dashed #000;font-size: 15px;padding:0px;margin:0px;">Head Teacher</td>
                </tr>
            <tr>

            </tr>
            </table>

                    
        </div>
        <style>
        @font-face {
    font-family: 'SutonnyMJ';
    src: url('http://localhost/dhanai/template/assets/fonts/SutonnyOMJ.ttf') format('truetype');
}
        table {
    border-collapse: collapse;
}

.routine tr>td {
    border: 1px solid #bdc3c7;
    padding: 3px;
    font-size:12px;
    font-family: 'SutonnyMJ';
}
.notice tr>td {
    padding: 3px;
    font-size:10px;
}
 

        </style>
  <?php } ?>
</div>
</body>