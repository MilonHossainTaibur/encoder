<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
	<div class="content-page">
		<!-- ============================================================== -->
		<!-- Start Content here -->
		<!-- ============================================================== -->
		<div class="content">
		
        <?php if($this->session->flashdata('message')):?>
			<?=$this->session->flashdata('message')?>
		<?php endif?>
            
			<div class="page-heading">
            	<h1><i class='fa fa-table'></i> Admission</h1>
			</div>            	
			<div class="row">
            	<div class="col-md-12">
                	<div class="widget" style="min-height: 400px">
                    	<div class="widget-content">
                            <div class="form-group">
								<div class="row">
									<div class="col-sm-12 col-md-6 col-md-offset-3" id="display">
                                           	<!---JSON Content will be displayed here--->
                                           		<form role="form" id="registerForm" method="POST" action="<?= base_url();?>exam/admission_marks_save">
													<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%" border=1>
														<thead>
															<tr>
																<th>Roll No</th>
																<th>Marks</th>
															</tr>
														</thead>
														<tbody>
																<?php for ($x = 0; $x <= 179; $x++) {?>
																<tr>
																	<td>
																		<input type="text" class="form-control" name="roll_sl[]" value="<?php echo $x+1; ?>" disabled/>
																		<input type="hidden" class="form-control" name="roll_no[]" value="<?php echo $x+1; ?>"/>
																	</td>
																	<td>
																		<input type="text" class="form-control" name="marks[]" value="<?php echo $results[$x]['get_mark'];?>" />
																	</td>
																</tr>
																<?php } ?>
																<tr>
																	<td colspan="2">
																		<input type="button" class="btn btn-primary" onClick="printPageArea('display')" value="Print This"/>
																		<input type="submit" class="btn btn-primary" value="Save"/><br/>
																	</td>
																</tr>
														</tbody>
													</table>
												</form>

<style>
{
	margin:auto auto;
}
</style>
<script>
function validation(number,student_id,marks)
{
	///var full_marks =parseInt($('.full_marks').text());
	var numbers=/^([0-9.]*)$/;
		if (numbers.test(number))
			{
				if(number>marks)
				{
					$('#obtain_marks'+student_id).after("<div id='validation"+student_id+"' class='validation_js_small'>This number is more than Full Marks</div>")
						$('#validation'+student_id).delay(2000).hide('slow');
						
					$('#obtain_marks'+student_id).val("");
				}
			}
		else
			{
				
				$('#obtain_marks'+student_id).after("<div id='validation"+student_id+"' class='validation_js_small'>Please enter number only</div>")
						$('#validation'+student_id).delay(2000).hide('slow');
				$('#obtain_marks'+student_id).val("");
			}
	
	
}
function validation_obj(number,student_id,marks)
{
	///var full_marks =parseInt($('.full_marks').text());
	var numbers=/^([0-9.]*)$/;
		if (numbers.test(number))
			{
				if(number>marks)
				{
					$('#objective_marks'+student_id).after("<div id='validation_obj"+student_id+"' class='validation_js_small'>This number is more than Full Marks</div>")
						$('#validation_obj'+student_id).delay(2000).hide('slow');
						
					$('#objective_marks'+student_id).val("");
				}
			}
		else
			{
				
				$('#objective_marks'+student_id).after("<div id='validation_obj"+student_id+"' class='validation_js_small'>Please enter number only</div>")
						$('#validation_obj'+student_id).delay(2000).hide('slow');
				$('#objective_marks'+student_id).val("");
			}
	
	
}
function validation_prac(number,student_id,marks)
{
	///var full_marks =parseInt($('.full_marks').text());
	var numbers=/^([0-9.]*)$/;
		if (numbers.test(number))
			{
				if(number>marks)
				{
					$('#practical_marks'+student_id).after("<div id='validation_prac"+student_id+"' class='validation_js_small'>This number is more than Full Marks</div>")
						$('#validation_prac'+student_id).delay(2000).hide('slow');
						
					$('#practical_marks'+student_id).val("");
				}
			}
		else
			{
				
				$('#practical_marks'+student_id).after("<div id='validation_prac"+student_id+"' class='validation_js_small'>Please enter number only</div>")
						$('#validation_prac'+student_id).delay(2000).hide('slow');
				$('#practical_marks'+student_id).val("");
			}
	
	
}
</script>
									</div>
								</div>
							</div>
                            
                        </div>
                    </div>
                </div>
			</div>

				
				
<?php include 'application/views/includes/footer.php';?>

<script>


function get_class_section_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'admin/section_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#section_id').html(html_data);
        }
    }
    });  
}

function get_class_group_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'academic/group_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#group_id').html(html_data);
        }
    }
    });  
}

function get_sub_list(group_id)
{
	var class_id=$('#class_id').val();
   $.ajax({
    type: "POST",
    url: baseUrl + 'academic/subject_list_ajax',
    data:
    {
        'class_id':class_id,
		'group_id':group_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
			$('#subject_id').html(html_data);
        }
    }
    });  
}

    function term_marks_json()
    {
        var class_id = $('#class_id').val();
        var class_short_name = $('#class_id :selected').attr('id');
		var section_id = $('#section_id').val();
		var group_id = $('#group_id').val();  
		var subject_id = $('#subject_id').val();
		var session_id = $('#session_id').val();  
		var term_id = $('#term_id').val();
		var term_name = $('#term_id :selected').text();
		var shift_id = $('#shift_id').val();
		var exam_year = $('#exam_year').val();
		
		var details_data = {school_name:'<?= $sc_info['school_name'];?>', class_name:$('#class_id :selected').text(), section_name:$('#section_id :selected').text(),group_name:$('#group_id :selected').text(),shift_name:$('#shift_id :selected').text(),subject_name:$('#subject_id :selected').text(),term_name:$('#term_id :selected').text()};
		
		if(!class_id)
		{
			$('#class_id').after("<div id='validation_class' class='validation_js'>Please select a class.</div>")
				$('#validation_class').delay(3000).hide('slow');
				return;
			
		}
		if(!section_id)
		{
			$('#section_id').after("<div id='validation_section' class='validation_js'>Please select a section.</div>")
				$('#validation_section').delay(3000).hide('slow');
				return;
			
		}
		if(!group_id)
		{
			$('#group_id').after("<div id='validation_group' class='validation_js'>Please select a group.</div>")
				$('#validation_group').delay(3000).hide('slow');
				return;
			
		}
		if(!subject_id)
		{
			$('#subject_id').after("<div id='validation_sub' class='validation_js'>Please select a subject.</div>")
				$('#validation_sub').delay(3000).hide('slow');
				return;
			
		}
		if(!session_id)
		{
			$('#session_id').after("<div id='validation_ses' class='validation_js'>Please select a session.</div>")
				$('#validation_ses').delay(3000).hide('slow');
				return;
			
		}
		if(!term_id)
		{
			$('#term_id').after("<div id='validation_ct' class='validation_js'>Please select a term.</div>")
				$('#validation_ct').delay(3000).hide('slow');
				return;
			
		}
		if(!shift_id)
		{
			$('#shift_id').after("<div id='validation_shift' class='validation_js'>Please select a shift.</div>")
				$('#validation_shift').delay(3000).hide('slow');
				return;
			
		}
		if(!exam_year)
		{
			$('#exam_year').after("<div id='validation_ex' class='validation_js'>Please put exam year.</div>")
				$('#validation_ex').delay(3000).hide('slow');
				return;
			
		}
		if(exam_year.length<4)
		{
			$('#exam_year').after("<div id='validation_ex' class='validation_js'>Please put four digit exam year(YYYY).</div>")
				$('#validation_ex').delay(3000).hide('slow');
				return;
			
		}
		
        $.ajax({ 
        url: baseUrl+'exam/get_student_list_for_term_json',
        data:
            {                  
                'class_id':class_id,
                'class_short_name':class_short_name,
				'section_id':section_id,
				'group_id':group_id,
				'subject_id':subject_id,
				'session_id':session_id,
				'term_id':term_id,
				'term_name':term_name,
				'shift_id':shift_id,
				'exam_year':exam_year,
				'details_data':details_data
            }, 
            dataType: 'json',
            success: function(data)
            {
                result                = ''+data['result']+'';
                mainContent           = ''+data['mainContent']+'';

                if(result == 'success')
                {            
                    $('#display').html(mainContent);     
                }                
            }
        });
        return false; // keeps the page from not refreshing     
    }
	
	function printPageArea(areaID){
		var printContent = document.getElementById(areaID);
		var WinPrint = window.open('', '', 'width=900,height=650');
		WinPrint.document.write('<link rel="stylesheet" type="text/css" href="<?= base_url();?>template/bootstrap-print/bootstrap-print.min.css" media="print" />')
		WinPrint.document.write('<style type="text/css" media="print"> @page { size: landscape; font-size:12px; } table{font-size:12px;} table td{padding:3px;} .print_button{ display:none;} </style>')
		WinPrint.document.write(printContent.innerHTML);
		WinPrint.document.close();
		WinPrint.focus();
		WinPrint.print();
		WinPrint.close();
	}
</script>