<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
<div class="content-page">			
    <div class="content">
        <?php if($this->session->flashdata('message')):?>
			<?=$this->session->flashdata('message')?>
		<?php endif?>
            
        <!-- Page Heading Start -->
        <div class="page-heading">
            <h1><i class='fa fa-check'></i> Marks Distribution System </h1>
        </div>
        <!-- Page Heading End-->
        <!-- Your awesome content goes here -->
        <div class="row">
            <div class="col-sm-12">
                <div class="widget" style="min-height:500px;">
                    <div class="widget-content padding">
						<div class="row">				
                            <div class="col-md-12">
                                <div class="widget">
                                    <div class="widget-content">
                                        <div class="form-group">
                                            <div class="row">
                                                <div class="col-sm-4">
                                                    <label>Class <span style="color:red;">*</span></label>
                                              		<select class="form-control" name="class_id" id="class_id"  onchange="get_class_group_list(this.value);">
                                                        <option value="">Select</option>
                                                        <?php foreach($class_list as $cl){ ?>
                                                        <option value="<?php echo $cl['class_id'];?>"><?php echo $cl['class_name'];?></option>
                                                        <?php } ?>
                                                    </select>
                                                </div>
                                                <div class="col-sm-4">
                                                    <label>Group <span style="color:red;">*</span></label>
                                                    <select class="form-control" name="group_id" id="group_id" required onChange="get_sub_list(this.value);" >
                                                        <option value="">Select</option>
                                                    </select>
                                            	</div>
                                                <div class="col-sm-4">
                                                    <label>Subject <span style="color:red;">*</span></label>
                                                    <select class="form-control" name="subject_id" id="subject_id">
                                                        <option value="">Select</option>
                                                    </select>
												</div>
                                            </div>
                                        </div> 
										<div class="form-group">
                                            <div class="row">
                                                <div class="col-sm-4">
                                 					<button type="button" class="btn btn-primary" style="margin-top:25px;" onclick="mark_distribution_system_json();">Get Rows</button>
                                                </div>
                                            </div>
                                        </div> 
                                         
                                        <div id="display">
                                        
                                            <!-- Content will be display here--->
                                        
                                        </div>
                                    </div>
                                </div>
                            </div>
						</div>
                          
                        <div class="form-group">
                            <div class="row">
                                <div class="col-sm-12">
                                    <table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
										<thead>
											<tr>
                                                <th>SLNO</th>
                                                <th>Class Name</th>
                                                <th>Group Name</th>
                                                <th>Subject Name</th>
                                                <th>Class attendance</th>
                                                <th>Class Work</th>
                                                <th>Home Work</th>
                                                <th>Class Test</th>
                                                <th>Assignment/Project</th>
                                                <th>Term Exam</th>
                                                <th>Action</th>
											</tr>
										</thead>
										<tbody>
											<?php $ci=1; foreach($mark_distribution_list as $mdl){ ?>
											<tr>
												<td><?= $ci;?></td>
                                                <td><?= $mdl['class_name'];?></td>
												<td><?= $mdl['group_name'];?></td>
                                                <td><?= $mdl['subject_name'];?></td>
                                                <td><?= str_replace(',', '', $mdl['ca']);?></td>
                                                <td><?= str_replace(',', '', $mdl['cw']);?></td>
                                                <td><?= str_replace(',', '', $mdl['hw']);?></td>
                                                <td><?= str_replace(',', '', $mdl['ct']);?></td>
                                                <td><?= str_replace(',', '', $mdl['aspj']);?></td>
                                                <td><?= str_replace(',', '', $mdl['te']);?></td>
                                                <td>
                                                	<a style=" cursor:pointer;"title="Edit" onClick="mark_distribution_system_json(<?= $mdl['class_id'];?>,<?= $mdl['group_id'];?>,<?= $mdl['subject_id'];?>)"><i class="fa fa-edit"></i></a> | 
													<?=anchor("exam/mark_distribution_system_delete/".$mdl['class_id']."/".$mdl['group_id']."/".$mdl['subject_id'],"<i class=\"fa fa-remove\"></i>",array('onclick' => "return confirm('Do you want delete this record')"))?>
                                                </td>
											</tr>
											<?php $ci++; } ?>
										</tbody>
									</table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php include 'application/views/includes/footer.php';?>
<script>
function get_class_group_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'academic/group_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#group_id').html(html_data);
        }
    }
    });  
}

function get_sub_list(group_id)
{
	var class_id=$('#class_id').val();
	//var group_id = $('#group_id').val();  
   $.ajax({
    type: "POST",
    url: baseUrl + 'exam/subject_list_mark_dist_ajax',
    data:
    {
        'class_id':class_id,
		'group_id':group_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
			$('#subject_id').html(html_data);
        }
    }
    });  
}

    function mark_distribution_system_json(class_id,group_id,subject_id)
    {
        if(!class_id)
			class_id = $('#class_id').val();
			
		if(!group_id)
			group_id = $('#group_id').val(); 
			
		if(!subject_id)	 
			subject_id = $('#subject_id').val();  
		
		if(!class_id)
		{
			$('#class_id').after("<div id='validation_class' style='position:absolute; background-color:#7ECCAD; width:auto; color:#fff; font-size:14px; font-weight:bold; border-radius:0px 15px 0px 15px; box-shadow:1px 1px 1px 1px #5DAF8F; padding:8px 8px 8px 8px; alignment-adjust:central; text-shadow:#FFE1FF;'> Please select a class name </div>")
						$('#validation_class').fadeToggle(5000);
						return;
			
		}
		
		if(!group_id)
		{
			$('#group_id').after("<div id='validation_group' style='position:absolute; background-color:#7ECCAD; width:auto; color:#fff; font-size:14px; font-weight:bold; border-radius:0px 15px 0px 15px; box-shadow:1px 1px 1px 1px #5DAF8F; padding:8px 8px 8px 8px; alignment-adjust:central; text-shadow:#FFE1FF;'> Please select a group name </div>")
						$('#validation_group').fadeToggle(5000);
						return;
			
		}
		if(!subject_id)
		{
			$('#subject_id').after("<div id='validation_sub' style='position:absolute; background-color:#7ECCAD; width:auto; color:#fff; font-size:14px; font-weight:bold; border-radius:0px 15px 0px 15px; box-shadow:1px 1px 1px 1px #5DAF8F; padding:8px 8px 8px 8px; alignment-adjust:central; text-shadow:#FFE1FF;'> Please select a subject name </div>")
						$('#validation_sub').fadeToggle(5000);
						return;
			
		}
		
        $.ajax({ 
        url: baseUrl+'exam/mark_distribution_system_json',
        data:
            {                  
                'class_id':class_id,
				'group_id':group_id,
				'subject_id':subject_id
            }, 
            dataType: 'json',
            success: function(data)
            {
                result                = ''+data['result']+'';
                mainContent           = ''+data['mainContent']+'';

                if(result == 'success')
                {            
                    $('#display').html(mainContent);     
                }                
            }
        });
        return false; // keeps the page from not refreshing     
    }
</script>