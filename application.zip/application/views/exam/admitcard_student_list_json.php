<div class="pull-left col-sm-4">
<button type="button" class="btn btn-info" title="Print admit card for all checked students" onclick="print_admit_card()">Print Admit Card</button>
<hr/>
</div>
<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
	<thead>
		<tr>
        	<th><label><input type="checkbox" id="bulk_check"></label></th>
            <th>Sl</th>
            <th>Roll</th>
            <th>Student ID</th>
            <th>Student Name</th>
			<th width="10%">Pic</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach($student_list as $k=>$sl): ?>
		<tr>
        	<th><input type="checkbox" class="bulk_check" <?php if($sl['status']==1) echo 'checked'; ?> value="<?= $sl['student_id'] ?>"></th>
			<td><?= $k+1 ?></td>
			<td><?= $sl['roll_no'] ?></td>
			<td><?= $sl['student_id'] ?></td>
            <td><?= $sl['student_name'] ?></td>
			<?php if($sl['student_image'] != ''){?>
            <td><img src="<?php echo base_url();?>upload/student_image/<?php print_r($sl['student_image']);?>" alt="" height="40" width="40"/></td>
			<?php }else{?>
			<td><img src="<?php echo base_url();?>upload/message_image/no_picture.png" alt="" height="40" width="40"/></td>
			<?php }?>
		</tr>
		<?php endforeach; ?>
	</tbody>
</table>

<script>
// check all checkbox just one click
$("#bulk_check").change(function(){
    var status = $(this).is(":checked") ? true : false;
    $(".bulk_check").prop("checked",status);
});
</script>