              
             <script>
              function pr()
{
	window.print('admit_card_view_al.php');
}
</script>
              <body onLoad="pr()">       
					  
					  <table id="datatables-1" cellspacing="0" width="100%" ><?php foreach($student_info as $sinfo){?>
                      <tr><td>
                        <div style=" page-break-inside:avoid;">
                         
                  <table width="100%">
                        <tr >
                        
                        <td width="25%" align="center"><img src="<?php echo base_url();foreach($school_info as $school_infos){?>upload/institute_logo/<?php echo $school_infos['logo']; ?>" width="30px" height="30px" alt="Logo" style="margin-bottom:-8px;">
                          <span style="font-family:Algerian; font-size:16px; margin-left:10px;">Al-hidaayah</span></td>
                          
                          <td colspan="2" align="center"><img src="<?php echo base_url(); ?>upload/institute_logo/<?php echo $school_infos['logo']; ?>" width="35px" height="35px" alt="Logo" style="margin-bottom:-8px;">
                          <span style="font-family:Algerian; font-size:22px; margin-left:10px;">Al-hidaayah</span></td>
                        </tr>
                        <tr >
                        <td style="font-size:8px; " align="center">I N T E R N A T I O N A L &nbsp; S C H O O L </td>
                        <td colspan="2" style="font-size:10px; "><table width="100%" style="font-size:10px;" ><tr align="right"><td>I</td><td>N</td><td>T</td><td>E</td><td>R</td><td>N</td><td>A</td><td>T</td><td>I</td><td>O</td><td>N</td><td>A</td><td>L</td><td align="right">&nbsp; &nbsp; S</td><td>C</td><td>H</td><td>O</td><td>O</td><td>L</td></tr></table></td>
                        </tr>
                        <tr> 
                        <td align="center" style="font-size:10px;" >Panchlaish R/A, GPO, Chittagong.</td>
                        <td align="center" colspan="2"><?php } 
			foreach($school_info as $school_infos)
			{?><span style="font-size:12px;">
            Contact: <?php echo $school_infos['contact_no']; ?>
			 E-mail: <?php echo $school_infos['email']; ?>
			 Website: <?php echo $school_infos['website'];}
			 ?></span>
						 </td>
                        </tr>
                        <tr>
                        <td align="center"><span style=" border:1px solid black; box-shadow:1px 1px 2px 1px; padding:3px; font-size:12px;">&nbsp;Admit Card&nbsp;</span></td>
                        <td align="center"><span style=" font-size:12px;"> <?php
						foreach($school_info as $school_infos){
							echo $school_infos['address'];?> <?php echo $school_infos['post_office']; ?> ,<?php echo $school_infos['district']; ?> .<?php } ?></span>
						 </td>
                        </table>
                        <table width="100%" >
                        <tr>
                        <td><span style=" font-size:14px;">Student Name : <?php echo $sinfo['student_name']; ?></span>
						 </td>
                        <td align="center" colspan="2"><span style=" border:1px solid black; box-shadow:1px 1px 2px 1px; font-size:12px; padding:3px;">&nbsp;Admit Card&nbsp;</span></td>
                        </tr>

                        <tr>
                        <td width="25%"><span style=" font-size:14px;">Class : <?php foreach($class as $classs){
							echo $classs['class_name'];
							}; ?></span>
						 </td>
                        <td colspan="2">Student Name : 
						<?php echo $sinfo['student_name']; ?>
						 </td>
                        </tr>
                        <tr>
                          <td width="25%"><span style=" font-size:14px;">Section :  <?php  foreach($section as $sections){
							 echo $sections['section_name'];} ?></span> 
						   </td>
                          <td> Class : <?php  foreach($class as $classs){
							  echo $classs['class_name'];} ?>
						   </td>
                          <td> Section :  <?php foreach($section as $sections){
							  echo $sections['section_name'];} ?>
						   </td>
                         
                        </tr>
                        <tr>
                          <td><span style=" font-size:14px;">Student ID : <?php echo $sinfo['student_id']; ?></span></td>
                          <td colspan="2">Student ID : <?php echo $sinfo['student_id']; ?>
						   </td>
                         
                        </tr>
						<tr>
						<td>&nbsp;</td><td></td><td></td>
						</tr>
                        <tr>
                          <td align="center"><div style="padding-top:3px; border-top:1px solid black; text-align:center; width:150px; margin-top:10px; ">Principal</div></td>
                          <td></td>
                     		<td align="center"><div style="padding-top:3px; border-top:1px solid black; text-align:center; width:150px; margin-top:10px; ">Principal</div></td>
                        </tr>
						
						
						<tr>
						<td colspan="3"><table style="border-top:1px dashed black;" width="100%"><tr><td></td></tr></table></td>
						</tr>
						
                      </table> 
                      </div>
                     
                      </td></tr> <?php } ?>
 </table>
 
 
 
<?php /*
                     $style2 ='<table>'; foreach($student_info as $sinfo){
                      $style2 .= '<tr>
						<td>
                        <table style="margin:5px 5px; padding:10px; border:1px solid black; "><tr> <td>
                         <table style=" border:5px dotted #666;">
						 <tr><td>
                  <table width="100%" style="margin:0px auto;">
                        <tr >
                          <td align="center"><img src="'. base_url();foreach($school_info as $school_infos){
						   $style2 .='upload/institute_logo/'.$school_infos['logo'].'" width="50px" height="50px" alt="Logo" style="margin-bottom:-8px;">
                          </td>
						  
						  <td align="center">
                          <span style="font-size:20px; margin-left:10px;">';}
						  foreach($school_info as $school_infos){
							  $style2 .=$school_infos['school_name'];
							  };
							  $style2 .='</span></td>
                        </tr>
                        <tr>
                        <td></td>
                        <td align="center">';
						foreach($school_info as $school_infos){
							$style2 .= $school_infos['address'].' '.$school_infos['post_office'].' ,'.$school_infos['district'].' .';}
						 $style2 .='</td>
                        </table>
                        <table width="100%">
                        <tr>
                        <td></td>
                        <td align="center" height="50px"><span style=" padding:5px; background-color:#333; color:#FFF; font-size:18px;">&nbsp;Admit Card&nbsp;</span></td>
                        </tr>
						<tr>
						<td></td>
                        <td align="center" height="40px"><span style=" border:1px solid black; padding:8px;">';
						foreach($term as $terms){
							$style2 .=$terms['term'].' - '.date("Y");}
							$style2 .='</span></td>
						</tr>
						</table>
                        <table width="100%" >
                        
                        <tr></td>
                        <td colspan="3">Student Name : ';
						$style2 .= $sinfo['student_name']; 
						 $style2 .='</td>
                        </tr>
                        <tr>
                          <td>Class :  ';  foreach($class as $classs){
							  $style2 .= $classs['class_name'];} 
						   $style2 .='</td>
                          <td align="center"> Student\'s Roll: ';  
							  $style2 .= $sinfo['student_id'];;
						   $style2 .='</td>
                          <td> Section :  ';  foreach($section as $sections){
							  $style2 .= $sections['section_name'];} 
						   $style2 .='</td>
                         
                        </tr>
                        <tr>
                          <td>Group : ';
						  $style2 .= $sinfo['group_name']; 
						   $style2 .='</td>
                          <td colspan="2" align="center">Exam Start Date : '; 
						  foreach($exam_date as $exam_dates){
						  $style2 .= $exam_dates['exam_date'];}; 
						   $style2 .='</td>
                         
                        </tr>
						<tr>
						<td align="center">';
						foreach($class_teacher as $class_teachers){
						$style2 .=$class_teachers['teacher_name'];};
						$style2 .='</td><td></td><td align="center">';
						foreach($head_teacher as $head_teachers){
							$style2 .= $head_teachers['teacher_name'];};
						$style2 .='</td>
						</tr>
                        <tr>
                          <td align="center"><div style="padding-top:3px; border-top:1px solid black; text-align:center; width:150px; margin-top:5px; ">Class Teacher</div></td>
                          <td></td>
                     		<td align="center"><div style="padding-top:3px; border-top:1px solid black; text-align:center; width:150px; margin-top:5px; ">Principal</div></td>
                        </tr>
						<tr>
						<td>&nbsp;</td><td></td><td></td>
						</tr>
						
						
						<tr>
						<td>&nbsp;</td><td></td><td></td>
						</tr>
                      </table> 
                      </tr> </td>
                      </table>
					  </tr> </td>
                      </table>
					  </td>
					  <td>
					  
					  
					  
					  
					  
					  
					  
					  <table style="margin:5px 5px; padding:10px; border:1px solid black; ">
					   <tr> <td>
                         <table style=" border:5px dotted #666;"><tr> <td>
                  <table width="100%" style="margin:0px auto;">
                        <tr >
                          <td align="center"><img src="'. base_url();
						   $style2 .='upload/institute_logo/Al-Hidaayah_International_School_logo.jpg" width="50px" height="50px" alt="Logo" style="margin-bottom:-8px;">
                          </td>
						  
						  <td align="center">
                          <span style="font-size:25px; margin-left:10px;">';
						  foreach($school_info as $school_infos){
							  $style2 .=$school_infos['school_name'];
							  };
							  $style2 .='</span></td>
                        </tr>
                        <tr>
                        <td></td>
                        <td align="center">';
						foreach($school_info as $school_infos){
							$style2 .= $school_infos['address'].' '.$school_infos['post_office'].' ,'.$school_infos['district'].' .';}
						 $style2 .='</td>
                        </table>
                        <table width="100%">
                        <tr>
                        <td></td>
                        <td align="center" height="50px"><span style=" padding:5px; background-color:#333; color:#FFF; font-size:18px;">&nbsp;Admit Card&nbsp;</span></td>
                        </tr>
						<tr>
						<td></td>
                        <td align="center" height="40px"><span style=" border:1px solid black; padding:8px;">';
						foreach($term as $terms){
							$style2 .=$terms['term'].' - '.date("Y");}
							$style2 .='</span></td>
						</tr>
						</table>
                        <table width="100%" >
                        
                        <tr></td>
                        <td colspan="3">Student Name : ';
						$style2 .= $sinfo['student_name']; 
						 $style2 .='</td>
                        </tr>
                        <tr>
                          <td>Class :  ';  foreach($class as $classs){
							  $style2 .= $classs['class_name'];} 
						   $style2 .='</td>
                          <td align="center"> Student\'s Roll: ';  
							  $style2 .= $sinfo['student_id'];;
						   $style2 .='</td>
                          <td> Section :  ';  foreach($section as $sections){
							  $style2 .= $sections['section_name'];} 
						   $style2 .='</td>
                         
                        </tr>
                        <tr>
                          <td>Group : ';
						  $style2 .= $sinfo['group_name']; 
						   $style2 .='</td>
                          <td colspan="2" align="center">Exam Start Date : '; 
						  foreach($exam_date as $exam_dates){
						  $style2 .= $exam_dates['exam_date'];}; 
						   $style2 .='</td>
                         
                        </tr>
						<tr>
						<td align="center">';
						foreach($class_teacher as $class_teachers){
						$style2 .=$class_teachers['teacher_name'];};
						$style2 .='</td><td></td><td align="center">';
						foreach($head_teacher as $head_teachers){
							$style2 .= $head_teachers['teacher_name'];};
						$style2 .='</td>
						</tr>
                        <tr>
                          <td align="center"><div style="padding-top:3px; border-top:1px solid black; text-align:center; width:150px; margin-top:5px; ">Class Teacher</div></td>
                          <td></td>
                     		<td align="center"><div style="padding-top:3px; border-top:1px solid black; text-align:center; width:150px; margin-top:5px; ">Principal</div></td>
                        </tr>
						<tr>
						<td>&nbsp;</td><td></td><td></td>
						</tr>
						
						
						<tr>
						<td>&nbsp;</td><td></td><td></td>
						</tr>
                      </table> 
                      </td>
					  </tr>
                      </table>
					   </td>
					  </tr>
                      </table>
					  </td>
					  </tr>
                      '; } ;
 $style2 .='</table>';
*/
?>
</body>

<!--include("../mpdf60/mpdf.php");
if($st1==1)
{
	$mpdf=new mPDF('c',$page_size,'','',0,0,11,0,16,13);

$mpdf->SetDisplayMode('fullpage');

$mpdf->list_indent_first_level = 0;	// 1 or 0 - whether to indent the first level of a list

// LOAD a stylesheet
$stylesheet = file_get_contents('mpdfstyletables.css');
$mpdf->WriteHTML($stylesheet,1);	// The parameter 1 tells that this is css/style only and no body/html/text

$mpdf->WriteHTML($style1);

$mpdf->Output();


}
else
{
	$mpdf=new mPDF('c',$page_size,'','',3,0,5,5,20,17); 
$mpdf->displayDefaultOrientation = true;

$mpdf->forcePortraitMargins = true;
$mpdf->SetDisplayMode('fullpage','two');
$stylesheet = file_get_contents('mpdfstyletables.css');
$mpdf->WriteHTML($stylesheet,1);
$mpdf->AddPage('L');
$mpdf->WriteHTML($style2);

$mpdf->Output();

}
exit;

//echo $style2;-->
