<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
	<div class="content-page">
		<!-- ============================================================== -->
		<!-- Start Content here -->
		<!-- ============================================================== -->
		<div class="content">
			<div class="page-heading">
            	<h1><i class='fa fa-table'></i> Set Class Routine </h1>
			</div>
            <div class="message"></div>
			<div class="row">
                <div class="col-md-12">
                    <div class="widget" style="min-height: 400px">
                        <div class="widget-content">
                            <form role="form" id="registerForm" method="POST">
                                <div class="widget-content padding">
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label>Class</label>
                                                <select class="form-control" name="class_id" id="class_id" onchange="get_class_section_list(this.value); get_class_group_list(this.value);">
                                                    <option value="">----Select Class----</option>
                                                    <?php foreach($class_list as $cl){ ?>
                                                    <option value="<?php echo $cl['class_id'];?>"><?php echo $cl['class_name'];?></option>   
                                                    <?php } ?>
                                                </select>
                                            </div>
                                            <div class="col-sm-4">
                                                <label>Section</label>
                                                <select class="form-control" name="section_id" id="section_id" />
                                                    <option value="">-----Select Section-----</option>
                                                </select>
                                            </div>
                                            <div class="col-sm-4">
												<label>Group</label>
                                                <select class="form-control" name="group_id" id="group_id" required />
													<option value="">-----Select group-----</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="row">
											<div class="col-sm-4">
												<label>Shift</label>
												<select class="form-control" name="shift_id" id="shift_id" required />
													<option value="">-----Select shift-----</option>
                                                    <?php foreach($shift_list as $sl){ ?>
                                                    <option value="<?php echo $sl['shift_id'];?>"><?php echo $sl['shift_name'];?></option>   
                                                    <?php } ?>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <button type="button" class="btn btn-primary" onclick="get_class_routine_json()">Get Routine Grid</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div id="display">
                                            
								</div>
                            </form>
                        </div>
                    </div>
                </div>
			</div>
		

<?php include 'application/views/includes/footer.php';?>
                    
<script type="text/javascript">
function get_class_section_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'admin/section_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#section_id').html(html_data);
        }
    }
    });
}

function get_class_group_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'academic/group_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#group_id').html(html_data);
        }
    }
    });  
}

// get the student list and fees list 
	function get_class_routine_json()
	{
        $.ajax({ 
        url: baseUrl+'academic/get_class_routine_json',
        data:
            {                  
                'class_id':$('#class_id').val(),
				'section_id':$('#section_id').val(),
				'group_id':$('#group_id').val(),
				'shift_id':$('#shift_id').val()
            }, 
            dataType: 'json',
            success: function(data)
            {
                result                = ''+data['result']+'';
                mainContent           = ''+data['mainContent']+'';

                if(result == 'success')
                {      
                    $('#display').html(mainContent);  
					
					var clPeriod=new Array();  
				 	var iclPeriod=0;
					
					$( "td#clperiod").each(function() {
						clPeriod[iclPeriod]=$(this).html();
								
						if($(this).html()=="tiffin")
							{//alert(iclPeriod);
								$('span.tid'+iclPeriod).html("<br/><span style=''>Break</span>");
								$('span.cid'+iclPeriod).html("");
								
							}
						iclPeriod++;
					});
					// call the routine if created before
					get_old_class_routine();
                }                
            }
        });
        return false; // keeps the page from not refreshing     
    }


function get_old_class_routine()
{
	$.getJSON(
			baseUrl + 'academic/get_old_routine_by_section_class',
			{
				'class_id':$('#class_id').val(),
				'section_id':$('#section_id').val(),
				'group_id':$('#group_id').val(),
				'shift_id':$('#shift_id').val()
			},
			function(jd) {
				for(i=0; i<jd.length; i++)
				{
					var multycolumn_no=jd[i].column_no.split(",");
					var multyteacher_id=jd[i].teacher_id.split(",");
					var multysubject_id=jd[i].subject_id.split(",");
					
					if(multycolumn_no.length > 1 )
					{
						for(mb=0; mb < multycolumn_no.length; mb++)
						{
							if(mb < 1)
							{
								$("td[id='"+jd[i].day+"'] select#tid"+multycolumn_no[mb]+jd[i].day).val(multyteacher_id[mb]);
								$("td[id='"+jd[i].day+"'] select#cid"+multycolumn_no[mb]+jd[i].day).val(multysubject_id[mb]);
							}
							else
							{
								// call function from json file to add new routine box
								new_box_old_routine(multycolumn_no[mb] , jd[i].day,multyteacher_id[mb]+multysubject_id[mb]);
								
								$("td[id='"+jd[i].day+"'] span#classtid"+multyteacher_id[mb]+multysubject_id[mb]+" select#tid"+multycolumn_no[mb]+jd[i].day).val(multyteacher_id[mb]);
								$("td[id='"+jd[i].day+"'] span#classcid"+multyteacher_id[mb]+multysubject_id[mb]+" select#cid"+multycolumn_no[mb]+jd[i].day).val(multysubject_id[mb]);
							}
						}
					}
					else
					{
						$("td[id='"+jd[i].day+"'] select#tid"+jd[i].column_no+jd[i].day).val(jd[i].teacher_id);
						$("td[id='"+jd[i].day+"'] select#cid"+jd[i].column_no+jd[i].day).val(jd[i].subject_id);
					}
				}
			}
			);
}

function save_class_routine()
{//1
	
	var final_routine = new Array();	
	//get class day id
	var day=new Array();  
	var iday=0;	
	$( "td#wkday").each(function(){
		day[iday]=$(this).html();
		iday++;
	});
	
	var class_id = $('#class_id').val();
	var section_id = $('#section_id').val();
	var group_id = $('#group_id').val();
	var shift_id = $('#shift_id').val();
						
	var totallcount=0;
	var clDu=new Array();  
	var icld=0;
	$("th#classDuration").each(function(){
		clDu[icld]=$(this).html();
		icld++;
		totallcount+=1;
	});
	
	var totalLoop=totallcount;
	var clPeriod=new Array();  
	var iclPeriod=0;
	$( "td#clperiod").each(function(){
		clPeriod[iclPeriod]=$(this).html();
		iclPeriod++;
	});
							//alert(clPeriod[1]);
							// get teachers name
	
	
	var rsl=1;
	for(itsc=0; itsc<totalLoop;)
		{//itsc
			//get subject name			
									
			var iwday=0;	
			$( "td#wkday").each(function(){
				iwday++;
			});
			
			var count=iwday;
			// routine save program
			var countsave=0;
										
				for(var isave=0; isave<count; isave++)
					{//1
						// make array of selected teacher id
						var teachersId=new Array();
						var itid=0;
						$('select#tid'+itsc+day[isave]).each(function()
							{
								teachersId[itid]=$(this).val();
								itid++;
							});
						// make array of selected subject id
						var subName=new Array();
						var icid=0;	
						$( 'select#cid'+itsc+day[isave]).each(function()
							{
								subName[icid]=$(this).val();
								icid++;
							});
						//alert('Please cheack these items and click on "OK" button or press "ENTER" .'+'\n\n class time= '+clDu[itsc]+' subject name= '+subName[isave]+' teacher\'s name= '+teachersId[isave]);
											
						if(clPeriod[itsc]=="tiffin")
							{//2
								final_routine.push({'school_id':'1','class_id':class_id,'section_id':section_id,'group_id':group_id,'shift_id':shift_id,'class_time':clDu[itsc],'class_period':clPeriod[itsc],'day':day[isave],'subject_id':'','teacher_id':'','column_no':itsc,'row_no':isave});			
							}//2
						else
							{//2
								if(teachersId.length > 0 && subName.length > 0 )
									{//3
										for(var ifinal=0; ifinal<teachersId.length; ifinal++)
										{
											final_routine.push({'school_id':'1','class_id':class_id,'section_id':section_id,'group_id':group_id,'shift_id':shift_id,'class_time':clDu[itsc],'class_period':clPeriod[itsc],'day':day[isave],'subject_id':subName[ifinal],'teacher_id':teachersId[ifinal],'column_no':itsc,'row_no':isave});
										}
									}//3
							}//2
					}//itsc
				itsc++;
		}		
		
		$.ajax({//4
			type: "POST",
			url: baseUrl + 'academic/save_class_routine',
			data:
			{
				'class_id':class_id,
				'section_id':section_id,
				'group_id':group_id,
				'shift_id':shift_id,
				'final_routine':final_routine
			}, 
			success: function(html_data)
			{
				if (html_data != '')
					{
						$('.message').html(html_data);
						$('#display').html('');
					}
			}
		});//4

 }
</script>