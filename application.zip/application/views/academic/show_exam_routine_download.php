 <script>
              function pr()
{
	window.print('admit_card_view_al.php');
}
</script>
              <body onLoad="pr()">

 <?php                                        
 $subject_name[]='';
 $isubject_name=0;
 foreach($full_routine as $full_routines)
				{
					 $subject_name[$isubject_name]=$full_routines['subject_name'];
					 $isubject_name++;
				}   
				  ?>
                  <div style=" border:1px double black; height:100%;">
                  
                  <div style="width:auto;
                                            			position:absolute;
                                            			margin:61% 0px 0px -19%;
                                             			font-size:26px;
                                                         -ms-transform: rotate(270deg); /* IE 9 */
                                                        -webkit-transform: rotate(270deg); /* Chrome, Safari, Opera */
                                                        transform: rotate(270deg)"><b><?php  foreach($school_info as $si){ echo $si['school_name']; }  ?></b></div>
                                                        
				   <div style="width:30%;
                   position:absolute;
                   				margin:59% 10px 0% -10px;
                                font-size:24px;
                                 -ms-transform: rotate(270deg); /* IE 9 */
                                 -webkit-transform: rotate(270deg); /* Chrome, Safari, Opera */
                                 transform: rotate(270deg)"><b>Exam Routine</b>
                   </div>
          <table border="1" cellspacing="0" width="100%" align="center" style="-ms-transform: rotate(270deg); /* IE 9 */
                                                        -webkit-transform: rotate(270deg); /* Chrome, Safari, Opera */
                                                        transform: rotate(270deg); margin-top:45%; margin-left:-19%; page-break-inside:avoid;" >
          <thead><tr><th colspan="2"></th>
	   <?php
       foreach($routine_class as $routine_classs)
				{ ?>
				<th id="exam_class_id"><?php echo $routine_classs['class_name']; ?></th>
		<?php	} ?>
                
        </tr><tr rowspan="2"><th style="min-width:125px; max-width:150px;">Date</th><th style="min-width:125px; max-width:150px;">Day</th>
			<?php
            	 foreach($routine_class as $routine_classs)
				{ ?>
				<th><?php echo $routine_classs['exam_time']; ?></th>
			<?php } ?>
				</tr></thead><tbody>
                <?php
				$i=0;
				 foreach($routine_day_date as $routine_day_dates)
				{ ?>
					<tr><td><?php echo $routine_day_dates['exam_date']; ?></td><td><?php echo $routine_day_dates['exam_day']; ?></td>
					<?php
					foreach($column_no as $col_no)
					{ ?>
						<td><?php echo $subject_name[$i]; ?></td>
					<?php	$i++;
					} ?>
					</tr>
			<?php		$itdday++; 
				} ?>
				</tbody></table></div>
	</body>				                     

<?php
/*include("../mpdf60/mpdf.php");

$mpdf=new mPDF('c','A4','','',20,0,5,5,20,17); 
$mpdf->displayDefaultOrientation = true;

//$mpdf->forcePortraitHeaders = true;
$mpdf->forcePortraitMargins = true;
$mpdf->SetDisplayMode('fullpage','two');

// LOAD a stylesheet
$stylesheet = file_get_contents('../mpdf60/examples/mpdfstyletables.css');
$mpdf->WriteHTML($stylesheet,1);	// The parameter 1 tells that this is css/style only and no body/html/text
$mpdf->AddPage('L');
$mpdf->WriteHTML($table);

$mpdf->Output();
exit;*/

?>