<div style="margin:10px auto; width:50%; text-align:center;">
	<h2>Telihaty High School</h2>
	<h4>Telihaty, Sreepur, Gazipur</h4>
	<h4>Class Routine <?php echo date('Y');?></h4>
	<h5>Class : <?php print_r($class_name[0]['class_name']);?>; Section : <?php print_r($section_name[0]['section_name']);?>; Group : <?php print_r($group_name[0]['group_name']);?>;</h5>
</div>
<table id="" class="table table-bordered" width="100%" cellspacing="0" border="1">
	<thead>
        <tr>
        	<th>Class Time</th>
            <?php foreach($class_time as $ct){?>
            <th id="classDuration"><?php echo $ct['start_time'].'-'.$ct['close_time'];?></th>  
            <?php }?>
        </tr>
    </thead>
    <tbody>
    	<tr>
            <td>Class Period</td>
            <?php foreach($class_time as $ct){ ?>
            <td id='clperiod'><?php echo $ct['period'];?></td>  
            <?php }?>
        </tr>
                                                
        <?php foreach($week as $wk){ ?>
        <tr>
        	<td id='wkday'><?php echo ucwords($wk['day']);?></td>
            <?php for($i=0; $i<count($class_time); $i++){ ?>
            <td id="<?php echo $wk['day'];?>">
                <div class="<?= 'div'.$i.$wk['day'];?>">
					<span class="form-control" style="border:none;" name="teachers_name" id="<?= 'tid'.$i;?>" >
						<!---Teacher name will be display here--->
					</span>
                
                    <span class="form-control subject_name" style="border:none;" name="subject_name" id="<?= 'cid'.$i;?>">
						<!---Subject name will be display here--->
                    </span>
                </div>
			</td>  
            <?php }?>
        </tr>  
        <?php }?>
    </tbody>
</table>
<div style="text-align:right;padding-top:40px;">
	<div style="margin:1px auto;">................................<div style="margin:1px auto;">Head Teacher Sign</div></div>
</div>
<div style="margin:5px auto;" class="print_button">
	<button type="button" class="btn btn-primary" title="Print This Routine" onclick="printPageArea('display')"> Print </button>
</div>
<script>
function new_box_old_routine(i,wk,id)
	{
		$('div.div'+i+wk).append('<span id="classtid'+id+'" class="form-control" style="border:none;"></span><span class="form-control subject_name" style="border:none;" id="classcid'+id+'"></span>');
	}
</script>