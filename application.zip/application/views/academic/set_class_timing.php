<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">			
            <div class="content">
            <?php if($this->session->flashdata('message')):?>
					<?=$this->session->flashdata('message')?>
				<?php endif?> 
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i> Class Time Assign</h1>
                </div>
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="widget" style="min-height:500px;">
                            <div class="widget-content padding">
                                <!-- Page Heading End-->
                                <div class="row">				
                                	<div class="col-md-12">
                                        <div class="widget">
                                            <div class="widget-content">
                                            <form role="form" method="POST" action="<?= base_url();?>academic/save_class_timing">
                                            	<div class="form-group">
                                                    <div class="row">
                                                        <div class="col-sm-4">
                                                             <label>Class</label>
                                                                <select class="form-control" name="class_id" id="class_id" onchange="get_class_section_list(this.value); get_class_group_list(this.value);" />
                                                                    <option value="">Select</option>
                                                                    <?php foreach($class_list as $cl){ ?>
                                                                    <option value="<?php echo $cl['class_id'];?>"><?php echo $cl['class_name'];?></option>
                                                                    <?php  } ?>
                                                                </select>
                                                        </div>
                                                        
                                                        <div class="col-sm-4">
                                                            <label>Section</label>
                                                            <select class="form-control" name="section_id" id="section_id" required />
                                                                <option value="">Select</option>
                                                            </select>
                                                        </div>
                                                         <div class="col-sm-4">
                                                           <label>Group <span style="color:red;">*</span></label>
                                                            <select class="form-control" name="group_id" id="group_id" required />
                                                                <option value="">Select</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div> 
                                                
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-sm-4">
                                                           <label>Shift <span style="color:red;">*</span></label>
                                                            <select class="form-control" name="shift_id" id="shift_id" required />
                                                                <option value="">Select</option>
                                                                 <?php
                                                                    foreach($shift_list as $sl){ ?>
                                                                     <option value="<?php echo $sl['shift_id'];?>"><?php echo $sl['shift_name'];?></option>   
                                                                <?php    }
                                                                ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                 <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-sm-4">
                                                           <button type="button" class="btn btn-primary" onclick="get_class_time_box();"> Get Time </button>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                <hr/>
                                                          
                                                <div class="display" style="display:none;" >
                                                	<button type="button" class="btn btn-info pull-left" onclick="add_time_box();">Add More Time Box</button>
                                                	<table id="class_time" border="0">
                
                                                    </table>
                                                    <div class="col-sm-4">
                                                    </div>
                                                    <div class="col-sm-4">
                                                    	<button type="submit" class="btn btn-primary" style="margin-top:25px;">Save</button>
                                                    	<button type="submit" class="btn btn-primary" style="margin-top:25px;" name="del_btn" value="delete">Delete All</button>
                                                    </div>
                                                 
                                                </div>
                                             </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
			
				
<?php include 'application/views/includes/footer.php';?>

                
<script>

function get_class_section_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'admin/section_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#section_id').html(html_data);
        }
    }
    });  
}

function get_class_group_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'academic/group_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#group_id').html(html_data);
        }
    }
    });  
}

function get_class_time_box()
{
	$( ".display" ).fadeOut( "fast" );
	var class_id=$('#class_id').val();
	var section_id=$('#section_id').val();
	var group_id=$('#group_id').val();
	var shift_id=$('#shift_id').val();
	
	$.ajax({
				type: "POST",
				url: baseUrl + 'academic/get_class_time_box',
				data:
					{
						'class_id':class_id,
						'section_id':section_id,
						'group_id':group_id,
						'shift_id':shift_id
					}, 
				success: function(html_data)
					{
						$( ".display" ).fadeIn( "slow" );
						if (html_data != '')
							{
								$('#class_time').html(html_data);
							}
					}
			});
	 // keeps the page from not refreshing 
}



function add_time_box()
{
	$.ajax({
			type: "POST",
			url: baseUrl + 'academic/get_class_period',
			data:
				{}, 
			success: function(html_data)
				{
					if (html_data != '')
						{
					 		$('#class_time').append('<tr><td>Start Time :</td><td><input type="text" name="start_time[]" id="start_time" class="form-control"></td><td >End Time :</td><td><input type="text" name="close_time[]" id="close_time" class="form-control"></td><td>Period :</td><td><select class="form-control" name="period[]" id="period">'+html_data+'</select></td></tr>');
								
						}
				}
		});
}
</script>