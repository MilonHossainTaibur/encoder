<table id="" class="table table-striped table-bordered" cellspacing="0" style="text-align:center;">
	<thead>
    	<tr style="text-align:center;">
            <th>Class Time</th>
                <?php
                    foreach($class_time as $ct){?>
                        <th id="classDuration"><?php echo $ct['start_time'].'-'.$ct['close_time'];?></th>  
                <?php }?>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Class Period</td>
            <?php foreach($class_time as $ct){ ?>
            <td id='clperiod'><?php echo $ct['period'];?></td>  
            <?php }?>
        </tr>
            <?php foreach($week as $wk){ ?>
        <tr class="wkday"><td id='wkday'><?php echo $wk['day'];?></td>
            <?php for($i=0; $i< count($class_time); $i++){ ?>
            <td id="<?php echo $wk['day'];?>">
            	<span id="<?php echo 'tid'.$i;?>">
                	<select class="form-control classtid" name="teachers_id" id="<?php echo 'tid'.$i;?>" >
                    	<option value="">----Select Teacher----</option>
                    	<?php foreach($teacher as $tn){ ?>
                        <option value="<?php echo $tn['teacher_id'];?>"><?php echo $tn['teacher_name'];?></option>   
                        <?php    } ?>
                    </select>
                </span>
                <div id="subject_name">
                	<span id="<?php echo 'cid'.$i;?>">
                    	<select class="form-control subject_name" name="subject_name" id="<?php echo 'cid'.$i;?>">
                     		<option value="">----Select Subject----</option>
                            <?php foreach($subject as $sub){ ?>
                            <option value="<?= $sub['subject_id'];?>"><?= $sub['subject_name'];?></option>   
                            <?php    } ?>
                        </select>
                    </span>
                </div>
			</td>  
             <?php }?>
         </tr>  
         	<?php }?>
     </tbody>
</table>
                                     
	<div class="form-group">
    	<div class="row">
        	<div class="col-sm-4">
            	<button type="button" class="btn btn-primary" onclick="save_class_routine()">save</button>
            </div>
        </div>
        </div>