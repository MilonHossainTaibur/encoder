<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>
				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">			
            <div class="content">
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i> Edit Term Subject </h1>
                </div>
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="widget" style="min-height:500px;">
                            <div class="widget-content padding">
                                <form role="form" id="ts_entry" name="ts_entry" method="POST" action="<?php echo base_url();?>academic/edit_term_subject_save">
                                   <input type="hidden" class="form-control" name="id" value="<?php echo $term_sub_list['id']; ?>" id="id">
                                    <div class="form-group">
                                        <div class="row">
                                            
                                            
                                            <div class="col-sm-4">
                                                <label>Class <span style="color:red;">*</span></label>
                                             <select class="form-control" name="class_id" id="class_id" onchange="get_class_group_list(this.value);" required >
                                                    <option value="">Select</option>
                                                   <?php
                                                        foreach($class_list as $cl){ ?>
                                                         <option value="<?php echo $cl['class_id'];?>" <?php if($term_sub_list['class_id'] == $cl['class_id']){echo "selected='selected'";} ?>><?php echo $cl['class_name'];?></option>   
                                                    <?php    }
                                                    ?>
                                                </select>
                                            </div>
                                            <div class="col-sm-4">
                                                <label>Group <span style="color:red;">*</span></label>
                                               <select class="form-control" name="group_id" id="group_id" required onChange="get_sub_list(this.value);" >
                                                
                                                <option value="">Select</option>
                                                   <?php
                                                        foreach($group_list as $gl){ ?>
                                                         <option value="<?php echo $gl['group_id'];?>" <?php if($term_sub_list['group_id'] == $gl['group_id']){echo "selected='selected'";} ?>><?php echo $gl['group_name'];?></option>   
                                                    <?php    }
                                                    ?>
                                                  
                                                </select>
                                            </div>
											 <div class="col-sm-4">
                                                <label>Subject <span style="color:red;">*</span></label>
                                                <?php
												
                                                $class_id = $term_sub_list['class_id'];   
												$sql_s = "SELECT * FROM  `tbl_class_subject` as S inner join tbl_subject on tbl_subject.subject_id = S.subject_id where S.school_id = 1 and S.class_id= $class_id order by tbl_subject.subject_id asc";
												$query = mysql_query($sql_s);
												while($sub_name =mysql_fetch_array($query))
												{
													$subject_name[]=$sub_name;
												}
												?>
												<select class="form-control" name="subject_id" id="subject_id" required>
                                                
                                                <option value="">Select</option>
                                                
                                                 <?php
                                                        foreach($subject_name as $sl){ ?>
                                                         <option value="<?php echo $sl['subject_id'];?>" <?php if($sl['subject_id'] == $term_sub_list['subject_id']){echo "selected='selected'";} ?>><?php echo $sl['subject_name'];?></option>  
                                                    <?php    }
                                                    ?>           
                             
                                                </select>
                                            </div>
											
                                        </div>
                                    </div>
                                    
                                    
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label>Term <span style="color:red;">*</span></label>
                                                  
												<select class="form-control" name="term_id" id="term_id" required>
                                                
                                                <option value="">Select</option>
                                                   <?php
                                                        foreach($term_list as $tl){ ?>
                                                         <option value="<?php echo $tl['term_id'];?>" <?php if($term_sub_list['term_id'] == $tl['term_id']){echo "selected='selected'";} ?>><?php echo $tl['term'];?></option>   
                                                    <?php    }
                                                    ?>
                                                
                                                </select>
                                            </div>
                                            
                                            <div class="col-sm-4">
                                                <label>Full Marks <span style="color:red;">*</span></label>
                                              <input type="text" class="form-control" pattern="[0-9]*" name="full_marks" id="full_marks" value="<?php echo $term_sub_list['sub_full_marks'];?>"  required>
                                            </div>
                                            <div class="col-sm-4">
                                                <label>Pass Marks in % <span style="color:red;">*</span></label>
                                              <input type="text" class="form-control" pattern="[0-9]*" name="pass_marks" id="pass_marks" value="<?php echo $term_sub_list['pass_marks'];?>"  required>
                                            </div>
                                        </div>
                                    </div>
									<hr />
									
									<button type="submit" class="btn btn-primary">Submit</button>
								</form>
                            </div>
                        </div>
                    </div>
                </div>
				

				
<?php include 'application/views/includes/footer.php';?>
                
<script type="text/javascript">

function get_class_group_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'academic/group_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#group_id').html(html_data);
        }
    }
    });  
}

function get_sub_list(group_id)
{
	var class_id=$('#class_id').val();
   $.ajax({
    type: "POST",
    url: baseUrl + 'academic/subject_list_ajax',
    data:
    {
        'class_id':class_id,
		'group_id':group_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
			$('#subject_id').html(html_data);
        }
    }
    });  
}

</script>

<!--For only numeric value can be typeable-->		
<script type="text/javascript">
	var specialKeys = new Array();
	specialKeys.push(8); //Backspace
	function IsNumeric(e) {
		var keyCode = e.which ? e.which : e.keyCode
		var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
		return ret;
	}
</script>