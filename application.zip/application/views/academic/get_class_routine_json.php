<table id="" class="table table-striped table-bordered" cellspacing="0" style="text-align:center;">
	<thead>
    	<tr style="text-align:center;">
            <th>Class Time</th>
                <?php
                    foreach($class_time as $ct){?>
                        <th id="classDuration"><?php echo $ct['start_time'].'-'.$ct['close_time'];?></th>  
                <?php }?>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>Class Period</td>
            <?php foreach($class_time as $ct){ ?>
            <td id='clperiod'><?php echo $ct['period'];?></td>  
            <?php }?>
        </tr>
            
		<?php foreach($week as $wk){ ?>
        <tr class="wkday"><td id='wkday' class="text-capitalize"><?php echo $wk['day'];?></td>
            <?php for($i=0; $i< count($class_time); $i++){ ?>
            <td id="<?= $wk['day'];?>" class="text-capitalize">
                <div class="<?= 'div'.$i.$wk['day'];?>">
					<span class="<?= 'tid'.$i;?>">
						<select class="form-control classtid text-capitalize" name="teachers_id" id="<?= 'tid'.$i.$wk['day'];?>" >
							<option value="">----Select Teacher----</option>
							<?php foreach($teacher as $tn){ ?>
							<option value="<?= $tn['teacher_id'];?>" class="text-capitalize"><?= $tn['teacher_name'];?></option>
							<?php } ?>
						</select>
					</span>
                	<span class="<?= 'cid'.$i;?>">
                    	<select class="form-control subject_name text-capitalize" name="subject_name" id="<?= 'cid'.$i.$wk['day'];?>">
                     		<option value="">----Select Subject----</option>
                            <?php foreach($subject as $sub){ ?>
                            <option value="<?= $sub['subject_id'];?>"><?= $sub['subject_name'];?></option>   
                            <?php }?>
                        </select>
                    </span>
                </div>
				<a herf="#" onclick="new_box(<?= $i; ?>,'<?= $wk['day'];?>')"><i class="fa fa-plus" aria-hidden="true"></i></a>
			</td>  
            <?php }?>
        </tr>  
        <?php }?>
    </tbody>
</table>

<div class="form-group">
    <div class="row">
        <div class="col-sm-4">
            <button type="button" class="btn btn-primary" onclick="save_class_routine()">save</button>
        </div>
    </div>
</div>

<script>
	iri=0;
	
	function new_box(i,wk)
	{ iri++;
		$('div.div'+i+wk).append('<div id="'+iri+'"><span class="'+'tid'+i+'" ><select class="form-control classtid" name="teachers_id" id="'+'tid'+i+wk+'" ><option value="">----Select Teacher----</option><?php foreach($teacher as $tn){ ?><option value="<?= $tn['teacher_id'];?>"><?= $tn['teacher_name'];?></option><?php } ?></select></span><span id="'+'cid'+i+'" ><select class="form-control subject_name" name="subject_name" id="'+'cid'+i+wk+'" ><option value="">----Select Subject----</option><?php foreach($subject as $sub){ ?><option value="<?= $sub['subject_id'];?>"><?= $sub['subject_name'];?></option><?php } ?></select></span><a class="pull-right" herf="#" style="color:red;" onclick="remove_box(\''+iri+'\')"><i class="fa fa-times" aria-hidden="true"></i></a><div>');
		
	}
	
	function remove_box(box_id)
	{
		$('#'+box_id).hide("slow");
	}
	
	function new_box_old_routine(i,wk,id)
	{
		$('div.div'+i+wk).append('<span class="'+'tid'+i+'" id="classtid'+id+'"><select class="form-control" name="teachers_id" id="'+'tid'+i+wk+'" ><option value="">----Select Teacher----</option><?php foreach($teacher as $tn){ ?><option value="<?= $tn['teacher_id'];?>"><?= $tn['teacher_name'];?></option><?php } ?></select></span><span class="'+'cid'+i+'" id="classcid'+id+'" ><select class="form-control subject_name" name="subject_name" id="'+'cid'+i+wk+'" ><option value="">----Select Subject----</option><?php foreach($subject as $sub){ ?><option value="<?= $sub['subject_id'];?>" ><?= $sub['subject_name'];?></option><?php } ?></select></span>');
	}
</script>