<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">			
            <div class="content">
			
            <?php if($this->session->flashdata('message')):?>
			<div class="alert alert-success">
				<a href="#" class="close" data-dismiss="alert">&times;</a>
				<?=$this->session->flashdata('message')?>
			</div>
			<?php endif?>
            
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-calendar'></i> Academic Calendar</h1>
                </div>
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
				<div class="row">				
					<div class="col-md-12">
						<div class="widget">
                        	<div class="col-lg-3">
	      						<div class="well well-small">
                                    <div id="add-event-form">
                                        <fieldset>
                                        <legend>Add Custom Event</legend>
                                        <span class="help-block">Event Title</span>
                                        <input id="title" name="title" type="text" placeholder="event title" class="form-control input-small">
                                        <label class="radio">
                                            <input type="radio" name="priority" value="label label-default" checked>
                                            <span class="label label-default">default</span>
                                        </label>
                                        <label class="radio">
                                            <input type="radio" name="priority" value="label label-warning">
                                            <span class="label label-warning">warning</span>
                                        </label>
                                        <label class="radio">
                                            <input type="radio" name="priority" value="label label-success">
                                            <span class="label label-success">success</span>
                                        </label>
                                        <label class="radio">
                                            <input type="radio" name="priority" value="label label-info">
                                            <span class="label label-info">info</span>
                                        </label>
                                        <label class="radio">
                                            <input type="radio" name="priority" value="label label-danger">
                                            <span class="label label-danger">danger</span>
                                        </label>
                                        <!--<br>
                                        <button id="add-event" type="button" class="btn btn-sm btn-default">Add Event</button>-->
                                        </fieldset>
                                    </div>
								</div>
                                
                                <!--<div class="well well-small">
                                <h4>Draggable Events</h4>
                                <ul id='external-events' class="list-inline">
                                    <li class="external-event"><span class="label label-default">My Event 1</span></li>
                                    <li class="external-event"><span class="label label-danger">My Event 2</span></li>
                                    <li class="external-event"><span class="label label-success">My Event 3</span></li>
                                    <li class="external-event"><span class="label label-warning">My Event 4</span></li>
                                    <li class="external-event"><span class="label label-info">My Event 5</span></li>
                                </ul>
                        
                                <label class="checkbox inline" for='drop-remove'>
                                    <input type="checkbox" id="drop-remove">
                                    remove after drop
                                </label>
                                </div>-->
                            </div>							
							
                            <div id="calendar" class="col-lg-9"></div>
						</div>
					</div>
				</div>

</div>
				
				

				
<?php include 'application/views/includes/footer.php';?>

<script src="<?php echo base_url();?>template/plugins/fullcalendar-1.6.2/fullcalendar/fullcalendar.min.js"></script>
<script>

function CalendarInit() {
	/*$.ajax({
		url: baseUrl + 'academic/get_event',
        type: 'POST', // Send post data
        data: '',
        async: false,
        success: function(s){alert(s);
        	json_events = s; 
        }
	});*/
    var date = new Date();
  var d = date.getDate();
  var m = date.getMonth();
  var y = date.getFullYear();

if ($(window).width() <= 767) {
        hdr = { left: 'title', center: '', right: 'prev,today,month,agendaWeek,agendaDay,next' };
    } else {
        hdr = { left: '', center: 'title', right: 'prev,today,month,agendaWeek,agendaDay,next' };
    }
	
  var calendar = $('#calendar').fullCalendar({
   editable: true,
   header: {
    left: 'prev,next today',
    center: 'title',
    right: 'month,agendaWeek,agendaDay'
   },
   
   events: baseUrl + 'academic/get_event',
   //events: JSON.parse(json_events),
   // Convert the allDay from string to boolean
   eventRender: function(event, element, view) {
    if (event.allDay === 'true') {
     event.allDay = true;
    } else {
     event.allDay = false;
    }
   },
   selectable: true,
   selectHelper: true,
   select: function(start, end, allDay) {
   var title = prompt('Event Title:');
   var color = prompt('Type Event url, if exits:');
   if (title) {
   var start = $.fullCalendar.formatDate(start, "yyyy-MM-dd HH:mm:ss");
   var end = $.fullCalendar.formatDate(end, "yyyy-MM-dd HH:mm:ss");
   $.ajax({
   type: "POST",
    url: baseUrl + 'academic/add_event',
    data:
    {
        'title':title,
		'start':start,
		'end':end
    },
   success: function(json) {
   alert('Added Successfully');
   }
   });
   calendar.fullCalendar('renderEvent',
   {
   title: title,
   start: start,
   end: end,
   allDay: allDay
   },
   true // make the event "stick"
   );
   }
   calendar.fullCalendar('unselect');
   },
   
   editable: true,
   eventDrop: function(event, delta) {
   var start = $.fullCalendar.formatDate(event.start, "yyyy-MM-dd HH:mm:ss");
   var end = $.fullCalendar.formatDate(event.end, "yyyy-MM-dd HH:mm:ss");
   $.ajax({
   url: 'http://localhost:8888/fullcalendar/update_events.php',
   data: 'title='+ event.title+'&start='+ start +'&end='+ end +'&id='+ event.id ,
   type: "POST",
   success: function(json) {
    alert("Updated Successfully");
   }
   });
   },
   eventResize: function(event) {
   var start = $.fullCalendar.formatDate(event.start, "yyyy-MM-dd HH:mm:ss");
   var end = $.fullCalendar.formatDate(event.end, "yyyy-MM-dd HH:mm:ss"); alert(start+end);
   $.ajax({
    url: 'http://localhost:8888/fullcalendar/update_events.php',
    data: 'title='+ event.title+'&start='+ start +'&end='+ end +'&id='+ event.id ,
    type: "POST",
    success: function(json) {
     alert("Updated Successfully");
    }
   });

}
   
  });
}
            CalendarInit();
        </script>
<!--For only numeric value can be typeable-->		
<script type="text/javascript">
	var specialKeys = new Array();
	specialKeys.push(8); //Backspace
	function IsNumeric(e) {
		var keyCode = e.which ? e.which : e.keyCode
		var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
		return ret;
	}
</script>  