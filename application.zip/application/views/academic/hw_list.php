<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
	<div class="content-page">
		<!-- ============================================================== -->
		<!-- Start Content here -->
		<!-- ============================================================== -->
		<div class="content"><?php echo $this->session->flashdata('success_msg'); ?><div id="tip" style="display:none; z-index:25; position:fixed; font-weight:bold; border-radius:8px 8px 8px 8px; background-color:#5DAF8F; padding:10px; color:#FFF;">Click Me To Hide </div>
			<div class="page-heading">
				<h1><i class='fa fa-table'></i> Home Work List</h1>
				
			</div>            	
			<div class="row">
			
				<div class="col-md-12">
					<div class="widget">	
                    
                    
                    
                    <div class="widget-content padding">
								<span style="font-size:22px; font-weight:bold;">Add New HW - <a href="javascript:void(0);" onclick="toggle_insertion_box(); return false;">Click Here</a></span>
								<div class="insertion_div">
									<form role="form" id="hw_entry" name="hw_entry" method="POST" action="<?php echo base_url();?>academic/create_hw_save">
                                   <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label>HW name</label>
                                                <input type="text" class="form-control" name="hw_name" id="hw_name" required>
                                            </div>
											<div class="col-sm-4">
                                                <label>HW topic</label>
                                                <input type="text" class="form-control" name="hw_topic" id="hw_topic" required>
                                            </div>
                                            
                                            <div class="col-sm-4">
                                                <label>Class <span style="color:red;">*</span></label>
                                                <select class="form-control" name="class_id" id="class_id" onclick="get_class_section_list(this.value);" onchange="get_sub_list(this.value);" required>
                                                    <option value="">Select</option>
                                                    <?php
                                                        foreach($class_list as $cl){ ?>
                                                         <option value="<?php echo $cl['class_id'];?>"><?php echo $cl['class_name'];?></option>   
                                                    <?php    }
                                                    ?>
                                                </select>
                                            </div>
                                            <div class="col-sm-4">
                                                <label>Section <span style="color:red;">*</span></label>
                                                <select class="form-control" name="section_id" id="section_id" required >
                                                    <option value="">Select</option>
                                                </select>
                                            </div>
											 <div class="col-sm-4">
                                                <label>Subject <span style="color:red;">*</span></label>
                                                <select class="form-control" name="sub_id" id="sub_id" required>
                                                    <option value="">Select</option>
                                                </select>
                                            </div>
											<div class="col-sm-4">
                                                <label>HW Date</label>
                     <input type="text" class="form-control datepicker-input" name="hw_date" id="hw_date" required>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label>Term <span style="color:red;">*</span></label>
                                                <select class="form-control" name="term" id="term" required>
                                                    <option value="">Select</option>
                                                   <?php
                                                        foreach($term_list as $tl){ ?>
                                                         <option value="<?php echo $tl['term_id'];?>"><?php echo $tl['term'];?></option>   
                                                    <?php    }
                                                    ?>
                                                </select>
                                            </div>
                                            
                                            <div class="col-sm-4">
                                                <label>Full Marks</label>
                                                <input type="text" pattern="[0-9]*" required class="form-control" name="marks" id="marks">
                                            </div>
                                        </div>
                                    </div>
									<hr />
									
									<button type="submit" class="btn btn-primary">Submit</button>
								</form>
                            </div>
                        </div>
                   						
						<div class="widget-content">
						<br>					
							<div class="table-responsive">
								<form class='form-horizontal' role='form'>
								<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
										<thead>
											<tr>
												<th>SLNO</th>
                                                <th>Name</th>
												<th>Topic</th>
												<th>Class</th>
												<th>Section</th>
												<th>Subject</th>
												<th>Date</th>
												
												<th>Full Marks</th>
												<th>Action</th>
											</tr>
										</thead>
								 
										
								 
										<tbody>
											<?php $hi=1;
												foreach($hw_list as $hw){ ?>
												<tr>
													<td><?php echo $hi;?></td>
                                                    <td><?php echo $hw['hw_name'];?></td>
													<td><?php echo $hw['hw_topic'];?></td>
													<td><?php echo $hw['class_name'];?></td>
													<td><?php echo $hw['section_name'];?></td>
													<td><?php echo $hw['subject_name'];?></td>
													<td><?php echo $hw['hw_date'];?></td>
													
													<td><?php echo $hw['hw_marks'];?></td>
													<td>
														<a href="<?php echo base_url();?>academic/hw_edit/<?php echo $hw['hw_id'];?>" title="Edit"><i class="fa fa-edit"></i></a> | <?=anchor("academic/hw_delete/".$hw['hw_id'],"<i class=\"fa fa-remove\"></i>",array('onclick' => "return confirm('Do you want delete this record')"))?>
													</td>
												</tr>
											<?php $hi++;	} ?>
										</tbody>
									</table>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>

				
				
				
				
<?php include 'application/views/includes/footer.php';?>

<script type="text/javascript">

function msg()
{
//alert("yes")
$('#massage').fadeToggle(500);
}

function hover()
  {
    
    
      $('#tip').fadeIn('slow');
    
     // $('#tip').fadeOut('slow');
    //alert("yes");
    
    $('#massage').mousemove(function(e)
    {
      var topPosition = e.pageY+5;
      var leftPosition = e.pageX+5;
	  //alert(topPosition+leftPosition)
      $('#tip').css(
      {
        'top' :  topPosition+ 'px',
        'left' : leftPosition +'px'
      });
    });
  };
function mouseuot()
{
	$('#tip').fadeOut('slow');
}


function get_class_section_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'admin/section_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#section_id').html(html_data);
        }
    }
    });  
}

function get_sub_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'admin/subject_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
		$('#sub_id').html(html_data);
        }
    }
    });  
}

</script>

<!--For only numeric value can be typeable-->		
<script type="text/javascript">
	var specialKeys = new Array();
	specialKeys.push(8); //Backspace
	function IsNumeric(e) {
		var keyCode = e.which ? e.which : e.keyCode
		var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
		return ret;
	}
</script>