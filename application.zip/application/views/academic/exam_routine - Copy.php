<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
	<div class="content-page" style="overflow:visible;" id="loadfunction">
		<!-- ============================================================== -->
		<!-- Start Content here -->
		<!-- ============================================================== -->
		<div class="content" style="overflow:visible;">
			<div class="page-heading">
                            <h1><i class='fa fa-table'></i> Set Exam Routine </h1>
			</div>            	
			<div class="row" style="overflow:auto;">
                            <div class="col-md-12">
                                <div class="widget" style="min-height: 400px">
                                    <div class="widget-content">
                                        <form role="form" id="registerForm" method="POST">
                                            <div class="widget-content padding">
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-sm-4" >
                                                            <label>Exam</label>
                      <select class="form-control" name="term_id" id="term_id" onchange="get_old_exam_routine(this.value);" onclick="exam_get_class_wise_subject()">
                                                                <option value="">----Select Exam----</option>
                                                                <?php
                                                                    foreach($term_list as $tl){ ?>
                                                                    <option value="<?php echo $tl['term_id'];?>"><?php echo $tl['term'];?></option>   
                                                                <?php    } ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            
                                            
											<table id="" class="table table-striped table-bordered" style="text-align:center;">
											<thead >
                                                <tr style="border-top:1px;">
                                                    <th style="min-width:125px;"></th>
                                                    <th style="min-width:125px;"></th>
                                                    <?php 
                                                         foreach($class_list as $cl){ ?>
    														<th id="exam_class_id" class="" style="min-width:125px;">
                                                        
                                                            <span id="<?php echo $cl['class_id'];?>" style="display:none;" class="class_id"><?php echo $cl['class_id'];?></span>
                                                            <div id="<?php echo $cl['class_id'];?>"> <?php echo $cl['class_name'];?></div>
                                         
                                          
                                                            </th>  
                                                                <?php }?>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <tr>
                                                    <td>Exam Date</td>
                                                    <td>Exam Day</td>
                                                    <?php $iexam_time=0;
                                                            foreach($class_list as $ct){ ?>
                                                            <td id='exam_time' class="<?php echo $iexam_time; ?>">
                                                            
                                                            <select class="form-control" name="exam_time" id="exam_time">
                                                                <option value="">Select Time</option>
                                                                
                                                                 <?php
                                                                    foreach($exam_time as $etInfo){ ?>
                                 <option value="<?php echo $etInfo['start_time']."-".$etInfo['close_time'];?>"><?php echo $etInfo['start_time']."-".$etInfo['close_time'];?></option>
                                            <?php    } $iexam_time+=1;?>
                                                            </select>
                                                            
                                                            </td>  
                                                                <?php } ?>
                                                </tr>
                                                
                            <?php   for($s=0; $s<$subject_count; $s++){ ?>
                		         <tr class="date countvalue">
                           <td id="<?php echo 'date'.$s;?>" class="<?php echo $s;?>"><div id='jqxWidget' onchange="get_day(this.value,<?php echo $s;?>)"></div></td>
                                 
                                 
                                 <td id="<?php echo 'wkday'.$s;?>" class="wday"></td>
                                 
                                 
                                 
                                  <?php $isub_name=0;
								  foreach($class_list as $subname){ ?>
                                      <td id="<?php echo 'cid'.$subname['class_id'];?>" class="<?php echo 'cid'.$s; ?>">
                                     
                                          <span id="<?php echo 'cid'.$isub_name;?>" class="subject_name">
                     <select class="form-control subject_name <?php echo 'cid'.$isub_name; ?>" name="subject_name" id="<?php echo 'cid'.$subname['class_id'];?>">
                                                    <option value="">Select Subject</option>
                                                </select>
                                           </span>
                                      
									   </td>  
                                  <?php $isub_name+=1; }  ?>
                                  </tr>  
                             <?php }?>
                                               
                                            </tbody>
                                            </table>

                                            </div>
                                            <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-sm-4">
                                                            <button type="button" class="btn btn-primary" onclick="save_class_routine()">save</button>
                                                        </div>
                                                    </div>
                                                </div>
                                           
                                        </form>
                                    </div>
                                </div>
                            </div>
			</div>

				
				
<?php include 'application/views/includes/footer.php';?>
                    
<script type="text/javascript">
function get_day(exam_date,id)
{
	
	 var dayNames = new Array( 'Sunday' , 'Monday' , 'Tuesday' , 'Wednesday' , 'Thursday' , 'Friday' , 'Saturday' );
            var nData = new Date (exam_date);
$('#date'+id).next('td').html(dayNames[nData.getDay()]);
	
}


function exam_get_class_wise_subject()
{
   $("span.class_id").each(function(){
	 var class_id=$(this).html();
								$.ajax({
										type: "POST",
										url: baseUrl + 'academic/exam_get_class_wise_subject',
										data:
										{
											'class_id':class_id
										}, 
										success: function(html_data)
										{
												$('select#cid'+class_id).each(function() {
												$(this).html(html_data);
												});
											
										}
										});
										
										});
								
}

</script>
<script>
function get_old_exam_routine(term_id)
{//1
	
	$( "div#jqxWidget").each(function()
								{//alert('y')
	 $(this).jqxDateTimeInput({width: '150px', height: '25px',formatString: 'yyyy-MM-dd'});
								})
	
	 
	$.ajax({//2
		type: "POST",
		url: baseUrl + 'academic/get_id_per_exam_term',
		data:
		{
			'exam_term_id':term_id,
		}, 
		success: function(html_data)
		{//3
			if (html_data != '')
			{ //alert(html_data); 4
				var a=html_data.split('|');
				for (i=0;i<a.length;i++)
				{//5
					$.getJSON(//6
						baseUrl + 'academic/get_old_exam_routine_by_term',
						{ 'id' : a[i] },
						function(jd) {//7
					
								
										
									$("th[class='"+jd.column_no+"'] select#class_id").val(jd.class_id);
									$("td[class='"+jd.column_no+"'] select#exam_time").val(jd.exam_time);
									$("td[class='"+jd.row_no+"'] input#inputjqxWidget").val(jd.exam_date);
									$("td[id='wkday"+jd.row_no+"']").html(jd.exam_day);
									$("td[class='cid"+jd.row_no+"'] select.cid"+jd.column_no).val(jd.exam_subject_id);
										
								}////7
								
					);////6
				}////5
			}////4
		
    	}////3
    });////2
										
}////1
</script>
<script>
 function save_class_routine()
{//1
		 var exam_term_id = $('#term_id').val();
			//alert(exam_term_id);
		$.ajax({//2
				type: "POST",
				url: baseUrl + 'academic/delete_exam_wise_exam_routine',
				data:
					{
					'exam_term_id':exam_term_id,
					}, 
				success: function(html_data)
					{//3
						if (html_data != '')
							{//4
							//var exam_term_id = $('#exam_id').val();
							var totallcount=0;
							// get class id as array
							var class_id=new Array();  
						var iclass_id=0;	
						$( "span.class_id").each(function()
							{
								class_id[iclass_id]=$(this).html();
								iclass_id++;
							});	
							//alert(class_id[1]);	
							
							// get exam time as array
							var exam_time=new Array();  
						var iexam_time=0;	
						$( "select#exam_time").each(function()
							{
								exam_time[iexam_time]=$(this).val();
								iexam_time++;
							});	
							
							//alert(exam_time);
							
									
							//get exam date as array
							var date_value=new Array();  
							var idate=0;	
							$( "input#inputjqxWidget").each(function()
								{
									date_value[idate]=$(this).val();
									idate++;
								});
							//alert(date_value[1]);
						
						
							//get exam day as array
							var day_value=new Array();  
							var iday=0;	
							$( "td.wday").each(function()
								{
									day_value[iday]=$(this).html();
									iday++;
								});
							//alert(day_value[1]);
							
							// get teachers name
							var subName=new Array();
							var rsl=1;
							//exam_time value =15
							for(itsc=0; itsc<iexam_time;)
								{//5
							//get subject name
									var icid=0;	
									$( 'select.cid'+itsc).each(function()
										{
											subName[icid]=$(this).val();
											icid++;
										});
									//alert(subName[0]+' '+subName[1]+' '+subName[2])
									var iwday=0;	
									$( "tr.countvalue").each(function()
										{
											iwday++;
										});
								var count=iwday;// value = 19
								
								//alert(count)
									// routine save program
										var countsave=0;
										for(var isave=0; isave<count; isave++)
										{//6
											if(subName[isave]!='' && day_value[isave]!='' && exam_time[itsc]!='')
												{//7
													//alert(exam_term_id+' class_id ='+class_id[itsc]+' exam_time ='+exam_time[itsc]+' day ='+day_value[isave]+' date ='+date_value[isave]+' subname ='+subName[isave]);
													$.ajax({//8
															type: "POST",
															url: baseUrl + 'academic/save_exam_routine',
															data:
															{
																'exam_term_id':exam_term_id,
																'class_id':class_id[itsc],
																'exam_time':exam_time[itsc],
																'exam_date':date_value[isave],
																'exam_day':day_value[isave],
																'exam_subject_id':subName[isave],
																'column_no':itsc,
																'row_no':isave
															}, 
															success: function(html_data)
															{
																if (html_data != '')
																{
																	//alert(html_data);
																	$("#ooo").append("<br/>record:"+rsl+ "  "+html_data);
																	rsl++;
																}
															}
															});////8
													}////7
										
										//	alert(isave)
										}////6
										itsc++;
								}alert(itsc)
									alert(" All records have been inserted.");
							}////4
					}////3
				});//2
					//end save program
 }////1
</script>
<div style="text-align:right; display:none;" id="ooo"></div>