<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>

       
	<div class="content-page">
		<!-- ============================================================== -->
		<!-- Start Content here -->
		<!-- ============================================================== -->
		<div class="content">
			<div class="page-heading">
				<h1><i class='fa fa-table'></i> Show Class Routine by Teacher </h1>
			</div>            	
			<div class="row">
				<div class="col-md-12">
					<div class="widget" style="min-height: 400px">
						<div class="widget-content">                                     
							<div class="widget-content padding">
								<div class="form-group">
									<div class="row">
										<div class="col-sm-4">
											<label>Class</label>
											<select class="form-control" name="teacher_id" id="teacher_id">
												<option value="">----Select Teacher----</option>
												<?php
													foreach($teacher_list as $tl){ ?>
													<option value="<?php echo $tl['teacher_id'];?>"><?php echo $tl['teacher_name'];?></option>   
												<?php    } ?>
											</select>
										</div>
									</div>
								</div>                                      
								<div class="form-group">
									<div class="row">
										<div class="col-sm-4">
											<button type="button" class="btn btn-primary" onclick="get_class_routine_json()">Get Routine Grid</button>
										</div>
									</div>
								</div>
							</div>                                            
							<div id="display" class="col-p-12"></div>                                            
						</div>
					</div>
				</div>
			</div>
			<span class="test"></span>
				
<?php include 'application/views/includes/footer.php';?>
                    
<script type="text/javascript">
	// get the student list and fees list 
	function get_class_routine_json()
	{
        $.ajax({ 
        url: baseUrl+'academic/get_class_routine_teacher_json_show',
        data:
            {                  
                'teacher_id':$('#teacher_id').val()
            }, 
            dataType: 'json',
            success: function(data)
            {
                result                = ''+data['result']+'';
                mainContent           = ''+data['mainContent']+'';

                if(result == 'success')
                {      
                    $('#display').html(mainContent);  
					
					// call the routine if created before
					//get_old_class_routine();
                }                
            }
        });
        return false; // keeps the page from not refreshing     
    }
	

	function get_old_class_routine()
	{
		$.getJSON( baseUrl + 'academic/get_old_routine_by_teacher_show',
				{
					'class_id':$('#class_id').val(),
					'section_id':$('#section_id').val(),
					'group_id':$('#group_id').val(),
					'shift_id':$('#shift_id').val()
				},
				function(jd) {
					for(i=0; i<jd.length; i++)
					{
						var multycolumn_no=jd[i].column_no.split(",");
						var multyteacher_name=jd[i].teacher_name.split(",");
						var multysubject_name=jd[i].subject_name.split(",");
						var multyteacher_id=jd[i].teacher_id.split(",");
						var multysubject_id=jd[i].subject_id.split(",");
							
						if(multycolumn_no.length > 1 )
						{
							for(mb=0; mb < multycolumn_no.length; mb++)
							{
								if(mb < 1)
								{
									$("td[id='"+jd[i].day+"'] span#tid"+multycolumn_no[mb]).html(multyteacher_name[mb]);
									$("td[id='"+jd[i].day+"'] span#cid"+multycolumn_no[mb]).html(' ('+multysubject_name[mb]+')');
								}
								else
								{
									// call function from json file to add new routine box
									new_box_old_routine(multycolumn_no[mb] , jd[i].day,multyteacher_id[mb]+multysubject_id[mb]);
									
									$("td[id='"+jd[i].day+"'] span#classtid"+multyteacher_id[mb]+multysubject_id[mb]).html('<br/>'+multyteacher_name[mb]);
									$("td[id='"+jd[i].day+"'] span#classcid"+multyteacher_id[mb]+multysubject_id[mb]).html(' ('+multysubject_name[mb]+')');
								}
							}
						}
						else
						{
							$("td[id='"+jd[i].day+"'] span#tid"+jd[i].column_no).html(jd[i].teacher_name);
							$("td[id='"+jd[i].day+"'] span#cid"+jd[i].column_no).html(' ('+jd[i].subject_name+')');
						}
					}
					}
				);
						
				var clPeriod=new Array();  
				var iclPeriod=0;
				$( "td#clperiod").each(function() {
					clPeriod[iclPeriod]=$(this).html();
									
					if($(this).html()=="tiffin")
					{//alert(iclPeriod);
						$('span#tid'+iclPeriod).html("<br/><span style=''>Break</span>");
						$('span#cid'+iclPeriod).html("");
					}
					iclPeriod++;
				});						
	}

	function printPageArea(areaID){
		var printContent = document.getElementById(areaID);
		var WinPrint = window.open('', '', 'width=900,height=650');
		WinPrint.document.write('<link rel="stylesheet" type="text/css" href="<?= base_url();?>template/bootstrap-print/bootstrap-print.min.css" media="print" />')
		WinPrint.document.write('<style type="text/css" media="print"> @page { size: landscape; font-size:12px; } table{font-size:12px;} table td{padding:3px;} .print_button{ display:none;} </style>')
		WinPrint.document.write(printContent.innerHTML);
		WinPrint.document.close();
		WinPrint.focus();
		WinPrint.print();
		WinPrint.close();
	}
</script>
