<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
<style>
.radio input[type=radio], .radio-inline input[type=radio], .checkbox input[type=checkbox], .checkbox-inline input[type=checkbox] {
     position: relative;
    margin-top: 4px \9;
    margin-left: 2px;
}
</style>
       
        <div class="content-page">			
            <div class="content">
			
            <?php if($this->session->flashdata('message')):?>
				<?=$this->session->flashdata('message')?>
			<?php endif?>
            
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-calendar'></i> Academic Calendar</h1>
                </div>
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
				<div class="row">				
					<div class="col-md-12">
						<div class="widget">
                        	<div class="col-lg-3 col-sm-12">
	      						<div class="well well-small">
                                    <div id="add-event-form">
                                        <fieldset>
                                        <legend>Add Custom Event</legend>
                                        <span class="help-block">Event Title</span>
                                        <input id="title" name="title" type="text" placeholder="event title" class="form-control input-small">
                                        <label class="radio">
                                            <input type="radio" name="priority" value="label label-default #777777" checked>
                                            <span class="label label-default">default</span>
                                        </label>
                                        <label class="radio">
                                            <input type="radio" name="priority" value="label label-warning #FFC052">
                                            <span class="label label-warning">warning</span>
                                        </label>
                                        <label class="radio">
                                            <input type="radio" name="priority" value="label label-success #68C39F">
                                            <span class="label label-success">success</span>
                                        </label>
                                        <label class="radio">
                                            <input type="radio" name="priority" value="label label-info #65BBD6">
                                            <span class="label label-info">info</span>
                                        </label>
                                        <label class="radio">
                                            <input type="radio" name="priority" value="label label-danger #E15554">
                                            <span class="label label-danger">danger</span>
                                        </label>
                                        <br/>
                                        <button id="add-event" type="button" class="btn btn-sm btn-default">Add Event</button>
                                        </fieldset>
                                    </div>
								</div>
                                
                                <div class="well well-small">
									<h4>Draggable Events</h4>
									<ul id='external-events' class="list-inline">
										<li class="external-event"><span class="label label-default">My Event 1</span></li>
										<!--<li class="external-event"><span class="label label-danger">My Event 2</span></li>
										<li class="external-event"><span class="label label-success">My Event 3</span></li>
										<li class="external-event"><span class="label label-warning">My Event 4</span></li>
										<li class="external-event"><span class="label label-info">My Event 5</span></li>-->
									</ul>
                        
									<label class="checkbox inline" for='drop-remove'>
										<input type="checkbox" id="drop-remove">
										remove after drop
									</label>
                                </div>
                            </div>							
							<div class="col-lg-9 col-sm-12 col-xs-12">
								<div id="calendar" style="overflow:auto;">
								<!--  calander will be displyed here -->
								</div>
							</div>
						</div>
					</div>
				</div>

</div>
				
<div id="fullCalModal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span> <span class="sr-only">close</span></button>
                <h4 id="modalTitle" class="modal-title"></h4>
            </div>
            <div id="modalBody" class="modal-body">
				<textarea class="form-control" id="description"></textarea>
				<input type="hidden" id="event_title" />
				<input type="hidden" id="start" />
				<input type="hidden" id="end" />
				<input type="hidden" id="color" />
				<input type="hidden" id="id" />
				
			</div>
            <div class="modal-footer">
                <button class="btn btn-primary add_button" onClick="add_event()">Save</button>
				<button class="btn btn-primary update_button" onClick="Update_event()">Update</button>
				<span class="close_button" data-dismiss="modal"></span>
            </div>
        </div>
    </div>
</div>			

<?php include 'application/views/includes/footer.php';?>

<script src="<?php echo base_url();?>template/plugins/fullcalendar-1.6.2/fullcalendar/fullcalendar.min.js"></script>
<script>

function CalendarInit() {
	"use strict";

    var date = new Date();
    var d = date.getDate();
    var m = date.getMonth();
    var y = date.getFullYear();

    var hdr = {};
/*
    if ($(window).width() <= 767) {
        hdr = { left: 'title', center: '', right: 'prev,today,month,agendaWeek,agendaDay,next' };
    } else {
        hdr = { left: '', center: 'title', right: 'prev,today,month,agendaWeek,agendaDay,next' };
    }
*/
	if ($(window).width() <= 767) {
        hdr = { left: 'prev,next', center: '', right: 'title' };
    } else {
        hdr = { left: 'prev,next', center: 'title', right: '' };
    }
    var initDrag = function (e) {
        // create an Event Object (http://arshaw.com/fullcalendar/docs/event_data/Event_Object/)
        // it doesn't need to have a start or end



        var eventObject = {
            title: $.trim(e.text()), // use the element's text as the event title

            className: $.trim(e.children('span').attr('class')) // use the element's children as the event class
        };
        // store the Event Object in the DOM element so we can get to it later
        e.data('eventObject', eventObject);

        // make the event draggable using jQuery UI
        e.draggable({
            zIndex: 999,
            revert: true, // will cause the event to go back to its
            revertDuration: 0  //  original position after the drag
        });
    };

    var addEvent = function (title,type,priority) {
        title = title.length === 0 ? "Untitled Event" : title;

        priority = priority.length === 0 ? "label label-default" : priority;

        var html = $('<li class="external-event"><span class="' + priority + '">' + title + '</span></li>');

        jQuery('#external-events').append(html);
        initDrag(html);
    };

    /* initialize the external events
     -----------------------------------------------------------------*/

    $('#external-events li.external-event').each(function () {
        initDrag($(this));
    });

    $('#add-event').click(function () {
        var title = $('#title').val();
        var priority = $('input:radio[name=priority]:checked').val();
		var type='';
        addEvent(title,type,priority);
    });
    /* initialize the calendar
     -----------------------------------------------------------------*/

    $('#calendar').fullCalendar({
        header: hdr,
        buttonText: {
            prev: '<i class="fa fa-angle-double-left"></i>',
            next: '<i class="fa fa-angle-double-right"></i>'
        },
        editable: true,
		eventResize: function(event, delta, revertFunc) {

			// data show to updateEvent
			$('.update_button').show();
			$('.add_button').hide();
            $('#calendar').fullCalendar('renderEvent', event, true);
			$('#modalTitle').html(event.title);
			$('#description').val(event.description);
            $('#start').val($.fullCalendar.formatDate(event.start, "yyyy-MM-dd HH:mm:ss"));
            $('#end').val($.fullCalendar.formatDate(event.end, "yyyy-MM-dd HH:mm:ss"));
			$('#id').val(event.id);
			
            $('#fullCalModal').modal();

    },
	events: baseUrl + 'academic/get_event',
	
    droppable: true, // this allows things to be dropped onto the calendar !!!
    drop: function (date, allDay) { // this function is called when something is dropped
            // retrieve the dropped element's stored Event Object
            var originalEventObject = $(this).data('eventObject');

            // we need to copy it, so that multiple events don't have a reference to the same object
            var copiedEventObject = $.extend({}, originalEventObject);

            // assign it the date that was reported
            copiedEventObject.start = date;
            //copiedEventObject.allDay = allDay;
			var color='';
			$('#external-events li span').each(function(index, element) {
                if($(this).html()==copiedEventObject.title)
				{color= $(this).attr('class');}
            });
			
            // render the event on the calendar
			$('.update_button').hide();
			$('.add_button').show();
            $('#calendar').fullCalendar('renderEvent', copiedEventObject, true);
			$('#modalTitle').html(copiedEventObject.title);
            $('#event_title').val(copiedEventObject.title);
            $('#start').val($.fullCalendar.formatDate(copiedEventObject.start, "yyyy-MM-dd HH:mm:ss"));
            $('#end').val($.fullCalendar.formatDate(copiedEventObject.start, "yyyy-MM-dd HH:mm:ss"));
            $('#color').val(color);
			
            $('#fullCalModal').modal();

            // is the "remove after drop" checkbox checked?
            if ($('#drop-remove').is(':checked')) {
                // if so, remove the element from the "Draggable Events" list
                $(this).remove();
            }
			

        },
		
    windowResize: function (event, ui) { $('#calendar').fullCalendar('render'); },
	renderEvent: function (copiedEventObject){ alert(copiedEventObject.start) },
	eventAfterRender: function (event, element) { $(element).tooltip({title:event.description, container: ""}); },
	eventClick: function(event, element) {
        //event.title = "CLICKED!";
		if (confirm("Do you want to delete this event?"))
		{
            $.ajax({
				   type: "POST",
					url: baseUrl + 'academic/delete_event',
					data:
					{
						'id':event.id
					},
				   success: function(json) {
						$('#calendar').fullCalendar('removeEvents', event.id);
				   }
				   });

        }
        $('#calendar').fullCalendar('updateEvent', event);

		}
    });
	
	//refresh page if close button clicked
	$('.close').click(function(){
		location.reload();
	});
	
}
// calander initialize
CalendarInit();

function add_event(){
	
	$.ajax({
			type: "POST",
			url: baseUrl + 'academic/add_event',
			data:
			{
				'title':$('#event_title').val(),
				'description':$('#description').val(),
				'start':$('#start').val(),
				'end':$('#end').val(),
				'color':$('#color').val(),
			},
			success: function(json) {
				$('.close_button').click();
				$('#description').val('');
				$('#start').val('');
				$('#end').val('');
				$('#color').val('');
				alert('Added Successfully');
				
			}
		});
}

function Update_event(){
	
	$.ajax({
			type: "POST",
			url: baseUrl + 'academic/update_event',
			data:
			{
				'description':$('#description').val(),
				'start':$('#start').val(),
				'end':$('#end').val(),
				'id':$('#id').val(),
			},
			success: function(json) {
				$('.close_button').click();
				$('#description').val('');
				$('#start').val('');
				$('#end').val('');
				$('#color').val('');
				alert('Update Successfully');
			}
		});
}
</script>  