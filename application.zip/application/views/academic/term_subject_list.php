<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">			
            <div class="content">
			
            <?php if($this->session->flashdata('message')):?>
				<?=$this->session->flashdata('message')?>
			<?php endif?>
            
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i> Term Subject List</h1>
                </div>
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="widget" style="min-height:500px;">
                            <div class="widget-content padding">
            	<!-- Page Heading End-->				<!-- Your awesome content goes here -->
				<div class="row">				
					<div class="col-md-12">
						<div class="widget">
                                                    
                                                    
                                                    
							<div class="widget-content padding">
								Add New Term Subject - <a href="javascript:void(0);" onclick="toggle_insertion_box(); return false;">Click Here</a>
								<div class="insertion_div">
									<form role="form" id="ts_entry" name="ts_entry" method="POST" action="<?php echo base_url();?>academic/create_term_subject_save">
                                   
                                    <div class="form-group">
                                        <div class="row">
                                            
                                            <div class="col-sm-4">
                                                <label>Class <span style="color:red;">*</span></label>
                                            <select class="form-control" name="class_id" id="class_id" onchange="get_class_group_list(this.value);" required >
                                                    <option value="">Select</option>
                                                    <?php
                                                        foreach($class_list as $cl){ ?>
                                                         <option value="<?php echo $cl['class_id'];?>"><?php echo $cl['class_name'];?></option>   
                                                    <?php    }
                                                    ?>
                                                </select>
                                            </div>
                                            
											 <div class="col-sm-4">
                                               <label>Group <span style="color:red;">*</span></label>
                                                <select class="form-control" name="group_id" id="group_id" required onChange="get_sub_list(this.value);" >
                                                    <option value="">Select</option>
                                                </select>
                                            </div>
											<div class="col-sm-4">
                                                <label>Subject <span style="color:red;">*</span></label>
                                                <select class="form-control" name="subject_id" id="subject_id" required >
                                                    <option value="">Select</option>
                                                </select>
                                            </div>
                                            
                                        </div>
                                    </div>
                                    
                                    
                                    <div class="form-group">
                                        <div class="row">
                                        
                                            <div class="col-sm-4">
                                                <label>Term <span style="color:red;">*</span></label>
                                                <select class="form-control" name="term_id" id="term_id" required >
                                                    <option value="">Select</option>
                                                   <?php
                                                        foreach($term_list as $tl){ ?>
                                                         <option value="<?php echo $tl['term_id'];?>"><?php echo $tl['term'];?></option>   
                                                    <?php    }
                                                    ?>
                                                </select>
                                            </div>
                                            
                                            <div class="col-sm-4">
                                                <label>Full Marks <span style="color:red;">*</span></label>
                                                <input type="text" pattern="[0-9]*" required class="form-control" name="full_marks" id="ct_marks">
                                            </div>
                                            <div class="col-sm-4">
                                                <label>Pass Marks in % <span style="color:red;">*</span></label>
                                                <input type="text" pattern="[0-9]*" required class="form-control" name="pass_marks" id="pass_marks">
                                            </div>
                                        </div>
                                    </div>
									<hr />
									
									<button type="submit" class="btn btn-primary">Submit</button>
								</form>
                            </div>
                        </div>
                   
							
							<div class="widget-content">
									<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
										<thead>
											<tr>
                                            <th>SLNO</th>
                                            <th>Term</th>
											<th>Class</th>
											<th>Group</th>
											<th>Subject</th>
											<th>Full Marks</th>
                                            <th>Pass Marks</th>
											<th>Action</th>
												
											</tr>
										</thead>
										<tbody>
											<?php $ci=1;
												foreach($term_sub_list as $tl){
												
												
												$class_id = $tl['class_id'];
												$sql_c = "SELECT class_name FROM  `tbl_class` WHERE  `class_id` ='$class_id' LIMIT 1";
												$query_c = $this->db->query($sql_c);
												$class_name = $query_c->row_array();
												?>
											<tr>
												
												<td><?php echo $ci;?></td>
                                                <td><?php echo $tl['term'];?></td>
                                                <td><?php echo $tl['class_name'];?></td>
                                                <td><?php echo $tl['group_name'];?></td>
                                                <td><?php echo $tl['subject_name'];?></td>
                                                <td><?php echo $tl['sub_full_marks'];?></td>
                                                <td><?php $pass= ($tl['pass_marks']*$tl['sub_full_marks'])/100; echo $pass;?></td>

												<td>
													<a href="<?php echo base_url();?>academic/term_subject_edit/<?php echo $tl['id'];?>" title="Edit"><i class="fa fa-edit"></i></a> | <?=anchor("academic/term_subject_delete/".$tl['id'],"<i class=\"fa fa-remove\"></i>",array('onclick' => "return confirm('Do you want delete this record')"))?> 
												</td>
											</tr>
											<?php   $ci++; } ?>
										</tbody>
									</table>
							</div>
						</div>
					</div>
				</div>

                            </div>
                        </div>
                    </div>
                </div>
				

				
				

				
<?php include 'application/views/includes/footer.php';?>

<script type="text/javascript">



function get_class_group_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'academic/group_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#group_id').html(html_data);
        }
    }
    });  
}

function get_sub_list(group_id)
{
	var class_id=$('#class_id').val();
   $.ajax({
    type: "POST",
    url: baseUrl + 'academic/subject_list_ajax',
    data:
    {
        'class_id':class_id,
		'group_id':group_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
			$('#subject_id').html(html_data);
        }
    }
    });  
}

</script>

<!--For only numeric value can be typeable-->		
<script type="text/javascript">
	var specialKeys = new Array();
	specialKeys.push(8); //Backspace
	function IsNumeric(e) {
		var keyCode = e.which ? e.which : e.keyCode
		var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
		return ret;
	}
</script>  