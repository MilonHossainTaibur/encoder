<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>
				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">
            <div class="content">
           <?php if($this->session->flashdata('message')):?>
			<div class="alert alert-success">
				<a href="#" class="close" data-dismiss="alert">&times;</a>
				<?=$this->session->flashdata('message')?>
			</div>
			<?php endif?>
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-table'></i> Tabulation Sheet View </h1>
                </div>
            <div class="row">
                            <div class="col-md-12">
                                <div class="widget" style="min-height: 400px">
                                    <div class="widget-content">
                <form role="form" id="registerForm" method="POST" action="<?php echo base_url();?>academic/tabulation_marks_save" enctype="multipart/form-data"> 
                                            <div class="widget-content padding">
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-sm-4">
                                        					<label>Class Name<span style="color:red;">*</span></label>
                    <select name="class_id" id="class_id" required class="form-control" onchange="get_class_section_list(this.value); get_class_group_list(this.value);" >
                                                <option value="">Select Class</option>
                                                <?php
                                                foreach($class_list as $cl){ ?>       
                                                <option value="<?php echo $cl['class_id']; ?>"><?php echo $cl['class_name']; ?></option>
                                            <?php } ?>
                                            </select>
                                            <br /><br />

                                        </div>
                                        
                                        
                                        <div class="col-md-4 col-sm-4 ">
                                        <label>Section<span style="color:red;">*</span></label>
                                            <select name="section_id" required id="section_id" class="form-control">
                                                <option value="">Select Section</option>
                                            </select>
                                            <br /><br />

                                        </div>
                                        <div class="col-md-4 col-sm-4 ">
                                        <label>Group <span style="color:red;">*</span></label>
                                                <select class="form-control" name="group_id" id="group_id" required >
                                                    <option value="">Select</option>
                                                </select>
                                            <br /><br />

                                        </div>
                                       
                                       <div class="col-sm-4">
                                               <label>Shift <span style="color:red;">*</span></label>
                                                <select class="form-control" name="shift_id" id="shift_id" required >
                                                    <option value="">Select</option>
                                                     <?php
                                                        foreach($shift_list as $sl){ ?>
                                                         <option value="<?php echo $sl['shift_id'];?>"><?php echo $sl['shift_name'];?></option>   
                                                    <?php    }
                                                    ?>
                                                </select>
                                            </div>
                                            
                                        <div class="col-md-4 col-sm-4 ">
                                           <label>Term Name <span style="color:red;">*</span></label>
                                                            <select class="form-control" required name="term_id" id="term_id" onchange="term_marks_json()">
                                                                <option value="">Select</option>
                                                                
                                                                 <?php
                                                                    foreach($term as $tl){ ?>
                                                                <option value="<?php echo $tl['term_id'];?>"><?php echo $tl['term'];?></option>
                                                                <?php    } ?>
                                                            </select>                                         
                                        </div>
                                         <div class="col-sm-4">
                                                         <?php  $currentDate = date("Y"); 
														 //echo $currentDate+6;
														// $examdate[]='';
														 for ($edb=0; $edb<=5; $edb++)
														 {
															 $examdate[$edb]=$currentDate-$edb;
														 }
														 $examdate=array_reverse($examdate);
														 $count=6;
														 for ($eda=1; $eda<=5; $eda++)
														 {
															 $examdate[$count]=$currentDate+$eda;
															 $count++; 
														 }
														 ?>
                                                <label>Exam Year <span style="color:red;">*</span></label>
                                                <select class="form-control" required name="exam_year" id="exam_year">
                                                    <option value="">Select</option>
                                                    
                                                     <?php
                                                                    foreach($examdate as $ed){ ?>
                                                                <option value="<?php echo $ed;?>"<?php if($ed==$currentDate) echo "selected"?>><?php echo $ed;?></option>
                                                     <?php    } ?>
                                                </select>
													</div>
                                                     <div class="col-md-4 col-sm-4 "><br /><br />

                                           <label> Passing System <span style="color:red;">*</span></label>
                                                            <select class="form-control" required name="passing_id" id="passing_id">
                                                                <option value="">----Select System----</option>
                                                                <option value="1"> Pass Every Field</option>
                                                                <option value="2"> Pass overall</option>
                                                            </select> <br /><br />                                        
                                        			</div>
                                                    <div class="col-sm-4"> <br /><br /> 
                                                       <label>Type of GPA<span style="color:red;">*</span></label>
   													 <select class="form-control" name="type_id" id="type_id" required>
                                                     <option value="">----Select----</option>
                                                     <option value="1">Type 1</option>
                                                     <option value="2">Type 2</option>
                                                     <option value="3">Type 3</option>
                                                     <option value="4">Type 4</option>
                                                     </select> <br /><br />   
                                                        </div>
                                    </div>
                                    </div>
                                    <button class="btn btn-success btn-label-center" onclick="tabulation_marks_json()" type="button"> Tabulation View </button>
                                    <hr />
                                    <div id="display">
										
                                        
                                        
                                        
                                    </div>
                                    
                                </div><!--//section-content--> 
                                    
                            </article><!--//news-item-->
                        </div><!--//news-wrapper-->
                        <aside class="page-sidebar  col-md-3 col-md-offset-1 col-sm-4 col-sm-offset-1 col-xs-12">
                        </aside>
                    </div><!--//page-row-->
                </div><!--//page-content-->
            </div><!--//page-wrapper-->
        </div><!--//content-->
    </div><!--//wrapper-->
    
<?php include 'application/views/includes/footer.php';?>

<!--Check department name based on class id--->
<script>


   function get_class_section_list(class_id)
		{
		   $.ajax({
			type: "POST",
			url: baseUrl + 'admin/section_list_ajax',
			data:
			{
				'class_id':class_id
			}, 
			success: function(html_data)
			{
				if (html_data != '')
				{
					$('#section_id').html(html_data);
				}
			}
			});  
		}
function get_class_group_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'academic/group_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#group_id').html(html_data);
        }
    }
    });  
}
	function tabulation_marks_json()
		{
			var class_id = $('#class_id').val();        
			var section_id = $('#section_id').val(); 
			var group_id = $('#group_id').val();
			var shift_id = $('#shift_id').val(); 
			var term_id = $('#term_id').val(); 
			var exam_year = $('#exam_year').val();
			var passing_id = $('#passing_id').val();
			var type_id = $('#type_id').val();
			
			if(!class_id)
		{
			$('#class_id').after("<div id='validation_class' style='position:absolute; background-color:#7ECCAD; width:auto; color:#fff; font-size:14px; font-weight:bold; border-radius:0px 15px 0px 15px; box-shadow:1px 1px 1px 1px #5DAF8F; padding:8px 8px 8px 8px; alignment-adjust:central; text-shadow:#FFE1FF;'> Please select a class name </div>")
						$('#validation_class').fadeToggle(5000);
						return;
		}
		if(!section_id)
		{
			$('#section_id').after("<div id='validation_section' style='position:absolute; background-color:#7ECCAD; width:auto; color:#fff; font-size:14px; font-weight:bold; border-radius:0px 15px 0px 15px; box-shadow:1px 1px 1px 1px #5DAF8F; padding:8px 8px 8px 8px; alignment-adjust:central; text-shadow:#FFE1FF;'> Please select a section name </div>")
						$('#validation_section').fadeToggle(5000);
						return;
		}
		if(!group_id)
		{
			$('#group_id').after("<div id='validation_group' style='position:absolute; background-color:#7ECCAD; width:auto; color:#fff; font-size:14px; font-weight:bold; border-radius:0px 15px 0px 15px; box-shadow:1px 1px 1px 1px #5DAF8F; padding:8px 8px 8px 8px; alignment-adjust:central; text-shadow:#FFE1FF;'> Please select a group name </div>")
						$('#validation_group').fadeToggle(5000);
						return;
		}
		if(!shift_id)
		{
			$('#shift_id').after("<div id='validation_shift' style='position:absolute; background-color:#7ECCAD; width:auto; color:#fff; font-size:14px; font-weight:bold; border-radius:0px 15px 0px 15px; box-shadow:1px 1px 1px 1px #5DAF8F; padding:8px 8px 8px 8px; alignment-adjust:central; text-shadow:#FFE1FF;'> Please select a shift name </div>")
						$('#validation_shift').fadeToggle(5000);
						return;
		}
		if(!term_id)
		{
			$('#term_id').after("<div id='validation_tr' style='position:absolute; background-color:#7ECCAD; width:auto; color:#fff; font-size:14px; font-weight:bold; border-radius:0px 15px 0px 15px; box-shadow:1px 1px 1px 1px #5DAF8F; padding:8px 8px 8px 8px; alignment-adjust:central; text-shadow:#FFE1FF;'> Please select a term name </div>")
						$('#validation_tr').fadeToggle(5000);
						return;
		}
		if(!exam_year)
		{
			$('#exam_year').after("<div id='validation_ey' style='position:absolute; background-color:#7ECCAD; width:auto; color:#fff; font-size:14px; font-weight:bold; border-radius:0px 15px 0px 15px; box-shadow:1px 1px 1px 1px #5DAF8F; padding:8px 8px 8px 8px; alignment-adjust:central; text-shadow:#FFE1FF;'> Please select an exam Year </div>")
						$('#validation_ey').fadeToggle(5000);
						return;
		}  
		if(!passing_id)
		{
			$('#passing_id').after("<div id='validation_pass' style='position:absolute; background-color:#7ECCAD; width:auto; color:#fff; font-size:14px; font-weight:bold; border-radius:0px 15px 0px 15px; box-shadow:1px 1px 1px 1px #5DAF8F; padding:8px 8px 8px 8px; alignment-adjust:central; text-shadow:#FFE1FF;'> Please select passing system </div>")
						$('#validation_pass').fadeToggle(5000);
						return;
		}
		if(!type_id)
		{
			$('#type_id').after("<div id='validation_gptyp' style='position:absolute; background-color:#7ECCAD; width:auto; color:#fff; font-size:14px; font-weight:bold; border-radius:0px 15px 0px 15px; box-shadow:1px 1px 1px 1px #5DAF8F; padding:8px 8px 8px 8px; alignment-adjust:central; text-shadow:#FFE1FF;'> Please select a GPA type </div>")
						$('#validation_gptyp').fadeToggle(5000);
						return;
		}    
		//alert(group_id)
			$.ajax({ 
			url: baseUrl+'academic/tabulation_marks_json',
			data:
				{                  
					'class_id':class_id,
					'section_id':section_id,
					'group_id':group_id,
					'shift_id':shift_id,
					'term_id':term_id,
					'exam_year':exam_year,
					'passing_id':passing_id,
					'type_id':type_id
				}, 
				dataType: 'json',
				success: function(data)
				{//alert(data)
					result                = ''+data['result']+'';
					mainContent           = ''+data['mainContent']+'';
	
					if(result == 'success')
					{            
						$('#display').html(mainContent);     
					}                
				}
			});
		}
		
		

</script> 


