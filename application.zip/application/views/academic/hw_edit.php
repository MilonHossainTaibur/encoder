<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>
				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">			
            <div class="content">
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i>Edit Home Work</h1>
                </div>
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="widget" style="min-height:500px;">
                            <div class="widget-content padding">
                                <form role="form" id="hw_entry" name="hw_entry" method="POST" action="<?php echo base_url();?>academic/hw_edit_save" enctype="multipart/form-data">
                                   
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label>HW name</label>
												<input type="hidden" class="form-control" name="hw_id" value="<?php echo $hw_edit['hw_id']; ?>" id="hw_id">
                                                <input type="text" required class="form-control" name="hw_name" value="<?php echo $hw_edit['hw_name']; ?>" id="hw_name">
                                            </div>
											<div class="col-sm-4">
                                                <label>HW topic</label>
                                                <input type="text" required class="form-control" name="hw_topic" value="<?php echo $hw_edit['hw_topic']; ?>" id="hw_topic">
                                            </div>
                                            
                                            <div class="col-sm-4">
                                                <label>Class <span style="color:red;">*</span></label>
                                                <select class="form-control" name="class_id" id="class_id" onclick="get_class_section_list(this.value);" onchange="get_sub_list(this.value);" required>
                                                    <option value="">Select</option>
                                                    <?php
                                                        foreach($class_list as $cl){ ?>
                                                         <option value="<?php echo $cl['class_id'];?>" <?php if($hw_edit['hw_class'] == $cl['class_id']){echo "selected='selected'";} ?>><?php echo $cl['class_name'];?></option>   
                                                    <?php    }
                                                    ?>
                                                </select>
                                            </div>
											<?php 
												$section_id = $hw_edit['section']; 
											?>
                                            <div class="col-sm-4">
                                                <label>Section <span style="color:red;">*</span></label>
                                                <select class="form-control" name="section_id" id="section_id" required>
                                                
                                                 <option value="">Select</option>
                                                   <?php
                                                        foreach($section_list as $sl){ ?>
                                                         <option value="<?php echo $sl['section_id'];?>" <?php if($hw_edit['section'] == $sl['section_id']){echo "selected='selected'";} ?>><?php echo $sl['section_name'];?></option>   
                                                    <?php    }
                                                    ?>
                                                    
                                                </select>
                                            </div>
											 <div class="col-sm-4">
                                                <label>Subject <span style="color:red;">*</span></label>
                                                
                                                <?php
												
                                                $class_id = $hw_edit['hw_class'];   
												$sql_s = "SELECT * FROM  `tbl_class_subject` as S inner join tbl_subject on tbl_subject.subject_id = S.subject_id where S.school_id = 1 and S.class_id= $class_id order by tbl_subject.subject_id asc";
												$query = mysql_query($sql_s);
												while($sub_name =mysql_fetch_array($query))
												{
													$subject_name[]=$sub_name;
												}
												?>
                                                <select class="form-control" name="sub_id" id="sub_id" required>
                                                    <option value="">Select</option>
                                                
                                                 <?php
                                                        foreach($subject_name as $sl){ ?>
                                                         <option value="<?php echo $sl['subject_id'];?>" <?php if($sl['subject_id'] == $hw_edit['hw_sub']){echo "selected='selected'";} ?>><?php echo $sl['subject_name'];?></option>  
                                                    <?php    }
                                                    ?>   
 
                                                </select>
                                            </div>
											<div class="col-sm-4">
                                                <label>HW Date</label>
                                                <input type="text" class="form-control datepicker-input" name="hw_date" value="<?php echo $hw_edit['hw_date']; ?>" id="hw_date" required>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label>Term <span style="color:red;">*</span></label>
                                                <select class="form-control" name="term" id="term" required>
                                                   <option value="">Select</option>
                                                   <?php
                                                        foreach($term_list as $tl){ ?>
<option value="<?php echo $tl['term_id'];?>" <?php if($hw_edit['term_id'] == $tl['term_id']){echo "selected='selected'";} ?>><?php echo $tl['term'];?></option>
                                                    <?php    }
                                                    ?>
                                                </select>
                                            </div>
                                            
                                            <div class="col-sm-4">
                                                <label>Full Marks</label>
                                                <input type="text" required class="form-control" name="marks" value="<?php echo $hw_edit['hw_marks']; ?>" id="marks">
                                            </div>
                                        </div>
                                    </div>
									<hr />
									
									<button type="submit" class="btn btn-primary">Submit</button>
								</form>
                            </div>
                        </div>
                    </div>
                </div>
				

				
<?php include 'application/views/includes/footer.php';?>
                
<script type="text/javascript">
function get_class_section_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'admin/section_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#section_id').html(html_data);
        }
    }
    });  
}

function get_sub_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'admin/subject_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
			$('#sub_id').html(html_data);
        }
    }
    });  
}

</script>

<!--For only numeric value can be typeable-->		
<script type="text/javascript">
	var specialKeys = new Array();
	specialKeys.push(8); //Backspace
	function IsNumeric(e) {
		var keyCode = e.which ? e.which : e.keyCode
		var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
		return ret;
	}
</script>