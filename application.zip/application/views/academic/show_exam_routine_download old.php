
 <?php                                        
 $subject_name[]='';
 $isubject_name=0;
 foreach($full_routine as $full_routines)
				{
					 $subject_name[$isubject_name]=$full_routines['subject_name'];
					 $isubject_name++;
				}   
				   
				   $table='<div style="width:30%; margin:20px auto; font-size:24px;"><b>Exam Routine</b></div>';
          $table.='<table border="0" cellspacing="0" bordercolorlight="#999999" class="bpmTopic" width="100%" align="center"><thead><tr><th colspan="2"></th>';
	   foreach($routine_class as $routine_classs)
				{
				$table.='<th id="exam_class_id">'.$routine_classs['class_name'].'</th>';
				}
                
        $table.='</tr><tr rowspan="2"><th style="min-width:125px; max-width:150px;">Date</th><th style="min-width:125px; max-width:150px;">Day</th>';
				 foreach($routine_class as $routine_classs)
				{
				 $table.='<th>'.$routine_classs['exam_time'].'</th>';
				}
				$table.='</tr></thead><tbody>';
				$i=0;
				 foreach($routine_day_date as $routine_day_dates)
				{
					$table.='<tr><td>'.$routine_day_dates['exam_date'].'</td><td>'.$routine_day_dates['exam_day'].'</td>';
					
					for($itdsub=0; $itdsub< $column_no; $itdsub++)
					{
						$table.='<td>'.$subject_name[$i].'</td>';
						$i++;
					}
					$table.='</tr>';
					$itdday++;
				}
				$table.='</tbody></table>';
					 
					                     
include("../mpdf60/mpdf.php");

$mpdf=new mPDF('c','A4','','',20,0,5,5,20,17); 
$mpdf->displayDefaultOrientation = true;

//$mpdf->forcePortraitHeaders = true;
$mpdf->forcePortraitMargins = true;
$mpdf->SetDisplayMode('fullpage','two');

// LOAD a stylesheet
$stylesheet = file_get_contents('../mpdf60/examples/mpdfstyletables.css');
$mpdf->WriteHTML($stylesheet,1);	// The parameter 1 tells that this is css/style only and no body/html/text
$mpdf->AddPage('L');
$mpdf->WriteHTML($table);

$mpdf->Output();
exit;

?>