<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
	<div class="content-page">
		
		<div class="content">
			<div class="page-heading">
            	<h1><i class="fa fa-file-text-o"></i>Former Headmasters </h1>
			</div>
            <?php if($this->session->flashdata('message')):?>
				<?=$this->session->flashdata('message')?>
			<?php endif?>
			<div class="row">
                <div class="col-sm-12">
                    <div class="widget" style="min-height:500px;">
                        <div class="widget-content padding">
                            <div class="row">				
                                <div class="col-md-12">
                                    <form role="form" id="ct_entry" name="ct_entry" method="POST" action="<?php echo base_url();?>web/headteacher_edit_save">
													<div class="form-group">
														<label for="name">Name</label>
														<input type="text" class="form-control" name="name" id="name" value="<?= $teachers[0]['name'];?>" required />
														<input type="hidden" name="id" value="<?= $teachers[0]['id'];?>" />
                                                    </div>
                                                    <div class="form-group">
														<label for="qualification">Qualification</label>
														<input type="text" class="form-control" name="qualification" id="qualification" value="<?= $teachers[0]['qualification'];?>" />
                                                    </div>
                                                    <div class="form-group">
														<label for="period">Period(From-to)</label>
														<input type="text" class="form-control" name="period" id="period" value="<?= $teachers[0]['period'];?>" />
                                                    </div>
                                                    <div class="form-group">
														<label for="photo">Photo</label>
														<input type="file" class="form-control" name="photo" id="photo" />
                                                    </div>


													<div class="form-group">
														<button type="submit" class="btn btn-primary">Save</button>
													</div>

												</form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

<?php include 'application/views/includes/footer.php';?>
<script type="text/javascript">

window.onload = function () {
	// Create Wysiwig editor for textare
	TinyMCEStart('#wysiwig_simple', null);
	TinyMCEStart('#wysiwig_full', 'extreme');
};
</script>