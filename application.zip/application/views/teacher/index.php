<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
	<div class="content-page">
		
		<div class="content">
			<div class="page-heading">
            	<h1><i class="fa fa-file-text-o"></i>Former Headmasters </h1>
			</div>
            <?php if($this->session->flashdata('message')):?>
				<?=$this->session->flashdata('message')?>
			<?php endif?>
			<div class="row">
                <div class="col-sm-12">
                    <div class="widget" style="min-height:500px;">
                        <div class="widget-content padding">
                            <div class="row">				
                                <div class="col-md-12">
                                    <div class="widget">
                                        <div class="widget-content padding"><a class="btn btn-info" href="javascript:void(0);" onclick="toggle_insertion_box(); return false;"><i class="fa fa-plus" aria-hidden="true"></i>
Add New Information</a>
                                            <div class="insertion_div">
											<hr/>
                                                <form role="form" id="ct_entry" name="ct_entry" method="POST" action="<?php echo base_url();?>web/headteacher_save">
													<div class="form-group">
														<label for="name">Name</label>
														<input type="text" class="form-control" name="name" id="name" required />
                                                    </div>
                                                    <div class="form-group">
														<label for="qualification">Qualification</label>
														<input type="text" class="form-control" name="qualification" id="qualification" />
                                                    </div>
                                                    <div class="form-group">
														<label for="period">Period(From-to)</label>
														<input type="text" class="form-control" name="period" id="period" />
                                                    </div>
                                                    <div class="form-group">
														<label for="photo">Photo</label>
														<input type="file" class="form-control" name="photo" id="photo" />
                                                    </div>


													<div class="form-group">
														<button type="submit" class="btn btn-primary">Save</button>
													</div>

												</form>
                                            </div>
                                        </div>

                                        <div class="widget-content">
                                            <table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="90%">
                                                <thead>
                                                    <tr>
                                                        <th>Information Heading</th>
														<th>Information Type</th>
														<th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
													<?php foreach($teachers as $teacher){ ?>
													<tr>
														<td><?= $teacher['name'];?></td>
														<td><?= $teacher['qualification'];?></td>
														<td><img class="img-thumbnail" width="150px" src="<?= base_url();?>upload/teacher_image/<?= $teacher['photo'];?>"></td>
														<td>
													<a class="btn btn-success btn-sm" href="<?= base_url();?>web/headteacher_edit/<?= $teacher['id'];?>" title="edit"><i class="fa fa-edit"></i></a>
													<a class="btn btn-danger btn-sm" href="<?= base_url();?>web/headteacher_delete/<?= $teacher['id'];?>" title="Delete" onclick="return confirm('Are You Want to Delete it?' );"><i class="fa fa-remove"></i></a></a>

														</td>
													</tr>
													<?php } ?>
												</tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

<?php include 'application/views/includes/footer.php';?>
<script type="text/javascript">

window.onload = function () {
	// Create Wysiwig editor for textare
	TinyMCEStart('#wysiwig_simple', null);
	TinyMCEStart('#wysiwig_full', 'extreme');
};
</script>