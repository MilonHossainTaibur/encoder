<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>

</script>
    <div class="content-page">
		<!-- ============================================================== -->
		<!-- Start Content here -->
		<!-- ============================================================== -->
		<div class="content">
			<div class="page-heading">
            	<h1><i class="fa fa-bell"></i> Notice Publish</h1>
			</div>
            <?php if($this->session->flashdata('message')):?>
				<?=$this->session->flashdata('message')?>
			<?php endif?>
			<div class="row">
                <div class="col-sm-12">
                    <div class="widget" style="min-height:500px;">
                        <div class="widget-content padding">
                            <div class="row">				
                                <div class="col-md-12">
                                    <div class="widget">
                                    <!--button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal">
   <i class="fa fa-plus-square" aria-hidden="true"> Add New Notice</i>
   </button-->
                                        <div class="widget-content padding"><a class="btn btn-info" href="javascript:void(0);" onclick="toggle_insertion_box(); return false;"> <i class="fa fa-plus" aria-hidden="true"></i>
Add New Notice</a>
                                            <div class="insertion_div"><hr/>
                                                <form action="<?= base_url();?>notice/notice_save" method="POST" enctype="multipart/form-data" id="message-form">
							<div class="form-group">
								<label>Notice Type</label>
								<select name="notice_type" id="notice_type" class="form-control" required>
									<option value="">Select Notice Type</option>
									<option value="1">General Notice</option>
									<option value="2">Admission Notice</option>
									<option value="3">Circular</option>
									<option value="4">Student</option>
								</select>
							</div>
							<div class="form-group">
								<label>Notice Heading</label>
								<input type="text" class="form-control" name="notice_heading" id="notice_heading" required>
							</div>
							<div class="form-group">
								<label>Details</label>
								<textarea class="form-control" rows="10" id="wysiwig_simple" name="notice_details" style="min-height:300px;"></textarea>
							</div>
							<div class="form-group">
								<div class="row">
									<div class="col-xs-12 col-sm-6">
										<label>Publish Date</label>
										<input type="text" id="input_date" class="form-control" name="publish_date" required>
									</div>
									<div class="col-xs-12 col-sm-6">
										<label for="notice_attachment">Attachment</label>
										<input type="file" id="notice_attachment" name="notice_attachment">
										<p class="help-block">Please provide doc|pdf|zip|jpg|jpeg|png|gif file onley.</p>
									</div>
								</div>
							</div>
							<div class="form-group">
								<button type="submit" class="btn btn-primary btn-label-left">Publish</button>
							</div>
						</form>
                                            </div>
                                        </div>

                                        <div class="widget-content">
                                            <table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="90%">
                                                <thead>
                                                    <tr>
                                                        <th>Notice Heading</th>
								<th>Notice Type</th>
								<th>Publish Date</th>
								<th>File</th>
								<th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
							<?php foreach($notice_list as $nl){ ?>
							<tr>
								<td><?= $nl['notice_heading'];?></td>
								<td><?php 
									if($nl['notice_type']==1)
										echo "General";
									else
										echo "Admission";
									?>
								</td>
								<td><?= $nl['publish_date'];?></td>
								<td><?= $nl['notice_attachment'];?></td>
								<td>
									<a href="<?= base_url();?>notice/single_notice/<?= $nl['notice_id']; ?>" title="View"><i class="fa fa-retweet"></i></a> |
									<a href="<?= base_url();?>notice/single_notice_edit/<?= $nl['notice_id']; ?>" title="Edit"><i class="fa fa-edit"></i></a> |
									<?=anchor("notice/notice_delete/".$nl['notice_id'],"<i class=\"fa fa-remove\"></i>",array('onclick' => "return confirm('Do you want delete this record')"))?>
								</td>
							</tr>
							<?php } ?>
							</tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            
            
            
            
            
            
            
            
    		<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog" role="document">
      <!--Content-->
      <div class="modal-content">
         <!--Header-->
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
            <h4 class="modal-title w-100" id="myModalLabel">Donor</h4>
         </div>
         <!--Body-->
         <div class="modal-body">
            <form action="<?= base_url();?>notice/notice_save" method="POST" enctype="multipart/form-data" id="message-form">
               <div class="form-group">
                  <div class="row">
                     <div class="col-sm-6 col-md-6">
                        <label>Notice Type</label>
								<select name="notice_type" id="notice_type" class="form-control" required>
									<option value="">Select Notice Type</option>
									<option value="1">General Notice</option>
									<option value="2">Admission Notice</option>
									<option value="3">Circular</option>
								</select>
                        <input type="hidden" name="id" id="id" value="0" />
                     </div>
                     <div class="col-sm-6 col-md-6">
                        <label>Notice Heading</label>
			<input type="text" class="form-control" name="notice_heading" id="notice_heading" required>
                     </div>
                     <div class="col-sm-12 col-md-12">
                        <label>Details</label>
		<textarea class="form-control tinymce-modal" rows="10" id="wysiwig_simple" name="notice_details" style="min-height:300px;"></textarea>
                     </div>
                     <div class="col-sm-6 col-md-6">
                       <label>Publish Date</label>
		<input type="text" id="input_date" class="form-control" name="publish_date" required>
                     </div>
                     <div class="col-xs-12 col-sm-6">
			<label for="notice_attachment">Attachment</label>
			<input type="file" id="notice_attachment" name="notice_attachment">
			<p class="help-block">Please provide doc|pdf|zip|jpg|jpeg|png|gif file onley.</p>
			</div>
                  </div>
               </div>
         </div>
         <!--Footer-->
         <div class="modal-footer">
         <button type="reset" class="btn btn-primary reset" id="reset">Clear</button>
         <button type="button" id="alert" class="btn btn-danger pull-left" data-dismiss="modal">Close</button>
         <input type="submit" name="submit" value="Publish" class="btn btn-success" id="sub"   />
         <input type="submit" value="Update" class="btn btn-success" id="update">				
         </div>
         </form>
      </div>
      <!--/.Content-->
   </div>
</div>
<!-- /.Live preview-->
<!--modal end-->        

<?php include 'application/views/includes/footer.php';?>     

<script type="text/javascript">

window.onload = function () {
	// Create Wysiwig editor for textare
	TinyMCEStart('#wysiwig_simple', null);
	TinyMCEStart('#wysiwig_full', 'extreme');
	// Add slider for change test input length
	FormLayoutExampleInputLength($( ".slider-style" ));
	// Initialize datepicker
	$('#input_date').datepicker( {minDate: '0', dateFormat: 'yy-dd-mm' } );
	// Load Timepicker plugin
	LoadTimePickerScript(DemoTimePicker);
	// Add tooltip to form-controls
	$('.form-control').tooltip();
	LoadSelect2Script(DemoSelect2);
	// Load example of form validation
	LoadBootstrapValidatorScript(DemoFormValidator);
	// Add drag-n-drop feature to boxes
	WinMove();
};
</script>