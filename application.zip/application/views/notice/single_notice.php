<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
    <div class="content-page">
		<!-- ============================================================== -->
		<!-- Start Content here -->
		<!-- ============================================================== -->
		<div class="content">
			<div class="page-heading">
            	<h1><i class="fa fa-bell"></i> <?= $notice_list[0]['notice_heading'] ?></h1>
			</div>
			<div class="row">
                <div class="col-sm-12">
                    <div class="widget" style="min-height:500px;">
                        <div class="widget-content padding" id="print_notice">
							<?php if($notice_list[0]['notice_attachment']): ?>
								<a href="<?= base_url();?>upload/notice_file/<?= $notice_list[0]['notice_attachment'] ?>" class="pull-left print_button"><i class="fa fa-download"></i> <b>Get the attachment file</b></a>
							<?php endif; ?>
							<span class="pull-right"><button type="button" class="btn btn-primary print_button" onclick="printPageArea('print_notice')"><i class="fa fa-print"></i> Print Notice</button></span>
							<table align="center" width="100%" border="0" style="text-align:center;">
								<tr>
									<td width="10%"></td>
									<td> <h2><b> <?= $notice_list[0]['notice_heading'] ?></b></h2> </td>
									<td width="10%"></td>
								</tr>
                                <tr>
									<td></td>
									<td><b>Publish Date: <?= $notice_list[0]['publish_date'] ?></b></span>
										&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
										<b>Notice Type: 
										<?php if($nl['notice_type']==1)
												echo "General";
											elseif($nl['notice_type']==2)
												echo "Admission";
											else
												echo "Circular";
										?></b>
									</td>
									<td></td>
									
								</tr>
								<tr>
									<td colspan="3">&nbsp;</td>
								</tr>
								<tr>
									<td colspan="3"><?= $notice_list[0]['notice_details'] ?></td>
								</tr>
                            </table>
							
                        </div>
                    </div>
                </div>
            </div>

<?php include 'application/views/includes/footer.php';?>       

<script type="text/javascript">
function printPageArea(areaID){
		var printContent = document.getElementById(areaID);
		var WinPrint = window.open('', '', 'width=900,height=650');
		WinPrint.document.write('<link rel="stylesheet" type="text/css" href="<?= base_url();?>template/bootstrap-print/bootstrap-print.min.css" media="print" />')
		WinPrint.document.write('<style type="text/css" media="print"> @page { font-size:12px; } table{font-size:12px;} table td{padding:3px;} .print_button{ display:none;} </style>')
		WinPrint.document.write(printContent.innerHTML);
		WinPrint.document.close();
		WinPrint.focus();
		WinPrint.print();
		WinPrint.close();
	}
</script>