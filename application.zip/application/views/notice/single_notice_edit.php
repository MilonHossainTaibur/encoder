<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>

    <div class="content-page">
		<div class="content">
			<div class="page-heading">
            	<h1><i class="fa fa-bell"></i> Notice Edit</h1>
			</div>
			<div class="row">
                <div class="col-sm-12">
                    <div class="widget" style="min-height:500px;">
                        <div class="widget-content padding">
                            <div class="row">				
                                <div class="col-md-12">
                                    <div class="widget">
                                        <form action="<?= base_url();?>notice/single_notice_edit_save" method="POST" enctype="multipart/form-data" id="message-form">
											<div class="form-group">
												<label>Notice Type</label>
												<select name="notice_type" id="notice_type" class="form-control" required>
                                                    <option value="">Select Notice Type</option>
                                                    <option value="1" <?php if($notice_list[0]['notice_type']==1){echo "selected";}?>>General Notice</option>
                                                    <option value="2" <?php if($notice_list[0]['notice_type']==2){ echo "selected"; } ?>>Admission Notice</option>
                                                    <option value="3" <?php if($notice_list[0]['notice_type']==3){ echo "selected"; } ?>>Circular</option>
                                                    <option value="4" <?php if($notice_list[0]['notice_type']==4){ echo "selected"; } ?>>Student</option>
                                                </select>
											</div>
											<div class="form-group">
												<label>Notice Heading</label>
												<input type="text" class="form-control" name="notice_heading" required value="<?= $notice_list[0]['notice_heading'];?>">
                                                <input type="hidden" name="notice_id" required value="<?= $notice_list[0]['notice_id'];?>">
											</div>
											<div class="form-group">
												<label>Details</label>
												<textarea id="wysiwig_simple" name="notice_details" style="min-height:300px;"> <?= $notice_list[0]['notice_details'];?> </textarea>
											</div>
											<div class="form-group">
												<div class="row">
													<div class="col-xs-12 col-sm-6">
														<label>Publish Date</label>
														<input type="text" id="input_date" class="form-control" name="publish_date" required value="<?= $notice_list[0]['publish_date'];?>" required>
													</div>
													<div class="col-xs-12 col-sm-6">
														<label for="notice_attachment">Attachment</label>
														<?php if($notice_list[0]['notice_attachment']!=''): ?>
                                                        <a href="<?= base_url();?>upload/notice_file/<?= $notice_list[0]['notice_attachment'];?>" target="_blank"><i class="fa fa-paperclip" style="font-size:50px;"></i></a>
                                                        <?php endif; ?>
														<input type="file" id="notice_attachment" name="notice_attachment">
														<input type="hidden" name="old_notice_attachment" value="<?= $notice_list[0]['notice_attachment'];?>">
														<p class="help-block">Please provide doc|pdf|zip|jpg|jpeg|png|gif file onley.</p>
													</div>
												</div>
											</div>

											<div class="form-group">
												<button type="submit" class="btn btn-primary btn-label-left">Publish</button>
											</div>
										</form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

<?php include 'application/views/includes/footer.php';?>     

<script type="text/javascript">

window.onload = function () {
	// Create Wysiwig editor for textare
	TinyMCEStart('#wysiwig_simple', null);
	TinyMCEStart('#wysiwig_full', 'extreme');
	// Add slider for change test input length
	FormLayoutExampleInputLength($( ".slider-style" ));
	// Initialize datepicker
	$('#input_date').datepicker({setDate: new Date()});
	// Load Timepicker plugin
	LoadTimePickerScript(DemoTimePicker);
	// Add tooltip to form-controls
	$('.form-control').tooltip();
	LoadSelect2Script(DemoSelect2);
	// Load example of form validation
	LoadBootstrapValidatorScript(DemoFormValidator);
	// Add drag-n-drop feature to boxes
	WinMove();
};
</script>
