<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
<div class="content-page">
	<div class="content">
		<!-- Page Heading Start -->
        <div class="page-heading">
            <h1><i class='fa fa-check'></i> Subject Edit</h1>
        </div>
        <!-- Page Heading End-->
        <!-- Your awesome content goes here -->
        <div class="row">
			<div class="col-sm-12">
				<div class="widget" style="min-height:300px;">
					<div class="widget-content padding">
						<form role="form" id="registerForm" method="POST" action="<?php echo base_url();?>admin/subject_edit_save">
                        <br/><br/><br/>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-sm-2"></div>
                                    <div class="col-sm-4">
                                        <label>Subject Name </label>
                                        <input type="text" class="form-control" name="subject_name" value="<?= $subject_list['subject_name']; ?>">
                                        <input type="hidden" class="form-control" name="subject_id" value="<?= $subject_list['subject_id']; ?>">
                                    </div>
                                </div>
                            </div>
							<div class="form-group">
                                <div class="row">
                                    <div class="col-sm-2"></div>
                                    <div class="col-sm-4">
                                        <label>Subject name (বাংলায়)</label>
                                        <input type="text" class="form-control" name="subject_bn" value="<?= $subject_list['subject_bn']; ?>">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-sm-2"></div>
                                    <div class="col-sm-4">
                                        <label>Subject Code </label>
                                        <input type="text" class="form-control" name="subject_code" value="<?= $subject_list['subject_code']; ?>">
									</div>
                                </div>
							</div>
							<div class="form-group">
								<div class="row">
									<div class="col-sm-2"></div>
									<div class="col-sm-4">
										<label>Is Optional</label>
										<select name="is_optional" id="is_optional" class="form-control">
                                            <option value="0" <?php if($subject_list['is_optional']==0){echo "selected";}?>>No</option>
                                            <option value="1" <?php if($subject_list['is_optional']==1){echo "selected";}?>>Yes</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
							<div class="form-group">
                                <div class="row">
                                    <div class="col-sm-2"></div>
                                    <div class="col-sm-4">
                                        <label>Is Optional</label>
                                        <select name="marks_type" id="marks_type" class="form-control">
                                            <option value="1" <?php if($subject_list['marks_type']==1){echo "selected";}?>>Subjective</option>
                                            <option value="2" <?php if($subject_list['marks_type']==2){echo "selected";}?>>Subjective, Objective</option>
                                            <option value="3" <?php if($subject_list['marks_type']==3){echo "selected";}?>>Subjective, Objective, Practical</option>
											<option value="4" <?php if($subject_list['marks_type']==4){echo "selected";}?>>Subjective, Practical</option>
											<option value="5" <?php if($subject_list['marks_type']==5){echo "selected";}?>>Objective, Practical</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-sm-2"></div>
                                    <div class="col-sm-4">
                                        <button type="submit" class="btn btn-primary">Update</button>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
<?php include 'application/views/includes/footer.php';?>