<?php
	if($details['class_id'] == 1){$c_name1='Seven';$c_value1='2';$c_name2='Six';$c_value2='1';}
	else if($details['class_id'] == 2){$c_name1='Eight';$c_value1='3';$c_name2='Seven';$c_value2='2';}
	else if($details['class_id'] == 3){$c_name1='Nine';$c_value1='4';$c_name2='Eight';$c_value2='3';}
	else if($details['class_id'] == 4){$c_name1='Ten';$c_value1='5';$c_name2='Nine';$c_value2='4';}
?>
<div class="table-responsive" id="print_area">

	<div class="container" style="text-align: center;width: 100%;">
		<div class="tabu-header">
			<h4 style="font-weight: 700;font-size: 25px;"><?= $school_info[0]['school_name'] ?></h4><br>
			<h5 style="font-size: 18px;"><?= $details['class_name']; ?> - <?= $details['exam_year']; ?></h5>
			<h5 style="margin-bottom: 10px!important;font-size: 18px;">Total Student: <?php echo count($student_list);?></h5>
		</div>
	</div>

	<style>
		table {
			border-collapse: collapse;
		}

		table, td{
			border: 1px solid black;
		}

		th {
			text-transform: uppercase;
		}
		.no-border{
			border:0!important;
		}
		.center{
			text-align:center;}
		.tb tr td {
			height: 50px;
		}
		.tabu-header h2,.tabu-header h3,.tabu-header h4,.tabu-header h5{
			padding: 0px!important;
			margin-top: 0px!important;
			margin-bottom: 0px!important;
		}
		span.fail{
			width:100%;
			border-bottom:5px solid #CD0000;
			color:#000;
		}
	</style>
	<style type="text/css">
		@page
		{
			size: portrait;
		}
		@media print{
			@page {
				size: portrait;
			}
		}
		@media print{
			.class-name{
			@page{
				size:portrait;
			}
		}
		}
		table thead tr>th{
			text-align: center;
			/*font-size: 15px;*/
			font-weight: 600;
		}
		table  tr>td{
			font-weight: 400;
			/*font-size: 15px;*/
		}
	</style>
	<style type="text/css" media="print">
		@page { size: portrait; }
		table tr>td{
			border-color: #95a5a6;
		}
		table thead tr{
			text-align: center;
			font-size: 14px!important;
			font-weight: 500;
			border:1px solid #95a5a6;
			border-color: #95a5a6;
		}
		table thead tr>th{

			border:1px solid #95a5a6;

		}
		table  tr>td{
			font-weight: 400;
			font-size: 15px;
		}
		.hid{
			display: none;
			visibility: hidden;
		}
	</style>
	<form role="form" id="promoteForm" method="POST" action="<?= base_url();?>admin/admission_student_mark_save">
		<table>
			<thead>
			<tr>
				<th style="max-width: 00px;">SL</th>
				<th>Exam Roll</th>
				<th style="min-width: 140px">Applicant's Name</th>
				<th>Father's Name</th>
				<th>Mark</th>
			</tr>
			</thead>
			<tbody class="center tb" >
			<?php
			usort($student_list, function($a,$b){	$c = $a['exam_roll'] <=> $b['exam_roll']; return $c;});
			//print_r($output);exit;
			foreach($student_list as $i=>$outval){
				?>
				<tr>
					<td><?php print_r($i+1);?></td>
					<td><?php print_r($outval['exam_roll']);?></td>
					<td><?php print_r(ucwords($outval['applicant_name']));?></td>
					<td><?php print_r(ucwords($outval['applicant_father']));?></td>
					<td>
                        <input type="text" name="mark[]" style="text-align: right" size="2" maxlength="4" value="<?php print_r($outval['mark']);?>" />
                        <input type="hidden" name="students_id[]" value="<?php print_r($outval['id']);?>">
                        <input type="hidden" name="student_class_id[]" value="<?php print_r($outval['class_id']);?>">
                        <input type="hidden" name="row_id[]" value="<?php print_r($outval['id']);?>">
                    </td>
				</tr>
			<?php }?>
			<tr class="hid">
				<td>
					<input type="submit" class="btn btn-primary hid" value="Save"/>
				</td>
			</tr>
			</tbody>
		</table>
	</form>
	<div class="print_button">
	<br/>
	<input type="button" class="btn btn-danger btn-lg hid" onClick="PrintElem('print_area')" value="Print"/>
</div>
	<script type="text/javascript">
        $('#all_std_check').change(function(){
            $('.std_check').prop('checked', $(this).prop('checked'));
        });

        $('.std_check').change(function(){
            if(false == $(this).prop("checked")){
                $("#all_std_check").prop('checked', false);
            }
            if ($('.std_check:checked').length == $('.std_check').length ){
                $("#all_std_check").prop('checked', true);
            }
        });
		// radio button code start
		$('.classno').change(function(){
            var value = $(this).val();
			$('.stdclassno-'+value).prop('checked', $(this).prop('checked'));
		});
    </script>
</div>
