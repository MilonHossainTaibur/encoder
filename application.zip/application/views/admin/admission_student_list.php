<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
<style>
.stu_image{
    -webkit-transition: all .3s ease; /* Safari and Chrome */
  	-moz-transition: all .3s ease; /* Firefox */
  	-o-transition: all .3s ease; /* IE 9 */
  	-ms-transition: all .3s ease; /* Opera */
  	transition: all .3s ease;
}
.stu_image:hover{
 -webkit-backface-visibility: hidden;
    backface-visibility: hidden;
    -webkit-transform:translateZ(0) scale(2.20); /* Safari and Chrome */
    -moz-transform:scale(2.20); /* Firefox */
    -ms-transform:scale(2.20); /* IE 9 */
    -o-transform:translatZ(0) scale(2.20); /* Opera */
    transform:translatZ(0) scale(2.20);
}
</style>
<div class="content-page">
	<!-- Start Content here -->
	<div class="content">
	<?php if($this->session->flashdata('message')):?>
		<?=$this->session->flashdata('message')?>
	<?php endif?>
		<div class="page-heading">
			<h1><i class='fa fa-table'></i> Student List</h1>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="widget">							
					<div class="widget-content">
						<form method="POST" action="<?= base_url() ?>admin/admission_student_list">
							<div class="widget-content padding">
								<div class="form-group">
									<div class="row">
										<div class="col-sm-6 col-md-3">
											<label>Class</label>
											<select class="form-control" name="class_id" id="class_id">
												<option value="all">----Select Class----</option>
												<?php foreach($class_list as $cl){ ?>
												<option value="<?= $cl['class_id'];?>" <?php if($this->session->userdata('class_id')==$cl['class_id']) echo "selected"; ?> ><?= $cl['class_name'];?></option>
												<?php } ?>
											</select>
										</div>
										<div class="col-sm-6 col-md-3">
											<label>Year</label>
											<select class="form-control" name="year_id" id="year_id">
												<option value="all">----Select Year----</option>
												<?php foreach($stusession_id as $cl){ ?>
												<option value="<?= $cl['session_name'];?>" <?php if($this->session->userdata('year_id')==$cl['session_name']) echo "selected"; ?> ><?= $cl['session_name'];?></option>
												<?php } ?>
											</select>
										</div>
									</div>
								</div>
								<div class="form-group">
									<div class="row">
										<div class="col-sm-4">
											<button type="submit" class="btn btn-primary">Show</button>
											<a href="#" data-toggle="modal" data-target="#create-item" data-whatever="">Add New</a>
										</div>
									</div>
								</div>
							</div>
						</form>
		
						<!-- modal content start here -->							
						<div class="modal fade bs-example-modal-smadd" id="create-item" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" >
							<div class="modal-dialog modal-md" role="document">
								<div class="modal-content">
									<div class="widget-box">
										<div class="modal-header">
											<h4 class="widget-title">Add New</h4>
											<span class="widget-toolbar">
												<button type="button" class="close" data-dismiss="modal">&times;</button>
											</span>
										</div>

										<div class="modal-body">
											<div class="widget-main no-padding">
												<form name="store-form" id="store-form"  method="post" action="<?= base_url() ?>admin/admission_student_save">
													<fieldset>
														<div class="form-group">
															<label for="applicant_name">Applicant's Name</label>
															<input type="text" name="applicant_name" class="form-control"  id="store-applicant_name" >
														</div>
														<div class="form-group">
															<label for="applicant_father">Applicant's Father Name</label>
															<input type="text" name="applicant_father" class="form-control"  id="store-applicant_father">
														</div>
														<div class="form-group">
															<label for="serial_no">Serial No</label>
															<input type="text" name="serial_no" class="form-control"  id="store-serial_no" required>
														</div>
														<div class="form-group">
															<label for="exam_roll">Exam Roll</label>
															<input type="text" name="exam_roll" class="form-control"  id="store-exam_roll">
														</div>
														<div class="form-group">
															<label for="exam_date">Exam Date</label>
															<input type="text" name="exam_date" class="form-control"  id="store-exam_date" placeholder="dd-mm-yyyy" required>
														</div>
														<div class="form-group">
															<label for="exam_duration">Exam Duration</label>
															<input type="text" name="exam_duration" class="form-control"  id="store-exam_duration">
														</div>
														<div class="form-group">
															<label for="class_id">Class</label>
															<input type="hidden" value="0">
															<select name="class_id" class="form-control" required  id="store-class_id">
																<?php foreach($class_list as $cl){ ?>
																<option value="<?= $cl['class_id'];?>" <?php if($this->session->userdata('class_id')==$cl['class_id']) echo "selected"; ?> ><?= $cl['class_name'];?></option>
																<?php } ?>
															</select>
														</div>
													</fieldset>

													<div class="form-actions center">
														<div class="modal-footer">
															<button type="submit" class="btn btn-success" id="store-submit">Save</button>
															<button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
														</div>
													</div>
												</form>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- modal content end here -->
		
						<!-- edit modal content start here -->							
						<div class="modal fade bs-example-modal-smadd" id="edit-item" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" >
							<div class="modal-dialog modal-md" role="document">
								<div class="modal-content">
									<div class="widget-box">
										<div class="modal-header">
											<h4 class="widget-title">Add New</h4>
											<span class="widget-toolbar">
												<button type="button" class="close" data-dismiss="modal">&times;</button>
											</span>
										</div>

										<div class="modal-body">
											<div class="widget-main no-padding">
												<form name="update-form" id="store-form"  method="post" action="<?= base_url() ?>admin/admission_student_edit">
													<fieldset>
														<div class="form-group">
															<label for="applicant_name">Applicant's Name</label>
															<input type="text" name="applicant_name" class="form-control"  id="update-applicant_name" >
														</div>
														<div class="form-group">
															<label for="applicant_father">Applicant's Father Name</label>
															<input type="text" name="applicant_father" class="form-control"  id="update-applicant_father">
														</div>
														<div class="form-group">
															<label for="serial_no">Serial No</label>
															<input type="text" name="serial_no" class="form-control"  id="update-serial_no" required>
														</div>
														<div class="form-group">
															<label for="exam_roll">Exam Roll</label>
															<input type="text" name="exam_roll" class="form-control"  id="update-exam_roll">
														</div>
														<div class="form-group">
															<label for="exam_date">Exam Date</label>
															<input type="text" name="exam_date" class="form-control"  id="update-exam_date" placeholder="dd-mm-yyyy">
														</div>
														<div class="form-group">
															<label for="exam_duration">Exam Duration</label>
															<input type="text" name="exam_duration" class="form-control"  id="update-exam_duration">
														</div>
														<div class="form-group">
															<label for="class_id">Class</label>
															<input type="hidden" value="0">
															<select name="class_id" class="form-control" required  id="update-class_id">
																<?php foreach($class_list as $cl){ ?>
																<option value="<?= $cl['class_id'];?>" <?php if($this->session->userdata('class_id')==$cl['class_id']) echo "selected"; ?> ><?= $cl['class_name'];?></option>
																<?php } ?>
															</select>
														</div>
													</fieldset>

													<div class="form-actions center">
														<div class="modal-footer">
															<input type="hidden" name="update_id" class="form-control"  id="update-id">
															<button type="submit" class="btn btn-success" id="update-submit">Save</button>
															<button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
														</div>
													</div>
												</form>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- modal content end here -->
						
						<div class="table-responsive">						
							<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
								<thead>
									<tr>
										<th style="display:none;"></th>
										<th>Applicant Name</th>
										<th>Father Name</th>
										<th>Exam Date</th>
										<th>Class</th>
										<th>Exam Roll</th>
										<th>Serial</th>
										<th>Action</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th style="display:none;"></th>
										<th>Applicant Name</th>
										<th>Father Name</th>
										<th>Exam Date</th>
										<th>Class</th>
										<th>Exam Roll</th>
										<th>Serial</th>
										<th>Action</th>
									</tr>
								</tfoot>
								<tbody>
									<?php foreach($student_list as $sl){ ?>
									<tr>
										<td style="display:none;"></td>
										<td><?= $sl['applicant_name'];?></td>
										<td><?= $sl['applicant_father'];?></td>
										<td><?= date('d-m-Y',strtotime($sl['exam_date']));?></td>
										<td><?php echo $sl['class_name']; ?></td>
										<td><?php echo $sl['exam_roll'];?></td>
										<td><?php echo $sl['serial_no'];?></td>
										<td>
											<a href="#" data-toggle="modal" data-target="#edit-item" data-whatever="<?php echo $sl['id'];?>" title="Edit"><i class="fa fa-edit"></i></a> |
											<a href="<?= base_url();?>admin/admission_student_delete/<?= $sl['id'];?>" title="Delete" onclick="return confirm('Do you want delete this record' );"><i class="fa fa-remove"></i></a> 
										</td>
									</tr>
									<?php 	} ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<script>
		$('#edit-item').on('show.bs.modal', function (event) {//alert('found');
			var button = $(event.relatedTarget); // Button that triggered the modal
			var recipient = button.data('whatever'); // Extract info from data-* attributes
			// If necessary, you could initiate an AJAX request here (and then do the updating in a callback).
			// Update the modal's content. We'll use jQuery here, but you could use a data binding library or other methods instead.
			// ajax code start
			$.ajax({
				type: "POST",
				url: baseUrl + 'admin/admission_student_view',
				dataType: 'JSON',
				data:
				{
					'id':recipient
				}, 
				success: function(html_data)
				{						
					var modal = $(this);
					var len = html_data.length;
					for(var i=0; i<len; i++){//console.log(html_data[i]['student_list'][i]['id']);
						var bandwith_qty,unit_price,sub_total,grand_total;
						var id				= html_data[i]['student_list'][i]['id'];
						var applicant_name	= html_data[i]['student_list'][i]['applicant_name'];
						var applicant_father= html_data[i]['student_list'][i]['applicant_father'];
						var serial_no		= html_data[i]['student_list'][i]['serial_no'];
						var exam_roll		= html_data[i]['student_list'][i]['exam_roll'];
						var exam_date		= html_data[i]['student_list'][i]['exam_date'];
						var exam_duration	= html_data[i]['student_list'][i]['exam_duration'];
						var class_id		= html_data[i]['student_list'][i]['class_id'];
						//var connect_dts 		= new Date(connect_dt);
						
						$('.modal-body #update-applicant_name').val(applicant_name);					
						$('.modal-body #update-applicant_father').val(applicant_father);					
						$('.modal-body #update-serial_no').val(serial_no);					
						$('.modal-body #update-exam_roll').val(exam_roll);					
						$('.modal-body #update-exam_date').val(convertDate(exam_date));				
						$('.modal-body #update-exam_duration').val(exam_duration);					
						$('.modal-body #update-class_id').val(class_id);					
						$('.modal-body #update-id').val(id);					
					}
				}
			});
		})
		
		function convertDate(dateString){
			var p = dateString.split(/\D/g)
			return [p[2],p[1],p[0] ].join("-")
		}
		</script>

<?php include 'application/views/includes/footer.php';?>