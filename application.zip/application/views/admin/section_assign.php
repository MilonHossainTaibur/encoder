<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">			
            <div class="content">
            
            <?php if($this->session->flashdata('message')):?>
			<div class="alert alert-success">
				<a href="#" class="close" data-dismiss="alert">&times;</a>
				<?=$this->session->flashdata('message')?>
			</div>
			<?php endif?>
            
            
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i> Section Assign</h1>
                </div>
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="widget" style="min-height:500px;">
                            <div class="widget-content padding">
            	<!-- Page Heading End-->				<!-- Your awesome content goes here -->
				<div class="row">				
                                    <div class="col-md-12">
                                        <div class="widget">
                                            <div class="widget-content">
                                                <form role="form" id="registerForm" method="POST" action="<?php echo base_url();?>admin/save_class_section" enctype="multipart/form-data">
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-sm-4">
                                                              <label>Class</label>
                                                            <select class="form-control" name="class_id" id="class_id" onchange="check_section_list(this.value);">
                                                                <option value="">Select</option>
                                                                <?php
                                                                    foreach($class_list as $tl){ ?> 
                                                                <option value="<?php echo $tl['class_id'];?>"><?php echo $tl['class_name'];?></option>
                                                              <?php } ?>
                                                              </select>
                                                        </div>
                                                        
<!--                                                        <div class="col-sm-4">
                                                            <label></label>
                                                             
                                                            <button type="button" class="btn btn-primary" style="margin-top:25px;" onclick="">Show</button>
                                                        </div>-->
                                                    </div>
                                                </div> 
                                                
                                                <div id="display">
                                                    
                                                    <!-- Content will be display here--->
                                                    
                                                </div>
                                            </form>
                                            </div>
                                        </div>
                                    </div>
				</div>
                            </div>
                        </div>
                    </div>
                </div>
			
				
<?php include 'application/views/includes/footer.php';?>

                
<script>
function check_section_list(class_id)
{
     $.ajax({ 
      url: baseUrl+'admin/get_section_list_json',
      data:
      {
            'class_id':class_id
      },
      dataType: 'json',
      success: function(data)
      {
          result = ''+data['result']+'';
          mainContent = ''+data['mainContent']+'';

          if(result == 'success')
          {
             $('#display').html(mainContent);     
          }
          else if(result == 'fail')
          {
             
          }  
      }
  });
  return false; // keeps the page from not refreshing 
}
function save_class_section_form(frm)
{
    //alert('Save task will be done very soon');
    //return false;
    frm.submit();
}
</script>