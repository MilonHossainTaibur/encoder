<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">			
            <div class="content">
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i> Student Information Edit</h1>
                </div>
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12 col-md-8 col-md-offset-2">
                        <div class="widget" style="min-height:500px;">
                            <div class="widget-content padding">
                                <div class="student_form">
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-12">
                                                <center>
                                                    <h3>APPLICATION FORM EDIT</h3>
                                                </center>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <form role="form" id="registerForm" name="registerForm" method="POST" action="<?= base_url();?>admin/student_information_edit_save" enctype="multipart/form-data">
                                    <legend><i class="icon32 icon-square-plus"></i> A. Personal Details</legend>
                                    <h4> 1. Applicant Particulars</h4> 
                                    
                                    <div class="form-group">
                                        <label>Official Name (as in Birth Registration or in the Passport) </label>
                                        <input type="text" class="form-control" name="student_name" id="student_name" value="<?= $student_info['student_name'];?>" required>
                                        <input type="hidden" class="form-control" name="student_id" id="student_id" value="<?= $student_info['student_id'];?>">
                                    </div>
                                    
									<div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label>Date of Birth</label>
                                                <input type="text" class="form-control datepicker-input" placeholder="yyyy-mm-dd" name="birth_date" id="birth_date" value="<?= $student_info['birth_date'];?>" onblur="myAgeValidation()"/> 
                                            </div>
                                            <div class="col-sm-4">
                                                <label>Age</label>
							<input type="text" class="form-control" name="age" id="age" value="<?= $student_info['age'];?>" onClick="myAgeValidation()" onFocus="myAgeValidation()" readonly="" />
                                                <input type="hidden" name="cur_date" value="<?= $student_info['cur_date'];?>" />
                                            </div>
											<div class="col-sm-4">
                                                <label>Birth Cert No: </label>
                                                <input type="text" class="form-control" name="birth_cert_no" value="<?= $student_info['birth_cert_no'];?>"> 
                                            </div>
                                        </div>
                                    </div>
									
									<div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label>Nationality</label>
                                                <input type="text" class="form-control" name="nationality" id="nationality" value="<?= $student_info['nationality'];?>">
                                            </div>
                                            <div class="col-sm-4">
                                                <label>Religion</label>
                                                <select class="form-control" name="religion" id="religion" required="">
                                                    <option value="">Select</option>
                                                    <option value="111" <?php if($student_info['religion']== '111') echo "selected"; ?>> Islam </option>
                                                    <option value="112" <?php if($student_info['religion']== '112') echo "selected"; ?>>Hinduism</option>
                                                    <option value="113" <?php if($student_info['religion']== '113') echo "selected"; ?>>Christianity</option>
                                                    <option value="114" <?php if($student_info['religion']== '114') echo "selected"; ?>>Buddhism</option>
                                                </select>
                                            </div>
											<div class="col-sm-4">
                                                <label>Gender</label>
                                                <select class="form-control" name="gender" id="gender">
                                                    <option value="">Select</option>
                                                    <option value="Male" <?php if($student_info['gender']=='Male'){echo "selected";}?>>Male</option>
                                                    <option value="Female" <?php if($student_info['gender']=='Female'){ echo "selected"; } ?> >Female</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>									
									
					<div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-12">
						<label>Student Image</label>
						<output id="list"><img src="<?php echo base_url();?>upload/student_image/<?php echo $student_info['student_image'];?>" alt="" height="200" width="200"/></output>
								<input type="file" class="btn btn-default" title="Browse New Picture" name="student_image" id="student_image">
						</div>
                                        </div>
                                    </div>
									<hr/>
									<h4> Present Address</h4>
									<div class="form-group">
										<div class="row">
                                            <div class="col-sm-12">
                                                <label>Village/Town/Road/House/Flat</label>
                                                <input type="text" class="form-control" name="present_address" id="present_address" value="<?php echo $student_info['present_address'];?>" />
                                            </div>
                                            <div class="col-sm-3">
                                                <label>Division</label>
                                           <select class="form-control" name="present_division" onchange="get_district(this.value,'present_district')">
								<option value="">----Select Division----</option>
								<?php if($division_list):
										foreach($division_list as $div_list):?>
											<option value="<?= $div_list['id']?>" <?php if($student_info['present_division']==$div_list['id']) echo 'selected'; ?>><?= $div_list['name']?></option>
										<?php endforeach; endif; ?>
												</select>
                                            </div>
											<div class="col-sm-3">
                                                <label>District</label>
											<select class="form-control" name="present_district" onchange="get_upazila(this.value,'present_upazila')">
												<option value="">----Select District----</option>
												<?php if($district_list):
														foreach($district_list as $dis_list):?>
													<option value="<?= $dis_list['id']?>" <?php if($student_info['present_district']==$dis_list['id']) echo 'selected'; ?>><?= $dis_list['d_name']?></option>
												<?php endforeach; endif; ?>
												</select>
                                            </div>
											<div class="col-sm-3">
                                                <label>P.S./Upazila</label>
                                                <select class="form-control" name="present_upazila">
												<option value="">----Select Upazila----</option>
												<?php if($upazila_list):
														foreach($upazila_list as $u_list):?>
													<option value="<?= $u_list['id']?>" <?php if($student_info['present_upazila']==$u_list['id']) echo 'selected'; ?>><?= $u_list['u_name']?></option>
												<?php endforeach; endif; ?>
												</select>
                                            </div>
											<div class="col-sm-3">
                                                <label>Post Office</label>
                                                <input type="text" class="form-control" name="present_po" value="<?php echo $student_info['present_po'];?>"/>
                                            </div>
											<div class="col-sm-3">
                                                <label>Post Code</label>
                                                <input type="text" class="form-control" name="present_pc" value="<?php echo $student_info['present_pc'];?>"/>
                                            </div>
                                        </div>
                                    </div>
						<hr/>
						<h4> Permanent Address<label class="checkbox-inline pull-right" style="color:red;">
							<input type="checkbox" name="check_address" id="check_address" value="1">Same as present address.</label>
						</h4>
				<div class="form-group permanent_address">
					<div class="row">
                                            <div class="col-sm-12">
                                                <label>Village/Town/Road/House/Flat</label>
                                                <input type="text" class="form-control" name="permanent_address" value="<?php echo $student_info['permanent_address'];?>" />
                                            </div>
                                            <div class="col-sm-3">
                                                <label>Division</label>
                                           <select class="form-control" name="permanent_division" onchange="get_district(this.value,'permanent_district')">
												<option value="">----Select Division----</option>
												<?php if($division_list):
														foreach($division_list as $div_list):?>
													<option value="<?= $div_list['id']?>" <?php if($student_info['permanent_division']==$div_list['id']) echo 'selected'; ?>><?= $div_list['name']?></option>
												<?php endforeach; endif; ?>
												</select>
                                            </div>
											<div class="col-sm-3">
                                                <label>District</label>
											<select class="form-control" name="permanent_district" onchange="get_upazila(this.value,'permanent_upazila')">
												<option value="">----Select District----</option>
												<?php if($district_list):
														foreach($district_list as $dis_list):?>
													<option value="<?= $dis_list['id']?>" <?php if($student_info['permanent_district']==$dis_list['id']) echo 'selected'; ?>><?= $dis_list['d_name']?></option>
												<?php endforeach; endif; ?>
												</select>
                                            </div>
											<div class="col-sm-3">
                                                <label>P.S./Upazila</label>
                                                <select class="form-control" name="permanent_upazila">
												<option value="">----Select Upazila----</option>
												<?php if($upazila_list):
														foreach($upazila_list as $u_list):?>
													<option value="<?= $u_list['id']?>" <?php if($student_info['permanent_upazila']==$u_list['id']) echo 'selected'; ?>><?= $u_list['u_name']?></option>
												<?php endforeach; endif; ?>
												</select>
                                            </div>
											<div class="col-sm-3">
                                                <label>Post Office</label>
                                                <input type="text" class="form-control" name="permanent_po" value="<?php echo $student_info['permanent_po'];?>"/>
                                            </div>
											<div class="col-sm-3">
                                                <label>Post Code</label>
                                                <input type="text" class="form-control" name="permanent_pc" value="<?php echo $student_info['permanent_pc'];?>"/>
                                            </div>
                                        </div>
                                    </div>
									<hr/>
									
									<h4> 2. Parents' Particulars</h4>
									
									<div class="form-group">
                                        <div class="row">                                            
                                            <div class="col-sm-6">
												<label>Father's Name</label>
                                                <input type="text" class="form-control" name="father_name" id="father_name" value="<?= $student_info['father_name'];?>">
											</div>
                                            <div class="col-sm-6">
												<label>Mother's Name</label>
                                                <input type="text" class="form-control" name="mother_name" id="mother_name" value="<?= $student_info['mother_name'];?>">
											</div>
                                        </div>
                                    </div>
									
									<div class="form-group">
                                        <div class="row">                                            
                                            <div class="col-sm-6">
												<label>Father's NID</label>
                                                <input type="text" class="form-control" name="father_nid" value="<?= $student_info['father_nid'];?>" />
											</div>
                                            <div class="col-sm-6">
												<label>Mother's NID</label>
                                                <input type="text" class="form-control" name="mother_nid" value="<?= $student_info['mother_nid'];?>" />
											</div>
                                        </div>
                                    </div>
									
									<div class="form-group">
                                        <div class="row">                                            
                                            <div class="col-sm-6">
												<label>Father's Occupation</label>
                                                <input type="text" class="form-control" name="father_occupation" id="father_occupation" value="<?= $student_info['father_occupation'];?>">
											</div>
                                            <div class="col-sm-6">
												<label>Mother's Occupation</label>
                                                <input type="text" class="form-control" name="mother_occupation" id="mother_occupation" value="<?= $student_info['mother_occupation'];?>">
											</div>
                                        </div>
                                    </div>
									
									<div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-6">
												<label>Father's Education</label>
                                                <select class="form-control" name="father_education" id="father_education">
                                                    <option value="">Select</option>
                                                    <option value="Pre-Graduate"
														<?php
															if($student_info['father_education']=='Pre-Graduate'){
																echo "selected";
															}
														?>
													>Pre-Graduate</option>
                                                    <option value="Graduate"
														<?php
															if($student_info['father_education']=='Graduate'){
																echo "selected";
															}
														?>
													>Graduate</option>
                                                    <option value="Post-Graduate"
														<?php
															if($student_info['father_education']=='Post-Graduate'){
																echo "selected";
															}
														?>
													>Post-Graduate</option>
                                                </select>
											</div>
                                            <div class="col-sm-6">
												<label>Mother's Education</label>
                                                <select class="form-control" name="mother_education" id="mother_education">
                                                    <option value="">Select</option>
                                                    <option value="Pre-Graduate"
														<?php
															if($student_info['mother_education']=='Pre-Graduate'){
																echo "selected";
															}
														?>
													>Pre-Graduate</option>
                                                    <option value="Graduate"
														<?php
															if($student_info['mother_education']=='Graduate'){
																echo "selected";
															}
														?>
													>Graduate</option>
                                                    <option value="Post-Graduate"
														<?php
															if($student_info['mother_education']=='Post-Graduate'){
																echo "selected";
															}
														?>
													>Post-Graduate</option>
                                                </select>
											</div>
                                        </div>
                                    </div>
									
									<div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <label>Father's Contact(Home)</label>
                                                <input type="text" class="form-control" name="father_home_contact" id="father_home_contact" placeholder="01********" value="<?= $student_info['father_home_contact'];?>">
                                            </div>
											<div class="col-sm-6">
                                                <label>Mother's Contact(Home)</label>
                                                <input type="text" class="form-control" name="mother_home_contact" id="mother_home_contact" placeholder="01********" value="<?= $student_info['mother_home_contact'];?>">
                                            </div>
                                        </div>
                                    </div>
									
									
									<div class="form-group">
                                        <div class="row">											
											<div class="col-sm-6">
                                                <label>Father's Email</label>
                                                <input type="text" class="form-control" name="father_email" id="exampleInputEmail1" value="<?= $student_info['father_email'];?>">
                                            </div>
											<div class="col-sm-6">
                                                <label>Mother's Email</label>
                                                <input type="text" class="form-control" name="mother_email" id="exampleInputEmail1" value="<?= $student_info['mother_email'];?>">
                                            </div>
                                        </div>
                                    </div>
									<div class="form-group">
                                        <div class="row">                                            
											<div class="col-sm-6">
                                                <label>SMS/Contact Number</label>
                                                <input type="text" class="form-control" name="mobile_contact" id="mobile_contact" placeholder="01*********" value="<?= $student_info['mobile_contact'];?>">
                                            </div>
                                        </div>
                                    </div>							
									
									<h4> 3. Guardians' Particulars</h4>
									<div class="form-group">
                                        <div class="row">                                            
                                            <div class="col-sm-6">
												<label>Guardian Name</label>
                                                <input type="text" class="form-control" name="guardian_1_name" id="guardian_1_name" value="<?= $student_info['guardian_1_name'];?>" />
											</div>
                                            <div class="col-sm-6">
												<label>Relation</label>
                                                <input type="text" class="form-control" name="guardian_1_relation" value="<?= $student_info['guardian_1_relation'];?>" />
											</div>
                                        </div>
                                    </div>
									
									<div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-6">
												<label>Occupation</label>
                                                <input type="text" class="form-control" name="guardian_1_occupation" value="<?= $student_info['guardian_1_occupation'];?>" />
											</div>
                                            <div class="col-sm-6">
												<label>Yearly Income</label>
                                                <input type="text" class="form-control" name="guardian_1_yearly_income" value="<?= $student_info['guardian_1_yearly_income'];?>" />
											</div>
                                        </div>
                                    </div>
									
									<div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-6">
												<label>Mobile</label>
                                                <input type="text" class="form-control" name="guardian_1_mobile" value="<?= $student_info['guardian_1_mobile'];?>" />
											</div>
                                            <div class="col-sm-6">
												<label>Email</label>
                                                <input type="text" class="form-control" name="guardian_1_email" value="<?= $student_info['guardian_1_email'];?>" />
											</div>
                                        </div>
                                    </div>
									
									<h4> 4. Particulars of siblings studying in this institution</h4> 
									<div class="form-group">
                                        <div class="row">                                            
                                            <div class="col-sm-3">
												<label>Siblings ID </label>
                                                <input type="text" class="form-control" name="siblings_1_id" value="<?= $student_info['siblings_1_id'];?>" />
											</div>
											
											<div class="col-sm-3">
												<label>Siblings ID </label>
                                                <input type="text" class="form-control" name="siblings_2_id" value="<?= $student_info['siblings_2_id'];?>" />
											</div>
											
											<div class="col-sm-3">
												<label>Siblings ID </label>
                                                <input type="text" class="form-control" name="siblings_3_id" value="<?= $student_info['siblings_3_id'];?>" />
											</div>
											
											<div class="col-sm-3">
												<label>Siblings ID </label>
                                                <input type="text" class="form-control" name="siblings_4_id" value="<?= $student_info['siblings_4_id'];?>" />
											</div>
                                        </div>
                                    </div>
									<hr />
									
									<legend><i class="icon32 icon-square-plus"></i> B. Academic Background</legend>
									<h3>Previous School</h3>
									<div class="form-group">
                                        <div class="row">                                            
											<div class="col-sm-6">
                                                <label>Name of School</label>
                                                <input type="text" class="form-control" name="previous_school_name" id="previous_school_name" value="<?= $student_info['previous_school_name'];?>">
                                            </div>
											
											<div class="col-sm-6">
                                                <label>Start Date</label>
                                                <input type="text" class="form-control datepicker-input" placeholder="mm/dd/yyyy" name="previous_start_date" id="previous_start_date" value="<?= $student_info['previous_start_date'];?>"> 
                                            </div>
                                        </div>
                                    </div>
									<div class="form-group">
                                        <div class="row">
											<div class="col-sm-6">
                                                <label>Finish Date</label>
                                                <input type="text" class="form-control datepicker-input" placeholder="mm/dd/yyyy" name="previous_finish_date" id="previous_finish_date" value="<?= $student_info['previous_finish_date'];?>"> 
                                            </div>                                            
											<div class="col-sm-6">
                                                <label>Finish Class</label>
                                                <input type="text" class="form-control" name="previous_finish_class" id="previous_finish_class" value="<?= $student_info['previous_finish_class'];?>">
                                            </div>
                                        </div>
                                    </div>
									<h4> 2. Board Exam Info</h4> 
									<div class="form-group">
                                        <div class="row">                                            
                                            <div class="col-sm-3">
												<label>Exam Name</label>
                                                <input type="text" class="form-control" name="exam_name[]" value="<?= $student_exam_info[0]['exam_name']?>" />
												<input type="hidden" name="id[]" value="<?= $student_exam_info[0]['id']?>" />
											</div>
											
											<div class="col-sm-3">
												<label>Regi. No</label>
                                                <input type="text" class="form-control" name="exam_regi[]" value="<?= $student_exam_info[0]['exam_regi']?>" />
											</div>
											
											<div class="col-sm-3">
												<label>Roll No</label>
                                                <input type="text" class="form-control" name="exam_roll[]" value="<?= $student_exam_info[0]['exam_roll']?>" />
											</div>
											
											<div class="col-sm-3">
												<label>GPA</label>
                                                <input type="text" class="form-control" name="exam_gpa[]" value="<?= $student_exam_info[0]['exam_gpa']?>" />
											</div>
                                        </div>
									</div>
									<div class="form-group">
										<div class="row">                                            
                                            <div class="col-sm-3">
                                                <input type="text" class="form-control" name="exam_name[]" value="<?= $student_exam_info[1]['exam_name']?>" />
												<input type="hidden" name="id[]" value="<?= $student_exam_info[1]['id']?>" />
											</div>
											
											<div class="col-sm-3">
                                                <input type="text" class="form-control" name="exam_regi[]" value="<?= $student_exam_info[1]['exam_regi']?>" />
											</div>
											
											<div class="col-sm-3">
                                                <input type="text" class="form-control" name="exam_roll[]" value="<?= $student_exam_info[1]['exam_roll']?>" />
											</div>
											
											<div class="col-sm-3">
                                                <input type="text" class="form-control" name="exam_gpa[]" value="<?= $student_exam_info[1]['exam_gpa']?>" />
											</div>
                                        </div>
                                    </div>
									<div class="form-group">
										<div class="row">                                            
                                            <div class="col-sm-3">
                                                <input type="text" class="form-control" name="exam_name[]" value="<?= $student_exam_info[2]['exam_name']?>" />
                                                <input type="hidden" name="id[]" value="<?= $student_exam_info[2]['id']?>" />
											</div>
											
											<div class="col-sm-3">
                                                <input type="text" class="form-control" name="exam_regi[]" value="<?= $student_exam_info[2]['exam_regi']?>" />
											</div>
											
											<div class="col-sm-3">
                                                <input type="text" class="form-control" name="exam_roll[]" value="<?= $student_exam_info[2]['exam_roll']?>" />
											</div>
											
											<div class="col-sm-3">
                                                <input type="text" class="form-control" name="exam_gpa[]" value="<?= $student_exam_info[2]['exam_gpa']?>" />
											</div>
                                        </div>
                                    </div>
									<hr />
									
                                    <legend><i class="icon32 icon-square-plus"></i>D. Other Info</legend>
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label>Blood group</label>
                                                <select class="form-control" name="blood_group" id="blood_group">
                                                    <option value="">Select</option>
                                                    <option value="AB+"
													<?php
														if($student_info['blood_group']=="AB+"){
															echo "selected";
														}
													?>
													>AB+</option>
                                                    <option value="AB−"
													<?php
														if($student_info['blood_group']=="AB-"){
															echo "selected";
														}
													?>
													>AB−</option>
                                                    <option value="B+"
													<?php
														if($student_info['blood_group']=="B+"){
															echo "selected";
														}
													?>
													>B+</option>
                                                    <option value="B−"
													<?php
														if($student_info['blood_group']=="B-"){
															echo "selected";
														}
													?>
													>B−</option>
                                                    <option value="A+"
													<?php
														if($student_info['blood_group']=="A+"){
															echo "selected";
														}
													?>
													>A+</option>
                                                    <option value="A−"
													<?php
														if($student_info['blood_group']=="A-"){
															echo "selected";
														}
													?>
													>A−</option>
                                                    <option value="O+"
													<?php
														if($student_info['blood_group']=="O+"){
															echo "selected";
														}
													?>
													>O+</option>
                                                    <option value="O−" <?php if($student_info['blood_group']=="O-"){ echo "selected"; } ?> >O−</option>
                                                </select>
                                            </div>
                                            
                                            <div class="col-sm-4">
                                                <label>Class <span style="color:red;">*</span></label>
                                                <select class="form-control" name="class_id" id="class_id" onchange="get_class_section_list(this.value);" required>
                                                    <option value="">Select</option>
                                                    <?php
                                                        foreach($class_list as $cl){ ?>
                                                         <option value="<?php echo $cl['class_id'];?>"
							<?php if($cl['class_id']==$student_info['class_id']){echo "selected";}?>><?= $cl['class_name'];?></option>   
                                                    <?php } ?>
                                                </select>
                                            </div>
                                            <div class="col-sm-4">
                                                <label>Section <span style="color:red;">*</span></label>
                                                <select class="form-control" name="section_id" id="section_id" required>
                                                    <option value="<?= $student_info['section_id']; ?>"><?= $student_info['section_name']; ?></option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label>Group <span style="color:red;">*</span></label>
                                                <select class="form-control" name="group_id" id="group_id" required>
                                                    <option value="">Select</option>
                                                    <?php
                                                        foreach($group_list as $gl){ ?>
                                                        <option value="<?php echo $gl['group_id'];?>"
                                                                <?php
                                                                if($student_info['group_id']==$gl['group_id']){echo "selected";}
                                                                ?>
                                                                ><?php echo $gl['group_name'];?></option>    
                                                    <?php    }   ?>
                                                </select>
                                            </div>
                                            
                                            <div class="col-sm-4">
                                                <label>Session <span style="color:red;">*</span></label>
                                                <select class="form-control" name="session_id" id="session_id" required>
                                                    <option value="">Select Session</option>
                                                    <?php
                                                        foreach($session_list as $sl){ ?>
                                                        <option value="<?php echo $sl['session_id'];?>"
                                                                <?php
                                                                if($student_info['session_id']==$sl['session_id']){echo "selected";}
                                                                ?>
                                                                ><?php echo $sl['session_name'];?></option>    
                                                    <?php    }   ?>
                                                </select>
                                            </div>
                                            
                                            <div class="col-sm-4">
                                                <label>Class Roll</label>
                                                <input type="text" class="form-control" name="roll_no" id="roll_no" value="<?php echo $student_info['roll_no'];?>">
                                            </div>
                                        </div>
                                    </div>
									
					<div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label>Shift <span style="color:red;">*</span></label>
                                                <select class="form-control" name="shift_id" id="shift_id" >
                                                    <?php foreach($shift_list as $sl){ ?>
                                                        <option value="<?php echo $sl['shift_id'];?>"
                                                        <?php  if($student_info['shift_id']==$sl['shift_id']){echo "selected";} ?> >
														<?= $sl['shift_name'];?></option>    
                                                    <?php } ?>
                                                </select>
                                            </div>
					</div>
                                    </div>
									
				<legend><i class="icon32 icon-square-plus"></i>E. Financial Aid Details</legend>
                                    <div class="form-group">
                                        <div class="row">
										
											<div class="col-sm-4">
                                                <label>Financial Aid</label>
                                                <select class="form-control" name="financial_aid" id="financial_aid">
                                                    <option value="">Select</option>
                                                    <option value="1" <?php if($student_info['financial_aid']==1){ echo "selected"; } ?> >Yes</option>
                                                    <option value="2" <?php if($student_info['financial_aid']==2){ echo "selected"; } ?> >No</option>
                                                    <option value="3" <?php if($student_info['financial_aid']==3){ echo "selected"; } ?> >Full Free</option>
                                                </select>
                                            </div>
											<div class="col-sm-4">
                                                <label>Fees Aid</label>
												<select class="form-control" name="fees_aid" id="fees_aid" >
													<option value="">----Select Fees----</option>
                                                    <?php foreach($fees_list as $fl){ ?>
                                                    <option value="<?= $fl['fees_cat_id'];?>" <?php if($fl['fees_cat_id']==$student_info['fees_aid']) echo "selected"; ?>><?= $fl['fees_particulars'];?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
											<div class="col-sm-4">
                                                <label>Aid Amount</label>
                                                <input type="text" class="form-control" name="aid_amount" id="aid_amount" onkeypress="return IsNumeric(event);" value="<?= $student_info['aid_amount'];?>"/>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <hr />		
					<legend><i class="icon32 icon-square-plus"></i>F. Authentication</legend>
                                    <div class="form-group">
                                        <div class="row">
										
					   <div class="col-sm-4">
					  	 <label>Password</label>
                                                 <input type="text" class="form-control" name="password" id="password" />
                                            </div>
                                        </div>
                                    </div>
                                    
									<button type="submit" class="btn btn-primary">Update</button>
								</form>
                            </div>
                        </div>
                    </div>
                </div>
<?php include 'application/views/includes/footer.php';?>

<script type="text/javascript">
function get_class_section_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'admin/section_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#section_id').html(html_data);
            document.getElementById('section_id').value = '<?= $student_info['section_id'];?>';
        }
    }
    });  
}
function get_class_group_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'academic/group_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#group_id').html(html_data);
        }
    }
    });  
}
function get_district(div_id,name)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'admin/district_list_ajax',
    data:
    {
        'div_id':div_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('[name='+name+']').html(html_data);
        }
    }
    });  
}
function get_upazila(dis_id,name)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'admin/upazila_list_ajax',
    data:
    {
        'dis_id':dis_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('[name='+name+']').html(html_data);
        }
    }
    });  
}
</script>

<!--For only numeric value can be typeable-->		
<script type="text/javascript">
	var specialKeys = new Array();
	specialKeys.push(8); //Backspace
	function IsNumeric(e) {
		var keyCode = e.which ? e.which : e.keyCode
		var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
		return ret;
	}
</script>

<!--For Calculating Age---->
<script> 
function myAgeValidation() { 
    var lre = /^\s*/;
    var datemsg = "";    
    var inputDate = document.registerForm.birth_date.value;
    inputDate = inputDate.replace(lre, "");
    document.registerForm.birth_date.value = inputDate;
    datemsg = isValidDate(inputDate);
        if (datemsg != "") {
            //alert(datemsg);
            return;
        }
        else {
            //Now find the Age based on the Birth Date
            getAge(new Date(inputDate));
        }
}
 
function getAge(birth) { 
    var today = new Date();
    var nowyear = today.getFullYear();
    var nowmonth = today.getMonth();
    var nowday = today.getDate();
 
    var birthyear = birth.getFullYear();
    var birthmonth = birth.getMonth();
    var birthday = birth.getDate();
 
    var age = nowyear - birthyear;
    var age_month = nowmonth - birthmonth;
    var age_day = nowday - birthday;
    
    if(age_month < 0 || (age_month == 0 && age_day <0)) {
            age = parseInt(age) -1;
        }		
    //alert(age);
	document.getElementById('age').value=age;	
}
 
function isValidDate(dateStr) {
    var msg = "";    
    var datePat = /^\d{4}-((0\d)|(1[012]))-(([012]\d)|3[01])$/;
 
    var matchArray = dateStr.match(datePat); // is the format ok?
    if (matchArray == null) {
        msg = "Date is not in a valid format.";
        return msg;
    }
    crt_date=dateStr.split('-')
    year = crt_date[0]; 
    month = crt_date[1]; // parse date into variables
    day = crt_date[2];
    
    if (month < 1 || month > 12) { // check month range
        msg = "Month must be between 1 and 12.";
        return msg;
    }
 
    if (day < 1 || day > 31) {
        msg = "Day must be between 1 and 31.";
        return msg;
    }
 
    if ((month==4 || month==6 || month==9 || month==11) && day==31) {
        msg = "Month "+month+" doesn't have 31 days!";
        return msg;
    }
 
    if (month == 2) { // check for february 29th
    var isleap = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
    if (day>29 || (day==29 && !isleap)) {
        msg = "February " + year + " doesn't have " + day + " days!";
        return msg;
    }
    }
 
    if (day.charAt(0) == '0') day= day.charAt(1);
    return msg;  // date is valid
}
 window.onload=function(){
	$('#check_address').click(function() {
		if(this.checked){
		$('.permanent_address').hide('slow');
		}
		else{
			$('.permanent_address').show('slow');
		}
	});
	get_class_section_list('<?= $student_info['class_id']; ?>');
	//get_class_group_list('4');
 }
 
 function handleFileSelect(evt) {
    var files = evt.target.files; // FileList object

    // Loop through the FileList and render image files as thumbnails.
    for (var i = 0, f; f = files[i]; i++) {

      // Only process image files.
      if (!f.type.match('image.*')) {
        continue;
      }

      var reader = new FileReader();

      // Closure to capture the file information.
      reader.onload = (function(theFile) {
        return function(e) {
          // Render thumbnail.
          var span = document.createElement('span');
          span.innerHTML = ['<img class="thumb" height="200" width="200" src="', e.target.result,
                            '" title="', escape(theFile.name), '"/>'].join('');
          document.getElementById('list').innerHTML=span.innerHTML;
        };
      })(f);

      // Read in the image file as a data URL.
      reader.readAsDataURL(f);
    }
  }

  document.getElementById('student_image').addEventListener('change', handleFileSelect, false);
</script>>