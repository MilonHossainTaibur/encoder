<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">			
            <div class="content">
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i> Teacher Information View</h1>
                </div>
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="widget" style="min-height:500px;">
                            <div class="widget-content padding">
                                <form role="form" id="registerForm">
                                    <legend><i class="icon32 icon-square-plus"></i>Personal Info</legend>
                                    
                                    <!--<div class="form-group">
                                        <label>Teacher's name </label>
                                        <input type="text" class="form-control" name="teacher_name" id="teacher_name" value="<?php echo $teacher_info['teacher_name'];?>" readonly="">
                                    </div>-->
                                    
                                    <div class="form-group">
                                          <div class="row">                                              
                                              <div class="col-sm-6">
                                                <label>Teacher's name </label>
                                                <input type="text" class="form-control" name="teacher_name" id="teacher_name" value="<?php echo $teacher_info['teacher_name'];?>" readonly="">
                                          </div>
                                              <div class="row">                                              
												  <div class="col-sm-6">
													<label>Father's name </label>
													<input type="text" class="form-control" name="father_name" id="father_name" value="<?php echo $teacher_info['father_name'];?>" readonly="">
												  </div>
											  </div>
                                    </div>
									
									<div class="form-group">
                                          <div class="row">                                              
                                              <div class="col-sm-6">
                                                <label>Husband's name </label>
                                                <input type="text" class="form-control" name="husband_name" id="husband_name" value="<?php echo $teacher_info['husband_name'];?>" readonly="">
                                          </div>
                                              <div class="col-sm-6">
                                                <label>Mother's name </label>
                                                <input type="text" class="form-control" name="mother_name" id="mother_name" value="<?php echo $teacher_info['mother_name'];?>" readonly="">
                                              </div>
                                          </div>
                                    </div>
                                    
                                   
                                    <div class="form-group">
                                          <div class="row">
                                              <div class="col-sm-4">
                                                  <label>Date of Birth</label>
                                                    <input type="text" class="form-control" value="<?php echo $teacher_info['birth_date'];?>" name="birth_date" id="birth_date" readonly="">
                                              </div>
                                              <div class="col-sm-4">
                                                    <label>Gender</label>
                                                    <select class="form-control" name="gender" id="gender" disabled=""> 
                                                        <option value="">select</option>
                                                        <option value="Male"
                                                                <?php
                                                                    if($teacher_info['gender']=="Male"){echo "selected";}
                                                                ?>
                                                                >Male</option>
                                                        <option value="Female"
                                                                <?php
                                                                    if($teacher_info['gender']=="Female"){echo "selected";}
                                                                ?>
                                                                >Female</option>
                                                    </select>
                                              </div>
                                              <div class="col-sm-4">
                                                  <label>Marital Status</label>
                                                    <select class="form-control" name="marital_status" id="marital_status" disabled="">
                                                        <option value="">select</option>
                                                        <option value="Married"
                                                                <?php
                                                                    if($teacher_info['marital_status']=="Married"){echo "selected";}
                                                                ?>
                                                                >Married</option>
                                                        <option value="Unmarried"
                                                                <?php
                                                                    if($teacher_info['marital_status']=="Unmarried"){echo "selected";}
                                                                ?>
                                                                >Unmarried</option>
                                                    </select>
                                              </div>
                                          </div>
                                    </div>
                                    
                                    
                                    <legend><i class="icon32 icon-square-plus"></i>Permanent Address</legend>
                                    
                                    <div class="form-group">
                                        <label>Address</label>
                                        <input type="text" class="form-control" name="permanent_address" id="permanent_address" value="<?php echo $teacher_info['permanent_address'];?>" readonly="">
                                    </div>
                                    
                                    <div class="form-group">
                                        <div class="row">                                            
                                            <div class="col-sm-4">
                                                <label>Thana</label>
                                                <input type="text" class="form-control" name="permanent_thana" id="permanent_thana" value="<?php echo $teacher_info['permanent_thana'];?>" readonly="">
                                            </div>
                                            <div class="col-sm-4">
                                                <label>District</label>
                                                <input type="text" class="form-control" name="permanent_district" id="permanent_district" value="<?php echo $teacher_info['permanent_district'];?>" readonly="">
                                            </div>
                                            <div class="col-sm-4">
                                                <label>Contact Number</label>
                                                <input type="text" class="form-control" data-mask="8801999999999" value="<?php echo $teacher_info['permanent_contact'];?>" name="permanent_contact" id="permanent_contact" readonly="">
                                            </div>
                                        </div>
                                    </div>
                                  
                                    <legend><i class="icon32 icon-square-plus"></i>Present Address</legend>
                                    
                                    <div class="form-group">
                                        <label>Address</label>
                                        <input type="text" class="form-control" name="present_address" id="present_address" value="<?php echo $teacher_info['present_address'];?>" readonly="">
                                    </div>
                                    
                                    
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label>Thana</label>
                                                <input type="text" class="form-control" name="present_thana" id="present_thana" value="<?php echo $teacher_info['present_thana'];?>" readonly="">
                                            </div>
                                            <div class="col-sm-4">
                                                <label>District</label>
                                                <input type="text" class="form-control" name="present_district" id="present_district" value="<?php echo $teacher_info['present_district'];?>" readonly="">
                                            </div>
                                            <div class="col-sm-4">
                                                <label>Contact Number</label>
                                                <input type="text" class="form-control" data-mask="8801999999999" value="<?php echo $teacher_info['present_contact'];?>" name="present_contact" id="present_contact" readonly="">
                                            </div>
                                        </div>
                                    </div>
                                    
                                    
                                    
                                    <legend><i class="icon32 icon-square-plus"></i>Other Info</legend>
                                    
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label>Account Number</label>
                                                <input type="text" class="form-control" name="account_number" id="account_number" value="<?php echo $teacher_info['account_number'];?>" readonly="">
                                            </div>
                                            
                                            <div class="col-sm-4">
                                                <label>Religion</label>
                                                <input type="text" class="form-control" name="religion" id="religion" value="<?php echo $teacher_info['religion'];?>" readonly="">
                                            </div>
                                            <div class="col-sm-4">
                                                <label>Nationality</label>
                                                <input type="text" class="form-control" name="nationality" id="nationality" value="<?php echo $teacher_info['nationality'];?>" readonly="">
                                            </div>
                                            
                                        </div>
                                    </div>
                                    
                                    
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label>National ID Card No. </label>
                                                <input type="text" class="form-control" name="national_id_card_no" id="national_id_card_no" value="<?php echo $teacher_info['national_id_card_no'];?>" readonly="">
                                            </div>
                                            
                                            
                                            <div class="col-sm-4">
                                                <label>Blood group</label>
                                                <select class="form-control" name="blood_group" id="blood_group" disabled="">
                                                    <option value="">Select</option>
                                                    <option value="AB+"
                                                            <?php
                                                                if($teacher_info['blood_group']=="AB+"){echo "selected";}
                                                            ?>
                                                            >AB+</option>
                                                    <option value="AB−"
                                                            <?php
                                                                if($teacher_info['blood_group']=="AB-"){echo "selected";}
                                                            ?>
                                                            >AB−</option>
                                                    <option value="B+"
                                                            <?php
                                                                if($teacher_info['blood_group']=="B+"){echo "selected";}
                                                            ?>
                                                            >B+</option>
                                                    <option value="B−"
                                                            <?php
                                                                if($teacher_info['blood_group']=="B-"){echo "selected";}
                                                            ?>
                                                            >B−</option>
                                                    <option value="A+"
                                                            <?php
                                                                if($teacher_info['blood_group']=="A+"){echo "selected";}
                                                            ?>
                                                            >A+</option>
                                                    <option value="A−"
                                                            <?php
                                                                if($teacher_info['blood_group']=="A-"){echo "selected";}
                                                            ?>
                                                            >A−</option>
                                                    <option value="O+"
                                                            <?php
                                                                if($teacher_info['blood_group']=="O+"){echo "selected";}
                                                            ?>
                                                            >O+</option>
                                                    <option value="O−"
                                                            <?php
                                                                if($teacher_info['blood_group']=="O-"){echo "selected";}
                                                            ?>
                                                            >O−</option>
                                                </select>                                      
                                            </div>
                                            <div class="col-sm-4">
                                                <label>E-Mail</label>
                                                <input type="email" class="form-control" id="inputEmail3" name="email" placeholder="Email" value="<?php echo $teacher_info['email'];?>" readonly="">
                                            </div>
                                            
                                        </div>
                                    </div>
                                    
                                    
                                    <div class="form-group">
                                        <div class="row">
                                            
                                            <div class="col-sm-4">
                                                <label>Department</label>
                                                
                                                <select class="form-control" name="department_id" id="department_id" disabled="">
                                                    <option value="">Select</option>
                                                    <?php
                                                        foreach($department_list as $dpt){ ?>
                                                        <option value="<?php echo $dpt['department_id'];?>"
                                                                <?php
                                                                    if($teacher_info['department_id']==$dpt['department_id']){
                                                                        echo "selected";
                                                                    }
                                                                ?>
                                                                ><?php echo $dpt['department_name'];?></option>
                                                    <?php    }
                                                    ?>
                                                </select>
                                            </div>
                                            
                                            <div class="col-sm-4">
                                                <label>Designation</label>
                                                <select class="form-control" name="designation_id" id="designation_id" disabled="">
                                                    <option value="">Select</option>
                                                    <?php
                                                        foreach($designation_list as $dl){ ?>
                                                        <option value="<?php echo $dl['designation_id'];?>"
                                                                <?php
                                                                    if($teacher_info['designation_id']==$dl['designation_id']){
                                                                        echo "selected";
                                                                    }
                                                                ?>
                                                                ><?php echo $dl['designation_name'];?></option>
                                                    <?php    } ?>
                                                </select>
                                            </div>
                                            <div class="col-sm-4">
                                                <label>Date of Joining</label>
                                                <input type="text" class="form-control" name="joining_date" id="joining_date" value="<?php echo $teacher_info['joining_date'];?>" readonly="">
                                            </div>
                                        </div>
                                    </div>   
                                    
                                    
                                    <div class="form-group">
                                        <label>Teacher Image</label>
                                        <img src="<?php echo base_url();?>upload/teacher_image/<?php echo $teacher_info['teacher_image'];?>" alt="" height="150" width="150"/>
                                    </div>
                                    
                                    
                                  </form>
                            </div>
                        </div>
                    </div>
                </div>
				
				
<?php include 'application/views/includes/footer.php';?>