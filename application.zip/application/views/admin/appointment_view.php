<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

<?php
function convert_number($number) 
{ 
    if (($number < 0) || ($number > 999999999)) 
    { 
    throw new Exception("Number is out of range");
    } 

    $Gn = floor($number / 100000);  /* lak (giga) */ 
    $number -= $Gn * 100000; 
    $kn = floor($number / 1000);     /* Thousands (kilo) */ 
    $number -= $kn * 1000; 
    $Hn = floor($number / 100);      /* Hundreds (hecto) */ 
    $number -= $Hn * 100; 
    $Dn = floor($number / 10);       /* Tens (deca) */ 
    $n = $number % 10;               /* Ones */ 

    $res = ""; 

    if ($Gn) 
    { 
        $res .= convert_number($Gn) . " lakh"; 
    } 

    if ($kn) 
    { 
        $res .= (empty($res) ? "" : " ") . 
            convert_number($kn) . " Thousand"; 
    } 

    if ($Hn) 
    { 
        $res .= (empty($res) ? "" : " ") . 
            convert_number($Hn) . " Hundred"; 
    } 

    $ones = array("", "One", "Two", "Three", "Four", "Five", "Six", 
        "Seven", "Eight", "Nine", "Ten", "Eleven", "Twelve", "Thirteen", 
        "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eightteen", 
        "Nineteen"); 
    $tens = array("", "", "Twenty", "Thirty", "Fourty", "Fifty", "Sixty", 
        "Seventy", "Eigthy", "Ninety"); 

    if ($Dn || $n) 
    { 
        if (!empty($res)) 
        { 
            $res .= " and "; 
        } 

        if ($Dn < 2) 
        { 
            $res .= $ones[$Dn * 10 + $n]; 
        } 
        else 
        { 
            $res .= $tens[$Dn]; 

            if ($n) 
            { 
                $res .= "-" . $ones[$n]; 
            } 
        } 
    } 

    if (empty($res)) 
    { 
        $res = "zero"; 
    } 
    return $res; 
} 

?>


<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">			
            <div class="content">
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i> View Appointment Letter</h1>
                </div>
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="widget" style="min-height:500px;">
                            <div class="widget-content padding">
                                <div class="appointment_view">
                                    Ref : AHIS/App/<?php echo $appoint_list['short_department_name'];?>-<?php echo $appoint_list['designation_name'];?>/<?php echo $appoint_list['teacher_id'];?> <br/><br/>
                                    Date: <b><?php echo date('d/m/Y');?></b><br/><br/>
                                    
                                    <table>
                                        <tr>
                                            <td>Name</td>
                                            <td>:</td>
                                            <td>
                                                <b><?php echo $appoint_list['teacher_name'];?></b>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                Father’s Name
                                            </td>
                                            <td>
                                                :
                                            </td>
                                            <td>
                                                <b><?php echo $appoint_list['father_name'];?></b>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                Present Address
                                            </td>
                                            <td>
                                                :
                                            </td>
                                            <td>
                                                <b><?php echo $appoint_list['present_address'];?>, <?php echo $appoint_list['present_thana'];?>, <?php echo $appoint_list['present_district'];?></b>
                                            </td>
                                        </tr>
                                        <tr>
                                            <td>
                                                Email
                                            </td>
                                            <td>
                                                :
                                            </td>
                                            <td>
                                                <b><?php echo $appoint_list['email'];?></b>
                                            </td>
                                        </tr>
                                    </table>                                   
                                    <p>                                        
                                        <br/><br/>
                                        <b> Subject: <u> Appointment Letter.</u> </b> <br/><br/>
                                        Dear Sir,<br/>
                                        With reference to your application and subsequent interview with us the management is pleased to appoint you as <b><?php echo $appoint_list['designation_name'];?></b> on probation of 03 (Three) months with a consolidated salary of Tk: <b><?php echo $appoint_list['salary'];?> (In words : <?php echo convert_number($appoint_list['salary']);?>)</b>. During probation period, either party can terminate the service without prior notice or salary in lieu thereof. <br/><br/>

                                        After successful completion of your probation period your service and salary may be confirmed as per school’s rules and regulations which will be reviewed from time to time. After confirmation, either party can terminate the service by giving 01 (one) month notice period or salary in lieu thereof. <br/><br/>

                                        <b> <u> Terms and conditions : </u></b><br/>

                                        <table>
                                            <tr>
                                                <td>
                                                   1.  
                                                </td>
                                                <td>
                                                    You must maintain school’s code of conduct. 
                                                </td>
                                            </tr>

                                            <tr>
                                                <td>
                                                    2. 
                                                </td>
                                                <td>
                                                    Salary and other payment will be made as per school’s financial procedure. 
                                                </td>
                                            </tr>

                                            <tr>
                                                <td>
                                                    3. 
                                                </td>
                                                <td>
                                                    You will be entitled 02 (two) festival bonus per calendar year after confirmation and after six months of your service. 
                                                </td>
                                            </tr>

                                            <tr>
                                                <td>
                                                    4. 
                                                </td>
                                                <td>
                                                    You will have to pay Income Tax, if applicable, as per Rule. 
                                                </td>
                                            </tr>

                                            <tr>
                                                <td>
                                                    5. 
                                                </td>
                                                <td>
                                                    After confirmation you will get yearly increment as per your performance evaluated at the beginning of every academic year. 
                                                </td>
                                            </tr>

                                            <tr>
                                                <td>
                                                    6. 
                                                </td>
                                                <td>
                                                    Your reporting line is to the “Principal” or to her order. 
                                                </td>
                                            </tr>

                                            <tr>
                                                <td>
                                                    7. 
                                                </td>
                                                <td>
                                                    That for all other service conditions (including disciplinary matters); you will be governed by the relevant provisions of the school’s rules and regulations. 
                                                </td>
                                            </tr>

                                            <tr>
                                                <td>
                                                    8. 
                                                </td>
                                                <td>
                                                    That during the continuance of your employment and thereafter, you will keep all secrets and will not divulge to any person, firm or company, whosoever (other than to the authorized representatives) your salary, increment and emoluments, as also all such secrets or confidential information of any description, acquired by you while in our service, concerning the business, properties or affairs of the company or any of in our service, its Associates or branches, their customers and suppliers. 
                                                </td>
                                            </tr>
                                        </table>

                                        <br/><br/>

                                        Thanking you, <br/><br/>

                                        Best regards, <br/><br/><br/>


                                        ______________________<br/>
                                        <b> Fahmida Sultana </b><br/>
                                        Principal <br/><br/>

                                        <br/>
                                        I have carefully read the appointment letter and rules and regulations and accepted the same set out thereof. 

                                        <br/><br/><br/>
                                        ______________________<br/>
                                        <b> Employee Signature </b> <br/>
                                        <br/><br/>
                                        <table>
                                            <tr>
                                                <td>
                                                    Cc: 
                                                </td>
                                                <td>
                                                    (1) Chairman
                                                </td>
                                            </tr>
                                            <tr>
                                                <td></td>
                                                <td>
                                                    (2) Head of School
                                                </td>
                                            </tr>
                                        </table>
                                    </p>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
				

				
				

				
<?php include 'application/views/includes/footer.php';?>