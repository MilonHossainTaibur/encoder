<div class="widget-content">
	<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
		<thead>
			<tr>
				<th>#SL</th>
				<th>Class Name</th>
				<th>Publish/Unpublish</th>
			</tr>
		</thead>
		<tbody>
			<?php $i=1; foreach($cs_list as $dl){ ?>
			<tr>
				<td><?= $i;?></td>
				<td><?= ucwords($dl['class_name']);?></td>
				<td class="<?= $i;?>">
					<?php if($dl['published']==1){ ?>
					<button class="btn btn-danger" onclick="change_status(<?= $dl['class_id'];?>,0,<?= $details['session_id'];?>,<?= $i;?>)"> Unpublish </button>
					<?php }else{ ?>
					<button class="btn btn-primary" onclick="change_status(<?= $dl['class_id'];?>,1,<?= $details['session_id'];?>,<?= $i;?>)"> Publish </button>
					<?php } ?>
				</td>
			</tr>
			<?php $i++; } ?>
		</tbody>
	</table>
</div>
<script>
function change_status(class_id,status,session_id,row)
		{
		   $.ajax({
			type: "POST",
			url: baseUrl + 'admin/admission_result_publish_change',
			data:
			{
				'class_id':class_id,
				'status':status,
				'session_id':session_id,
				'row':row
			}, 
			success: function(html_data)
			{
				if (html_data != '')
				{
					$('.'+row).html(html_data);
				}
			}
			});  
		}
</script>