<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
	<div class="content-page">
		<!-- ============================================================== -->
		<!-- Start Content here -->
		<!-- ============================================================== -->
		<div class="content">
			<div class="page-heading">
				<h1><i class='fa fa-table'></i> Income List</h1>
			</div>       
			
			<?php if($this->session->flashdata('message')):?>
				<div class="alert alert-success">
				<a href="#" class="close" data-dismiss="alert">&times;</a>
				<?=$this->session->flashdata('message')?>
			</div>
			<?php endif?>
				
			<div class="row">					
				<div class="col-md-12">
					<div class="widget">							
						<div class="widget-content">
						<br>					
							<div class="table-responsive">
									
								<form class='form-horizontal' role='form'>	
								<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
										<thead>
											<tr>
												<th>VNo</th>
												<th>A/C Name</th>
												<th>Pay To</th>
												<th>Designation</th>
												<th>Income</th>
												<th>Date</th>
												<th>Action</th>
											</tr>
										</thead>
								 
										<tfoot>
											<tr>
												<th>VNo</th>
												<th>A/C Name</th>
												<th>Pay To</th>
												<th>Designation</th>
												<th>Income</th>
												<th>Date</th>
												<th>Action</th>
											</tr>
										</tfoot>
								 
										<tbody>
											<?php
												foreach($expenses_list as $sl){ ?>
												<tr>
													<td><?php echo $sl['voucher_no'];?></td>
													<td><?php echo $sl['ac_name'];?></td>
													<td><?php echo $sl['pay_to_name'];?></td>
													<td><?php echo $sl['designation'];?></td>
													<td><?php echo $sl['cr'];?></td>
													<td><?php echo $sl['rec_date'];?></td>
													<td>
														<a href="<?php echo base_url();?>admin/manage_income_edit/<?php echo $sl['general_ledger_id'];?>" title="Edit"><i class="fa fa-edit"></i></a> | <a onClick='return delete_alert("Are you sure Delete Income ????");' href="<?php echo base_url();?>admin/manage_income_delete/<?php echo $sl['general_ledger_id'];?>" title="Delete"><i class="fa fa-remove"></i></a> 
													</td>
												</tr>
											<?php 	} ?>
										</tbody>
									</table>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
	
<?php include 'application/views/includes/footer.php';?>