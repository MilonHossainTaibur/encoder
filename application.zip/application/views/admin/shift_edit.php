<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">			
            <div class="content">
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i> Shift Edit</h1>
                </div>
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="widget" style="min-height:300px;">
                           
                            <div class="widget-content padding">
                                <form role="form" id="registerForm" method="POST" action="<?php echo base_url();?>admin/shift_edit_save" enctype="multipart/form-data">
                                    <br/><br/><br/>
                                    
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-2"></div>
                                            <div class="col-sm-4">
                                                <label>Shift name </label>
                                                <input type="text" class="form-control" name="shift_name" id="shift_name" value="<?php echo $shift_list['shift_name']; ?>">
                                                <input type="hidden" class="form-control" name="shift_id" id="shift_id" value="<?php echo $shift_list['shift_id']; ?>">
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-2"></div>
                                            <div class="col-sm-4">
                                                <button type="submit" class="btn btn-primary">Update</button>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    
                                    
                                    
                                    
                                  </form>
                            </div>
                        </div>
                    </div>
                </div>
				

				
				

				
<?php include 'application/views/includes/footer.php';?>