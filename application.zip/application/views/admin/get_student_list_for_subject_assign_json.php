<hr />
<style>
    table{
        margin:0;
    padding:0;
    background:none;
    border:none;
    border-collapse:collapse;
    border-spacing:0;
    background-image:none;
    }
</style>
<div class="form-group">
    <div class="row">
        <div class="col-sm-12">
            <table class="table table-bordered table-striped" border="1" width="100%">
                <tr>
                    <th>Student ID</th>
                    <th>Student Name</th>
                    <th>Optional Subject</th>
                    <th>Compulsory Subject</th>
                </tr>

            <?php
            foreach($student_list as $i=>$sl){ ?>
                <tr>
                    <td>
                        <?php echo $sl['student_id'];?>
                    </td>
                    <td><?php echo $sl['student_name'];?></td>
                    <td><?php foreach($subject_list as $sublist){
                            $checked            = '';
                            $has_assign_subject = $this->Admin_model->search_class_wise_student_subj($school_id, $class_id, $group_id, $sl['student_id'], $sublist['subject_id'], 1);
                            if($has_assign_subject == 1) $checked = 'checked';
                        ?>
						<input type="radio" name="subject_op[<?php echo $i;?>]" <?php echo $checked;?> value="<?= $sl['student_id'];?>,<?= $sublist['subject_id'];?>,1"/>
						<?php echo $sublist['subject_name'];?>- <?php echo $sublist['subject_code'];?><br/>
						<?php 	} ?>
                    </td>
                     <td><?php foreach($subject_list as $j=>$sublist){
                             $checked            = '';
                             $has_assign_subject = $this->Admin_model->search_class_wise_student_subj($school_id, $class_id, $group_id, $sl['student_id'], $sublist['subject_id'], 0);
                             if($has_assign_subject == 1) $checked = 'checked';
                        ?>
						<input type="radio" name="subject_com[<?php echo $i;?>]" <?php echo $checked;?> value="<?= $sl['student_id'];?>,<?= $sublist['subject_id'];?>,0"/>
						<?php echo $sublist['subject_name'];?>- <?php echo $sublist['subject_code'];?><br/>
						<?php 	} ?>
                    </td>
                </tr>


        <?php 	} ?>
            </table>
        </div>
    </div>
</div>
<hr />

<div class="form-group">
    <div class="row">
        <div class="col-sm-4">
            <input type="button" class="btn btn-primary" onClick="printPageArea('display')" value="Print This"/>
            <button type="submit" class="btn btn-primary">Save</button>
        </div>
    </div>
</div>