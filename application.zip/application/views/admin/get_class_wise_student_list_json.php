<div class="table-responsive">
		<form class='form-horizontal' role='form'>
			<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
					<thead>
						<tr>
							<th>Student ID</th>
							<th>Name</th>
							<th>Class</th>
							<th>Section</th>
							<th>Class Roll</th>
							<th>Action</th>
						</tr>
					</thead>

					<tfoot>
						<tr>
							<th>Student ID</th>
							<th>Name</th>
							<th>Class</th>
							<th>Section</th>
							<th>Class Roll</th>
							<th>Action</th>
						</tr>
					</tfoot>

					<tbody>
						<?php
							foreach($student_list as $sl){ ?>
							<tr>
								<td><?php echo $sl['student_id'];?></td>
								<td><?php echo $sl['student_name'];?></td>
								<td><?php echo $sl['class_name'];?></td>
								<td><?php echo $sl['section_name'];?></td>
								<td><?php echo $sl['roll_no'];?></td>
								<td>
									<a href="<?php echo base_url();?>admin/student_information_view/<?php echo $sl['student_id'];?>" title="View"><i class="fa fa-retweet"></i></a> | <a href="<?php echo base_url();?>admin/student_information_edit/<?php echo $sl['student_id'];?>" title="Edit"><i class="fa fa-edit"></i></a> | <a href="<?php echo base_url();?>admin/student_information_delete/<?php echo $sl['student_id'];?>" title="Delete"><i class="fa fa-remove"></i></a> 
								</td>
							</tr>
						<?php 	} ?>
					</tbody>
			</table>
		</form>
</div>