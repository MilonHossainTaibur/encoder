<!-- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>
				
<!-- Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
<div class="content-page">			
    <div class="content">
        <!-- Page Heading Start -->
        <div class="page-heading">
            <h1><i class='fa fa-table'></i> Publish Admission Result </h1>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="widget" style="min-height: 400px">
					<div class="widget-content">
						<div class="widget-content padding">
							<div class="form-group">
								<div class="row">									
									<div class="col-sm-3 col-md-3">
										<label>Year <span style="color:red;">*</span></label>
										<select class="form-control" name="session_id" id="session_id">
											<option value="">-----Select Year-----</option>
											<?php foreach($stusession_id as $sl){ ?>
											<option value="<?= $sl['session_name'];?>"><?= $sl['session_name'];?></option>
											<?php } ?>
										</select>
									</div>
								</div>
							</div><br><br>
							<button class="btn btn-success btn-label-center" onclick="result_publish_json()" type="button"> Get Class List </button>
                            <hr />
							<div id="display">
								<!-- content will display here -->
							</div>
						</div><!--//section-content-->
					</div><!--//news-wrapper-->
				</div><!--//page-row-->
			</div><!--//page-content-->
		</div><!--//page-wrapper-->
    
<?php include 'application/views/includes/footer.php';?>

<!--Check department name based on class id-->
<script>
	function result_publish_json()
	{
		var session_id = $('#session_id').val();
	
		if(!session_id)
		{
			$('#session_id').after("<div id='validation_ses' class='validation_js'>Please select year</div>")
				$('#validation_ses').delay(3000).hide('slow');
				return;
			
		}
	
		$.ajax({ 
		url: baseUrl+'admin/admission_result_publish_json',
		data:
			{ 
				'session_id':session_id
			}, 
			dataType: 'json',
			success: function(data)
			{
				result                = ''+data['result']+'';
				mainContent           = ''+data['mainContent']+'';

				if(result == 'success')
				{            
					$('#display').html(mainContent);     
				}                
			}
		});
	}
</script> 

