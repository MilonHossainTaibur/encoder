<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
<style>
.stu_image{
    -webkit-transition: all .3s ease; /* Safari and Chrome */
  	-moz-transition: all .3s ease; /* Firefox */
  	-o-transition: all .3s ease; /* IE 9 */
  	-ms-transition: all .3s ease; /* Opera */
  	transition: all .3s ease;
}
.stu_image:hover{
 -webkit-backface-visibility: hidden;
    backface-visibility: hidden;
    -webkit-transform:translateZ(0) scale(2.20); /* Safari and Chrome */
    -moz-transform:scale(2.20); /* Firefox */
    -ms-transform:scale(2.20); /* IE 9 */
    -o-transform:translatZ(0) scale(2.20); /* Opera */
    transform:translatZ(0) scale(2.20);
}
</style>
<div class="content-page">
	<!-- Start Content here -->
	<div class="content">
	<?php if($this->session->flashdata('message')):?>
		<?=$this->session->flashdata('message')?>
	<?php endif?>
		<div class="page-heading">
			<h1><i class='fa fa-table'></i> Student List</h1>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="widget">							
					<div class="widget-content">
						<form method="POST" action="<?= base_url() ?>admin/student_list">
							<div class="widget-content padding">
								<div class="form-group">
									<div class="row">
										<div class="col-sm-6 col-md-3">
											<label>Class</label>
											<select class="form-control" name="class_id" id="class_id" onchange="get_class_section_list(this.value); get_class_group_list(this.value)">
												<option value="all">----Select Class----</option>
												<?php foreach($class_list as $cl){ ?>
												<option value="<?= $cl['class_id'];?>" <?php if($this->session->userdata('class_id')==$cl['class_id']) echo "selected"; ?> ><?= $cl['class_name'];?></option>
												<?php } ?>
											</select>
										</div>
										<div class="col-sm-6 col-md-3">
											<label>Section</label>
											<select class="form-control" name="section_id" id="section_id">
												<option value="all">----Select Section----</option>
											</select>
										</div>
										<div class="col-sm-6 col-md-3">
											<label>Group</label>
											<select class="form-control" name="group_id" id="group_id">
												<option value="all">----Select Group----</option>
											</select>
										</div>
										<div class="col-sm-6 col-md-3">
											<label>Shift</label>
											<select class="form-control" name="shift_id" id="shift_id">
												<option value="all">----Select Shift----</option>
												<?php foreach($shift_list as $sl){ ?>
												<option value="<?= $sl['shift_id'];?>" <?php if($this->session->userdata('shift_id')==$sl['shift_id']) echo "selected"; ?> ><?= $sl['shift_name'];?></option>
												<?php } ?>
											</select>
										</div>
									</div>
								</div>
								<div class="form-group">
									<div class="row">
										<div class="col-sm-6 col-md-3">
											<label>Gender</label>
											<select class="form-control" name="gender_id" id="gender_id">
												<option value="all">----Select Gender----</option>
												<option value="Male" <?php if($this->session->userdata('gender_id')=='Male') echo "selected"; ?> >Male</option>
												<option value="Female" <?php if($this->session->userdata('gender_id')=='Female') echo "selected"; ?> >Female</option>
											</select>
										</div>
									</div>
								</div>
								<div class="form-group">
									<div class="row">
										<div class="col-sm-4">
											<button type="submit" class="btn btn-primary">Show</button>
										</div>
									</div>
								</div>
							</div>
						</form>
						<div class="table-responsive">
						
							<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
								<thead>
									<tr>
										<th style="display:none;"></th>
										<th>Student ID</th>
										<th>Name</th>
										<th>F Name</th>
										<th>M Name</th>
										<th>Present Address</th>
										<th>Permanent Address</th>
										<th>Class</th>
										<th>Mobile</th>
										<th>Class Roll</th>
										<th>DOB</th>
										<!--<th>Nationality</th>-->
										<th>Image</th>
										<th>Action</th>
									</tr>
								</thead>
								<tfoot>
									<tr>
										<th style="display:none;"></th>
										<th>Student ID</th>
										<th>Name</th>
										<th>F Name</th>
										<th>M Name</th>
										<th>Present Address</th>
										<th>Permanent Address</th>
										<th>Class</th>
										<th>Mobile</th>
										<!--<th>Section</th>-->
										<th>Class Roll</th>
										<th>DOB</th>
										<!--<th>Nationality</th>-->
										<th>Image</th>
										<th>Action</th>
									</tr>
								</tfoot>
								<tbody>
									<?php foreach($student_list as $sl){ ?>
									<tr>
										<td style="display:none;"></td>
										<td><?= $sl['student_id'];?></td>
										<td class="text-capitalize"><?= $sl['student_name'];?></td>
										<td class="text-capitalize"><?= $sl['father_name'];?></td>
										<td class="text-capitalize"><?= $sl['mother_name'];?></td>
										<td class="text-capitalize"><?php if($sl['present_address']) { echo $sl['present_address'].', '; }; ?> 
										<?php if($sl['present_upazila']) { echo $upazila_list[array_search($sl['present_upazila'], array_column($upazila_list, 'id'))]['u_name'].', '; }; ?> 
										<?php if($sl['present_district']) { echo $district_list[array_search($sl['present_district'], array_column($district_list, 'id'))]['d_name'].', '; }; ?> 
										<?php if($sl['present_division']){ echo $division_list[array_search($sl['present_division'], array_column($division_list, 'id'))]['name']; }; ?>
										</td>
										<td class="text-capitalize"><?php if($sl['permanent_address']) { echo $sl['permanent_address'].', '; };?> 
										<?php if($sl['permanent_upazila']) { echo $upazila_list[array_search($sl['permanent_upazila'], array_column($upazila_list, 'id'))]['u_name'].', '; }; ?> 
										<?php if($sl['permanent_district']) { echo $district_list[array_search($sl['permanent_district'], array_column($district_list, 'id'))]['d_name'].', '; }; ?>
										<?php if($sl['permanent_division']) { echo $division_list[array_search($sl['permanent_division'], array_column($division_list, 'id'))]['name']; }; ?>
										</td>
										<td class="text-capitalize"><?= $sl['class_name'];?></br><?= $sl['section_name'];?></td>
										<td class="text-capitalize"><?= $sl['mobile_contact'];?></td>

										<!--<td><?= $sl['section_name'];?></td>-->
										<td class="text-capitalize"><?= $sl['roll_no'];?></td>
										<td class="text-capitalize"><?php if($sl['birth_date']){ echo date('d-m-Y',strtotime($sl['birth_date']));} ?></td>
										<!--<td><?= $sl['nationality'] ;?></td>-->
										<td><?php if(!empty($sl['student_image'])){ ?>
											<img class="zoom-image img-responsive center-block" src="<?= base_url()?>upload/student_image/<?= $sl['student_image'];?>" width="40" class="stu_image" />								
											<?php 

											}else{
											 
											?>
											<img class="zoom-image img-responsive center-block" src="<?= base_url() ?>template/assets/images/no_image.png" width="40" class="stu_image" /> 
											<?php  } ?>
										</td>
										<td>
											<a href="<?= base_url();?>admin/student_information_view/<?= $sl['student_id'];?>" title="View"><i class="fa fa-retweet"></i></a>
											| <a href="<?= base_url();?>admin/student_information_edit/<?= $sl['student_id'];?>" title="Edit"><i class="fa fa-edit"></i></a> |
											<a href="<?= base_url();?>admin/student_information_delete/<?= $sl['student_id'];?>" title="Delete" onclick="return confirm('Are You Want to Delete it?' );"><i class="fa fa-remove"></i></a> 
										</td>
									</tr>
									<?php 	} ?>
								</tbody>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>

<?php include 'application/views/includes/footer.php';?>
<script>
window.onload=function(){
	
	get_class_section_list(<?=$this->session->userdata('class_id')?>);
	get_class_group_list(<?=$this->session->userdata('class_id')?>);
}
function get_class_section_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'admin/section_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#section_id').html(html_data);
			$("#section_id").val($("#section_id option:first").val('all'));
			document.getElementById('section_id').value = '<?=$this->session->userdata('section_id')?>';
        }
    }
    });  
}
function get_class_group_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'academic/group_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#group_id').html(html_data);
			$("#group_id").val($("#group_id option:first").val('all'));
			document.getElementById('group_id').value = '<?=$this->session->userdata('group_id')?>';
        }
    }
    });  
}
</script>