<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>

<style>

</style>

<div class="content-page">			
    <div class="content">
        <!-- Page Heading Start -->
        <div class="page-heading">
            <h1><i class='fa fa-check'></i> Student Information View</h1>
        </div>
		<div class="panel panel-info" style="width:70%; margin:auto;">
			<div class="panel-heading">
				<span class="pull-center">Student Information</span>&nbsp;					
			</div>
			<legend>Personal Information</legend> 
            <div class="row">
            	<div class="col-sm-6 col-md-6">
            		Student Name: <?= $student_info['student_name'];?><br />
            		Date of Birth: <?= date('d F, Y',strtotime($student_info['birth_date']));?><br />
            		Age: <?= $student_info['age'];?><br />
            		Birth Certificate No: <?= $student_info['birth_cert_no'];?><br />
            		Nationality: <?= $student_info['nationality'];?><br />
            		Religion: <?php $religion=array('111'=>'Islam','112'=>'Hinduism','113'=>'Christianity','114'=>'Buddhism'); ?>
														<?= $religion[$student_info['religion']];?><br />
					Gender: <?= $student_info['gender'];?><br />
					SMS/Contact No: <?php echo $student_info['mobile_contact'];?><br />
					Blood Group: <?php echo $student_info['blood_group'];?>
            	</div>
            	<div class="col-sm-6 col-md-2 col-md-offset-2">
            	<img src="<?php echo base_url();?>upload/student_image/<?php echo $student_info['student_image'];?>" alt="" width="150"/>
            	</div>
            </div><hr>
            <div class="row">
            	<div class="col-sm-6 col-md-6">
            		Present Adress:<br />
            		Village/Town/Road/House/Flat: <?php echo $student_info['present_address'];?><br />
            		Post Office: <?php echo $student_info['present_po'];?><br />
            		Post Code: <?php echo $student_info['present_pc'];?><br />
            		P.S./Upazilla: <?php foreach($upazila_list as $ul){ if($student_info['present_upazila']==$ul['id'])echo $ul['u_name'];}?><br />
            		District: <?php foreach($district_list as $disl){ if($student_info['present_district']==$disl['id'])echo $disl['d_name'];}?><br />
            		Division: <?php foreach($division_list as $divl){ if($student_info['present_division']==$divl['id'])echo $divl['name'];}?><br />
            	</div>
            	<div class="col-sm-6 col-md-6">
            		Permanent Adress:<br />
            		Village/Town/Road/House/Flat: <?php echo $student_info['permanent_address'];?><br />
            		Post Office: <?php echo $student_info['permanent_po'];?><br />
            		Post Code: <?php echo $student_info['permanent_pc'];?><br />
            		P.S./Upazilla: <?php foreach($upazila_list as $ul){ if($student_info['permanent_upazila']==$ul['id'])echo $ul['u_name'];}?><br />
            		District: <?php foreach($district_list as $disl){ if($student_info['permanent_district']==$disl['id'])echo $disl['d_name'];}?><br />
            		Division: <?php foreach($division_list as $divl){ if($student_info['permanent_division']==$divl['id'])echo $divl['name'];}?><br />
            	</div>
            </div>
            <legend>Guardian's Information</legend>
            <div class="row">
            	<div class="col-sm-4 col-md-4">
            		<div> father</div>
            		Father's Name: <?php echo $student_info['father_name'];?><br />
            		Occupation: <?php echo $student_info['father_occupation'];?><br />
            		NID: <?php echo $student_info['father_nid'];?><br />
            		Education: <?php echo $student_info['father_education'];?><br />
            		Contact: <?= $student_info['father_home_contact'];?><br />
            		Email: <?= $student_info['father_email'];?><br />
            	</div>
            	<div class="col-sm-4 col-md-4">
					<div>Mother</div>
					Mother's Name: <?php echo $student_info['mother_name'];?><br />
            		Occupation: <?php echo $student_info['mother_occupation'];?><br />
            		NID: <?php echo $student_info['mother_nid'];?><br />
            		Education: <?php echo $student_info['mother_education'];?><br />
            		Contact: <?= $student_info['mother_home_contact'];?><br />
            		Email: <?= $student_info['mother_email'];?><br />
            	</div>
            	<div class="col-sm-4 col-md-4">
            		<div>Guardian</div>
            		Guardian Name: <?php echo $student_info['guardian_1_name'];?><br />
            		Relation: <?php echo $student_info['guardian_1_relation'];?><br />
            		Occupation: <?php echo $student_info['guardian_1_occupation'];?><br />
            		Yearly Income: <?php echo $student_info['guardian_1_yearly_income'];?><br />
            		Contact: <?php echo $student_info['guardian_1_mobile'];?><br />
            		Email: <?php echo $student_info['guardian_1_email'];?><br />
            	</div>
            </div>
            <legend>Academic Information</legend>
            <div class="row">
            	<div class="col-sm-4 col-md-4">
            		Class: <?php echo $student_info['class_name'];?><br />
            		Section: <?php echo $student_info['section_name'];?><br />
            		Group: <?php foreach($group_list as $gl){ if($student_info['group_id']==$gl['group_id'])echo $gl['group_name'];}?><br />
            		Session: <?php echo $student_info['session_name'];?><br />
            		Class roll: <?php echo $student_info['roll_no'];?><br />
            		Shift: <?php foreach($shift_list as $sl){ if($student_info['shift_id']==$sl['shift_id'])echo $sl['shift_name'];}?><br />            		
            	</div>
            	<div class="col-sm-4 col-md-4">

            	</div>
            </div>
            <legend>Attendance</legend>
            <div class="row">
	            <div class="col-md-12">
	            	<table class="table table-responsive table-striped">
	            		<thead>
	            			<tr>
	            				<th rowspan="2" class="text-center">Month-Year</th>
	            				<th colspan="3" class="text-center">Attendance</th>
	            			</tr>
	            			<tr>			
	            				<th>Present</th>
	            				<th>Absent</th>
	            				<th>Action</th>
	            			</tr>
	            		</thead>
	            		<tbody>
	            			<?php $months=array('01'=>'January','02'=>'February','03'=>'March','04'=>'April','05'=>'May','06'=>'June','07'=>'July','08'=>'August','09'=>'September','10'=>'October','11'=>'November','12'=>'December'); ?>
	            			<?php $i=1; foreach($att_details as $adl): ?>
	            			<tr>
	            				<td><?= $adl['Y'] ?> - <?= $months[$adl['M']];?></td>
	            				<td><?= $adl['present'] ?></td>                                  
	            				<td><?= $adl['absent'] ?></td>
	            				<td><a href="<?= base_url();?>attendance/student_monthly_details?month=<?= $adl['M'] ?>&year=<?= $adl['Y'] ?>&student_id=<?= $student_info['student_id'] ?>" class="btn btn-default">Details</a></td>
	            			</tr>
	            			<?php $i++; endforeach; ?>
	            		</tbody>
	            	</table>
	            </div>
            </div>
		</div>

<?php include 'application/views/includes/footer.php';?>

<script type="text/javascript">
function get_class_section_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'admin/section_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#section_id').html(html_data);
        }
    }
    });  
}
</script>

<!--For only numeric value can be typeable-->		
<script type="text/javascript">
	var specialKeys = new Array();
	specialKeys.push(8); //Backspace
	function IsNumeric(e) {
		var keyCode = e.which ? e.which : e.keyCode
		var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
		return ret;
	}
</script>