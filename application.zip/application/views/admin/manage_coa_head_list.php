<?php include 'application/views/includes/admin_header.php';?>
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
	<div class="content-page">
		<!-- ============================================================== -->
		<!-- Start Content here -->
		<!-- ============================================================== -->
		<div class="content">
			<div class="page-heading">
				<h1><i class='fa fa-table'></i> COA Head List</h1>
			</div>       
			
			<?php if($this->session->flashdata('message')):?>
				<div class="alert alert-success">
				<a href="#" class="close" data-dismiss="alert">&times;</a>
				<?=$this->session->flashdata('message')?>
			</div>
			<?php endif?>
				
			<div class="row">					
				<div class="col-md-12">
					<div class="widget">							
						<div class="widget-content">
						<br>					
							<div class="table-responsive">
									
								<form class='form-horizontal' role='form'>	
								<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
										<thead>
											<tr>
												<th>Account ID</th>
												<th>Account Name</th>
												<th>Account Type</th>
												<th>Description</th>
												<th>Action</th>
											</tr>
										</thead>
								 
										<tfoot>
											<tr>
												<th>Account ID</th>
												<th>Account Name</th>
												<th>Account Type</th>
												<th>Description</th>
												<th>Action</th>
											</tr>
										</tfoot>
								 
										<tbody>
											<?php
												foreach($coa_head_list as $sl){ ?>
												<tr>
													<td><?php echo $sl['id'];?></td>
													<td><?php echo $sl['ac_name'];?></td>
													<td><?php echo $sl['ac_type'];?></td>
													<td><?php echo $sl['description'];?></td>
													<td>
														<a href="<?php echo base_url();?>admin/manage_coa_head_edit/<?php echo $sl['id'];?>" title="Edit"><i class="fa fa-edit"></i></a> | <a onClick='return delete_alert("Are you sure Delete COA Head ????");' href="<?php echo base_url();?>admin/manage_coa_head_delete/<?php echo $sl['id'];?>" title="Delete"><i class="fa fa-remove"></i></a> 
													</td>
												</tr>
											<?php 	} ?>
										</tbody>
									</table>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
<?php include 'application/views/includes/footer.php';?>