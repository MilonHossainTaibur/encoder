<?php include 'application/views/includes/admin_header.php';?> <!--- Admin Header -->
<?php include 'application/views/includes/admin_sidebar.php';?> <!----Admin Sidebar -->
</div>
       
        <div class="content-page">			
            <div class="content">
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i>COA Head Edit</h1>
                </div>
				
				<?php if($this->session->flashdata('message')):?>
				<div class="alert alert-success">
					<a href="#" class="close" data-dismiss="alert">&times;</a>
					<?=$this->session->flashdata('message')?>
				</div>
				<?php endif?>

				
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="widget" style="min-height:500px;">
                            <div class="widget-content padding">
                                <form role="form" id="registerForm" name="registerForm" method="POST" action="<?php echo base_url();?>admin/manage_coa_head_edit_save" enctype="multipart/form-data">
									
									<div class="form-group">
										<ul class="list-inline">
											<li><a href="<?php echo base_url();?>admin/manage_coa_head" class="text-muted small">COA Create</a> </li> |
											<li><a href="<?php echo base_url();?>admin/manage_coa_head_list" class="text-muted small">COA List View</a> </li>
										</ul>
									</div>
									
									<div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <label>A/C Name <span style="color:red;">*</span></label>
                                                <input type="text" class="form-control" name="ac_name" id="ac_name" value="<?php echo $coa_head_edit['ac_name'];?>" required />
                                            </div>
                                            <?php
											$selected_debit="";
											$selected_credit="";
											if($coa_head_edit['ac_type'] == 'Debit'){
												$selected_debit='selected="selected"';
											}
											else if($coa_head_edit['ac_type'] == 'Credit'){
												$selected_credit='selected="selected"';
											}
											?>
											<div class="col-sm-6">
                                                <label>A/C Type <span style="color:red;">*</span></label>
                                                <select class="form-control" name="ac_type" id="ac_type" required>
                                                    <option value="">Select</option>
                                                    <option value="Debit" <?php echo $selected_debit;  ?>>Debit</option>
                                                    <option value="Credit" <?php echo $selected_credit; ?>>Credit</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>									
									
                                    <div class="form-group">
                                        <div class="row">
											<div class="col-sm-12">
                                                <label>Description</label>
                                                <textarea name="description" id="description" cols="30" rows="5" style="width:100%;resize:none"><?php echo $coa_head_edit['description'];?></textarea>
                                            </div>
                                        </div>
                                    </div>
									<input type="hidden" name="ac_id" value="<?php echo $coa_head_edit['id'];?>" />
									<button type="submit" class="btn btn-primary">Update</button>
								</form>
                            </div>
                        </div>
                    </div>
                </div>
				
				
<?php include 'application/views/includes/footer.php';?>