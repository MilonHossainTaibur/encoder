<!-- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

<!-- Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
<style>
.table > tbody > tr > td, .table > tbody > tr > th, .table > tfoot > tr > td, .table > tfoot > tr > th, .table > thead > tr > td, .table > thead > tr > th {
    padding-left: 5px;
    vertical-align: middle;
}
.table {
border-collapse: collapse;
	border-spacing: 0;
    width: 100%;
    max-width: 100%;
    margin-bottom: 0px;
}

td, th {
    border: 1px solid #000;
    padding: 5px;
}
</style>
<STYLE type="text/css">
		@page
		{
			size: portrait;
		}
		@media print{
			@page {
				size: portrait
			}
		}
		@media print{
			.class-name{
			@page{
				size:portrait;
			}
		}
		}
		table thead tr>th{
			text-align: center;
		}
	</STYLE>
	<STYLE type="text/css" media="print">
		@page { size: portrait; }
	</STYLE>
<div class="content-page">
    <div class="content">
        <!-- Page Heading Start -->
        <div class="page-heading">
            <h1><i class='fa fa-table'></i> Students List </h1>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="widget" style="min-height: 400px">
					<div class="widget-content">
						<div class="widget-content padding">
							<div class="form-group">
								<div class="row">
									<div class="col-sm-3 col-md-3">
										<label>Class <span style="color:red;">*</span></label>
										<select class="form-control" name="class_id" id="class_id">
											<option value="">-----Select Class-----</option>
											<?php foreach($class_list as $cl){ ?>
											<option value="<?= $cl['class_id'];?>" id="<?= $cl['class_short_form'];?>"><?php echo $cl['class_name'];?></option>
											<?php } ?>
										</select>
									</div>
									<div class="col-sm-3 col-md-3">
										<label>Year <span style="color:red;">*</span></label>
										<select class="form-control" name="year_id" id="year_id">
											<option value="">----Select Year----</option>
											<?php foreach($stusession_id as $cl){ ?>
											<option value="<?= $cl['session_name'];?>" ><?= $cl['session_name'];?></option>
											<?php } ?>
										</select>
									</div>
								</div>
							</div><br />
							<button class="btn btn-success btn-label-center" onclick="student_class_roll_json()" type="button"> View </button>
                            <hr />
							<div id="display">
								<!-- content will display here -->
							</div>
						</div><!--//section-content-->
					</div><!--//news-wrapper-->
				</div><!--//page-row-->
			</div><!--//page-content-->
		</div><!--//page-wrapper-->
<!--div class="print_button">
	<br/>
	<input type="button" class="btn btn-primary" onClick="PrintElem('print_area')" value="Print"/>
</div-->
<?php include 'application/views/includes/footer.php';?>

	<script>
	function student_class_roll_json(){
		$('#display').html('');
		var class_id = $('#class_id').val();
		var class_name = $('#class_id :selected').text();
		var year_id = $('#year_id').val();
		var year = $('#year_id option:selected').text();

		if(!class_id)
		{
			$('#class_id').after("<div id='validation_class' class='validation_js'>Please select a class.</div>")
				$('#validation_class').delay(3000).hide('slow');
				return;

		}
		if(!year_id)
		{
			$('#year_id').after("<div id='validation_year_id' class='validation_js'>Please select a year.</div>")
				$('#validation_year_id').delay(3000).hide('slow');
				return;

		}

		$.ajax({
		url: baseUrl+'admin/admission_student_mark_entry_json',
		data:
			{
				'class_id':class_id,
				'class_name':class_name,
				'year_id':year_id,
				'year':year
			},
			dataType: 'json',
			success: function(data)
			{
				result                = ''+data['result']+'';
				mainContent           = ''+data['mainContent']+'';

				if(result == 'success')
				{
					$('#display').html(mainContent);
				}
			}
		});
	}

	function PrintElem(elem)
	{
		var mywindow = window.open('', 'PRINT', 'width=650,height=900');

		mywindow.document.write('<html><head><title>' + document.title  + '</title>');
		mywindow.document.write('</head><body >');
		mywindow.document.write('<span>' + document.title  + '</span>');
		mywindow.document.write(document.getElementById(elem).innerHTML);
		mywindow.document.write('</body></html>');

		mywindow.document.close(); // necessary for IE >= 10
		mywindow.focus(); // necessary for IE >= 10*/

		mywindow.print();
		mywindow.close();

		return true;
	}
	</script>

