<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
<div class="content-page">			
    <div class="content">
        <!-- Page Heading Start -->
        <div class="page-heading">
            <h1><i class='fa fa-check'></i> Teachers/Staff Salary Structure View</h1>
        </div>
        <!-- Page Heading End-->
        <!-- Your awesome content goes here -->
        <div class="row">
            <div class="col-sm-12">
                <div class="widget" style="min-height:500px;">
                    <div class="widget-content padding">
						<div class="form-group">
                            <div class="row">
                                <div class="col-sm-12">
                                    <center>
                                        <h2><?= urldecode($teacher_details['teacher_name'])?></h2>
                                        <h4><?= urldecode($teacher_details['department_name'])?></h4>
                                        <h4><?= urldecode($teacher_details['designation_name'])?></h4>
                                    </center>
                                </div>
                            </div>
                        </div>
						<div class="form-group">
                            <div class="row">
                                <div class="col-sm-12 col-md-6 col-md-offset-3">
								<form method="POST" action="<?= base_url();?>admin/salary_structure_edit_save">
									<table class="table table-striped table-bordered" cellspacing="0">
										<tr>
											<td><label>Teacher/Staff Name</label></td>
											<td>
												<select class="form-control" name="teacher_id" id="teacher_id">
                                                    <option value="">----Select Teacher/Staff----</option>
                                                    <?php foreach($teacher_list as $tl){ ?> 
                                                    <option value="<?php echo $tl['teacher_id'];?>"
														<?php if($teacher_id == $tl['teacher_id']){ echo "selected"; }?>><?= $tl['teacher_name'];?></option>
                                                    <?php } ?>
                                                </select>
											</td>
										</tr>
										<?php $total=0; if($salary_list): foreach($salary_list as $sl): ?>
										<tr>
											<td><b><?= $sl['salary_particulars']?></b></td>
											<td>
											<input type="text" class="form-control salary_particulars" id="<?= $sl['effect']?>" name="amount[]" onkeyup="totalsalary()" value="<?= $sl['amount']?>">
											<input type="hidden" name="effect[]" value="<?= $sl['effect']?>" />
											<input type="hidden" name="salary_particulars[]" value="<?= $sl['id']?>" />
											<input type="hidden" name="teacher_salary_id[]" value="<?= $sl['teacher_salary_id']?>" />
											<?php if( $sl['effect']=="+") $total+=$sl['amount']; else $total-=$sl['amount'];?></td>
										</tr>
										<?php endforeach; endif; ?>
										<tr>
											<td><b>Total</b></td>
											<td id="total"><?= $total ?></td>
										</tr>
										<tr>
											<td></td>
											<td><button type="submit" class="btn btn-primary" style="margin-top:25px;" onclick="">Save</button></td>
										</tr>
									</table>
								</form>
								</div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php include 'application/views/includes/footer.php';?>
<script type="text/javascript">

function totalsalary(){
	var total=0;
	$( ".salary_particulars" ).each(function() {
		// particulars value
		var field1=$(this).val();
		if(field1=="" || field1!=parseFloat(field1)) field1=0;
		// add or reduce value
		if($(this).attr("id")=="-")
		total -=parseFloat(field1);
		else
		total +=parseFloat(field1);
	});
	$( "#total" ).text(total);
}
</script>
