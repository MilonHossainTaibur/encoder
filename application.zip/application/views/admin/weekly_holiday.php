<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>

<div class="content-page">			
            <div class="content">
             <?php if($this->session->flashdata('message')):?>
			<div class="alert alert-success">
				<a href="#" class="close" data-dismiss="alert">&times;</a>
				<?=$this->session->flashdata('message')?>
			</div>
			<?php endif?>
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i> Weekly Holiday Set</h1>
                </div>
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="widget" style="min-height:300px;">
                           <?php echo $this->session->flashdata('success_msg'); ?>
                            <div class="widget-content padding">
                                <form role="form" id="registerForm" method="POST" action="<?php echo base_url();?>admin/weekly_holiday_update" enctype="multipart/form-data">
                                
<div class="form-group">
    <div class="row">
        <div class="col-sm-1"></div>
            <div class="col-sm-10">
                <table class="table table-striped table-bordered dataTable"> 
                    <tr>
                        <td>Week Holiday Name</td>
                        <td>Week class day Name</td>
                        <td>status</td>
                        
                    </tr>                
            <?php
               $is=0;
                    foreach($week_day as $wd)
                    {
                        #$school_id = $_SESSION['school_id'];
                        $school_id = 1;
                        $w_day_id = $wd['id'];        

                        $sqlw = "SELECT * FROM tbl_weekdays WHERE school_id = $school_id AND id = $w_day_id LIMIT 1";
                        $queryw = $this->db->query($sqlw);
                        $roww = $queryw->row_array();
                        if($roww['status']==0)
                        {
                            $checked = 'checked="checked"';
							$checked1 = '';
							$onoff= 'Holiday';
                        }
                        else 
                        {
                            $checked = '';
							$checked1 = 'checked="checked"';
							$onoff= 'Class Day';
                        }
                    ?>
                        <tr>
                            <td>
                                <input type="checkbox" <?php echo $checked?> name="status[]" class="aaa" value="0"/> <?php echo $wd['day'];?>
                            </td>
                            <td>
                                <input type="checkbox" <?php echo $checked1?> name="status[]" class="aaa" value="1"/> <?php echo $wd['day'];?>
                            </td>
                            <td>
                                <?php 
                                    echo $onoff;
                                ?>
                                <input type="hidden" name="id[]" value="<?php echo $wd['id'];?>">
                            </td>
                            
                        </tr>
                        <?php   }    ?>
                    </table>
                </div>
            </div>
        </div>

        <br/><br/>
        <div class="form-group">
            <div class="row">
                <div class="col-sm-2"></div>
                <div class="col-sm-4">
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </div>
        </div>  
       </form>
                            </div>
                        </div>
                    </div>
                </div>
				  
<?php include 'application/views/includes/footer.php';?>
<script>
function ck()
{
	$('.aaa').each(function()
								{
									var clPeriod=$(this).val();
									alert(clPeriod)
								});
}
</script>