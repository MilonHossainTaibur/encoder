

<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
<div class="content-page">
<div class="content">
<div class="page-heading">
   <h1><i class="fa fa-video-camera" aria-hidden="true"></i>
 Video Gallery</h1>
      <hr>
   <!-- Button trigger modal -->
   <a class="btn btn-info" href="<?= base_url();?>web/video_create">
   <i class="fa fa-plus-square" aria-hidden="true"> Add New</i>
   </a>
</div>
<?php if($this->session->flashdata('message')):?>
<?=$this->session->flashdata('message')?>
<?php endif?>
<div class="row">
   <div class="col-sm-12">
      <div class="widget" style="min-height:500px;">
         <div class="widget-content padding">
            <div class="row">
               <div class="col-md-12">
                  <div class="widget">
                     <div class="widget-content">
                        <table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
                           <thead>
                              <tr>
                                 <th> ID</th>
                                 <th>Title</th>
                                 <th>Video</th>
                                 <th>Body</th>
                                 <th>Status</th>
                                 <th>Action</th>
                              </tr>
                           </thead>
                           <tbody>
                              <?php foreach($videos as $video){ ?>
                              
                              <tr>
                                 <td><?= $video['id'];?></td>
                                 <td><?= $video['title'];?></td>
                                 <td><iframe width="200" height="auto" src="https://www.youtube.com/embed/<?= $video['video_url'];?>"></iframe>
                                 </td>
                                 <td><?= $video['body'];?></td>
                                 <td><?php if($video['status']==1) {echo "<a class='btn btn-sm btn-success'>Active</a>";}else{echo "<a class='btn btn-sm btn-success'>Inactive</a>";} ?></td>
                                 <td>
                                    <a class="btn btn-success btn-sm" href="<?= base_url();?>web/edit_video/<?= $video['id'];?>" ><i class="fa fa-edit"></i></a>
                                    <a class="btn btn-danger btn-sm" href="<?= base_url();?>web/video_delete/<?= $video['id'];?>" title="Delete" onclick="return confirm('Are You Want to Delete it?' );"><i class="fa fa-remove"></i></a></a>
                                 </td>
                              </tr>
                              <?php    } ?>
                             
                           </tbody>
                        </table>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php include 'application/views/includes/footer.php';?>

