<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
	<div class="content-page">
		
		<div class="content">
			<div class="page-heading">
            	<h1><i class="fa fa-video-camera" aria-hidden="true"></i>
 Video Gallery</h1>
			</div>
            <?php if($this->session->flashdata('message')):?>
				<?=$this->session->flashdata('message')?>
			<?php endif?>
			<div class="row">
                <div class="col-sm-12">
                    <div class="widget" style="min-height:500px;">
                        <div class="widget-content padding">
                            <div class="row">				
                                <div class="col-md-12">
                                    <form role="form" id="ct_entry" name="ct_entry" method="POST" action="<?php echo base_url();?>web/video_save">
													<div class="form-group row">
														<div class="col-md-12">
															<label for="title" class="">Heading</label>
														<input type="text" class="form-control" name="title" id="title" required />
														</div>
                                                    </div>
                                                    <div class="form-group row">
														<div class="col-md-6">
															<label for="url" class="">video Url</label>
														<input type="text" class="form-control" name="url" id="url" required />
														</div>
                                                    </div>
           													<div class="form-group">
														<label for="body">Details</label>
														<textarea class="form-control" rows="5" id="body" name="body" style="min-height:300px;"></textarea>
													</div>
													<div class="form-group">
														<button type="submit" class="btn btn-success btn-block">Save</button>
													</div>
												</form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

<?php include 'application/views/includes/footer.php';?>
<script type="text/javascript">

window.onload = function () {
	// Create Wysiwig editor for textare
	TinyMCEStart('#body', null);
	TinyMCEStart('#wysiwig_full', 'extreme');
};
</script>