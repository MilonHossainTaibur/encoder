<style>
    html, body, div, span, iframe, p,
    a, form,table, tbody, tfoot, thead, tr, th, td{
        margin: 0;
        padding: 0;
        border: 0;
        font: inherit;
        vertical-align: baseline;
    }
    body {
        line-height: 1;
        font-size: 14px;
        font-family: "Times New Roman", Times, serif;
    }
    .table > tbody > tr > td, .table > tbody > tr > th, .table > tfoot > tr > td, .table > tfoot > tr > th, .table > thead > tr > td, .table > thead > tr > th {
        padding-left: 5px;
        vertical-align: middle;
    }
    .table {
        border-collapse: collapse;
        border-spacing: 0;
        width: 100%;
        max-width: 100%;
        margin-bottom: 0px;
    }
    td, th {
        border: 1px solid #000;
        padding: 5px;
    }
    .no-border td {
        border: 0px!important;
    }

    .uppercase {
        text-transform: uppercase;
    }
    .name {
        font-size: 25px;
        padding-bottom: 10px;
    }

    .center {
        text-align: center!important;
    }
    .left {
        text-align: left!important;
    }
    .right{
        text-align: right!important;
    }
    .student-info {
        width: 60%;
        float: left;
        min-height: 100px;
        clear: both;
    }
    .remark span{
        position: absolute;
        bottom: -2px;
    }
    .gpa-info {
        width: 40%;
        float: right;
    }
    .mark-col-1,.mark-col-3,.mark-col-2 {
        float: left;
        overflow: hidden;
        border-right: 1px dotted #000;
        min-height:80px;
    }
    .mark-col-3{
        border-right: 0px;
    }
    .mark-col-4{
        float: left;
        overflow: hidden;
        min-height:80px;
    }

    .transcript-title {
        /*background-color: rgba(24, 137, 203, .5);*/
        font-weight: 600;
        font-size: 20px;
        border-bottom: 2px solid #000;
        width: 270px;

    }
    .info p {
        padding-bottom: 5px;
    }
    .col-1 p,
    .col-2 p,
    .col-3 p,
    .col-4 p {
        border-top:2px solid #000;
        margin-top: 90px;
        padding-top: 5px;
        text-align: center;

    }

    .transcript-bottom {
        margin-top: 5px;
    }

    .col-1 {
        width: 18%;
        float: left;
        min-height: 110px;
        margin-left: 1%;
        margin-right: 1%;
    }

    .col-2 {
        width: 18%;
        float: left;
        min-height: 110px;
        margin-left: 1%;
        margin-right: 1%;
    }

    .col-4 {
        width: 18%;
        float: right;
        height: 110px;
        margin-left: 1%;
        margin-right: 1%;
    }

    .col-3 {
        width: 36%;
        height: 110px;
        margin-left: 2%;
        margin-right: 2%;
    }

    .col-1,
    .col-2,
    .col-3,
    .col-4 {
        display: inline-block;
        position: relative;
    }

    .gpa-info {
        float: right;
    }
    .info {
        width: 40%;
        float: left;
    }

    .student-info {
        width: 60%;
        min-height: 100px;
        clear: both;

        position:relative;
    }
    @page {
        size:  21.0cm 29.7cm ;
    }
    .school-info{
        position:relative;
        text-align:center;}

    .logo {
        position: absolute;
        top: 30px;
        left: 10px;*/
    }
    .student-photo {
    position: absolute;
    right: 0;
    top: 30px;
}
    .logo img {
        width: 100px;
        height: 100px;
        
    }
    .student-photo img {
        width: 100px;
        height: 110px;
    }
    .main-content {
        float:left;
        width: 100%;
    }
    .print_break{
        page-break-after: always;
    }

</style>


<div class="print_button pull-left padding" style="float:left; width: 100%">
    <input type="button " class="btn btn-primary " onClick="printPageArea('display') " value="Print"/>
    <br/>
</div>
<?php foreach($std_transcripts as $k=>$std_trans){
    $school_info        = $std_trans['std_transcript']['school_info'];
    $student_info       = $std_trans['std_transcript']['student_info'];
    $student_mark_info  = $std_trans['std_transcript']['student_mark_info'];
    $optional           = $std_trans['std_transcript']['optional'];
    $optional_sub_id    = $std_trans['std_transcript']['optional_sub_id'];
    $details            = $std_trans['std_transcript']['details'];
    $max_mark           = $std_trans['std_transcript']['max_mark'];
    $grd_system         = $std_trans['std_transcript']['grd_system'];
    $ranks              = $std_trans['std_transcript']['ranks'];
    $ranks_by_gpa       = $std_trans['std_transcript']['ranks_by_gpa'];
?>

<div class="main-content">
    <div class=""><!--table-responsive-->
        <div class="school-info" style="width:100%">

            <div class="info" style="width:100%;">
                <h2 style="text-transform:uppercase;line-height:20px; margin:0 auto;font-size:20px;font-weight: 600;"><?= $school_info['school_name'];?></h2>
                <h3 style="line-height:27px; margin:0 auto;font-size: 18px;font-weight: 500;">
                    <?= $school_info['address'];?>, <?= $school_info['district'];?>.</h3>
                <h4 style="line-height:22px; margin:0 auto;font-size: 18px;font-weight: 400;">E-mail:
                    <?= $school_info['email'];?></h4>
                <h5 style="line-height:20px; margin:0 auto;font-size: 16px;font-weight: 400;"><?= $school_info['website'];?></h5>
                <h5 class="exam-type" style="line-height:25px; margin:0 auto;font-size: 20px;font-weight: 400;">Term: <?= $details['term_name']; ?></h5>
                <h2 class="transcript-title" style="margin:0 auto;line-height:25px;padding-bottom: 8px">Academic Transcript</h2>
            </div>
            <div class="logo" style="">
                <img src="<?= base_url(); ?>upload/institute_logo/<?= $school_info['logo'];?>" alt="" height="100" width="100" />
            </div>
            <?php if(!isset($public_flag)){
                if(!empty($student_info['student_image'])){$std_img = 'upload/student_image/'.$student_info['student_image'];}
                else{$std_img = 'template/assets/images/no_image.png';}
                ?>
                <div class="student-photo" style="">
                    <img style="border: 2px solid gray;" src="<?php echo base_url().$std_img;?>" alt="Student Photo">
                </div>
            <?php }?>


        </div>

    </div><!--/.student-info-->

    <!--<div style="height:36px; width:100%">&nbsp;</div>-->
    <div class="new-div" style="width:100%;clear:both;">
        <p style="padding-left:5px"> Session/Year: <?= $details['session']; ?></p>
        <div class="student-info" style="width: 65%;">

            <table class="table table-striped" width="90%">
                <tr  class="no-border">
                    <td>Name of Student</td>
                    <td>:</td>
                    <td class="uppercase">
                        <?= $student_info['student_name']; ?>
                    </td>
                </tr>
                <tr class="no-border">
                    <td>Father's Name</td>
                    <td>:</td>
                    <td class="uppercase"><?= $student_info['father_name']; ?></td>
                </tr>
                <tr class="no-border">
                    <td>Mother's Name</td>
                    <td>:</td>
                    <td class="uppercase"><?= $student_info['mother_name']; ?></td>
                </tr>
                <tr class="no-border">
                    <td>Student ID</td>
                    <td>:</td>
                    <td>
                        <?= $student_info['student_id']; ?>
                    </td>
                </tr>
                <tr class="no-border">
                    <td>Class</td>
                    <td>:</td>
                    <td>
                        <?= $student_info['class_name']; ?>
                    </td>
                </tr>
                <tr class="no-border">
                    <td>Roll No.</td>
                    <td>:</td>
                    <td>
                        <?= $student_info['roll_no']; ?>
                    </td>
                </tr>
                <tr class="no-border">
                    <td>Section</td>
                    <td>:</td>
                    <td>
                        <?= $student_info['section_name']; ?>
                    </td>
                </tr>
                <tr class="no-border">
                    <td>Group</td>
                    <td>:</td>
                    <td><?= $student_info['group_name']; ?></td>
                </tr>
            </table>

        </div>
        <div class="gpa-info" style="width: 35%; margin-bottom: 10px;">
            <table width="100%" class="table table-striped">
                <tr>
                    <th class="center">Letter Grade</th>
                    <th class="center">Class Interval</th>
                    <th class="center">Grade Point</th>
                </tr>
                <tbody>
                <?php foreach($grd_system as $gp){ ?>
                    <tr class="center">
                        <td class="center">
                            <?= $gp['gpa'] ?>
                        </td>
                        <td class="center">
                            <?=$gp['start_marks'].' - '.$gp['end_marks']?>
                        </td>
                        <td class="center">
                            <?= $gp['grd_point'] ?>
                        </td>
                    </tr>
                <?php } ?>
                </tbody>

            </table>

        </div>
    </div>
    <!--/new-div-->


    <?php $final_status=0; $total=0; $totalbn=0; $totalpasbn=0; $totalen=0; $totalpasen=0; $getbn=0; $geten=0; $total_gpa=0; $getbnsub=0; $getbnobj=0; $getbnsubpass=0; $getbnobjpass=0; ?>

    <table class="table table-striped table-bordered" cellspacing="0" border="1" width="100%">
        <thead>
        <tr>
            <th class="center" style="width:40%">Subject Name</th>
            <th style="max-width:35px;"  class="center">Full Marks</th>
            <th style="max-width:35px;"  class="center">Pass Marks</th>
            <th class="center">Sub</th>
            <th class="center">Obj</th>
            <th class="center">Prac</th>
            <?php $extd=0; $ca=0; if(explode('*',$student_mark_info[0]['ca'])[0]){ $ca=1; $extd++; ?>
                <th>CA</th>
            <?php } ?>
            <?php $cw=0; if(explode('*',$student_mark_info[0]['cw'])[0]){ $cw=1; $extd++;  ?>
                <th>CW</th>
            <?php } ?>
            <?php $hw=0; if(explode('*',$student_mark_info[0]['hw'])[0]){ $hw=1; $extd++; ?>
                <th>HW</th>
            <?php } ?>
            <?php $ct=0; if(explode('*',$student_mark_info[0]['ct'])[0]){  $ct=1; $extd++; ?>
                <th>CT</th>
            <?php } ?>
            <?php $aspj=0; if(explode('*',$student_mark_info[0]['aspj'])[0]){  $aspj=1; $extd++; ?>
                <th>AS/PJ</th>
            <?php } ?>
            <th class="center">Total</th>
            <th style="max-width:40px;" class="center">Highest Marks</th>
            <th class="center">GP</th>
            <th class="center">Grade</th>
        </tr>
        </thead>
        <tbody>
        <?php   $total_marks=0; $optional_sub_flag = 0;
        foreach($student_mark_info as $sl):
            $total_marks=$total_marks+$sl['f_mark'];
            ?>
            <tr>
                <td><?php echo $sl['subject_name']; if($optional_sub_id['subject_id']==$sl['subject_id']) echo ' (Optional)';?></td>
                <td class="center"><?= $sl['f_mark'];?></td>
                <td class="center"><?= round($sl['p_mark']*$sl['f_mark']/100); ?></td>
                <td class="center">
                    <?php
                    if(explode('*',$sl['sub'])[0]):
                        $p_ms=explode('*',$sl['sub'])[1]*$sl['p_mark']/100;

                        $flag=0;
                        if($sl['pass_id']==1):
                        if($optional_sub_id['subject_id']==$sl['subject_id']): echo explode('*',$sl['sub'])[0];else:
                            if(explode('*',$sl['sub'])[1]>0 && round(explode('*',$sl['sub'])[0]) < round($p_ms)):
                                ?>
                                <span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"><?= explode('*',$sl['sub'])[0]; ?></span>
                                <?php $flag=1; $final_status=1; ?>
                            <?php else: ?>
                                <?= explode('*',$sl['sub'])[0]; ?>
                            <?php endif; endif; ?>
                        <?php else: ?>
                            <?= explode('*',$sl['sub'])[0]; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                </td>
                <td class="center">
                    <?php
                    if(explode('*',$sl['obj'])[0]):

                        //$term_pass_mark_obj = explode('*',$sl['obj'])[0]*100/explode('*',$sl['obj'])[1];
                        $p_mo=explode('*',$sl['obj'])[1]*$sl['p_mark']/100;
                        if($sl['pass_id']==1):
                        if($optional_sub_id['subject_id']==$sl['subject_id']): echo explode('*',$sl['obj'])[0];else:
                            if(explode('*',$sl['obj'])[1]>0 && round(explode('*',$sl['obj'])[0]) < round($p_mo)):
                                ?>
                                <span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"><?= explode('*',$sl['obj'])[0]; ?></span>
                                <?php $flag=1; $final_status=1; ?>
                            <?php else: ?>
                                <?= explode('*',$sl['obj'])[0]; ?>
                            <?php endif; endif; ?>
                        <?php else: ?>
                            <?= explode('*',$sl['obj'])[0]; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                </td>
                <td class="center">
                    <?php
                    if(explode('*',$sl['prac'])[0]):

                        //$term_pass_mark_prac = explode('*',$sl['prac'])[0]*100/explode('*',$sl['prac'])[1];
                        $p_mp=explode('*',$sl['prac'])[1]*$sl['p_mark']/100;
                        if($sl['pass_id']==1):
                        if($optional_sub_id['subject_id']==$sl['subject_id']): echo explode('*',$sl['prac'])[0];else:
                            if(explode('*',$sl['prac'])[1]>0 && round(explode('*',$sl['prac'])[0]) < round($p_mp)):
                                ?>
                                <span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"><?= explode('*',$sl['prac'])[0]; ?></span>
                                <?php $flag=1; $final_status=1; ?>
                            <?php else: ?>
                                <?= explode('*',$sl['prac'])[0]; ?>
                            <?php endif; endif;?>
                        <?php else: ?>
                            <?= explode('*',$sl['prac'])[0]; ?>
                        <?php endif; ?>
                    <?php endif; ?>
                </td>
                <?php if($ca==1){ ?>
                    <td class="center">
                        <?php
                        //$term_pass_mark_ca = explode('*',$sl['ca'])[0]*100/explode('*',$sl['ca'])[1];
                        $p_mca=explode('*',$sl['ca'])[1]*$sl['p_mark']/100;
                        if($sl['pass_id']==1){
                            if(explode('*',$sl['ca'])[1]>0 && round(explode('*',$sl['ca'])[0]) < round($p_mca)){
                                ?>
                                <span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"><?= explode('*',$sl['ca'])[0]; ?></span>
                                <?php $flag=1; $final_status=1; ?>
                            <?php }else{ ?>
                                <?= explode('*',$sl['ca'])[0]; ?>
                            <?php } ?>
                        <?php }else{ ?>
                            <?= explode('*',$sl['ca'])[0]; ?>
                        <?php }; ?>
                    </td>
                <?php } ?>
                <?php if($cw==1){ ?>
                    <td class="center">
                        <?php
                        //$term_pass_mark_cw = explode('*',$sl['cw'])[0]*100/explode('*',$sl['cw'])[1];
                        $p_mcw=explode('*',$sl['cw'])[1]*$sl['p_mark']/100;
                        if($sl['pass_id']==1){
                            if(explode('*',$sl['cw'])[1]>0 && round(explode('*',$sl['cw'])[0]) < round($p_mcw)){
                                ?>
                                <span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"><?= explode('*',$sl['cw'])[0]; ?></span>
                                <?php $flag=1; $final_status=1; ?>
                            <?php }else{ ?>
                                <?= explode('*',$sl['cw'])[0]; ?>
                            <?php } ?>
                        <?php }else{ ?>
                            <?= explode('*',$sl['cw'])[0]; ?>
                        <?php }; ?>
                    </td>
                <?php } ?>
                <?php if($hw==1){ ?>
                    <td class="center">
                        <?php
                        //$term_pass_mark_hw = explode('*',$sl['hw'])[0]*100/explode('*',$sl['hw'])[1];
                        $p_mhw=explode('*',$sl['hw'])[1]*$sl['p_mark']/100;
                        if($sl['pass_id']==1){
                            if(explode('*',$sl['hw'])[1]>0 && round(explode('*',$sl['hw'])[0]) < round($p_mhw)){
                                ?>
                                <span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"><?= explode('*',$sl['hw'])[0]; ?></span>
                                <?php $flag=1; $final_status=1; ?>
                            <?php }else{ ?>
                                <?= explode('*',$sl['hw'])[0]; ?>
                            <?php } ?>
                        <?php }else{ ?>
                            <?= explode('*',$sl['hw'])[0]; ?>
                        <?php }; ?>
                    </td>
                <?php } ?>
                <?php if($ct==1){ ?>
                    <td class="center">
                        <?php
                        //$term_pass_mark_ct = explode('*',$sl['ct'])[0]*100/explode('*',$sl['ct'])[1];
                        $p_mct=explode('*',$sl['ct'])[1]*$sl['p_mark']/100;
                        if($sl['pass_id']==1){
                            if(explode('*',$sl['ct'])[1]>0 && round(explode('*',$sl['ct'])[0]) < round($p_mct)){
                                ?>
                                <span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"><?= explode('*',$sl['ct'])[0]; ?></span>
                                <?php $flag=1; $final_status=1; ?>
                            <?php }else{ ?>
                                <?= explode('*',$sl['ct'])[0]; ?>
                            <?php } ?>
                        <?php }else{ ?>
                            <?= explode('*',$sl['ct'])[0]; ?>
                        <?php }; ?>
                    </td>
                <?php } ?>
                <?php if($aspj==1){ ?>
                    <td class="center">
                        <?php
                        //$term_pass_mark_aspj = explode('*',$sl['aspj'])[0]*100/explode('*',$sl['aspj'])[1];
                        $p_maspj=explode('*',$sl['aspj'])[1]*$sl['p_mark']/100;
                        if($sl['pass_id']==1){
                            if(explode('*',$sl['aspj'])[1]>0 && round(explode('*',$sl['aspj'])[0]) < round($p_maspj)){
                                ?>
                                <span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"><?= explode('*',$sl['aspj'])[0]; ?></span>
                                <?php $flag=1; $final_status=1; ?>
                            <?php }else{ ?>
                                <?= explode('*',$sl['aspj'])[0]; ?>
                            <?php } ?>
                        <?php }else{ ?>
                            <?= explode('*',$sl['aspj'])[0]; ?>
                        <?php }; ?>
                    </td>
                <?php } ?>
                <td class="center">
                    <?php
                    if($sl['subject_code']==102 || $sl['subject_code']==101){
                        $getbnsub+=$sl['sub'];
                        $getbnobj+=$sl['obj'];
                        $getbnsubpass+=round(explode('*',$sl['sub'])[1]*$sl['p_mark']/100);
                        $getbnobjpass+=round(explode('*',$sl['obj'])[1]*$sl['p_mark']/100);
                        //
                        $getbn+=$sl['sub_total'];
                        $totalbn+=$sl['f_mark'];
                        $totalpasbn+=$sl['p_mark'];
                    }
                    elseif($sl['subject_code']==107 || $sl['subject_code']==108){
                        $geten+=$sl['sub_total'];
                        $totalen+=$sl['f_mark'];
                        $totalpasen+=$sl['p_mark'];
                    }
                    else{
                        // check if class is nine or higher
                        if($details['class_short_form'] >= 11){
                            if($sl['subject_code']==$optional){
                                $total+=($sl['sub_total']-40 < 0 ? 0 : $sl['sub_total']-40);
                                $total_gpa+=($sl['gpa']-2 < 0 ? 0 : $sl['gpa']-2);
                                $total_f_mark+=0;
                            }
                            else{
                                $total+=$sl['sub_total'];
                                $total_gpa+=$sl['gpa'];
                                $total_f_mark+=$sl['f_mark'];
                            }
                        }else{
                            if($sl['subject_code'] == explode(',',$optional)[0] || $sl['subject_code'] == explode(',',$optional)[1]){
                                $total+=($sl['sub_total']-40 < 0 ? 0 : $sl['sub_total']-40);
                                $total_gpa+=($sl['gpa']-2 < 0 ? 0 : $sl['gpa']-2);
                                $total_f_mark+=0;
                            }
                            else{
                                if($optional_sub_id['subject_id']==$sl['subject_id']){
                                    $total+=$sl['sub_total'];
                                    if($sl['gpa']>2){$total_gpa+=$sl['gpa']-2;}
                                    $total_f_mark+=$sl['f_mark'];
                                    $optional_sub_flag = 1;
                                }else{
                                    $total+=$sl['sub_total'];
                                    $total_gpa+=$sl['gpa'];
                                    $total_f_mark+=$sl['f_mark'];
                                }
                            }
                        }
                    }

                    $total_term= explode('*',$sl['sub'])[1]+explode('*',$sl['obj'])[1]+explode('*',$sl['prac'])[1];
                    $term_pass_mark_get_per =$sl['p_mark']*$total_term/100;
                    if($sl['sub_total'] < $term_pass_mark_get_per || $flag==1): ?>
                        <span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"><?= $sl['sub_total']; ?></span>
                        <?php if($sl['subject_code'] == 102 || $sl['subject_code'] == 101 || $sl['subject_code']==107 || $sl['subject_code']==108 || ($optional_sub_id['subject_id']==$sl['subject_id'])){}else{ $final_status=1;} ?>
                    <?php else: ?>
                        <?= $sl['sub_total']; ?>
                    <?php endif; ?>
                </td>
                <td class="center">
                    <?= $max_mark[array_search($sl['subject_id'], array_column($max_mark, 'subject_id'))]['max_mark']  ?>
                </td>
                <td class="center">
                    <?php if($sl['subject_code'] == 102 || $sl['subject_code'] == 101 || $sl['subject_code']==107 || $sl['subject_code']==108){
                    }else{ $f_fail=0; if($optional_sub_id['subject_id']==$sl['subject_id']){ echo $sl['gpa'];}else{
                        if($sl['gpa'] <= 0 || $flag==1){ $f_fail=1; ?>
                            <span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;">0</span>
                            <?php $final_status=1; ?>
                        <?php } else{ ?>
                            <?= $sl['gpa']; ?>
                        <?php }}} ?>
                </td>
                <td class="center">
                    <?php if($sl['subject_code'] == 102 || $sl['subject_code'] == 101 || $sl['subject_code']==107 || $sl['subject_code']==108){
                    }else{ if($f_fail==1){?>
                        <span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;">F</span>
                        <?php $final_status=1; ?>
                    <?php } else{ ?>
                        <?= $grd_system[array_search($sl['gpa'], array_column($grd_system, 'grd_point'))]['gpa']; ?>
                    <?php } ?>
                    <?php } ?>
                </td>
            </tr>
            <?php if($sl['subject_code']==102){ ?>
                <tr style="background: #ced6d2;" class="center">
                    <td colspan="6" style="padding-right: 15px" class="right"><b>Total</b></td>
                    <!--td class="center" colspan="<?= $extd+5; ?>"></td-->
                    <td class="center">
                        <?php
                        $bn_f=0;
                        $get_mark_bn = floor(($getbn*100)/$totalbn);
                        $total+=$getbn;
                        //$total+=$get_mark_bn;
                        $total_f_mark+=100;
                        $pass_mark_bn=round(($totalpasbn/2));
                        // for check bangla 1st & 2nd paper subj, obj wise pass (only for 9&10) start
						if(($get_class==4) ||($get_class==5))
						{
							if($getbnsub<$getbnsubpass) $bn_f=1;
							if($getbnobj<$getbnobjpass) $bn_f=1;
						}
                        // for check bangla 1st & 2nd paper subj, obj wise pass (only for 9&10) end

                        //if($get_mark_bn < $pass_mark_bn){ $bn_f=1; $final_status==1;
                        if(($bn_f == 1) || ($get_mark_bn < $pass_mark_bn)){$bn_f=1;$final_status==1; ?>
                            <span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"><?= $getbn+0; ?></span>
                        <?php }else{ ?>
                            <b><?= $getbn; ?></b>
                        <?php } ?>
                    </td>
                    <td class="center"></td>
                    <td class="center">
                        <?php $gpbn='';
                        if($bn_f==1){ ?>
                            <span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;">0 </span>
                        <?php } else{
                            foreach($grd_system as $gplbn):
                                if($gplbn['start_marks'] <= $get_mark_bn && $gplbn['end_marks'] >= $get_mark_bn ):
                                    echo '<b>'.$gplbn['grd_point'].'</b>'; $total_gpa+=$gplbn['grd_point'];
                                    $gpabn=$gplbn['grd_point'];
                                endif;
                            endforeach;
                        }
                        ?>
                    </td>
                    <td class="center">
                        <?php  if($bn_f==1){ ?>
                            <span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;">F</span>
                            <?php $final_status=1; ?>
                        <?php } else{ ?>
                            <b><?= $grd_system[array_search($gpabn, array_column($grd_system, 'grd_point'))]['gpa']; ?></b>
                        <?php } ?>
                    </td>
                </tr>
            <?php } ?>
            <?php if($sl['subject_code']==108){ ?>
            <tr style="background: #ced6d2;" class="center">
                <td colspan="6" style="padding-right: 15px" class="right"><b> Total</b></td>
                <!--td colspan="<?= $extd+5; ?>" class="center"></td-->
                <td class="center">
                    <?php
                    $get_mark_en = floor(($geten*100)/$totalen);
                    $total+=$geten;
                    //$total+=$get_mark_en;
                    $total_f_mark+=100;
                    $pass_mark_en=round(($totalpasen/2));
                    $en_f=0;

                    if($get_mark_en < $pass_mark_en){ $en_f=1; $final_status==1; ?>
                        <span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"><?= $geten+0; ?></span>
                    <?php }else{ ?>
                        <b><?= $geten; ?></b>
                    <?php } ?>
                </td>
                <td class="center"></td>
                <td class="center">
                    <?php $gpen='';
                    if($en_f==1){ ?>
                        <span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;">0 </span>
                    <?php } else{
                        foreach($grd_system as $gpl):
                            if($gpl['start_marks'] <= $get_mark_en && $gpl['end_marks'] >= $get_mark_en ):
                                echo '<b>'.$gpl['grd_point'].'</b>'; $total_gpa+=$gpl['grd_point'];
                                $gpaen=$gpl['grd_point'];
                            endif;
                        endforeach;}
                    ?>
                </td>
                <td class="center">
                    <?php  if($en_f==1){ ?>
                        <span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;">F</span>
                        <?php $final_status=1; ?>
                    <?php } else{ ?>
                        <b><?= $grd_system[array_search($gpaen, array_column($grd_system, 'grd_point'))]['gpa']; ?></b>
                    <?php } ?>
                </td>
            </tr>
        <?php } ?>
        <?php $sub_array[] = $sl['subject_code'];?>
        <?php endforeach;?>
        <!--tr>
                                                <td><b> Total </b></td>
                                                <td colspan="<?= $extd+5; ?>"></td>
                                                <td>
                                                    <?php if($final_status==1){ ?>
                                                        <span style="width:100%; border-bottom:5px solid #CD0000; color:red; font-weight:bold;"><?= $total; ?></span>
                                                        <?php }else{ ?>
                                                            <?= $total; ?>
                                                                <?php } ?>
                                                </td>
                                                <td></td>
                                                <td>
                                                    <?php if($final_status==1){?>
                                                        <span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"><?= 0; ?></span>
                                                        <?php }else{
															if (in_array('101', $sub_array, true)) 
															{
																$avgpp=sprintf('%0.2f', $total_gpa/(count($student_mark_info)-(2+$optional_sub_flag)));
            $avgp=($avgpp >= 5 ? 5 : $avgpp);
															}else
															{
																$avgpp=sprintf('%0.2f', $total_gpa/(count($student_mark_info)-(0+$optional_sub_flag)));
            $avgp=($avgpp >= 5 ? 5 : $avgpp);
															}
        } ?>
                                                </td>
                                                <td>
                                                    <?php $obtgpa="F"; if($final_status==1){ ?>
                                                        <span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"> F </span>
                                                        <?php }else{
            foreach ($grd_system as $key => $row) {
                $mid[$key]  = $row['grd_point'];
            }
            // Sort the data with mid descending
            // Add $data as the last parameter, to sort by the common key
            array_multisort($mid, SORT_DESC, $grd_system);

            $i=0;
            while($i <= count($grd_system)) {
                if ($grd_system[$i]['grd_point'] <= $avgp) {
                    $obtgpa=$grd_system[$i]['gpa'];
                    //echo $grd_system[$i]['gpa'];
                    break;
                }
                $i++;
            }
        } ?>
                                                </td>
                                            </tr-->
        </tbody>
    </table>
    <hr style="clear:both;margin-top: 5px;margin-bottom: 0px;background-color:#000;">
    <div class="stu-info-det" class="clear:both;width:100%">
        <div class="mark-col-1" style="width:30%">
            <table width="100%" class="table table-striped">
                <tr class="no-border">
                    <td>Working days</td>
                    <td>:</td>
                    <td>0</td>
                </tr>
                <tr class="no-border">
                    <td>Presence</td>
                    <td>:</td>
                    <td>0</td>
                </tr>
                <tr class="no-border">
                    <td>Absence</td>
                    <td>:</td>
                    <td>0</td>
                </tr>
            </table>
        </div>
        <div class="mark-col-2" style="width:35%">
            <table class="table table-striped">
                <tr class="no-border">
                    <td>Total Marks</td>
                    <td>:</td>
                    <td><?php echo $total_marks;?></td>
                </tr>
                <tr class="no-border">
                    <td>Obtained Marks</td>
                    <td>:</td>
                    <td><?php if($final_status==1){ ?>
                            <span style="width:100%;font-weight:bold;"><?= $total; ?></span>
                        <?php }else{ ?>
                            <?= $total; ?>
                        <?php } ?></td>
                </tr>
                <!--tr class="no-border">
                    <td>Section/Group Students</td>
                    <td>:</td>
                    <td></td>
                </tr-->
                <tr class="no-border">
                    <td>Total Students</td>
                    <td>:</td>
                    <td><?= count($ranks_by_gpa); ?></td>
                </tr>
                <tr class="no-border">
                    <td>Section Wise Merit</td>
                    <td>:</td>
                    <td>
                        <?php //if(isset($avgp)){
							//usort($ranks_by_gpa, function($a,$b){	$c = strcmp($b['point'], $a['point']); $c.=$b['ttl_get_mark'] - $a['ttl_get_mark']; return $c;});
							usort($ranks_by_gpa, function($a,$b){	$c = $b['point'] <=> $a['point']; $c.=$b['ttl_get_mark'] - $a['ttl_get_mark']; return $c;});

                            echo array_search($student_info['student_id'], array_column($ranks_by_gpa, 'student_id'))+1;
                        //}
                        ?>
                    </td>
                </tr>
            </table>
        </div>
        <div class="mark-col-3 no-border" style="width:34%">
            <table class="table table-striped">
                <tr class="no-border">
                    <td>Total GP</td>
                    <td>:</td>
                    <td>5.00</td>
                </tr>
                <tr class="no-border">
                    <td>Obtained GP</td>
                    <td>:</td>
                    <td> <?php if($final_status==1){?>
                            <span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"><?= 0; ?></span>
                        <?php }else{echo sprintf('%0.2f',$avgp);}?>
                    </td>
                </tr>



                <tr class="no-border">
                    <td>Letter Grade</td>
                    <td>:</td>
                    <td><?= $obtgpa; ?></td>
                </tr>




            </table>
        </div>

    </div>
    <!--./stu-info-det-->
    <hr style="clear:both;margin-top: 0px;margin-bottom: 5px;background-color:#000;">
    <div class="transcript-bottom">
        <div class="col-1">
            <p>Class Teacher</p>
        </div>
        <div class="col-2">
            <p>Gurdian Signature</p>
        </div>
        <div class="col-3 remark">
            <form>
                        <textarea name="message" rows="3" cols="30" style="width: 100%;border:1px solid #000;height: 90px;" >Remarks:
                        </textarea>
            </form>
            <span style="color: #2ecc71; font-weight: bold;text-align:center;margin-top:8px;">Result Publication Date: 30.12.2019</span >
        </div>
        <div class="col-4">
            <p>Head Teacher</p>
        </div>

    </div>
    </div>
    <div style="text-align:center;">
        <p style="line-height: 25px;margin:0 auto;clear:both;">This is a system generated result. Any mistake will be considerable.</p>
        <p style="color: #d35400; font-weight: bold;line-height: 25px;margin:0 auto;">Powered by Weblink Communication Ltd.</p>
    </div >
</div>
<div class="print_break"></div>
<?php }?>