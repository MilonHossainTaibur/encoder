<?php if(count($final_submit)>0){?><div class="alert alert-warning fade in alert-dismissible">
	<a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
	<?php echo 'Already Final Submit. Passing System is '; if($final_submit['pass_id'] == 2) echo '<strong>Pass overall</strong>';else echo '<strong>Pass Every Field</strong>';?>
</div>
<?php }?>
<table class="table table-striped" width="100%">
    <tr>
        <td colspan="2">&nbsp;</td>
        <td colspan="6" style="text-align:center;">
            <span style="font-weight:bold; font-size:22px;">
            <?= $details['details_data']['school_name']; ?>
            </span>
        </td>
        <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="2">&nbsp;</td>
        <td colspan="6" style="text-align:center;">
            <span style=" font-weight:bold; font-size:18px;">
            Subject Name : <?= $details['details_data']['subject_name']; ?>
            </span>
        </td>
        <td colspan="2">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="2">&nbsp;</td>
        <td>&nbsp;</td>
        <td>
         	<span style="font-size:18px;">
        		Class Name : <?= $details['details_data']['class_name']; ?>
        	</span>
        </td>
        <td>&nbsp;</td>
        <td>
            <span style="font-size:18px;">
            	Section Name : <?= $details['details_data']['section_name']; ?>
            </span>
        </td>
        <td>&nbsp;</td>
        <td colspan="3">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="2">&nbsp;</td>
        <td>&nbsp;</td>
        <td>
            <span style="font-size:18px;">
                Group Name : <?= $details['details_data']['group_name']; ?>
            </span>
        </td>
        <td>&nbsp;</td>
        <td>
            <span style="font-size:18px;">
                Shift Name : <?= $details['details_data']['shift_name']; ?>
            </span>
        </td>
        <td>&nbsp;</td>
        <td colspan="3">&nbsp;</td>
    </tr>
    <tr>
        <td colspan="2">&nbsp;</td>
        <td>&nbsp;</td>
        <td>
			<span style="font-size:18px;">
				Term Name : <?= $details['details_data']['term_name']; ?>
			</span>
        </td>
        <td>&nbsp;</td>
        <td>
         <span style="font-size:18px;">
            Exam Year : <?= $details['exam_year']; ?>
        </span>
        </td>
        <td>&nbsp;</td>
        <td colspan="3">&nbsp;</td>
    </tr>
</table>

<form role="form" method="POST" action="<?= base_url();?>result/tabulation_marks_save">
<table class="table table-striped table-bordered" cellspacing="0" border="1">
	<thead>
		<tr>
			<th>Student ID</th>
            <th>Roll No</th>
            <th>Student Name</th>
            <th>Full Marks</th>
            <?php 
				$mark_dists=explode(',',$subject_infos['mark_dist']);
					
						$total_marks=0; 	//subject full marks
						$other_marks='';
					foreach($mark_dists as $mark_dist):
						$mark_dis=explode(':',$mark_dist);
							//subject full marks
							$total_marks+=$mark_dis[1];
								if($mark_dis[0]=='TE')
								{ $sub_term_mark=$mark_dis[1];  }
							if($mark_dis[0]!='0' && $mark_dis[0]!='TE'):
						$other_marks.=$mark_dis[0].",".$mark_dis[1].'*';?>
			<th><?= $mark_dis[1]."<br/>".$mark_dis[0]; ?></th>
			<?php endif; endforeach; $total_marks_all=$subject_infos['subjective_marks']+$subject_infos['objective_marks']+$subject_infos['practical_marks'] ?>
				<input type="hidden" name="mark_dis" value="<?= $other_marks; ?>" />
                <input type="hidden" name="f_mark" value="<?= $total_marks_all;?>" />
                <input type="hidden" name="p_mark" value="<?= $subject_infos['pass_marks'];?>" />
                <input type="hidden" name="sub_mark" value="<?= $subject_infos['subjective_marks']; ?>" />
                <input type="hidden" name="obj_mark" value="<?= $subject_infos['objective_marks']; ?>" />
                <input type="hidden" name="prac_mark" value="<?= $subject_infos['practical_marks']; ?>" />
            				<?php if($subject_infos['subjective_marks']!=0): ?>
            <th>Sub</th>
            				<?php endif; if($subject_infos['objective_marks']!=0): ?>
            <th>Obj</th>
                            <?php endif; if($subject_infos['practical_marks']!=0): ?>
            <th>Prac</th>
            				<?php endif; ?>
            <th><?= $sub_term_mark."<br/>"; ?>Sub Total</th>
            <th>Total</th>
            <th>Grede Point</th>
        </tr>
	</thead>
	<tbody>
    	<?php  foreach($student_list as $sl): ?>
    	<?php  $pass_flg=0; ?>
		<tr>
			<td> <?= $sl['student_id'];?>
                <input type="hidden" name="student_id[]" value="<?= $sl['student_id'];?>" />        
            </td>
            <td><?= $sl['roll_no'];?></td>
			<td><?= $sl['student_name'];?></td>
            <td><?= $total_marks_all;?></td>
			<?php 
				$mark_dists=explode(',',$subject_infos['mark_dist']);
					$total_marks_get=0; 
					$other_mark='';
					foreach($mark_dists as $mark_dist):
						$mark_dis=explode(':',$mark_dist);
							if($mark_dis[0]!='0' && $mark_dis[0]!='TE'):
							$total_marks_get+=$sl[$mark_dis[0]]; 
						$other_mark.=$mark_dis[0].",".$sl[$mark_dis[0]].'*';?>
			<td><?= round($sl[$mark_dis[0]]); ?></td>
            			<?php endif; endforeach; ?>	
            <input type="hidden" name="other_mark[]" value="<?= $other_mark; ?>" />
			<?php if($subject_infos['subjective_marks']!=0): ?>
           	<td>
				<?php 
					//$term_pass_mark_sub = $sl['sub']*100/$subject_infos['subjective_marks'];
					$p_ms=$subject_infos['subjective_marks']*$subject_infos['pass_marks']/100;
					if($details['passing_id']==1):
						if(round($sl['sub']) < round($p_ms)):?>
						<?php  $pass_flg=1; ?>
                            <span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"><?= $sl['sub']; ?></span>
                        <?php else: ?>
							<?= $sl['sub']; ?>
                        <?php endif; ?>
					<?php else: ?>
                       	<?= $sl['sub']; ?>
					<?php endif; ?>
					<input type="hidden" name="sub[]" value="<?= $sl['sub']; ?>" />
            </td>
            <?php endif; if($subject_infos['objective_marks']!=0): ?>
            <td><?php 
					//$term_pass_mark_obj = $sl['obj']*100/$subject_infos['objective_marks'];
					$p_mo=$subject_infos['objective_marks']*$subject_infos['pass_marks']/100;
					
						if($details['passing_id']==1):
							if(round($sl['obj']) < round($p_mo)):?>
							<?php  $pass_flg=1; ?>
                            <span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"><?= $sl['obj']; ?></span>
                            <?php else: ?>
								<?= $sl['obj']; ?>
                            <?php endif; ?>
						<?php else: ?>
                        	<?= $sl['obj']; ?>
						<?php endif; ?>
					<input type="hidden" name="obj[]" value="<?= $sl['obj']; ?>" />
            </td>
            <?php endif; if($subject_infos['practical_marks']!=0): ?>
            <td>
				<?php 
						//$term_pass_mark_prac = $sl['prac']*100/$subject_infos['practical_marks'];
						$p_mprac=$subject_infos['practical_marks']*$subject_infos['pass_marks']/100;
						if($details['passing_id']==1):
							if(round($sl['prac']) < $p_mprac):?>
							<?php  $pass_flg=1; ?>
                            <span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"><?= $sl['prac']; ?></span>
                            <?php else: ?>
								<?= $sl['prac']; ?>
                            <?php endif; ?>
						<?php else: ?>
                        	<?= $sl['prac']; ?>
						<?php endif; ?>
					<input type="hidden" name="prac[]" value="<?= $sl['prac']; ?>" />
            </td>
            <?php endif; ?>
            <td>
				<?php
						$total_term= $subject_infos['subjective_marks']+$subject_infos['objective_marks']+$subject_infos['practical_marks'];
						$total_term_get= ($sl['sub']+$sl['obj']+$sl['prac'])*$sub_term_mark/$total_term;
						$term_pass_mark_get = $total_term_get*$total_term/$sub_term_mark;

						if($details['passing_id']==1 ):
							if($pass_flg==1): ?>
                            <span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"><?= $term_pass_mark_get; ?></span>
                            <?php else: ?>
								<?= $term_pass_mark_get; ?>
                            <?php endif; ?>
						<?php else: ?>
                        	<?= $term_pass_mark_get; ?>
						<?php endif; ?>
					<input type="hidden" name="sub_total[]" value="<?= $term_pass_mark_get; ?>" />
            </td>    
            <td>
            	<?php 
					$get_mark_in_per=sprintf('%0.1f', $total_marks_get+$total_term_get)*100/$total_marks;
					if($pass_flg==1): ?>
					<span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"><?= $total_marks_get+$term_pass_mark_get; ?></span>
                <?php else: ?>
					<?= $total_marks_get+$term_pass_mark_get; ?>
                <?php endif; ?>
            </td> 
            <td>
				<?php $gpa='';
					if($pass_flg==1): ?>
						<span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;">F</span>
                <?php else:
						foreach($gp_list as $gpl):
							if($gpl['start_marks'] <= $get_mark_in_per && $gpl['end_marks'] >= $get_mark_in_per ):
								echo $gpl['grd_point']; $gpa=$gpl['grd_point'];
							endif;
						endforeach;
					endif; 
				?>
				<input type="hidden" name="gpa[]" value="<?= $gpa; ?>" />
				<input type="hidden" name="pass_flag[]" value="<?= $pass_flag; ?>" />
			</td>
		</tr>
		<?php endforeach; ?>
	</tbody>
</table>
<input type="hidden" name="pass_id" value="<?= $details['passing_id']; ?>" />
<input type="hidden" name="type_id" value="<?= $details['type_id']; ?>" />
<input type='hidden' name='school_id' value="<?= $details['school_id']; ?>" />
<input type='hidden' name='class_id' value="<?= $details['class_id']; ?>" />
<input type='hidden' name='section_id' value='<?= $details['section_id']; ?>' />
<input type='hidden' name='group_id' value='<?= $details['group_id']; ?>' />
<input type='hidden' name='shift_id' value='<?= $details['shift_id']; ?>' />
<input type='hidden' name='subject_id' value="<?= $details['subject_id']; ?>" />
<input type='hidden' name='exam_year' value="<?= $details['exam_year']; ?>" /> 
<input type='hidden' name='term_id' value="<?= $details['term_id']; ?>" />
<div class="print_button pull-left padding">
	<br/>
	<input type="button" class="btn btn-primary" onClick="printPageArea('display')" value="Print This Tabulation Sheet"/>
</div>
<div class="print_button pull-left padding">
	<br/>
	<input type="submit" class="btn btn-primary" value="Final Submit"/>
</div>
</form>
<div class="print_button pull-right padding">
	<br/>
				<form role="form" method="POST" action="<?= base_url();?>academic/marks_status_change">
                	<input type="hidden" name="status" value="1" />
                    <input type='hidden' name='school_id' value='<?= $details['school_id']; ?>' />
                    <input type='hidden' name='class_id' value='<?= $details['class_id']; ?>' />
                    <input type='hidden' name='section_id' value='<?= $details['section_id']; ?>' />
                    <input type='hidden' name='group_id' value='<?= $details['group_id']; ?>' />											
                    <input type='hidden' name='shift_id' value='<?= $details['shift_id']; ?>' />
                    <input type='hidden' name='subject_id' value='<?= $details['subject_id']; ?>' />
                    <input type='hidden' name='exam_year' value='<?= $details['exam_year']; ?>' /> 
                    <input type='hidden' name='term_id' value='<?= $details['term_id']; ?>' />
                             
                    <input type="submit" class="btn btn-danger" value="Allow User Again"/><br />
                </form>
</div>