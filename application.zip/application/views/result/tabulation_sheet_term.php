<!-- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>
				
<!-- Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
<style>
.table > tbody > tr > td, .table > tbody > tr > th, .table > tfoot > tr > td, .table > tfoot > tr > th, .table > thead > tr > td, .table > thead > tr > th {
    padding-left: 5px;
    vertical-align: middle;
}
.table {
border-collapse: collapse;
	border-spacing: 0;
    width: 100%;
    max-width: 100%;
    margin-bottom: 0px;
}

td, th {
    border: 1px solid #000;
    padding: 5px;
}
</style>
<div class="content-page">			
    <div class="content">
        <!-- Page Heading Start -->
        <div class="page-heading">
            <h1><i class='fa fa-table'></i> Tabulation Sheet View (Combine Terms)</h1>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="widget" style="min-height: 400px">
					<div class="widget-content">
						<div class="widget-content padding">
							<div class="form-group">
								<div class="row">
									<div class="col-sm-3 col-md-3">
										<label>Class <span style="color:red;">*</span></label>
										<select class="form-control" name="class_id" id="class_id"  onchange="get_class_section_list(this.value); get_class_group_list(this.value);">
											<option value="">-----Select Class-----</option>
											<?php foreach($class_list as $cl){ ?>
											<option value="<?= $cl['class_id'];?>" id="<?= $cl['class_short_form'];?>"><?php echo $cl['class_name'];?></option>
											<?php } ?>
										</select>
									</div>
									<div class="col-sm-3 col-md-3">
										<label>Group <span style="color:red;">*</span></label>
										<select class="form-control" name="group_id" id="group_id" required onChange="get_sub_list(this.value);" >
											<option value="">-----Select Group-----</option>
										</select>
									</div>
									 <?php if($shift_list): ?>
                                            <div class="col-sm-3 col-md-3">
                                                <label>Shift <span style="color:red;">*</span></label>
                                                <select class="form-control" name="shift_id" id="shift_id" >
                                                	<option value="">-----Select Shift-----</option>
                                                    <?php foreach($shift_list as $shl){ ?>
                                                    <option value="<?php echo $shl['shift_id'];?>"><?php echo $shl['shift_name'];?></option>
                                                    <?php    } ?>
                                                </select>
											</div>
                                            <?php else: ?>
													<input type="hidden" id="shift_id" value="0" />
											<?php endif; ?>
								</div>
								<div class="form-group">
									<div class="row">
										<div class="col-sm-3 col-md-3">
											<label>Session <span style="color:red;">*</span></label>
											<select class="form-control" name="session_id" id="session_id" >
												<option value="">-----Select Session-----</option>
												<?php foreach($session_list as $sl){ ?>
												<option value="<?= $sl['session_id'];?>"><?= $sl['session_name'];?></option>
												<?php } ?>
											</select>
										</div>
                                        <div class="col-sm-3 col-md-3">
                                            <label>Exam Year<span style="color:red;">*</span></label>
                                            <input type="text" class="form-control" name="exam_year" id="exam_year" value="<?php echo date('Y');?>" />
                                        </div>
										<div class="col-sm-3 col-md-3">
											<label>Term Name <span style="color:red;">*</span></label>
                                            <?php foreach($term_list as $tl){ ?>
                                                <br><input type="checkbox" name="term_id" class="term_id" value="<?php echo $tl['term_id'];?>"><?php echo ' '.$tl['term'];?>
                                            <?php }?>
										</div>
									 </div>
								</div>
							</div><br />
							<button class="btn btn-success btn-label-center" onclick="tabulation_marks_term_json()" type="button"> Tabulation View </button>
                            <hr />
							<div id="display">
								<!-- content will display here -->
							</div>
						</div><!--//section-content-->
					</div><!--//news-wrapper-->
				</div><!--//page-row-->
			</div><!--//page-content-->
		</div><!--//page-wrapper-->
    
<?php include 'application/views/includes/footer.php';?>

<!--Check department name based on class id-->
<script>
function get_class_section_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'admin/section_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#section_id').html(html_data);
        }
    }
    });  
}

function get_class_group_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'academic/group_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#group_id').html(html_data);
        }
    }
    });  
}

function tabulation_marks_term_json(){
	$('#display').html('');
	var class_id = $('#class_id').val();
	var class_name = $('#class_id :selected').text();
	var group_id = $('#group_id').val();
	var group_name = $('#group_id :selected').text();
	var shift_id = $('#shift_id').val();
	var shift_name = $('#shift_id :selected').text();
	//var term_id = $('#term_id').val();
	var term_id = $.map($('input[name="term_id"]:checked'), function(c){return c.value; })
	var term_name = $('#term_id option:selected').text();
	var session_id = $('#session_id').val();
	var session = $('#session_id option:selected').text();
	var exam_year = $('#exam_year').val();
	var bill = '';

	if(!class_id)
	{
		$('#class_id').after("<div id='validation_class' class='validation_js'>Please select a class.</div>")
			$('#validation_class').delay(3000).hide('slow');
			return;
		
	}
	if(!group_id)
	{
		$('#group_id').after("<div id='validation_group_id' class='validation_js'>Please select a group.</div>")
			$('#validation_group_id').delay(3000).hide('slow');
			return;
		
	}
	if(!shift_id)
	{
		$('#shift_id').after("<div id='validation_shift_id' class='validation_js'>Please select a shift.</div>")
			$('#validation_shift_id').delay(3000).hide('slow');
			return;
		
	}
	if(!session_id)
	{
		$('#session_id').after("<div id='validation_session_id' class='validation_js'>Please select a session.</div>")
			$('#validation_session_id').delay(3000).hide('slow');
			return;
		
	}
	if(!term_id)
	{
		$('#term_id').after("<div id='validation_ct' class='validation_js'>Please select a term.</div>")
			$('#validation_ct').delay(3000).hide('slow');
			return;
		
	}
	if(!exam_year)
	{
		$('#exam_year').after("<div id='validation_ey' class='validation_js'>Please fill up this box.</div>")
			$('#validation_ey').delay(3000).hide('slow');
			return;
		
	}

	$.ajax({ 
	url: baseUrl+'result/tabulation_marks_term_json',
	data:
		{                  
			'class_id':class_id,
			'class_name':class_name,
			'group_id':group_id,
			'group_name':group_name,
			'shift_id':shift_id,
			'shift_name':shift_name,
			'session_id':session_id,
			'term_id':term_id,
			'term_name':term_name,
			'exam_year':exam_year,
			'session':session,
			'bill':bill
		}, 
		dataType: 'json',
		success: function(data)
		{
			result                = ''+data['result']+'';
			mainContent           = ''+data['mainContent']+'';

			if(result == 'success')
			{            
				$('#display').html(mainContent);     
			}                
		}
	});
}

function PrintElem(elem)
{
    var mywindow = window.open('', 'PRINT', 'width=900,height=650');

    mywindow.document.write('<html><head><title>' + document.title  + '</title>');
    mywindow.document.write('</head><body >');
    mywindow.document.write('<span>' + document.title  + '</span>');
    mywindow.document.write(document.getElementById(elem).innerHTML);
    mywindow.document.write('</body></html>');

    mywindow.document.close(); // necessary for IE >= 10
    mywindow.focus(); // necessary for IE >= 10*/

    mywindow.print();
    mywindow.close();

    return true;
}
</script> 

