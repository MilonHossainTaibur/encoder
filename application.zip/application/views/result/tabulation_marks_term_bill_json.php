<div class="print_button">
	<br/>
	<input type="button" class="btn btn-primary" onClick="PrintElem('print_area')" value="Print This Tabulation Sheet"/>
</div>

<div class="table-responsive" id="print_area">

	<div class="container" style="text-align: center;width: 100%;">
		<div class="tabu-header">
			<h2 style="font-weight: 700;font-size: 32px;"><?= $school_info[0]['school_name'] ?></h2>
			<h3 style="font-size: 24px;">Tabulation Sheet for <?= $details['term_name']; ?>-<?= $details['exam_year']; ?></h3>
			<h4 style="font-size: 20px;">Class - <?= $details['class_name']; ?> - <?= $details['section_name']; ?> (<?= $details['shift_name']; ?> - <?= $details['group_name']; ?>)</h4>
			<h5 style="margin-bottom: 10px!important;font-size: 18px;">Total Student: <?php echo $total_student;?>, Pass: <?php echo ($total_student-$total_fail);?>, Fail: <?php echo $total_fail;?></h5>
		</div>
	</div>

	<style>
		table {
			border-collapse: collapse;
		}

		table, td, th{
			border: 1px solid black;
		}

		th {
			text-transform: uppercase;
		}
		.no-border{
			border:0!important;
		}
		.center{
			text-align:center;}
		.tb tr td {
			height: 50px;
		}
		.tabu-header h2,.tabu-header h3,.tabu-header h4,.tabu-header h5{
			padding: 0px!important;
			margin-top: 0px!important;
			margin-bottom: 0px!important;
		}
		span.fail{
			width:100%;
			border-bottom:5px solid #CD0000;
			color:#000;
		}
	</style>
	<STYLE type="text/css">
		@page
		{
			size: landscape;
		}
		@media print{
			@page {
				size: landscape
			}
		}
		@media print{
			.class-name{
			@page{
				size:landscape;
			}
		}
		}
		table thead tr>th{
			text-align: center;
		}
	</STYLE>
	<STYLE type="text/css" media="print">
		@page { size: landscape; }
	</STYLE>
	<table>
		<thead>
		<tr>
			<th>SL</th>
			<th>Std ID</th>
			<th>Name</th>
			<th>Parent</th>
			<th>Roll</th>
			<th>Avg. GPA</th>
			<th>Avg. GRADE</th>
			<th>Mobile No</th>
			<th>Total</th>
			<th>Due Amount</th>
		</tr>
		</thead>
		<tbody class="center tb" >
		<?php
		usort($output, function($a,$b){	$c = $b['point'] <=> $a['point']; $c.=$b['ttl_get_mark'] - $a['ttl_get_mark']; return $c;});
		//print_r($output);exit;
		foreach($output as $i=>$outval){
			?>
			<tr>
				<td><?php print_r($i+1);?></td>
				<td><?php print_r($outval['student_id']);?></td>
				<td><?php print_r($outval['student_name']);?></td>
				<td><?php print_r($outval['father_name'].'<br>'.$outval['mother_name']);?></td>
				<td><?php print_r($outval['roll_no']);?></td>
				<td><?php print_r($outval['point']);?></td>
				<td><?php if($outval['grade'] == 'F'){?><span class="fail"><?php print_r($outval['grade']);?></span><?php }else{print_r($outval['grade']);}?></td>
                <td></td>
                <td></td>
                <td></td>
			</tr>
		<?php }?>
		</tbody>
	</table>
</div>
