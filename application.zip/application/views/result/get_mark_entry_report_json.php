

<div id="display">
   <div class="print_button">
      <br>
      <input type="button" class="btn btn-primary" onclick="PrintElem('print_area')" value="Print This Tabulation Sheet">
   </div>
   <div class="table-responsive" id="print_area">
      <div class="container" style="text-align: center;width: 100%;">
         <div class="tabu-header">
            <h2 style="font-weight: 700;font-size: 32px;">Telihaty High School</h2>
            <h3 style="font-size: 24px;">Mark Sheet Report</h3>
            <h4 style="font-size: 20px;">Class : <?php echo $mark_entry_report[0]['classname'];?></h4>
         </div>
      </div>
   </br>
      <style>
         table {
         border-collapse: collapse;
         }
         table, td, th {
         border: 1px solid black;
         }
         .no-border{
         border:0!important;
         }
         .center{
         text-align:center;}
         .tb tr td {
         height: 50px;
         }
         .tabu-header h2,.tabu-header h3,.tabu-header h4,.tabu-header h5{
         padding: 0px!important;
         margin-top: 0px!important;
         margin-bottom: 0px!important;
         }
         span.fail{
         width:100%;
         border-bottom:5px solid #CD0000;
         color:#000;
         }
      </style>
      <style type="text/css">
         @page
         {
         size: landscape;
         }
         @media print{
         @page {
         size: landscape
         }
         }
         @media print{
         .class-name{
         @page{
         size:landscape;
         }
         }
         }
         table thead tr>th{
         text-align: center;
         }
      </style>
      <style type="text/css" media="print">
         @page { size: landscape; }
      </style>
      <table>
         <thead>
            <tr>
               <th rowspan="3">Exam Name</th>
               <th style="min-width:70px;" rowspan="3">Year</th>
               <th rowspan="3">Group</th>
               <th rowspan="2" colspan="3">Register student</th>
               <th rowspan="2" colspan="3">Exam Participate Student</th>
               <th rowspan="2" colspan="3">Total Student</th>
               <th colspan="12">GPA Wise Totalpass</th>
               <th rowspan="2" colspan="2">Totalpass</th>

            </tr>
            <tr>

               <th colspan="6">Boys</th>
               <th colspan="6">Girls</th>
       
            </tr>

            <tr>
              
               <th>Boys</th>
               <th>Girls</th>
               <th>Total</th>
               <th>Boys</th>
               <th>Girls</th>
               <th>Total</th>
               <th>Boys</th>
               <th>Girls</th>
               <th>Total</th>
               <th>5.00</th>
               <th>4-4.99</th>
               <th>3-3.99</th>
               <th>2-2.99</th>
               <th>Below</th>
               <th>F</th>
               <th>5.00</th>
               <th>4-4.99</th>
               <th>3-3.99</th>
               <th>2-2.99</th>
               <th>Below</th>
               <th>F</th>
               <th>Total</th>
               <th>Girls</th>
               
              
            </tr>
     <?php foreach($mark_entry_report as $sl){ //print_r($sl); exit(); ?>
            <tr>
               <th><?php echo $sl['classname'];?></th>
               <th><?php echo $sl['sessionname'];?></th>
               <th><?php echo $sl['groupname'];?></th>
               <th><?php echo $sl['registration_Male_count'];?></th>
               <th><?php echo $sl['registration_Female_count'];?></th>
               <th><?php echo $sl['registration_Male_count'] + $sl['registration_Female_count'];?></th>
               <th><?php echo $sl['participate_Male_count'];?></th>
               <th><?php echo $sl['participate_Female_count'];?></th>
               <th><?php echo $sl['participate_Male_count'] + $sl['participate_Female_count'];?></th>
               <th><?php echo $sl['Total_Male_count'];?></th>
               <th><?php echo $sl['Total_Female_count'];?></th>
               <th><?php echo $sl['Total_Male_count'] + $sl['Total_Female_count'];?></th>
               <th><?php echo $sl['gpa_five_male'];?></th>
               <th><?php echo $sl['gpa_four_male'];?></th>
               <th><?php echo $sl['gpa_three_male'];?></th>
               <th><?php echo $sl['gpa_two_male'];?></th>
               <th><?php echo $sl['gpa_one_male'];?></th>
               <th><?php echo $sl['gpa_ziro_male'];?></th>
               <th><?php echo $sl['gpa_five_female'];?></th>
               <th><?php echo $sl['gpa_four_female'];?></th>
               <th><?php echo $sl['gpa_three_female'];?></th>
               <th><?php echo $sl['gpa_two_female'];?></th>
               <th><?php echo $sl['gpa_one_female'];?></th>
               <th><?php echo $sl['gpa_ziro_female'];?></th>
              
              <?php $totalpass = $sl['gpa_five_male'] + $sl['gpa_four_male'] + $sl['gpa_three_male'] + $sl['gpa_two_male'] + $sl['gpa_one_male'] + $sl['gpa_ziro_male'] + $sl['gpa_five_female'] + $sl['gpa_four_female'] + $sl['gpa_three_female'] + $sl['gpa_two_female'] + $sl['gpa_one_female'] + $sl['gpa_ziro_female'];?>


               <th><?php echo $totalpass;?></th>

               <?php $totalpassgirl = $sl['gpa_five_female'] + $sl['gpa_four_female'] + $sl['gpa_three_female'] + $sl['gpa_two_female'] + $sl['gpa_one_female'] + $sl['gpa_ziro_female'];?>

               <th><?php echo $totalpassgirl;?></th>
              
            </tr>
          <?php } ?>
         </thead>
         <tbody class="center tb">
         </tbody>
      </table>
   </div>
</div>

