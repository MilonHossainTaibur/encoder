	<script language="javascript" type="application/javascript">
        function pr()
			{
				window.print('tabulation_marks_print.php');
			}
	</script>
<body onLoad="pr()">

<table class="table table-striped" width="100%">
    <tr>
        <td colspan="2">&nbsp;</td>
        <td colspan="6" style="text-align:center;">
            <span style="font-weight:bold; font-size:16px;">
            <?= $school_info[0]['school_name'] ?>
            </span>
        </td>
        <td colspan="2">&nbsp;</td>
    </tr>
	<tr>
        <td colspan="2">&nbsp;</td>
        <td colspan="6" style="text-align:center;">
            <span style="font-weight:bold; font-size:14px;">
            Tabulation Sheet for <?= $details['term_name']; ?>-<?= $details['exam_year']; ?>
            </span>
        </td>
        <td colspan="2">&nbsp;</td>
    </tr>
	<tr>
        <td colspan="2">&nbsp;</td>
        <td colspan="6" style="text-align:center;">
            Class - <?= $details['class_name']; ?> - <?= $details['section_name']; ?> (<?= $details['shift_name']; ?> - <?= $details['group_name']; ?>)
        </td>
        <td colspan="2">&nbsp;</td>
    </tr>
</table>
<?php 
/* initial value */
$term_pass_mark_sub=0;
$bn_mark_sub=0;
$bn_mark_obj=0;
$bn_mark_prac=0;
$bn_mark_sub_ful=0;
$bn_mark_obj_ful=0;
$bn_mark_prac_ful=0;
$eng_mark_sub=0;
$eng_mark_obj=0;
$eng_mark_prac=0;
$eng_mark_sub_ful=0;
$eng_mark_obj_ful=0;
$eng_mark_prac_ful=0;
$rel=0;
$aghom=0;
$total_marks=0;
$pass_flag=0;
$total_gpa=0;
/* /initial value */
 ?>
<?php 
foreach($student_list as $stu_list){
		$students_data[$stu_list['student_id']][$stu_list['subject_code']]=$stu_list;
		$roll_no[$stu_list['student_id']]=$stu_list['roll_no'];
		$student_name[$stu_list['student_id']]=$stu_list['student_name'];
   } 
   //print_r($students_data);
   ?>
<table border="1">
	<thead>
		<tr>
			<th rowspan="2">ID</th>
            <th rowspan="2">Roll</th>
            <th rowspan="2">Name</th>
            <th rowspan="2">Exam Name</th>
            <?php foreach($subject_infos as $sub_i){
					
					if($sub_i['subject_code']==111){
						
						$sub_type[]=$sub_i['marks_type'];
						$rel=1; 
						echo "<th colspan='".($sub_i['marks_type']+1)."'>Religion</th>";
					}
					elseif($sub_i['subject_code']==112){
						if($rel==0){
							$sub_type[]=$sub_i['marks_type'];
							$rel=1; 
							echo "<th colspan='".($sub_i['marks_type']+1)."'>Religion</th>";
						}
					}
					elseif($sub_i['subject_code']==113){
						if($rel==0){
							$sub_type[]=$sub_i['marks_type'];
							$rel=1; 
							echo "<th colspan='".($sub_i['marks_type']+1)."'>Religion</th>";
						}
					}
					elseif($sub_i['subject_code']==114){
						if($rel==0){
							$sub_type[]=$sub_i['marks_type'];
							$rel=1; 
							echo "<th colspan='".($sub_i['marks_type']+1)."'>Religion</th>";
						}
					}
					else{
						if($sub_i['subject_code']==134){
							$sub_type[]=$sub_i['marks_type'];
							$aghom=1;
							echo "<th colspan='".($sub_i['marks_type']+1)."'>Agriculture/ Home Science</th>";
						}
						elseif($sub_i['subject_code']==151){
							if($aghom==0){
								$sub_type[]=$sub_i['marks_type'];
								$aghom=1;
							echo "<th colspan='".($sub_i['marks_type']+1)."'>Agriculture/ Home Science</th>";
							}
						}
						else{
							if($sub_i['subject_code']==101){
								$sub_type[]=$sub_i['marks_type'].':'.$sub_i['subject_code'];
								echo "<th colspan='".($sub_i['marks_type'])."'>".$sub_i['subject_name']."</th>";
							}
							elseif($sub_i['subject_code']==107){
								$sub_type[]=$sub_i['marks_type'].':'.$sub_i['subject_code'];
								echo "<th colspan='".($sub_i['marks_type'])."'>".$sub_i['subject_name']."</th>";
							}
							else{
								$sub_type[]=$sub_i['marks_type'];
								echo "<th colspan='".($sub_i['marks_type']+1)."'>".$sub_i['subject_name']."</th>";
							}
						}
					}
			}
			?>
            <th rowspan="2">Sub Total</th>
            <th rowspan="2">Total</th>
            <th rowspan="2">Avg</th>
            <th rowspan="2">GPA</th>
        </tr>
		<tr>
			<?php foreach($sub_type as $sub_t){
					$sub_c=explode(':', $sub_t);
					if($sub_c[0]==1){
						if($sub_c[1]==101 || $sub_c[1]==107){
							echo "<th>Sub</th>";
						}
						else{
							echo "<th>Sub</th>";
							echo "<th>Total</th>";
						}
						
					}
					elseif($sub_c[0]==2){
						if($sub_c[1]==101 || $sub_c[1]==107){
							echo "<th>Sub</th>";
							echo "<th>Obj</th>";
						}
						else{
							echo "<th>Sub</th>";
							echo "<th>Obj</th>";
							echo "<th>Total</th>";
						}
					}
					elseif($sub_c[0]==3){
						if($sub_c[1]==101 || $sub_c[1]==107){
							echo "<th>Sub</th>";
							echo "<th>Obj</th>";
							echo "<th>Prac</th>";
						}
						else{
							echo "<th>Sub</th>";
							echo "<th>Obj</th>";
							echo "<th>Prac</th>";
							echo "<th>Total</th>";
						}
					}
			} ?>
		</tr>
	</thead>
	<tbody>
		<?php foreach($students_data as $k=>$stu_datas){
				/* initial value */
					$total_marks=0;
					$pass_flag=0;
					$total_gpa=0;
					/* /initial value */
					$i=count($stu_datas);
		?>
		<tr>
			
			<td> <?= $k ?></td>
			<td> <?= $roll_no[$k] ?></td>
			<td> <?= $student_name[$k] ?></td>
			<td> <?= $details['term_name']?></td>
			<?php foreach($stu_datas as $sk=>$stu_data){
					/* initial value */
					$term_pass_mark_sub=0;
					$term_pass_mark_obj = 0;
					$term_pass_mark_prac=0;
					/* /initial value */
					if($stu_data['marks_type']==1){ /* mark type check */
						
						if($stu_data['subject_code']==101){
							echo '<td>'.explode('*',$stu_data['sub'])[0].'</td>';
							$bn_mark_sub+=explode('*',$stu_data['sub'])[0];/* get bangla 1st mark */
							$bn_mark_sub_ful+=explode('*',$stu_data['sub'])[1];/* get bangla 1st full mark */
						}
						elseif($stu_data['subject_code']==102){
							echo '<td>'.explode('*',$stu_data['sub'])[0].'</td>';
							$bn_mark_sub+=explode('*',$stu_data['sub'])[0];/* get english 1st mark */
							$bn_mark_sub_ful+=explode('*',$stu_data['sub'])[1];/* get bangla 1st full mark */
							$term_pass_mark_sub_ban = $bn_mark_sub*100/$bn_mark_sub_ful;
							if($term_pass_mark_sub_ban < $stu_data['p_mark']){
								echo '<td><span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;">'.round($term_pass_mark_sub_ban).'</span></td>';
								$pass_flag=1;
							}
							else{
								echo "<td>".round($term_pass_mark_sub_ban)."</td>";
							}
							$total_marks+=round($term_pass_mark_sub_ban);// get total marks 
							/*  get gpa*/
							foreach($grd_system as $gplbn){
								if($gplbn['start_marks'] <= round($term_pass_mark_sub_ban) && $gplbn['end_marks'] >= round($term_pass_mark_sub_ban) ):
									echo '<b>'.$gplbn['grd_point'].'</b>'; $total_gpa+=$gplbn['grd_point'];
									$gpa[$stu_data['student_id']][$stu_data['subject_code']]=$gplbn['grd_point'];
								endif;
							}
							/*  get gpa*/
						}
						elseif($stu_data['subject_code']==107){
							echo '<td>'.explode('*',$stu_data['sub'])[0].'</td>';
							$eng_mark_sub+=explode('*',$stu_data['sub'])[0];/* get english 1st mark */
							$eng_mark_sub_ful+=explode('*',$stu_data['sub'])[1];/* get english 1st full mark */
						}
						elseif($stu_data['subject_code']==108){
							echo '<td>'.explode('*',$stu_data['sub'])[0].'</td>';
							$eng_mark_sub+=explode('*',$stu_data['sub'])[0];/* get english 1st mark */
							$eng_mark_sub_ful+=explode('*',$stu_data['sub'])[1];/* get bangla 1st full mark */
							$term_pass_mark_sub_eng = $eng_mark_sub*100/$eng_mark_sub_ful;
							if($term_pass_mark_sub_eng < $stu_data['p_mark']){
								echo '<td><span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;">'.round($term_pass_mark_sub_eng).'</span></td>';
								$pass_flag=1;
							}
							else{
								echo "<td>".round($term_pass_mark_sub_eng)."</td>";
							}
							
							$total_marks+=round($term_pass_mark_sub_eng);// get total marks
							// get total marks 
							foreach($grd_system as $gplen){
								if($gplen['start_marks'] <= round($term_pass_mark_sub_eng) && $gplen['end_marks'] >= round($term_pass_mark_sub_eng) ):
									 $total_gpa+=$gplen['grd_point'];
									$gpa[$stu_data['student_id']][$stu_data['subject_code']]=$gplen['grd_point'];
								endif;
							}
							// get total marks 
						}
						else{
							$term_pass_mark_sub = explode('*',$stu_data['sub'])[0]*100/explode('*',$stu_data['sub'])[1];
							if($term_pass_mark_sub < $stu_data['p_mark']){
								echo '<td><span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;">'.$stu_data['sub_total'].'</span></td>';
								$pass_flag=1;
							}
							else{
								echo "<td>".$stu_data['sub_total']."</td>";
							}
							$total_marks+=$stu_data['sub_total'];// get total marks
							$gpa[$stu_data['student_id']][$stu_data['subject_code']]=$stu_data['gpa'];// gread point
							$total_gpa+=$stu_data['gpa'];// gread point
						}
					} /* mark type check */
					elseif($stu_data['marks_type']==2){ /* mark type check */
						if($stu_data['pass_id']==1){
							if($stu_data['subject_code']==101){
								echo '<td>'.explode('*',$stu_data['sub'])[0].'</td>';
								echo '<td>'.explode('*',$stu_data['obj'])[0].'</td>';
								$bn_mark_sub+=explode('*',$stu_data['sub'])[0];/* get bangla 1st mark sub */
								$bn_mark_obj+=explode('*',$stu_data['obj'])[0];/* get bangla 1st mark obj */
								$bn_mark_sub_ful+=explode('*',$stu_data['sub'])[1];/* get bangla 1st full mark sub */
								$bn_mark_obj_ful+=explode('*',$stu_data['obj'])[1];/* get bangla 1st full mark obj */
							}
							elseif($stu_data['subject_code']==102){
								echo '<td>'.explode('*',$stu_data['sub'])[0].'</td>';
								echo '<td>'.explode('*',$stu_data['obj'])[0].'</td>';
								$bn_mark_sub+=explode('*',$stu_data['sub'])[0];/* get bangla 1st mark sub */
								$bn_mark_obj+=explode('*',$stu_data['obj'])[0];/* get bangla 1st mark obj */
								$bn_mark_sub_ful+=explode('*',$stu_data['sub'])[1];/* get bangla 1st full mark sub */
								$bn_mark_obj_ful+=explode('*',$stu_data['obj'])[1];/* get bangla 1st full mark obj */
								
								$term_pass_mark_sub_ban = $bn_mark_sub*100/$bn_mark_sub_ful;
								$term_pass_mark_obj_ban = $bn_mark_obj*100/$bn_mark_obj_ful;
								if($term_pass_mark_sub_ban < $stu_data['p_mark'] || $term_pass_mark_obj_ban < $stu_data['p_mark'] ){
									echo '<td><span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;">'.round($term_pass_mark_sub_ban+term_pass_mark_obj_ban).'</span></td>';
									$pass_flag=1;
								}
								else{
									echo "<td>".round($term_pass_mark_sub_ban+term_pass_mark_obj_ban)."</td>";
								}
								$total_marks+=round($term_pass_mark_sub_ban+term_pass_mark_obj_ban);// get total marks
								// get total marks 
								foreach($grd_system as $gplen){
									if($gplen['start_marks'] <= round($term_pass_mark_sub_ban+term_pass_mark_obj_ban) && $gplen['end_marks'] >= round($term_pass_mark_sub_ban+term_pass_mark_obj_ban) ):
										 $total_gpa+=$gplen['grd_point'];
										$gpa[$stu_data['student_id']][$stu_data['subject_code']]=$gplen['grd_point'];
									endif;
								}
								// get total marks 
							}
							elseif($stu_data['subject_code']==107){
								echo '<td>'.explode('*',$stu_data['sub'])[0].'</td>';
								echo '<td>'.explode('*',$stu_data['obj'])[0].'</td>';
								$eng_mark_sub+=explode('*',$stu_data['sub'])[0];/* get english 1st mark sub */
								$eng_mark_obj+=explode('*',$stu_data['obj'])[0];/* get english 1st mark obj */
								$eng_mark_sub_ful+=explode('*',$stu_data['sub'])[1];/* get english 1st full mark sub */
								$eng_mark_obj_ful+=explode('*',$stu_data['obj'])[1];/* get english 1st full mark obj */
							}
							elseif($stu_data['subject_code']==108){
								echo '<td>'.explode('*',$stu_data['sub'])[0].'</td>';
								echo '<td>'.explode('*',$stu_data['obj'])[0].'</td>';
								$eng_mark_sub+=explode('*',$stu_data['sub'])[0];/* get bangla 1st mark sub */
								$eng_mark_obj+=explode('*',$stu_data['obj'])[0];/* get bangla 1st mark obj */
								$eng_mark_sub_ful+=explode('*',$stu_data['sub'])[1];/* get bangla 1st full mark sub */
								$eng_mark_obj_ful+=explode('*',$stu_data['obj'])[1];/* get bangla 1st full mark obj */
								
								$term_pass_mark_sub_eng = $eng_mark_sub*100/$eng_mark_sub_ful;
								$term_pass_mark_obj_eng = $eng_mark_obj*100/$eng_mark_obj_ful;
								if($term_pass_mark_sub_eng < $stu_data['p_mark'] || $term_pass_mark_obj_eng < $stu_data['p_mark'] ){
									echo '<td><span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;">'.round($term_pass_mark_sub_eng+$term_pass_mark_obj_eng).'</span></td>';
									$pass_flag=1;
								}
								else{
									echo "<td>".round($term_pass_mark_sub_eng+$term_pass_mark_obj_eng)."</td>";
								}
								$total_marks+=round($term_pass_mark_sub_eng+term_pass_mark_obj_eng);// get total marks
								// get total marks 
								foreach($grd_system as $gplen){
									if($gplen['start_marks'] <= round($term_pass_mark_sub_eng+term_pass_mark_obj_eng) && $gplen['end_marks'] >= round($term_pass_mark_sub_eng+term_pass_mark_obj_eng) ):
										 $total_gpa+=$gplen['grd_point'];
										$gpa[$stu_data['student_id']][$stu_data['subject_code']]=$gplen['grd_point'];
									endif;
								}
							}
							else{
								$term_pass_mark_sub = explode('*',$stu_data['sub'])[0]*100/explode('*',$stu_data['sub'])[1];
								$term_pass_mark_obj = explode('*',$stu_data['obj'])[0]*100/explode('*',$stu_data['obj'])[1];
								if($term_pass_mark_sub < $stu_data['p_mark']){
									echo '<td><span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;">'.explode('*',$stu_data['sub'])[0].'</span></td>';
									$pass_flag=1;
								}
								else{
									echo "<td>".explode('*',$stu_data['sub'])[0]."</td>";
								}
								if($term_pass_mark_obj < $stu_data['p_mark']){
									echo '<td><span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;">'.explode('*',$stu_data['obj'])[0].'</span></td>';
									$pass_flag=1;
								}
								else{
									echo "<td>".explode('*',$stu_data['obj'])[0]."</td>";
								}
								if($term_pass_mark_sub < $stu_data['p_mark'] || $term_pass_mark_obj < $stu_data['p_mark']){
									echo '<td><span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;">'.$stu_data['sub_total'].'</span></td>';
									$pass_flag=1;
								}
								else{
									echo "<td>".$stu_data['sub_total']."</td>";
								}
								$total_marks+=$stu_data['sub_total'];// get total marks
								$gpa[$stu_data['student_id']][$stu_data['subject_code']]=$stu_data['gpa'];// gread point
								$total_gpa+=$stu_data['gpa'];// gread point
							}
						}
						else{
							if($stu_data['subject_code']==101){
								echo '<td>'.explode('*',$stu_data['sub'])[0].'</td>';
								echo '<td>'.explode('*',$stu_data['obj'])[0].'</td>';
								$bn_mark_sub+=explode('*',$stu_data['sub'])[0];/* get bangla 1st mark sub */
								$bn_mark_obj+=explode('*',$stu_data['obj'])[0];/* get bangla 1st mark obj */
								$bn_mark_sub_ful+=explode('*',$stu_data['sub'])[1];/* get bangla 1st full mark sub */
								$bn_mark_obj_ful+=explode('*',$stu_data['obj'])[1];/* get bangla 1st full mark obj */
							}
							elseif($stu_data['subject_code']==102){
								echo '<td>'.explode('*',$stu_data['sub'])[0].'</td>';
								echo '<td>'.explode('*',$stu_data['obj'])[0].'</td>';
								$bn_mark_sub+=explode('*',$stu_data['sub'])[0];/* get bangla 1st mark sub */
								$bn_mark_obj+=explode('*',$stu_data['obj'])[0];/* get bangla 1st mark obj */
								$bn_mark_sub_ful+=explode('*',$stu_data['sub'])[1];/* get bangla 1st full mark sub */
								$bn_mark_obj_ful+=explode('*',$stu_data['obj'])[1];/* get bangla 1st full mark obj */
								
								$term_pass_mark_ban = ($bn_mark_sub+$bn_mark_obj)*100/($bn_mark_obj_ful+$bn_mark_sub_ful);
								if($term_pass_mark_ban < $stu_data['p_mark']){
									echo '<td><span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;">'.round($term_pass_mark_ban).'</span></td>';
									$pass_flag=1;
								}
								else{
									echo "<td>".round($term_pass_mark_ban)."</td>";
								}
								$total_marks+=round($term_pass_mark_ban);// get total marks
								// get total marks 
								foreach($grd_system as $gplen){
									if($gplen['start_marks'] <= round($term_pass_mark_ban) && $gplen['end_marks'] >= round($term_pass_mark_ban) ):
										 $total_gpa+=$gplen['grd_point'];
										$gpa[$stu_data['student_id']][$stu_data['subject_code']]=$gplen['grd_point'];
									endif;
								}
							}
							elseif($stu_data['subject_code']==107){
								echo '<td>'.explode('*',$stu_data['sub'])[0].'</td>';
								echo '<td>'.explode('*',$stu_data['obj'])[0].'</td>';
								$eng_mark_sub+=explode('*',$stu_data['sub'])[0];/* get english 1st mark sub */
								$eng_mark_obj+=explode('*',$stu_data['obj'])[0];/* get english 1st mark obj */
								$eng_mark_sub_ful+=explode('*',$stu_data['sub'])[1];/* get english 1st full mark sub */
								$eng_mark_obj_ful+=explode('*',$stu_data['obj'])[1];/* get english 1st full mark obj */
							}
							elseif($stu_data['subject_code']==108){
								echo '<td>'.explode('*',$stu_data['sub'])[0].'</td>';
								echo '<td>'.explode('*',$stu_data['obj'])[0].'</td>';
								$eng_mark_sub+=explode('*',$stu_data['sub'])[0];/* get bangla 1st mark sub */
								$eng_mark_obj+=explode('*',$stu_data['obj'])[0];/* get bangla 1st mark obj */
								$eng_mark_sub_ful+=explode('*',$stu_data['sub'])[1];/* get bangla 1st full mark sub */
								$eng_mark_obj_ful+=explode('*',$stu_data['obj'])[1];/* get bangla 1st full mark obj */
								
								$term_pass_mark_eng = ($eng_mark_sub+$eng_mark_obj)*100/($eng_mark_sub_ful+$eng_mark_obj_ful);
								if($term_pass_mark_eng < $stu_data['p_mark']){
									echo '<td><span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;">'.round($term_pass_mark_eng).'</span></td>';
									$pass_flag=1;
								}
								else{
									echo "<td>".round($term_pass_mark_eng)."</td>";
								}
								$total_marks+=round($term_pass_mark_eng);// get total marks
								// get total marks 
								foreach($grd_system as $gplen){
									if($gplen['start_marks'] <= round($term_pass_mark_eng) && $gplen['end_marks'] >= round($term_pass_mark_eng) ):
										 $total_gpa+=$gplen['grd_point'];
										$gpa[$stu_data['student_id']][$stu_data['subject_code']]=$gplen['grd_point'];
									endif;
								}
							}
							else{
								echo "<td>".explode('*',$stu_data['sub'])[0]."</td>";
								echo "<td>".explode('*',$stu_data['obj'])[0]."</td>";
									
								if($stu_data['sub_total'] < $stu_data['p_mark']){
									echo '<td><span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;">'.$stu_data['sub_total'].'</span></td>';
									$pass_flag=1;
								}
								else{
									echo "<td>".$stu_data['sub_total']."</td>";
								}
								$total_marks+=$stu_data['sub_total'];// get total marks
								$gpa[$stu_data['student_id']][$stu_data['subject_code']]=$stu_data['gpa'];// gread point
								$total_gpa+=$stu_data['gpa'];// gread point
							}
						}
					} /* /mark type check */
					elseif($stu_data['marks_type']==3){ /* mark type check */
						if($stu_data['pass_id']==1){
							if($stu_data['subject_code']==101){
								echo '<td>'.explode('*',$stu_data['sub'])[0].'</td>';
								echo '<td>'.explode('*',$stu_data['obj'])[0].'</td>';
								echo '<td>'.explode('*',$stu_data['prac'])[0].'</td>';
								$bn_mark_sub+=explode('*',$stu_data['sub'])[0];/* get bangla 1st mark sub */
								$bn_mark_obj+=explode('*',$stu_data['obj'])[0];/* get bangla 1st mark obj */
								$bn_mark_prac+=explode('*',$stu_data['prac'])[0];/* get bangla 1st mark prac */
								$bn_mark_sub_ful+=explode('*',$stu_data['sub'])[1];/* get bangla 1st full mark sub */
								$bn_mark_obj_ful+=explode('*',$stu_data['obj'])[1];/* get bangla 1st full mark obj */
								$bn_mark_prac_ful+=explode('*',$stu_data['prac'])[1];/* get bangla 1st full mark prac */
							}
							elseif($stu_data['subject_code']==102){
								echo '<td>'.explode('*',$stu_data['sub'])[0].'</td>';
								echo '<td>'.explode('*',$stu_data['obj'])[0].'</td>';
								echo '<td>'.explode('*',$stu_data['prac'])[0].'</td>';
								$bn_mark_sub+=explode('*',$stu_data['sub'])[0];/* get bangla 1st mark sub */
								$bn_mark_obj+=explode('*',$stu_data['obj'])[0];/* get bangla 1st mark obj */
								$bn_mark_prac+=explode('*',$stu_data['prac'])[0];/* get bangla 1st mark prac */
								$bn_mark_sub_ful+=explode('*',$stu_data['sub'])[1];/* get bangla 1st full mark sub */
								$bn_mark_obj_ful+=explode('*',$stu_data['obj'])[1];/* get bangla 1st full mark obj */
								$bn_mark_prac_ful+=explode('*',$stu_data['prac'])[1];/* get bangla 1st full mark prac */
								
								$term_pass_mark_sub_ban = $bn_mark_sub*100/$bn_mark_sub_ful;
								$term_pass_mark_obj_ban = $bn_mark_obj*100/$bn_mark_obj_ful;
								$term_pass_mark_prac_ban = $bn_mark_prac*100/$bn_mark_prac_ful;
								if($term_pass_mark_sub_ban < $stu_data['p_mark'] || $term_pass_mark_obj_ban < $stu_data['p_mark'] || $term_pass_mark_prac_ban < $stu_data['p_mark']){
									echo '<td><span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;">'.round($term_pass_mark_sub_ban+term_pass_mark_obj_ban+$term_pass_mark_prac_ban).'</span></td>';
									$pass_flag=1;
								}
								else{
									echo "<td>".round($term_pass_mark_sub_ban+term_pass_mark_obj_ban+$term_pass_mark_prac_ban)."</td>";
								}
								$total_marks+=round($term_pass_mark_sub_ban+term_pass_mark_obj_ban+$term_pass_mark_prac_ban);// get total marks
								// get total marks 
								foreach($grd_system as $gplen){
									if($gplen['start_marks'] <= round($term_pass_mark_sub_ban+term_pass_mark_obj_ban+$term_pass_mark_prac_ban) && $gplen['end_marks'] >= round($term_pass_mark_sub_ban+term_pass_mark_obj_ban+$term_pass_mark_prac_ban) ):
										 $total_gpa+=$gplen['grd_point'];
										$gpa[$stu_data['student_id']][$stu_data['subject_code']]=$gplen['grd_point'];
									endif;
								}
								
							}
							elseif($stu_data['subject_code']==107){
									echo '<td>'.explode('*',$stu_data['sub'])[0].'</td>';
								echo '<td>'.explode('*',$stu_data['obj'])[0].'</td>';
								echo '<td>'.explode('*',$stu_data['prac'])[0].'</td>';
								$eng_mark_sub+=explode('*',$stu_data['sub'])[0];/* get english 1st mark sub */
								$eng_mark_obj+=explode('*',$stu_data['obj'])[0];/* get english 1st mark obj */
								$eng_mark_prac+=explode('*',$stu_data['obj'])[0];/* get english 1st mark prac */
								$eng_mark_sub_ful+=explode('*',$stu_data['sub'])[1];/* get english 1st full mark sub */
								$eng_mark_obj_ful+=explode('*',$stu_data['obj'])[1];/* get english 1st full mark obj */
								$eng_mark_prac_ful+=explode('*',$stu_data['obj'])[1];/* get english 1st full mark prac */
							}
							elseif($stu_data['subject_code']==108){
								echo '<td>'.explode('*',$stu_data['sub'])[0].'</td>';
								echo '<td>'.explode('*',$stu_data['obj'])[0].'</td>';
								echo '<td>'.explode('*',$stu_data['prac'])[0].'</td>';
								$eng_mark_sub+=explode('*',$stu_data['sub'])[0];/* get english 1st mark sub */
								$eng_mark_obj+=explode('*',$stu_data['obj'])[0];/* get english 1st mark obj */
								$eng_mark_prac+=explode('*',$stu_data['obj'])[0];/* get english 1st mark prac */
								$eng_mark_sub_ful+=explode('*',$stu_data['sub'])[1];/* get english 1st full mark sub */
								$eng_mark_obj_ful+=explode('*',$stu_data['obj'])[1];/* get english 1st full mark obj */
								$eng_mark_prac_ful+=explode('*',$stu_data['obj'])[1];/* get english 1st full mark prac */
								
								$term_pass_mark_sub_eng = $eng_mark_sub*100/$eng_mark_sub_ful;
								$term_pass_mark_obj_eng = $eng_mark_obj*100/$eng_mark_obj_ful;
								$term_pass_mark_prac_eng = $eng_mark_prac*100/$eng_mark_prac_ful;
								if($term_pass_mark_sub_eng < $stu_data['p_mark'] || $term_pass_mark_obj_eng < $stu_data['p_mark'] || $term_pass_mark_prac_eng < $stu_data['p_mark']){
									echo '<td><span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;">'.round($term_pass_mark_sub_eng+$term_pass_mark_obj_eng+$term_pass_mark_prac_eng).'</span></td>';
									$pass_flag=1;
								}
								else{
									echo "<td>".round($term_pass_mark_sub_eng+$term_pass_mark_obj_eng+$term_pass_mark_prac_eng)."</td>";
								}
								$total_marks+=round($term_pass_mark_sub_eng+$term_pass_mark_obj_eng+$term_pass_mark_prac_eng);// get total marks
								// get total marks 
								foreach($grd_system as $gplen){
									if($gplen['start_marks'] <= round($term_pass_mark_sub_eng+$term_pass_mark_obj_eng+$term_pass_mark_prac_eng) && $gplen['end_marks'] >= round($term_pass_mark_sub_eng+$term_pass_mark_obj_eng+$term_pass_mark_prac_eng) ):
										 $total_gpa+=$gplen['grd_point'];
										$gpa[$stu_data['student_id']][$stu_data['subject_code']]=$gplen['grd_point'];
									endif;
								}
							}
							else{
								$term_pass_mark_sub = explode('*',$stu_data['sub'])[0]*100/explode('*',$stu_data['sub'])[1];
								$term_pass_mark_obj = explode('*',$stu_data['obj'])[0]*100/explode('*',$stu_data['obj'])[1];
								$term_pass_mark_prac = explode('*',$stu_data['prac'])[0]*100/explode('*',$stu_data['prac'])[1];
								if($term_pass_mark_sub < $stu_data['p_mark']){
									echo '<td><span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;">'.explode('*',$stu_data['sub'])[0].'</span></td>';
									$pass_flag=1;
								}
								else{
									echo "<td>".explode('*',$stu_data['sub'])[0]."</td>";
								}
								if($term_pass_mark_obj < $stu_data['p_mark']){
									echo '<td><span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;">'.explode('*',$stu_data['obj'])[0].'</span></td>';
									$pass_flag=1;
								}
								else{
									echo "<td>".explode('*',$stu_data['obj'])[0]."</td>";
								}
								if($term_pass_mark_prac < $stu_data['p_mark']){
									echo '<td><span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;">'.explode('*',$stu_data['prac'])[0].'</span></td>';
									$pass_flag=1;
								}
								else{
									echo "<td>".explode('*',$stu_data['prac'])[0]."</td>";
								}
								if($term_pass_mark_sub < $stu_data['p_mark'] || $term_pass_mark_obj < $stu_data['p_mark'] || $term_pass_mark_prac < $stu_data['p_mark']){
									echo '<td><span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;">'.$stu_data['sub_total'].'</span></td>';
									$pass_flag=1;
								}
								else{
									echo "<td>".$stu_data['sub_total']."</td>";
								}
								$total_marks+=$stu_data['sub_total'];// get total marks
								$gpa[$stu_data['student_id']][$stu_data['subject_code']]=$stu_data['gpa'];// gread point
								$total_gpa+=$stu_data['gpa'];// gread point
								
							}
						}
						else{
							if($stu_data['subject_code']==101){
								echo '<td>'.explode('*',$stu_data['sub'])[0].'</td>';
								echo '<td>'.explode('*',$stu_data['obj'])[0].'</td>';
								echo '<td>'.explode('*',$stu_data['prac'])[0].'</td>';
								$bn_mark_sub+=explode('*',$stu_data['sub'])[0];/* get bangla 1st mark sub */
								$bn_mark_obj+=explode('*',$stu_data['obj'])[0];/* get bangla 1st mark obj */
								$bn_mark_prac+=explode('*',$stu_data['prac'])[0];/* get bangla 1st mark prac */
								$bn_mark_sub_ful+=explode('*',$stu_data['sub'])[1];/* get bangla 1st full mark sub */
								$bn_mark_obj_ful+=explode('*',$stu_data['obj'])[1];/* get bangla 1st full mark obj */
								$bn_mark_prac_ful+=explode('*',$stu_data['prac'])[1];/* get bangla 1st full mark prac */
							}
							elseif($stu_data['subject_code']==102){
								echo '<td>'.explode('*',$stu_data['sub'])[0].'</td>';
								echo '<td>'.explode('*',$stu_data['obj'])[0].'</td>';
								echo '<td>'.explode('*',$stu_data['prac'])[0].'</td>';
								$bn_mark_sub+=explode('*',$stu_data['sub'])[0];/* get bangla 1st mark sub */
								$bn_mark_obj+=explode('*',$stu_data['obj'])[0];/* get bangla 1st mark obj */
								$bn_mark_prac+=explode('*',$stu_data['prac'])[0];/* get bangla 1st mark prac */
								$bn_mark_sub_ful+=explode('*',$stu_data['sub'])[1];/* get bangla 1st full mark sub */
								$bn_mark_obj_ful+=explode('*',$stu_data['obj'])[1];/* get bangla 1st full mark obj */
								$bn_mark_prac_ful+=explode('*',$stu_data['prac'])[1];/* get bangla 1st full mark prac */

								
								$term_pass_mark_ban = ($bn_mark_sub+$bn_mark_obj+$bn_mark_prac)*100/($bn_mark_obj_ful+$bn_mark_sub_ful+$bn_mark_prac_ful);
								if($term_pass_mark_ban < $stu_data['p_mark']){
									echo '<td><span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;">'.round($term_pass_mark_ban).'</span></td>';
									$pass_flag=1;
								}
								else{
									echo "<td>".round($term_pass_mark_ban)."</td>";
								}
								$total_marks+=round($term_pass_mark_ban);// get total marks
								// get total marks 
								foreach($grd_system as $gplen){
									if($gplen['start_marks'] <= round($term_pass_mark_ban) && $gplen['end_marks'] >= round($term_pass_mark_ban) ):
										 $total_gpa+=$gplen['grd_point'];
										$gpa[$stu_data['student_id']][$stu_data['subject_code']]=$gplen['grd_point'];
									endif;
								}
							}
							elseif($stu_data['subject_code']==107){
								echo '<td>'.explode('*',$stu_data['sub'])[0].'</td>';
								echo '<td>'.explode('*',$stu_data['obj'])[0].'</td>';
								echo '<td>'.explode('*',$stu_data['prac'])[0].'</td>';
								$eng_mark_sub+=explode('*',$stu_data['sub'])[0];/* get english 1st mark sub */
								$eng_mark_obj+=explode('*',$stu_data['obj'])[0];/* get english 1st mark obj */
								$eng_mark_prac+=explode('*',$stu_data['prac'])[0];/* get english 1st mark prac */
								$eng_mark_sub_ful+=explode('*',$stu_data['sub'])[1];/* get english 1st full mark sub */
								$eng_mark_obj_ful+=explode('*',$stu_data['obj'])[1];/* get english 1st full mark obj */
								$eng_mark_prac_ful+=explode('*',$stu_data['prac'])[1];/* get english 1st full mark prac */
							}
							elseif($stu_data['subject_code']==108){
								echo '<td>'.explode('*',$stu_data['sub'])[0].'</td>';
								echo '<td>'.explode('*',$stu_data['obj'])[0].'</td>';
								echo '<td>'.explode('*',$stu_data['prac'])[0].'</td>';
								$eng_mark_sub+=explode('*',$stu_data['sub'])[0];/* get english 1st mark sub */
								$eng_mark_obj+=explode('*',$stu_data['obj'])[0];/* get english 1st mark obj */
								$eng_mark_prac+=explode('*',$stu_data['prac'])[0];/* get english 1st mark prac */
								$eng_mark_sub_ful+=explode('*',$stu_data['sub'])[1];/* get english 1st full mark sub */
								$eng_mark_obj_ful+=explode('*',$stu_data['obj'])[1];/* get english 1st full mark obj */
								$eng_mark_prac_ful+=explode('*',$stu_data['prac'])[1];/* get english 1st full mark prac */
								
								$term_pass_mark_eng = ($eng_mark_sub+$eng_mark_obj+$eng_mark_prac)*100/($eng_mark_sub_ful+$eng_mark_obj_ful+$eng_mark_prac_ful);
								if($term_pass_mark_eng < $stu_data['p_mark']){
									echo '<td><span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;">'.round($term_pass_mark_eng).'</span></td>';
									$pass_flag=1;
								}
								else{
									echo "<td>".round($term_pass_mark_eng)."</td>";
								}
								$total_marks+=round($term_pass_mark_eng);// get total marks
								// get total marks 
								foreach($grd_system as $gplen){
									if($gplen['start_marks'] <= round($term_pass_mark_eng) && $gplen['end_marks'] >= round($term_pass_mark_eng) ):
										 $total_gpa+=$gplen['grd_point'];
										$gpa[$stu_data['student_id']][$stu_data['subject_code']]=$gplen['grd_point'];
									endif;
								}
							}
							else{
								echo "<td>".explode('*',$stu_data['sub'])[0]."</td>";
								echo "<td>".explode('*',$stu_data['obj'])[0]."</td>";
								echo '<td>'.explode('*',$stu_data['prac'])[0].'</td>';
									
								if($stu_data['sub_total'] < $stu_data['p_mark']){
									echo '<td><span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;">'.$stu_data['sub_total'].'</span></td>';
									$pass_flag=1;
								}
								else{
									echo "<td>".$stu_data['sub_total']."</td>";
								}
								$total_marks+=$stu_data['sub_total'];// get total marks
								$gpa[$stu_data['student_id']][$stu_data['subject_code']]=$stu_data['gpa'];// gread point
								$total_gpa+=$stu_data['gpa'];// gread point
							}
						}
					}
			  } ?>
			  <td><?= $total_marks ?></td>
			  <td><?= $total_marks-40 ?></td>
			  <td><?= round($total_marks/($i-3),1) ?></td>
			  <td><?= round($total_gpa/($i-3),1) ?></td>
		</tr>
		<?php }?>
	</tbody>
</table>

</body>