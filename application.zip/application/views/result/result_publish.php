<!-- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>
				
<!-- Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
<div class="content-page">			
    <div class="content">
        <!-- Page Heading Start -->
        <div class="page-heading">
            <h1><i class='fa fa-table'></i> Publish result </h1>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="widget" style="min-height: 400px">
					<div class="widget-content">
						<div class="widget-content padding">
							<div class="form-group">
								<div class="row">
									
									<div class="col-sm-3 col-md-3">
										<label>Session <span style="color:red;">*</span></label>
										<select class="form-control" name="session_id" id="session_id">
											<option value="">-----Select Session-----</option>
											<?php foreach($session_list as $sl){ ?>
											<option value="<?= $sl['session_id'];?>"><?= $sl['session_name'];?></option>
											<?php } ?>
										</select>
									</div>
									<div class="col-sm-3 col-md-3">
										<label>Term Name <span style="color:red;">*</span></label>
										<select class="form-control" required name="term_id" id="term_id">
											<option value="">Select</option>
											<?php foreach($term_list as $tl){ ?>
											<option value="<?php echo $tl['term_id'];?>"><?php echo $tl['term'];?></option>
											<?php } ?>
										</select>
									</div>
								</div>
							</div><br><br>
							<button class="btn btn-success btn-label-center" onclick="result_publish_json()" type="button"> Get Class List </button>
                            <hr />
							<div id="display">
								<!-- content will display here -->
							</div>
						</div><!--//section-content-->
					</div><!--//news-wrapper-->
				</div><!--//page-row-->
			</div><!--//page-content-->
		</div><!--//page-wrapper-->
    
<?php include 'application/views/includes/footer.php';?>

<!--Check department name based on class id-->
<script>
	function result_publish_json()
		{
			var session_id = $('#session_id').val();
			var term_id = $('#term_id').val();
		
			if(!session_id)
			{
				$('#session_id').after("<div id='validation_ses' class='validation_js'>Please select a session.</div>")
					$('#validation_ses').delay(3000).hide('slow');
					return;
				
			}
			if(!term_id)
			{
				$('#term_id').after("<div id='validation_ct' class='validation_js'>Please select a term.</div>")
					$('#validation_ct').delay(3000).hide('slow');
					return;
				
			}
		
			$.ajax({ 
			url: baseUrl+'result/result_publish_json',
			data:
				{ 
					'session_id':session_id,
					'term_id':term_id
				}, 
				dataType: 'json',
				success: function(data)
				{
					result                = ''+data['result']+'';
					mainContent           = ''+data['mainContent']+'';
	
					if(result == 'success')
					{            
						$('#display').html(mainContent);     
					}                
				}
			});
		}
</script> 

