<div class="print_button">
	<br/>
	<input type="button" class="btn btn-primary" onClick="PrintElem('print_area')" value="Print This Tabulation Sheet"/>
</div>

<div class="table-responsive" id="print_area">

	<div class="container" style="text-align: center;width: 100%;">
		<div class="tabu-header">
			<h2 style="font-weight: 700;font-size: 32px;"><?= $school_info[0]['school_name'] ?></h2>
			<h3 style="font-size: 24px;">Tabulation Sheet for <?= $details['term_name']; ?>-<?= $details['exam_year']; ?></h3>
			<h4 style="font-size: 20px;">Class - <?= $details['class_name']; ?> - <?= $details['section_name']; ?> (<?= $details['shift_name']; ?> - <?= $details['group_name']; ?>)</h4>
			<h5 style="margin-bottom: 10px!important;font-size: 18px;">Total Student: <?php echo $total_student;?>, Pass: <?php echo ($total_student-$total_fail);?>, Fail: <?php echo $total_fail;?></h5>
		</div>
	</div>

<style>
table {
    border-collapse: collapse;
}

table, td, th {
    border: 1px solid black;
}
.no-border{
border:0!important;
}
.center{
text-align:center;}
.tb tr td {
    height: 50px;
}
.tabu-header h2,.tabu-header h3,.tabu-header h4,.tabu-header h5{
	padding: 0px!important;
	margin-top: 0px!important;
	margin-bottom: 0px!important;
}
span.fail{
	width:100%;
	border-bottom:5px solid #CD0000;
	color:#000;
}
</style>
<STYLE type="text/css">
@page
{
size: landscape;
}
@media print{
@page {
	size: landscape
}
}
@media print{
.class-name{
    @page{
        size:landscape;
    }
}
}
table thead tr>th{
	text-align: center;
}
</STYLE>
<STYLE type="text/css" media="print">
  @page { size: landscape; }
</STYLE>
<table>
	<thead>
		<tr>
			<th rowspan="3">Position</th>
			<th style="min-width:70px;" rowspan="3">Std ID</th>
            <th rowspan="3">Name</th>
            <th rowspan="3">Roll</th>
            <?php foreach($subject_infos as $sub_i){
					if($sub_i['marks_type']==1)
						$sub_im=1;
					elseif($sub_i['marks_type']==2)
						$sub_im=2;
					elseif($sub_i['marks_type']==3)
						$sub_im=3;
					elseif($sub_i['marks_type']==4)
						$sub_im=2;
					elseif($sub_i['marks_type']==5)
						$sub_im=2;
					elseif($sub_i['marks_type']==6)
						$sub_im=1;

					if($sub_i['subject_code']==111 || $sub_i['subject_code']==112 || $sub_i['subject_code']==113 || $sub_i['subject_code']==114){

						if($rel==0){
							$sun[]=$sub_i['marks_type'];
							$rel=1;
							echo "<th colspan='".($sub_im+1)."' rowspan='2'>Religion</th>";
						}
					}
					else{
						if($sub_i['subject_code']==126 || $sub_i['subject_code']==134 || $sub_i['subject_code']==151 || $sub_i['subject_code']==158){
							if($aghom==0){
								$sun[]=$sub_i['marks_type'];
								$aghom=1;
								if($sub_i['subject_code']==158) {
									echo "<th colspan='" . ($sub_im + 1) . "' rowspan='2'>Higher Mathematics/ Agriculture</th>";
								}else{
									echo "<th colspan='" . ($sub_im + 1) . "' rowspan='2'>Agriculture/Home Science</th>";
								}
							}

						}
						else{
							if($sub_i['subject_code']==101){
								$sun[]=$sub_i['marks_type'].'`'.$sub_i['subject_code'];
								$sub_im_b = $sub_im;
							}
							elseif($sub_i['subject_code']==102){
                                $subject_name = explode(' ',$sub_i['subject_name']);
								//echo "<th colspan='".($sub_im+1)."' rowspan='2'>".$subject_name[0]."</th>";
								if($sub_im_b != '')
								{
									$sun[]=$sub_i['marks_type'].'`'.$sub_i['subject_code'];
									echo "<th colspan='".($sub_im+$sub_im_b+1)."'>".$subject_name[0]."</th>";
								}else{
									$sun[]='7'.'`'.$sub_i['subject_code'];
									echo "<th colspan='".($sub_im+1)."' rowspan='2'>".$subject_name[0]."</th>";
								}

							}
							elseif($sub_i['subject_code']==107){
								$sun[]=$sub_i['marks_type'].'`'.$sub_i['subject_code'];
								$sub_im_e = $sub_im;
							}
							elseif($sub_i['subject_code']==108){
                                $subject_name = explode(' ',$sub_i['subject_name']);
								if($sub_im_e != '')
								{
									$sun[]=$sub_i['marks_type'].'`'.$sub_i['subject_code'];
									echo "<th colspan='".($sub_im+$sub_im_e+1)."'>".$subject_name[0]."</th>";
								}else{
									$sun[]='8'.'`'.$sub_i['subject_code'];
									echo "<th colspan='".($sub_im+1)."' rowspan='2'>".$subject_name[0]."</th>";
								}
							}
							else{
								$sun[]=$sub_i['marks_type'].'`'.$sub_i['subject_code'];
								if($sub_i['marks_type']==1)
									echo "<th colspan='".($sub_im+1)."' rowspan='2'>".$sub_i['subject_name']."</th>";
								else
									echo "<th colspan='".($sub_im+1)."' rowspan='2'>".$sub_i['subject_name']."</th>";
							}
						}
					}
			}
			?>
            <th rowspan="3">GPA</th>
            <th rowspan="3">GRADE</th>
        </tr>
		<tr>
			<?php foreach($sun as $sub_t){
					$sub_c=explode('`',$sub_t);
                    $col_span = 1;
					if($sub_c[1]==101 || $sub_c[1]==107){
						if($sub_c[0]==1){
                            echo "<th colspan='".($col_span)."'>1st Paper</th>";
						}
						elseif($sub_c[0]==2){
                            echo "<th colspan='".($col_span+1)."'>1st Paper</th>";
						}
						elseif($sub_c[0]==3){
                            echo "<th colspan='".($col_span+3)."'>1st Paper</th>";
						}
						elseif($sub_c[0]==4){
                            echo "<th colspan='".($col_span+1)."'>1st Paper</th>";
						}
						elseif($sub_c[0]==5){
                            echo "<th colspan='".($col_span+1)."'>1st Paper</th>";
						}
					}else if($sub_c[1]==102 || $sub_c[1]==108){
                        if($sub_c[0]==1){
                            echo "<th colspan='".($col_span)."'>2nd Paper</th>";
                            echo "<th rowspan='2'>Total</th>";
                        }
                        elseif($sub_c[0]==2){
                            echo "<th colspan='".($col_span+1)."'>2nd Paper</th>";
                            echo "<th rowspan='2'>Total</th>";
                        }
                        elseif($sub_c[0]==3){
                            echo "<th colspan='".($col_span+2)."'>2nd Paper</th>";
                            echo "<th rowspan='2'>Total</th>";
                        }
                        elseif($sub_c[0]==4){
                            echo "<th colspan='".($col_span+1)."'>2nd Paper</th>";
                            echo "<th rowspan='2'>Total</th>";
                        }
                        elseif($sub_c[0]==5){
                            echo "<th colspan='".($col_span+1)."'>2nd Paper</th>";
                            echo "<th rowspan='2'>Total</th>";
                        }
                        elseif($sub_c[0]==7){
							//
                        }
                        elseif($sub_c[0]==8){
							//
                        }
                    }

			} ?>
		</tr>
        <tr>
			<?php foreach($sun as $sub_t){
					$sub_c=explode('`',$sub_t);

					if($sub_c[1]==101 || $sub_c[1]==107){
						if($sub_c[0]==1){
							echo "<th>Sub</th>";
						}
						elseif($sub_c[0]==2){
							echo "<th>Sub</th>";
							echo "<th>Obj</th>";
						}
						elseif($sub_c[0]==3){
							echo "<th>Sub</th>";
							echo "<th>Obj</th>";
							echo "<th>Prac</th>";
						}
						elseif($sub_c[0]==4){
							echo "<th>Sub</th>";
							echo "<th>Prac</th>";
						}
						elseif($sub_c[0]==5){
							echo "<th>Obj</th>";
							echo "<th>Prac</th>";
						}
					}else if($sub_c[1]==102 || $sub_c[1]==108){
                        if($sub_c[0]==1){
                            echo "<th>Sub</th>";
                        }
                        elseif($sub_c[0]==2){
                            echo "<th>Sub</th>";
                            echo "<th>Obj</th>";
                        }
                        elseif($sub_c[0]==3){
                            echo "<th>Sub</th>";
                            echo "<th>Obj</th>";
                            echo "<th>Prac</th>";
                        }
                        elseif($sub_c[0]==4){
                            echo "<th>Sub</th>";
                            echo "<th>Prac</th>";
                        }
                        elseif($sub_c[0]==5){
                            echo "<th>Obj</th>";
                            echo "<th>Prac</th>";
                        }
						elseif($sub_c[0]==7){
							echo "<th>Sub</th>";
							echo "<th>Obj</th>";
							echo "<th>Total</th>";
						}
						elseif($sub_c[0]==8){
							echo "<th>Sub</th>";
							echo "<th>Total</th>";
						}
                    }else{
						if($sub_c[0]==1){
							echo "<th>Sub</th>";
							echo "<th>Total</th>";
						}
						elseif($sub_c[0]==2){
							echo "<th>Sub</th>";
							echo "<th>Obj</th>";
							echo "<th>Total</th>";
						}
						elseif($sub_c[0]==3){
							echo "<th>Sub</th>";
							echo "<th>Obj</th>";
							echo "<th>Prac</th>";
							echo "<th>Total</th>";
						}
						elseif($sub_c[0]==4){
							echo "<th>Sub</th>";
							echo "<th>Prac</th>";
							echo "<th>Total</th>";
						}
						elseif($sub_c[0]==5){
							echo "<th>Obj</th>";
							echo "<th>Prac</th>";
							echo "<th>Total</th>";
						}
						elseif($sub_c[0]==6){
							echo "<th>Prac</th>";
							echo "<th>Total</th>";
						}
					}

			} ?>
		</tr>
	</thead>
	<tbody class="center tb" >
		<?php
			//usort($output, function($a, $b) { return $a['position'] <=> $b['position'];});
			//usort($output, function($a,$b){	$c = strcmp($b['point'], $a['point']); $c.=$a['roll_no'] - $b['roll_no']; return $c;});
			usort($output, function($a,$b){	$c = $b['point'] <=> $a['point']; $c.=$b['ttl_get_mark'] - $a['ttl_get_mark']; return $c;});
			//print_r($output);exit;
			foreach($output as $i=>$outval){
		?>
		<tr>
			<td><?php print_r($i+1);?></td>
			<td><?php print_r($outval['student_id']);?></td>
			<td style="min-width: 170px;"><?php print_r($outval['student_name']);?></td>
			<td><?php print_r($outval['roll_no']);?></td>
			<?php
				//$all_subj_marks =($outval['subjects_mark']+$subject_infos);
				$all_subj_marks =($outval['subjects_mark']);
				ksort($all_subj_marks);//print_r($all_subj_marks);exit;
				// get key start
					/* if (($key = array_search(13, array_column($all_subj_marks, 'subj_id'))) !== false) {
						echo ' top found';
						print_r(array_search(22, array_column($all_subj_marks, 'subj_id')));exit;
						unset($all_subj_marks[array_search(14, array_column($all_subj_marks, 'subject_id'))]);
						echo 'found';
					}else{
						echo 'not found';
					}*/
				// get key end
				foreach($all_subj_marks as $j=>$all_subj_mark){
					if(empty($all_subj_mark['subj_id'])){//print_r($all_subj_mark['subject_id']); echo ' ... ';
						if(($all_subj_mark['subject_id'] !=5) && ($all_subj_mark['subject_id'] !=6) && ($all_subj_mark['subject_id'] !=7) && ($all_subj_mark['subject_id'] !=8)){
							if($all_subj_mark['marks_type'] ==1){
								echo '<td> --- </td>';echo '<td> --- </td>';
							}elseif($all_subj_mark['marks_type'] ==3){
								echo '<td> --- </td>';echo '<td> --- </td>';echo '<td> --- </td>';echo '<td> --- </td>';
							}else{
								echo '<td> --- </td>';echo '<td> --- </td>';echo '<td> --- </td>';
							}
						}
					}else{
			?>
				<?php if(!empty($all_subj_mark['subj_sub']) || (strlen($all_subj_mark['subj_sub'])>0)){?><td><?php if($all_subj_mark['sub_pass'] == 0){?><span class="fail"><?php print_r($all_subj_mark['subj_sub']);?></span><?php }else{print_r($all_subj_mark['subj_sub']);}?></td><?php }?>
				<?php if(!empty($all_subj_mark['subj_obj']) || (strlen($all_subj_mark['subj_obj'])>0)){?><td><?php if($all_subj_mark['obj_pass'] == 0){?><span class="fail"><?php print_r($all_subj_mark['subj_obj']);?></span><?php }else{print_r($all_subj_mark['subj_obj']);}?></td><?php }?>
				<?php if(!empty($all_subj_mark['subj_prac']) || (strlen($all_subj_mark['subj_prac'])>0)){?><td><?php if($all_subj_mark['prac_pass'] == 0){?><span class="fail"><?php print_r($all_subj_mark['subj_prac']);?></span><?php }else{print_r($all_subj_mark['subj_prac']);}?></td><?php }?>
				<?php if(($all_subj_mark['subj_id'] ==4)){?>
					<?php if(!empty($all_subj_mark['subj_total']) || (strlen($all_subj_mark['subj_total'])>0)){?><td><?php if(($all_subj_mark['ttl_pass_mark'])>($all_subj_mark['subj_total']*100/$all_subj_mark['ttl_full_mark'])){?><span class="fail"><?php print_r($all_subj_mark['subj_total']);?></span><?php }else{print_r($all_subj_mark['subj_total']);}?></td><?php }?>
				<?php }	else if(($all_subj_mark['subj_id'] !=1) && ($all_subj_mark['subj_id'] !=3)){?>
					<?php if(!empty($all_subj_mark['subj_total']) || (strlen($all_subj_mark['subj_total'])>0)){?><td><?php if(($all_subj_mark['subj_total'] == 0) || ($all_subj_mark['sub_gpa'] == 0)){?><span class="fail"><?php print_r($all_subj_mark['subj_total']);?></span><?php }else{print_r($all_subj_mark['subj_total']);}?></td><?php }?>
				<?php }?>
			<?php }}?>
			<td><?php print_r($outval['point']);?></td>
			<td><?php if($outval['grade'] == 'F'){?><span class="fail"><?php print_r($outval['grade']);?></span><?php }else{print_r($outval['grade']);}?></td>
		</tr>
		<?php }?>
	</tbody>
</table>
</div>
