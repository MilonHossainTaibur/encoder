<?php
	if($details['class_id'] == 1){$c_name1='Seven';$c_value1='2';$c_name2='Six';$c_value2='1';}
	else if($details['class_id'] == 2){$c_name1='Eight';$c_value1='3';$c_name2='Seven';$c_value2='2';}
	else if($details['class_id'] == 3){$c_name1='Nine';$c_value1='4';$c_name2='Eight';$c_value2='3';}
	else if($details['class_id'] == 4){$c_name1='Ten';$c_value1='5';$c_name2='Nine';$c_value2='4';}
?>
<div class="table-responsive" id="print_area">

	<div class="container" style="text-align: center;width: 100%;">
		<div class="tabu-header">
			<h4 style="font-weight: 700;font-size: 25px;"><?= $school_info[0]['school_name'] ?></h4>
			<h5 style="font-size: 20px;">Tabulation Sheet for <?= $details['term_name']; ?>-<?= $details['exam_year']; ?></h5>
			<h5 style="font-size: 18px;">Class - <?= $details['class_name']; ?> - <?= $details['section_name']; ?> (<?= $details['shift_name']; ?> - <?= $details['group_name']; ?>)</h5>
			<h5 style="margin-bottom: 10px!important;font-size: 18px;">Total Student: <?php echo $total_student;?>, Pass: <?php echo ($total_student-$total_fail);?>, Fail: <?php echo $total_fail;?></h5>
		</div>
	</div>

	<style>
		table {
			border-collapse: collapse;
		}

		table, td{
			border: 1px solid black;
		}

		th {
			text-transform: uppercase;
		}
		.no-border{
			border:0!important;
		}
		.center{
			text-align:center;}
		.tb tr td {
			height: 50px;
		}
		.tabu-header h2,.tabu-header h3,.tabu-header h4,.tabu-header h5{
			padding: 0px!important;
			margin-top: 0px!important;
			margin-bottom: 0px!important;
		}
		span.fail{
			width:100%;
			border-bottom:5px solid #CD0000;
			color:#000;
		}
	</style>
	<style type="text/css">
		@page
		{
			size: portrait;
		}
		@media print{
			@page {
				size: portrait;
			}
		}
		@media print{
			.class-name{
			@page{
				size:portrait;
			}
		}
		}
		table thead tr>th{
			text-align: center;
			/*font-size: 15px;*/
			font-weight: 600;
		}
		table  tr>td{
			font-weight: 400;
			/*font-size: 15px;*/
		}
	</style>
	<style type="text/css" media="print">
		@page { size: portrait; }
		table tr>td{
			border-color: #95a5a6;
		}
		table thead tr{
			text-align: center;
			font-size: 14px!important;
			font-weight: 500;
			border:1px solid #95a5a6;
			border-color: #95a5a6;
		}
		table thead tr>th{

			border:1px solid #95a5a6;

		}
		table  tr>td{
			font-weight: 400;
			font-size: 15px;
		}
		.hid{
			display: none;
			visibility: hidden;
		}
	</style>
	<form role="form" id="promoteForm" method="POST" action="<?= base_url();?>result/student_yearly_promote_save">
		<table>
			<thead>
			<tr>
				<th style="max-width: 00px;">SL</th>
				<th class="hid"><input type="checkbox" id="all_std_check"></th>
				<th>Std ID</th>
				<th style="min-width: 140px">Name</th>
				<th>Section</th>
				<th>Roll</th>
				<?php foreach($term_list as $tl){ if (in_array($tl['term_id'], $terms_id)){?>
					<th><?php echo $tl['term'].' gpa';?></th>
				<?php }}?>
				<th>Avg. GPA</th>
				<th>Avg. GRADE</th>
				<th style="min-width: 110px">
					<input type="radio" class="classno" name="classno" value="<?php echo $c_value1;?>"><?php echo $c_name1;?> <input type="radio" class="classno" name="classno" value="<?php echo $c_value2;?>"><?php echo $c_name2;?> </th>
			</tr>
			</thead>
			<tbody class="center tb" >
			<?php
			usort($output, function($a,$b){	$c = $b['point'] <=> $a['point']; $c.=$b['ttl_get_mark'] - $a['ttl_get_mark']; return $c;});
			//print_r($output);exit;
			foreach($output as $i=>$outval){
				?>
				<tr>
					<td><?php print_r($i+1);?></td>
					<td class="hid"><input type="checkbox" class="std_check" name="std_check[<?= $outval['student_id'];?>]" ></td>
					<td><?php print_r($outval['student_id']);?></td>
					<td><?php print_r($outval['student_name']);?></td>
					<td><?php print_r($outval['section_name']);?></td>
					<td><?php print_r($outval['roll_no']);?></td>
					<?php foreach($outval['term_point'] as $term_point){?>
						<td><?php print_r($term_point);?></td>
					<?php }?>
					<td><?php print_r($outval['point']);?></td>
					<td><?php if($outval['grade'] == 'F'){?><span class="fail"><?php print_r($outval['grade']);?></span><?php }else{print_r($outval['grade']);}?></td>
					<td>
						<input type="radio" class="stdclassno-<?php echo $c_value1;?>" name="stdclassno-<?php print_r($i);?>" value="<?php echo $c_value1;?>" checked><?php echo $c_name1;?> <input type="radio" class="stdclassno-<?php echo $c_value2;?>" name="stdclassno-<?php print_r($i);?>" value="<?php echo $c_value2;?>"><?php echo $c_name2;?>
						<input type="hidden" name="student_iddfsd[]" value="<?= $outval['student_id'];?>">
					</td>
				</tr>
			<?php }?>
			<tr class="hid">
				<td>
					<input type="hidden" name="session_id" value="<?= $details['session_id']+1; ?>">
					<input type="hidden" name="group_id" value="<?= $details['group_id']; ?>">
					<input type="hidden" name="shift_id" value="<?= $details['shift_id']; ?>">
					<input type="hidden" name="class_id" value="<?= $details['class_id']; ?>">
					<input type="submit" class="btn btn-primary hid" value="Save"/>
				</td>
			</tr>
			</tbody>
		</table>
	</form>
	<div class="print_button">
	<br/>
	<input type="button" class="btn btn-danger btn-lg hid" onClick="PrintElem('print_area')" value="Print"/>
</div>
	<script type="text/javascript">
        $('#all_std_check').change(function(){
            $('.std_check').prop('checked', $(this).prop('checked'));
        });

        $('.std_check').change(function(){
            if(false == $(this).prop("checked")){
                $("#all_std_check").prop('checked', false);
            }
            if ($('.std_check:checked').length == $('.std_check').length ){
                $("#all_std_check").prop('checked', true);
            }
        });
		// radio button code start
		$('.classno').change(function(){
            var value = $(this).val();
			$('.stdclassno-'+value).prop('checked', $(this).prop('checked'));
		});
    </script>
</div>
