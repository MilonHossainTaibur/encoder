	<form role="form" id="registerForm" method="POST" action="<?= base_url();?>result/get_mark_entry_save">
		<div class="form-group">
        	<div class="row">
            	<div class="col-sm-11" style="text-align: center;font-size:20px;font-weight:bold;">
                	<p><?php echo 'Exam Name: '.$mark_entry_list['0']['class_name']. ' <br> Group: '.$mark_entry_list['0']['group_name']. ' <br> Exam Year: '.$mark_entry_list['0']['session_name'] ;?></p>
				</div>
            </div>
        </div>
						
		<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%" border=1>
			<thead>
				<tr>
					<th>Student ID</th>
					<th>Roll No</th>
                    <th>Student Name</th>
                    <th style="display: none;">Student ID</th>
					<th style="display: none;">Roll No</th>
                    <th style="display: none;">Student Name</th>
                    <th style="display: none;">Student ID</th>
					<th style="display: none;">Roll No</th>
                    <th style="display: none;">Student Name</th>
                    <th style="display: none;">Student ID</th>
					<th style="display: none;">Roll No</th>
                    <th style="display: none;">Student Name</th>
                    <th style="display: none;">Student ID</th>
					<th style="display: none;">Roll No</th>
                    <th style="display: none;">Student Name</th>
                    <th>Total GPA</th>
                    <th>Letter Grade</th>
                    <th>Registration</th>
                    <th>Participate in the selection exam</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach($mark_entry_list as $sl): ?>
				<tr>
					<td>
                        <input type="text" class="form-control" name="student_id[]" value="<?= $sl['student_id'];?>" readonly="readonly" />
					</td>
					<td>
                    	<input type="text" class="form-control" name="roll_no[]" value="<?= $sl['roll_no'];?>" readonly="readonly" />
					</td>
					<td>
						<input type="text" class="form-control" name="student_name[]" value="<?= $sl['student_name'];?>" readonly="readonly" />
						
					</td>
                    <td style="display: none;">
                    	<input type="text" class="form-control" name="gender[]" value="<?= $sl['gender'];?>" />
					</td>
					<td style="display: none;">
						<input type="text" class="form-control" name="student_image[]" value="<?= $sl['student_image'];?>" />
					</td>
					<td style="display: none;">
						<input type="text" class="form-control" name="present_address[]" value="<?= $sl['present_address'];?>" />
					</td>
                    <td style="display: none;">
                    	<input type="text" class="form-control" name="father_name[]" value="<?= $sl['father_name'];?>" />
					</td>
					<td style="display: none;">
						<input type="text" class="form-control" name="mobile_contact[]" value="<?= $sl['mobile_contact'];?>" />
					</td>
					<td style="display: none;">
						<input type="text" class="form-control" name="student_class_id[]" value="<?= $sl['student_class_id'];?>" />
					</td>

					<td style="display: none;">
						<input type="text" class="form-control" name="session_id[]" value="<?= $sl['session_id'];?>" />
					</td>
					<td style="display: none;">
						<input type="text" class="form-control" name="section_id[]" value="<?= $sl['section_id'];?>" />
					</td>
                    <td style="display: none;">
                    	<input type="text" class="form-control" name="group_id[]" value="<?= $sl['group_id'];?>" />
					</td>
					<td style="display: none;">
						<input type="text" class="form-control" name="class_id[]" value="<?= $sl['class_id'];?>" />
					</td>
					<td style="display: none;">
						<input type="text" class="form-control" name="class_name[]" value="<?= $sl['class_name'];?>" />
					</td>
                    <td style="display: none;">
                    	<input type="text" class="form-control" name="class_short_form[]" value="<?= $sl['class_short_form'];?>" />
					</td>

					<td>
						<input type="text" class="form-control" name="gpa[]" placeholder="GPA"/>
					</td>
                    <td>
                    
						<input type="text" class="form-control" name="grade[]" placeholder="Grade"/>
					</td>

					<td>
						<select class="form-control" name="registration[]">
						  <option value="1" selected>Yes</option>
						  <option value="0">No</option>
						</select>
					</td>
                    <td>
                        <select class="form-control" name="participate[]">
						  <option value="1" selected>Yes</option>
						  <option value="0">No</option>
						</select>
					</td>
                    
                    
				</tr>
				<?php endforeach; ?>
				<tr>
					<td colspan="2">
						<input type="submit" class="btn btn-primary" value="Save"/><br/>
					</td>
				</tr>
			</tbody>
		</table>
  	</form>

<style>
{
	margin:auto auto;
}
</style>
<script>
function validation(number,student_id,marks)
{
	///var full_marks =parseInt($('.full_marks').text());
	var numbers=/^([0-9.]*)$/;
		if (numbers.test(number))
			{
				if(number>marks)
				{
					$('#obtain_marks'+student_id).after("<div id='validation"+student_id+"' class='validation_js_small'>This number is more than Full Marks</div>")
						$('#validation'+student_id).delay(2000).hide('slow');
						
					$('#obtain_marks'+student_id).val("");
				}
			}
		else
			{
				
				$('#obtain_marks'+student_id).after("<div id='validation"+student_id+"' class='validation_js_small'>Please enter number only</div>")
						$('#validation'+student_id).delay(2000).hide('slow');
				$('#obtain_marks'+student_id).val("");
			}
	
	
}
function validation_obj(number,student_id,marks)
{
	///var full_marks =parseInt($('.full_marks').text());
	var numbers=/^([0-9.]*)$/;
		if (numbers.test(number))
			{
				if(number>marks)
				{
					$('#objective_marks'+student_id).after("<div id='validation_obj"+student_id+"' class='validation_js_small'>This number is more than Full Marks</div>")
						$('#validation_obj'+student_id).delay(2000).hide('slow');
						
					$('#objective_marks'+student_id).val("");
				}
			}
		else
			{
				
				$('#objective_marks'+student_id).after("<div id='validation_obj"+student_id+"' class='validation_js_small'>Please enter number only</div>")
						$('#validation_obj'+student_id).delay(2000).hide('slow');
				$('#objective_marks'+student_id).val("");
			}
	
	
}
function validation_prac(number,student_id,marks)
{
	///var full_marks =parseInt($('.full_marks').text());
	var numbers=/^([0-9.]*)$/;
		if (numbers.test(number))
			{
				if(number>marks)
				{
					$('#practical_marks'+student_id).after("<div id='validation_prac"+student_id+"' class='validation_js_small'>This number is more than Full Marks</div>")
						$('#validation_prac'+student_id).delay(2000).hide('slow');
						
					$('#practical_marks'+student_id).val("");
				}
			}
		else
			{
				
				$('#practical_marks'+student_id).after("<div id='validation_prac"+student_id+"' class='validation_js_small'>Please enter number only</div>")
						$('#validation_prac'+student_id).delay(2000).hide('slow');
				$('#practical_marks'+student_id).val("");
			}
	
	
}
</script>