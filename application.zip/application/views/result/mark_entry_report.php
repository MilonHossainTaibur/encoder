<!-- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>
				
<!-- Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
<div class="content-page">			
    <div class="content">
        <!-- Page Heading Start -->
        <div class="page-heading">
            <h1><i class='fa fa-table'></i>Mark Entry(SSC, JSC) Report</h1>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="widget" style="min-height: 400px">
					<div class="widget-content">
						<div class="widget-content padding">
							<div class="form-group">
								<div class="row">
									 <div class="col-sm-3 col-md-3">
										<label>Exam Name<span style="color:red;">*</span></label>
										<select class="form-control" name="class_id" id="class_id" onchange="get_class_section_list(this.value);get_class_group_list(this.value);">
											<option value="">----Select Exam Name----</option>
											<option value="5">SSC</option>
											<option value="3">JSC</option>
										</select>
									 </div>
								
									 <div class="col-sm-3 col-md-3">
									   <label>Group <span style="color:red;">*</span></label>
										<select class="form-control" name="group_id" id="group_id" required onChange="get_sub_list(this.value);" >
											<option value="">-----Select Group-----</option>
										</select>
									</div>

									<div class="col-sm-3 col-md-3">
										<label>Exam Year<span style="color:red;">*</span></label>
										<select class="form-control" name="session_id" id="session_id" onChange="get_student_list_marksheet(this.value)">
											<option value="">-----Select Session-----</option>
											<?php foreach($session_list as $sl){ ?>
											<option value="<?= $sl['session_id'];?>"><?= $sl['session_name'];?></option>
											<?php } ?>
										</select>
									</div>

									<div class="col-sm-3 col-md-3">
										<button class="btn btn-success btn-label-center" style="margin-top: 23px;" onclick="mark_entry_report_json()" type="button">Show Result</button>
									</div>
				
									
								</div>
							</div>
					
							
					
							<div id="display">
								<!-- content will display here -->
							</div>
						</div><!--//section-content-->
					</div><!--//news-wrapper-->
				</div><!--//page-row-->
			</div><!--//page-content-->
		</div><!--//page-wrapper-->
    
<?php include 'application/views/includes/footer.php';?>

<!--Check department name based on class id-->
<script>
function get_class_section_list(class_id)
   {
      $.ajax({
       type: "POST",
       url: baseUrl + 'admin/section_list_ajax',
       data:
       {
           'class_id':class_id
       }, 
       success: function(html_data)
       {
           if (html_data != '')
           {
               $('#section_id').html(html_data);
           }
       }
       });
   }

function get_class_group_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'academic/group_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#group_id').html(html_data);
        }
    }
    });  
}

 function mark_entry_report_json(session_id)
		{
			//alert();
			var class_id = $('#class_id').val();
			var group_id = $('#group_id').val();
			var session_id = $('#session_id').val();
		   $.ajax({
			type: "POST",
			url: baseUrl + 'result/get_mark_entry_report_json',
			data:
			{
				'class_id':class_id,
				'group_id':group_id,
				'session_id':session_id
			}, 
			success: function(html_data)
			{
				if (html_data != '')
				{
					$('#display').html(html_data);
				}
			}
			});  
		}
	function mark_sheet_json($parm)
		{
			var class_id = $('#class_id').val();
			var class_short_form = $('#class_id :selected').attr('id');
			var section_id = $('#section_id').val();
			var shift_id = $('#shift_id').val();
			var group_id = $('#group_id').val();
			var session_id = $('#session_id').val();
			var student_id = $('#student_id').val();
			var term_id = $('#term_id').val();
			var term_name = $('#term_id option:selected').text();
			var session = $('#session_id option:selected').text();
			var view_type = $parm;
			//alert(class_id+group_id);
			
			if(!class_id)
			{
				$('#class_id').after("<div id='validation_class' class='validation_js'>Please select a class.</div>")
					$('#validation_class').delay(3000).hide('slow');
					return;
				
			}
			if(!section_id)
			{
				$('#section_id').after("<div id='validation_section' class='validation_js'>Please select a section.</div>")
					$('#validation_section').delay(3000).hide('slow');
					return;
				
			}
			if(!group_id)
			{
				$('#group_id').after("<div id='validation_group' class='validation_js'>Please select a group.</div>")
					$('#validation_group').delay(3000).hide('slow');
					return;
				
			}
			if(!shift_id)
			{
				$('#shift_id').after("<div id='validation_shift_id' class='validation_js'>Please select a shift.</div>")
					$('#validation_shift_id').delay(3000).hide('slow');
					return;
				
			}
			if(!session_id)
			{
				$('#session_id').after("<div id='validation_ses' class='validation_js'>Please select a session.</div>")
					$('#validation_ses').delay(3000).hide('slow');
					return;
				
			}
			if(!student_id)
			{
				$('#student_id').after("<div id='validation_stu' class='validation_js'>Please select a student.</div>")
					$('#validation_stu').delay(3000).hide('slow');
					return;
				
			}
			if(!term_id)
			{
				$('#term_id').after("<div id='validation_ct' class='validation_js'>Please select a term.</div>")
					$('#validation_ct').delay(3000).hide('slow');
					return;
				
			}
		
			$.ajax({ 
			url: baseUrl+'result/mark_sheet_json',
			data:
				{                  
					'class_id':class_id,
					'class_short_form':class_short_form,
					'session_id':session_id,
					'section_id':section_id,
					'shift_id':shift_id,
					'group_id':group_id,
					'student_id':student_id,
					'term_id':term_id,
					'term_name':term_name,
					'session':session,
					'view_type':view_type
				},
				dataType: 'json',
				success: function(data)
				{
					result                = ''+data['result']+'';
					mainContent           = ''+data['mainContent']+'';
	
					if(result == 'success')
					{            
						$('#display').html(mainContent);     
					}                
				}
			});
		}	
		
function PrintElem(elem)
{
    var mywindow = window.open('', 'PRINT', 'width=2800,height=1700');

    mywindow.document.write('<html><head><title>' + document.title  + '</title>');
    mywindow.document.write('</head><body >');
    mywindow.document.write('<span>' + document.title  + '</span>');
    mywindow.document.write(document.getElementById(elem).innerHTML);
    mywindow.document.write('</body></html>');

    mywindow.document.close(); // necessary for IE >= 10
    mywindow.focus(); // necessary for IE >= 10*/

    mywindow.print();
    mywindow.close();

    return true;
}
</script> 

