<div class="table-responsive" id="print_area">

	<div class="container" style="text-align: center;width: 100%;">
		<div class="tabu-header">
			<h2 style="font-weight: 700;font-size: 32px;"><?= $school_info[0]['school_name'] ?></h2>
			<h3 style="font-size: 24px;">Students List for Final Promote</h3>
			<h4 style="font-size: 20px;"><?= $details['class_name']; ?> - <?= $details['group_name']; ?></h4>
			<h5 style="margin-bottom: 10px!important;font-size: 18px;">Total Student: <?php echo count($student_list);?></h5>
		</div>
	</div>

	<style>
		table {
			border-collapse: collapse;
		}

		table, td{
			border: 1px solid black;
		}

		th {
			text-transform: uppercase;
		}
		.no-border{
			border:0!important;
		}
		.center{
			text-align:center;}
		.tb tr td {
			height: 50px;
		}
		.tabu-header h2,.tabu-header h3,.tabu-header h4,.tabu-header h5{
			padding: 0px!important;
			margin-top: 0px!important;
			margin-bottom: 0px!important;
		}
		span.fail{
			width:100%;
			border-bottom:5px solid #CD0000;
			color:#000;
		}
	</style>
	<STYLE type="text/css">
		@page
		{
			size: portrait;
		}
		@media print{
			@page {
				size: portrait
			}
		}
		@media print{
			.class-name{
			@page{
				size:portrait;
			}
		}
		}
		table thead tr>th{
			text-align: center;
		}
	</STYLE>

    <form role="form" id="promoteForm" method="POST" action="<?= base_url();?>result/student_yearly_final_promote_save">
        <table>
            <thead>
            <tr>
                <th>Std ID</th>
                <th>Name</th>
                <th>Class</th>
                <th>New Roll</th>
                <th>Section</th>
                <th>Group</th>
            </tr>
            </thead>
            <tbody class="center tb" >
            <?php
            //usort($output, function($a,$b){	$c = strcmp($b['point'], $a['point']); $c.=$a['roll_no'] - $b['roll_no']; return $c;});
            //print_r($student_list);exit;
            foreach($student_list as $i=>$outval){
                ?>
                <tr>
                    <td><?php print_r($outval['student_id']);?></td>
                    <td><?php print_r($outval['student_name']);?></td>
                    <td><?php print_r($details['class_name']); ?></td>
                    <td><input type="text" name="new_roll[]" style="text-align: right" size="2" maxlength="4" value="<?php print_r($i+1);?>" /></td>
                    <td><?php foreach($sectionInfo as $k=>$sections){?><input type="radio" class="classno" name="sectionno-<?php echo $i;?>" value="<?php echo $sections['section_id'];?>" checked><?php echo $sections['section_name'];?> <?php }?></td>
                    <td>
                        <?php foreach($groupInfo as $k=>$groups){?><input type="radio" class="groupno" name="groupno-<?php echo $i;?>" value="<?php echo $groups['group_id'];?>" <?php if($outval['group_id'] == $groups['group_id']) echo 'checked';?>><?php echo $groups['group_name'];?> <?php }?>
                        <input type="hidden" name="students_id[]" value="<?php print_r($outval['student_id']);?>">
						<input type="hidden" name="shift_id" value="<?php print_r($outval['shift_id']);?>">
                    </td>

                </tr>
            <?php }?>
                <tr>
                    <td>
                        <input type="hidden" name="session_id" value="<?= $details['session_id']; ?>">
                        <input type="hidden" name="group_id" value="<?= $details['group_id']; ?>">
                        <input type="hidden" name="class_id" value="<?= $details['class_id']; ?>">
                        <input type="submit" class="btn btn-primary" value="Save"/><br/>
                    </td>
                </tr>
            </tbody>
        </table>
    </form>
</div>
<div class="">
	<br/>
	<input type="button" class="btn btn-danger btn-lg hid" onClick="PrintElem('print_area')" value="Print"/>
</div>
