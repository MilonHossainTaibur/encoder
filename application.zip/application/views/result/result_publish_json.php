<div class="widget-content">
	<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
		<thead>
			<tr>
				<th>#SL</th>
				<th>Class Name</th>
				<th>section Name</th>
				<th>Publish/Unpublish</th>
			</tr>
		</thead>
		<tbody>
			<?php $i=1; foreach($cs_list as $dl){ ?>
			<tr>
				<td><?= $i;?></td>
				<td><?= $dl['class_name'];?></td>
				<td><?= $dl['section_name'];?></td>
				<td class="<?= $i;?>">
					<?php if(isset($csp_list[$dl['class_id'].$dl['section_id']]->status) && $csp_list[$dl['class_id'].$dl['section_id']]->status==1){ ?>
					<button class="btn btn-danger" onclick="change_status(<?= $dl['class_id'];?>,<?= $dl['section_id'];?>,<?= $details['session_id'];?>,<?= $details['term_id'];?>,0,<?= $i;?>)"> Unpublish </button>
					<?php }else{ ?>
					<button class="btn btn-primary" onclick="change_status(<?= $dl['class_id'];?>,<?= $dl['section_id'];?>,<?= $details['session_id'];?>,<?= $details['term_id'];?>,1,<?= $i;?>)"> Publish </button>
					<?php } ?>
				</td>
			</tr>
			<?php $i++; } ?>
		</tbody>
	</table>
</div>
<script>
function change_status(class_id,section_id,session_id,term_id,status,row)
		{
		   $.ajax({
			type: "POST",
			url: baseUrl + 'result/result_publish_change',
			data:
			{
				'class_id':class_id,
				'section_id':section_id,
				'session_id':session_id,
				'term_id':term_id,
				'status':status,
				'row':row
			}, 
			success: function(html_data)
			{
				if (html_data != '')
				{
					$('.'+row).html(html_data);
				}
			}
			});  
		}
</script>