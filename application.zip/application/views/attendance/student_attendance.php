<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
<div class="content-page">
	<!-- Start Content here -->
	<div class="content">
		<div class="page-heading">
            <h1><i class='fa fa-table'></i> Student Attendance</h1>
		</div>
		<?php if($this->session->flashdata('message')):?>
			<?=$this->session->flashdata('message')?>
		<?php endif?> 
		<div class="row">
            <div class="col-md-12">
				<div class="widget" style="min-height: 400px">
					<div class="widget-content">
						<div class="widget-content padding">
							<div class="form-group">
								<div class="row">
									<div class="col-sm-6 col-md-3">
										<label>Class</label>
										<select class="form-control" id="class_id" onchange="get_class_section_list(this.value);">
											<option value="">-----Select Class-----</option>
											<?php foreach($class_list as $cl){ ?>
											<option value="<?php echo $cl['class_id'];?>"><?php echo $cl['class_name'];?></option>
											<?php } ?>
										</select>
									</div>
									<div class="col-sm-6 col-md-3">
										<label>Section <span style="color:red;">*</span></label>
										<select class="form-control" name="section_id" id="section_id">
											<option value="">-----Select Section-----</option>
										</select>
									</div>
									<div class="col-sm-6 col-md-3">
										<label>Shift</label>
										<select class="form-control" id="shift_id">
											<option value="">-----Select Shift-----</option>
											<?php foreach($shift_list as $shiftl){ ?>
											<option value="<?= $shiftl['shift_id'];?>"><?= $shiftl['shift_name'];?></option>
											<?php  } ?>
										</select>
									</div>
									<div class="col-sm-6 col-md-3">
										<label>Session</label>
										<select class="form-control" id="session_id">
											<option value="">-----Select Session-----</option>
											<?php foreach($session as $sl){ ?>
											<option value="<?= $sl['session_id'];?>"><?= $sl['session_name'];?></option>
											<?php  } ?>
										</select>
									</div>
								</div>
							</div>
							<div class="form-group">
								<div class="row">
									<div class="col-sm-4">
										<button type="button" class="btn btn-primary" onclick="get_student_list()">Show Students</button>
									</div>
								</div>
							</div>
						</div>
						<hr/>
                        
						<div id="display">
							<!---JSON Content will be displayed here--->
						</div>
					</div>
				</div>
			</div>
		</div>

<?php include 'application/views/includes/footer.php';?>

<script>
	function get_class_section_list(class_id)
	{
	   $.ajax({
		type: "POST",
		url: baseUrl + 'admin/section_list_ajax',
		data:
		{
			'class_id':class_id
		}, 
		success: function(html_data)
		{
			if (html_data != '')
			{
				$('#section_id').html(html_data);
			}
		}
		});  
	}
	// get the student list and fees list 
	function get_student_list()
	{
		var class_id = $('#class_id').val();
		var section_id = $('#section_id').val();
		var shift_id = $('#shift_id').val();
		var session_id = $('#session_id').val();
        $.ajax({ 
        url: baseUrl+'attendance/get_student_list_for_attendance_json',
        data:
            {                  
                'class_id':class_id,
				'section_id':section_id,
				'shift_id':shift_id,
				'session_id':session_id
            }, 
            dataType: 'json',
            success: function(data)
            {
                result                = ''+data['result']+'';
                mainContent           = ''+data['mainContent']+'';

                if(result == 'success')
                {            
                    $('#display').html(mainContent);     
                }                
            }
        });
        return false; // keeps the page from not refreshing     
    }

</script>