<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
	<div class="content-page">
		<!-- ============================================================== -->
		<!-- Start Content here -->
		<!-- ============================================================== -->
		<div class="content">
			<div class="page-heading">
            	<h1><i class='fa fa-table'></i> Student Attendance Report</h1>
			</div>
			<div class="row">
            	<div class="col-md-12">
                    <div class="widget" style="min-height: 400px">
                        <div class="widget-content">
                            <div class="widget-content padding">
								<div class="form-group">
									<div class="row">
										<div class="col-sm-12 col-md-12"><label>Report Type<span style="color:red;">*</span></label></div>
										<div class="col-sm-12 col-md-4">
											<label class="radio-inline">
											  <input type="radio" name="stu_rep_radio" class="stu_rep_radio" value="daily" checked>Daily
											</label>
											<label class="radio-inline">
											  <input type="radio" name="stu_rep_radio" class="stu_rep_radio" value="monthly">Monthly
											</label>
										</div>
									</div>
								</div>
								<div class="daily">
									<div class="form-group">
										<div class="row">
											<div class="col-sm-4 col-md-4">
												<label>Date <span style="color:red;">*</span></label>
												<input type="text" id="input_date" class="form-control input_date">
											</div>
										</div>
                                    </div>
									<div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <button type="button" class="btn btn-primary" onclick="student_for_att_report_daily_json()">Show Report</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
								<div class="monthly" style="display:none">
									<?php $months=array('01'=>'January','02'=>'February','03'=>'March','04'=>'April','05'=>'May','06'=>'June','07'=>'July','08'=>'August','09'=>'September','10'=>'October','11'=>'November','12'=>'December'); ?>
									<div class="form-group">
										<div class="row">
											<div class="col-xs-12 col-sm-6 col-md-3">
												<label>Session <span style="color:red;">*</span></label>
												<select class="selectpicker" id="session_id">
                                                    <?php foreach($session as $ses){ ?>
                                                    <option value="<?= $ses['session_id'];?>"><?= $ses['session_name'];?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
											<div class="col-xs-12 col-sm-6 col-md-3">
												<label>Month <span style="color:red;">*</span></label>
												<select class="selectpicker" id="month_id">
                                                    <?php foreach($months as $key => $value){ ?>
                                                    <option value="<?= $key;?>"><?= $value;?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                            <div class="col-xs-12 col-sm-6 col-md-3">
                                                <label>Class <span style="color:red;">*</span></label>
                                                <select class="selectpicker" id="class_id" onchange="get_student_list(this.value);">
                                                	<option value="">-----Select Class-----</option>
                                                    <?php foreach($class_list as $cl){ ?>
                                                    <option value="<?= $cl['class_id'];?>"><?= $cl['class_name'];?></option>
                                                    <?php } ?>
                                                </select>
											</div>
                                            <div class="col-xs-12 col-sm-6 col-md-3">
                                            	<label>Student Name</label>
												<select class="selectpicker" id="student_id">
													<option value="">-----Select Student-----</option>
                                                </select>
											</div>
										</div>
									</div>
									<div class="form-group">
										<div class="row">
											<div class="col-sm-4">
												<button type="button" class="btn btn-primary" onclick="student_for_att_report_monthly_json()">Show Report</button>
											</div>
										</div>
									</div>
								</div>
							</div>
								<hr/>
							<div class="widget-content padding">
                                <div id="display">
                                	<!--JSON Content will be displayed here-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
			</div>

<?php include 'application/views/includes/footer.php';?>

<script>
	function get_student_list(class_id)
	{
		var session_id = $('#session_id').val();
	   $.ajax({
		type: "POST",
		url: baseUrl+'attendance/get_student_list_by_class',
		data:
		{
			'class_id':class_id,
			'session_id':session_id
		}, 
		success: function(html_data)
		{
			if (html_data != '')
			{
				$('#student_id').html(html_data);
			}
		}
		});  
	}
window.onload = function () {
	// Initialize datepicker
	$('#input_date').datepicker({altFormat: "yy-mm-dd"});
	// Load Timepicker plugin
	//LoadTimePickerScript(DemoTimePicker);
	// work for radio button
	$('.stu_rep_radio').click(function(){
		var div_class= $(this).val();
		if(div_class=='daily'){
			$('.daily').show("slow" );
			$('.monthly').hide("slow" );
		}
		else{
			$('.daily').hide("slow" );
			$('.monthly').show("slow" );
		}
	});
	
	};
	
	// get the student daily att report
	function student_for_att_report_daily_json()
	{
		var att_date = $('#input_date').val();
		
        $.ajax({ 
        url: baseUrl+'attendance/student_for_att_report_daily_json',
        data:
            {                  
                'att_date':att_date
            }, 
            dataType: 'json',
            success: function(data)
            {
                result                = ''+data['result']+'';
                mainContent           = ''+data['mainContent']+'';

                if(result == 'success')
                {            
                    $('#display').html(mainContent);     
                }                
            }
        });
        return false; // keeps the page from not refreshing     
    }
	
	// get the student monthly report
	function student_for_att_report_monthly_json()
	{
		var month_id = $('#month_id').val();
		var year_id = $( "#session_id option:selected" ).text();
		var class_id = $('#class_id').val();
		var student_id = $('#student_id').val();
		var student_name = $( "#student_id option:selected" ).text();
		var month_name = $( "#month_id option:selected" ).text();
		var class_name = $( "#class_id option:selected" ).text();
		
        $.ajax({ 
        url: baseUrl+'attendance/student_for_att_report_monthly_json',
        data:
            {                  
                'month_id':month_id,
                'year_id':year_id,
                'class_id':class_id,
                'student_id':student_id,
                'student_name':student_name,
                'month_name':month_name,
                'class_name':class_name
            }, 
            dataType: 'json',
            success: function(data)
            {
                result                = ''+data['result']+'';
                mainContent           = ''+data['mainContent']+'';

                if(result == 'success')
                {            
                    $('#display').html(mainContent);     
                }                
            }
        });
        return false; // keeps the page from not refreshing     
    }
	
	//print all report
	function printPageArea(areaID){
		var printContent = document.getElementById(areaID);
		var WinPrint = window.open('', '', 'width=900,height=650');
		WinPrint.document.write('<link rel="stylesheet" type="text/css" href="<?= base_url();?>template/libs/bootstrap/css/bootstrap.min.css" media="print" />');
		WinPrint.document.write('<style type="text/css" media="print"> @page { font-size:12px; } table{font-size:12px;} table td{padding:3px;} .print_button{ display:none;} .header-div-box{display:inline-block;} .header-div-box.box-left{float:left; margin-bottom:10px;} .header-div-box.box-right{float:right;}</style>');
		WinPrint.document.write(printContent.innerHTML);
		WinPrint.document.close();
		WinPrint.focus();
		WinPrint.print();
		WinPrint.close();
	}
</script>