<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
	<div class="content-page">
		<!-- ============================================================== -->
		<!-- Start Content here -->
		<!-- ============================================================== -->
		<div class="content">
			<div class="page-heading">
            	<h1><i class='fa fa-table'></i> Teacher Attendance</h1>
			</div>
             <?php if($this->session->flashdata('message')):?>
					<?=$this->session->flashdata('message')?>
				<?php endif?> 
			<div class="row">
            	<div class="col-md-12">
                    <div class="widget" style="min-height: 400px">
                        <div class="widget-content">
                            <div class="widget-content padding">
                                <h3>Today : <?= date('d F, Y'); ?> </h3>
                            </div>
                            
								 <hr/>
                                <div id="display">
									<?php $ab_reason=array(1=>'Leave',2=>'Sick',3=>'Other'); ?>
                                	<form method="POST" action="save_teacher_attendance">
									<table class="table table-striped table-bordered" cellspacing="0" width="100%">
										<thead>
											<tr>
												<th>SLNO</th>
												<th>Teacher ID</th>
												<th>Teacher Name</th>
												<th>Status</th>
												<th>Absent Reason</th>
											</tr>
										</thead>
										<tbody>
											<?php $i=1; foreach($teacher_details as $fdl): ?>
											<tr>
												<th><?= $i ?></th>
												<td>
													<?= $fdl['teacher_id'] ?>
													<input type="hidden" name="teacher_id[]" value="<?= $fdl['teacher_id'] ?>" />
												</td>
												<td><?= $fdl['teacher_name'] ?> (<?= $fdl['designation_name'] ?>)</td>
												<td>
													<?php if(isset($fdl['status'])): ?>
													
														<button type="button" class="btn <?php if($fdl['status']==1) {echo "btn-info";}else { echo "btn-danger";} ?>" id="status_change<?= $fdl['teacher_id'] ?>" onclick="change_att_status('<?= $fdl['teacher_id'] ?>')"><?php if($fdl['status']==1) {echo "Present";}else { echo "Absent";} ?></button>
														<input type="hidden" id="status<?= $fdl['teacher_id'] ?>" name="status[]" value="<?= $fdl['status'] ?>" />
														<input type="hidden" name="att_id[]" value="<?= $fdl['att_id'] ?>" />
													
													<?php else: ?>
													
														<button type="button" class="btn btn-info" id="status_change<?= $fdl['teacher_id'] ?>" onclick="change_att_status('<?= $fdl['teacher_id'] ?>')">Present</button>
														<input type="hidden" id="status<?= $fdl['teacher_id'] ?>" name="status[]" value="1" />
													
													<?php endif; ?>
												</td>
												<td>
													<select name="absent_reason[]" class="form-control">
														<option value="0">----- Select Reason-----</option>
														<?php foreach($ab_reason as $key => $value): ?>
														<option value="<?= $key; ?>" <?php if($key==$fdl['absent_reason']) echo "selected"; ?>> <?= $value ?></option>
														<?php endforeach; ?>
													</select>
												</td>
											</tr>
											<?php $i++; endforeach; ?>
											<tr>
												<td colspan="5"><button type="submit" class="btn btn-primary">Save</button></td>
											</tr>
										</tbody>
									</table>
									</form>
                                </div>
                            </div>
                        </div>
                    </div>
				</div>

				
				
<?php include 'application/views/includes/footer.php';?>
<script>
function change_att_status(teacher_id)
{
	if($("#status_change"+teacher_id).hasClass('btn-info'))
	{
		$("#status_change"+teacher_id).removeClass("btn-info").addClass('btn-danger');
		$("#status"+teacher_id).val('0'); // absent
		$("#status_change"+teacher_id).text('Absent');
	}
	else
	{
		$("#status_change"+teacher_id).removeClass("btn-danger").addClass('btn-info');
		$("#status"+teacher_id).val('1');  // present
		$("#status_change"+teacher_id).text('Present');
	}
}

</script>