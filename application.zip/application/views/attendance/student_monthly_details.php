<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!--Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>

<div class="content-page">
	<!-- Start Content here -->
	<div class="content">
		<div class="page-heading">
			<h1><i class='fa fa-table'></i>Monthly Attendance Report</h1>
		</div>
		<div class="panel panel-info" style="width:70%; margin:auto;">
			<div class="panel-heading">
				<span class="pull-center">Attendance Details</span>&nbsp;					
			</div>
			<div class="row">
				<div class="col-md-12">
					<div class="table-responsive table-striped">
						<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
							<thead>
								<tr>
									<th>Date</th>
									<th>Attendance</th>
									<th>Attendance Time</th>
								</tr>
							</thead>
							<tfoot>
								<tr>
									<th>Date</th>
									<th>Attendance</th>
									<th>Attendance Time</th>
								</tr>
							</tfoot>
							<tbody>
								<?php foreach($att_details as $atd){ ?>
								<tr>
									<td>
										<?php
											$date = strtotime($atd['att_date']);
											echo date('d-m-Y', $date);
										?>
									</td>
									<td>
										<?php $status=array('1'=>'Present','0'=>'Absent'); ?>
										<?= $status[$atd['status']];?>
									</td>
									<td>
										<?php
											$date = strtotime($atd['att_date']);
											echo date('h:i:s a', $date); 
										?>
									</td>
								</tr>
								<?php } ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
<?php include 'application/views/includes/footer.php';?>