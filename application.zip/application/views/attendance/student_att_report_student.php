<button type="button" class="btn btn-default pull-right print_button" title="Print This Attendance" onclick="printPageArea('display')"><i class="fa fa-print"></i> Print</button>
<div class="clear"></div>
<?php
		$tr='';
		$p=0;
		$a=0;
	foreach($att_details as $adl):
		 $tr.="<tr><td>".date('d M Y',strtotime($adl['att_date']))."</td><td>".date('l',strtotime($adl['att_date']))."</td>";
		 if($adl['status']==1):
			$tr.="<td> P </td>";
			$p++;
		else:
			$tr.="<td> -- </td>";
		endif;
		
		if($adl['status']==0):
			$tr.="<td> A </td>";
			$a++;
		else:
			$tr.="<td> -- </td>";
		endif;
		$tr.="</tr>";
		
	endforeach; ?>
<div class="col-sm-12 col-md-5 header-div-box box-left" style="text-align:center;">
	<div class="row">
		<div class="col-sm-12 col-md-8 pull-right" style="border:1px solid #EBEBEB; border-radius:5px; padding:10px;" >
			<h2><?= $student_name; ?></h2>
			<h3>ID: <?= $student_id; ?> &nbsp;&nbsp; Class: <?= $class_name; ?></h3>
			<h4>Year : <?= date('Y'); ?> &nbsp;&nbsp; Month: <?= $month_name; ?></h4>
		</div>
	</div>
</div>
<div class="col-sm-12 col-md-5 col-md-offset-1 header-div-box box-right" style="text-align:center;">
	<div class="row">
		<div class="col-sm-12 col-md-8 pull-left" style="border:1px solid #EBEBEB; border-radius:5px; padding:10px;" >
			<h4 style="background:#189119; color:#FFF; padding:5px; margin:0"><b>Total Presents: <?= $p; ?></b></h4>
            <h4 style="background:#EF4B27; color:#FFF; padding:5px; margin:10px 0px 0"><b>Total Absents:  <?= $a; ?></b></h4>
		</div>
	</div>
</div>
<div class="col-lg-12"> &nbsp;</div>
<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
	<thead>
		<tr>
        	<th>Date</th>
            <th>Day</th>
            <th>Present</th>
            <th>Absent</th>
		</tr>
	</thead>
	<tbody>
		<?= $tr; ?>
	</tbody>
</table>
