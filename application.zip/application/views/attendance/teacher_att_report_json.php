<?php $ab_reason=array(1=>'Leave',2=>'Sick',3=>'Other'); ?>
<button type="button" class="btn btn-success pull-right print_button" title="Print This Attendance" onclick="printPageArea('display')"><i class="fa fa-print"></i> Print</button>
<div class="clear"></div>
<?php if($repo_type=="d"): ?>
	<?php
		$i=1;
		$tr='';
		$p=0;
		$a=0;
	 foreach($att_details as $adl):
		 $tr.="<tr><td>".$adl['teacher_id']."</td><td>".$teacher_name_json[array_search($adl['teacher_id'], array_column($teacher_name_json, 'teacher_id'))]['teacher_name']."</td><td>".$teacher_name_json[array_search($adl['teacher_id'], array_column($teacher_name_json, 'teacher_id'))]['designation_name']."</td>";
		 if($adl['status']==1):
			$tr.="<td>P</td>";
			$p++;
		else:
			$tr.="<td>--</td>";
		endif;
		
		if($adl['status']==0):
			$tr.="<td>A</td>";
			$a++;
		else:
			$tr.="<td>--</td>";
		endif;
		$tr.="<td>".$ab_reason[$adl['absent_reason']]."</td></tr>";		
	 $i++; endforeach;
	?>

<div class="col-sm-12 col-md-5 header-div-box box-left" style="text-align:center;">
	<div class="row">
		<div class="col-sm-12 col-md-8 pull-right" style="border:1px solid #EBEBEB; border-radius:5px; padding:10px;" >
			<h3><b><?= $att_day; ?></b></h3>
			<h4>Teachers Attendance Of</h4>
			<h4><?= $att_date; ?></h4>
		</div>
	</div>
</div>
<div class="col-sm-12 col-md-5 col-md-offset-1 header-div-box box-right" style="text-align:center;">
	<div class="row">
		<div class="col-sm-12 col-md-8 pull-left" style="border:1px solid #EBEBEB; border-radius:5px; padding:10px;" >
			<h4 style="background:#189119; color:#FFF; padding:5px; margin:0"><b>Total Presents: <?= $p; ?></b></h4>
            <h4 style="background:#EF4B27; color:#FFF; padding:5px; margin:10px 0px 0"><b>Total Absents:  <?= $a; ?></b></h4>
		</div>
	</div>
</div>
<div class="col-lg-12"> &nbsp;</div>
<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
	<thead>
		<tr>
            <th>TID</th>
            <th>Teacher Name</th>
            <th>Teacher Designation</th>
            <th>Present</th>
			<th>Absent</th>
        	<th>Absent Reason</th>
		</tr>
	</thead>
	<tbody>
          <?= $tr; ?>
	</tbody>
</table>
<?php elseif($repo_type=="m"): ?>
<div style="text-align:center;">
	<h3>Teachers Attendance of</h3>
	<h4><b>Year : <?= date('Y'); ?> &nbsp;&nbsp;&nbsp;&nbsp; Month: <?= $month_name; ?></b></h4>
</div>
<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
	<thead>
		<tr>
            <th>TID</th>
            <th>Teacher Name</th>
            <th>Teacher Designation</th>
            <th>Present</th>
			<th>Absent</th>
		</tr>
	</thead>
	<tbody>
		<?php $i=1; foreach($att_details as $adl): ?>
		<tr>
        	<td><?= $adl['teacher_id']; ?></td>
        	<td><?= $teacher_name_json[array_search($adl['teacher_id'], array_column($teacher_name_json, 'teacher_id'))]['teacher_name'];  ?></td>
        	<td><?= $teacher_name_json[array_search($adl['teacher_id'], array_column($teacher_name_json, 'teacher_id'))]['designation_name'];  ?></td>
        	<td><?= $adl['present'] ?></td>
        	<td><?= $adl['absent'] ?></td>
		</tr>
		<?php $i++; endforeach; ?>
	</tbody>
</table>

<?php elseif($repo_type=="t"): ?>
	<?php
		$i=1;
		$tr='';
		$p=0;
		$a=0;
		$leave=array();
	 foreach($att_details as $adl):
		 $tr.="<tr><td>".date('d M Y',strtotime($adl['att_date']))."</td><td>".date('l',strtotime($adl['att_date']))."</td>";
		 if($adl['status']==1):
			$tr.="<td>P</td>";
			$p++;
		else:
			$tr.="<td>--</td>";
		endif;
		
		if($adl['status']==0):
			$tr.="<td>A</td>";
			if($adl['absent_reason']==3 || $adl['absent_reason']==0):
				$a++;
			endif;
		else:
			$tr.="<td>--</td>";
		endif;
		$tr.="<td>".$ab_reason[$adl['absent_reason']]."</td></tr>";
		// push leave status array
		array_push($leave,$ab_reason[$adl['absent_reason']]);
		
	 $i++; endforeach; print_r();
	?>
<div class="col-sm-12 col-md-5 header-div-box box-left" style="text-align:center;">
	<div class="row">
		<div class="col-sm-12 col-md-8 pull-right" style="border:1px solid #EBEBEB; border-radius:5px; padding:10px;" >
			<h3><?= $month_name; ?> , <?= date('Y'); ?></h3>
			<h4>Attendance Of</h4>
			<h4><b><?= $teacher_name; ?></b></h4>
		</div>
	</div>
</div>
<div class="col-sm-12 col-md-5 col-md-offset-1 header-div-box box-right" style="text-align:center;">
	<div class="row">
		<div class="col-sm-12 col-md-8 pull-left" style="border:1px solid #EBEBEB; border-radius:5px; padding:10px;" >
			<h4 style="background:#189119; color:#FFF; padding:5px; margin:0"><b>Total Presents: <?= $p; ?></b></h4>
            <h4 style="background:#EF4B27; color:#FFF; padding:5px; margin:10px 0px 0"><b>Total Absents:  <?= $a; ?></b></h4>
            <h4 style="background:#1DB0AB; color:#FFF; padding:5px; margin:10px 0px 0"><b>
				<?php foreach(array_count_values($leave) as $key => $value):
						if($key!="Other"):
				?>
				<?= $key; ?>:  <?= $value; ?>
				<?php endif; endforeach; ?>
				</b>
			</h4>
		</div>
	</div>
</div>
<div class="col-lg-12"> &nbsp;</div>
<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
	<thead>
		<tr>
            <th>Date</th>
            <th>Day</th>
            <th>Present</th>
			<th>Absent</th>
        	<th>Absent Reason</th>
		</tr>
	</thead>
	<tbody>
		<?= $tr; ?>
	</tbody>
	
</table>
<?php endif; ?>