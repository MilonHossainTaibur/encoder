<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
	<div class="content-page">
		<!-- ============================================================== -->
		<!-- Start Content here -->
		<!-- ============================================================== -->
		<div class="content">
			<div class="page-heading">
            	<h1><i class='fa fa-table'></i> Teacher Attendance Report</h1>
			</div>
			<div class="row">
            	<div class="col-md-12">
                    <div class="widget" style="min-height: 400px">
                        <div class="widget-content">
                            <div class="widget-content padding">
							<div class="row">
								<div class="col-sm-12 col-md-4 col-lg-2">
									<div class="row">
										<div class="col-sm-12 col-md-12"><label>Report Type<span style="color:red;">*</span></label></div>
										<div class="col-sm-12 col-md-12">
											<label class="radio-inline">
											  <input type="radio" name="stu_rep_radio" class="stu_rep_radio" value="daily" checked>Daily
											</label>
											<label class="radio-inline">
											  <input type="radio" name="stu_rep_radio" class="stu_rep_radio" value="monthly">Monthly
											</label>
										</div>
									</div>
								</div>
								<div class="col-sm-12 col-md-8 col-lg-10">
								<div class="daily">
									<div class="form-group">
										<div class="row">
											<div class="col-sm-4 col-md-4">
												<label>Date <span style="color:red;">*</span></label>
												<input type="text" id="input_date" class="form-control input_date">
											</div>
										</div>
                                    </div>
					<div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <button type="button" class="btn btn-primary pull-right" onclick="teacher_att_report_json('d')">Show Report</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
								<div class="monthly" style="display:none">
									<?php $months=array('01'=>'January','02'=>'February','03'=>'March','04'=>'April','05'=>'May','06'=>'June','07'=>'July','08'=>'August','09'=>'September','10'=>'October','11'=>'November','12'=>'December'); ?>
									<div class="form-group">
										<div class="row">
											<div class="col-xs-12 col-sm-6 col-md-4">
												<label>Month <span style="color:red;">*</span></label>
												<select class="selectpicker" id="month_id">
                                                    <?php foreach($months as $key => $value){ ?>
                                                    <option value="<?= $key;?>"><?= $value;?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                            <div class="col-xs-12 col-sm-6 col-md-4">
                                                <label>Teacher Name <span style="color:red;">*</span></label>
                                                <select class="selectpicker" id="teacher_id">
                                                	<option value="">-----Select Teacher-----</option>
                                                    <?php foreach($teacher_list as $tl){ ?>
                                                    <option value="<?= $tl['teacher_id'];?>"><?= $tl['teacher_name'];?> (<?= $tl['designation_name'];?>)</option>
                                                    <?php } ?>
                                                </select>
											</div>
										</div>
									</div>
									<div class="form-group">
										<div class="row">
											<div class="col-sm-8">
												<button type="button" class="btn btn-primary pull-right" onclick="teacher_att_report_json('m')">Show Report</button>
											</div>
										</div>
									</div>
								</div>
								</div>
							</div>
							</div>
								<hr/>
							<div class="widget-content padding">
                                <div id="display">
                                	<!---JSON Content will be displayed here-->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
			</div>

<?php include 'application/views/includes/footer.php';?>

<script>

window.onload = function () {
	// Initialize datepicker
	$('#input_date').datepicker();
	// Load Timepicker plugin
	//LoadTimePickerScript(DemoTimePicker);
	// work for radio button
	$('.stu_rep_radio').click(function(){
		var div_class= $(this).val();
		if(div_class=='daily'){
			$('.daily').show('slide', {direction: 'down'},300);
			$('.monthly').hide('slide', {direction: 'up'},50);
		}
		else{
			$('.daily').hide('slide', {direction: 'down'},50);
			$('.monthly').show('slide', {direction: 'up'},300);
		}
	});
	
	};
	
	
	// get the student monthly report
	function teacher_att_report_json(report_type)
	{
		var input_date = $('#input_date').val();
		var month_id = $('#month_id').val();
		var teacher_id = $('#teacher_id').val();
		var teacher_name = $( "#teacher_id option:selected" ).text();
		var month_name = $( "#month_id option:selected" ).text();
		//var teacher_name_json=<?= json_encode($teacher_list); ?>;
		//alert(teacher_name_json);	
        $.ajax({ 
        url: baseUrl+'attendance/teacher_att_report_json',
        data:
            {                  
                'att_date':$('#input_date').val(),
                'month_id':month_id,
                'teacher_id':teacher_id,
                'teacher_name':teacher_name,
                'month_name':month_name,
                //'teacher_name_json':teacher_name_json,
		'report_type':report_type
            }, 
            dataType: 'json',
            success: function(data)
            {
                result                = ''+data['result']+'';
                mainContent           = ''+data['mainContent']+'';

                if(result == 'success')
                {  //alert(mainContent);          
                    $('#display').html(mainContent);     
                }                
            }
        });
        return false; // keeps the page from not refreshing     
    }
	
	//print all report
	function printPageArea(areaID){
		var printContent = document.getElementById(areaID);
		var WinPrint = window.open('', '', 'width=900,height=650');
		WinPrint.document.write('<link rel="stylesheet" type="text/css" href="<?= base_url();?>template/libs/bootstrap/css/bootstrap.min.css" media="print" />');
		WinPrint.document.write('<style type="text/css" media="print"> @page { font-size:12px; } table{font-size:12px;} table td{padding:3px;} .print_button{ display:none;} .header-div-box{display:inline-block;} .header-div-box.box-left{float:left; margin-bottom:10px;} .header-div-box.box-right{float:right;}</style>');
		WinPrint.document.write(printContent.innerHTML);
		WinPrint.document.close();
		WinPrint.focus();
		WinPrint.print();
		WinPrint.close();
	}
</script>