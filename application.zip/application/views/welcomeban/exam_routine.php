<?php require 'application/views/welcome/includes/header.php';?>    

    <!-- ******CONTENT****** --> 
        <div class="content container" style="width:95%; margin:0px auto; background-color:#FFF; ">
            <div class="page-wrapper">
                <header class="page-heading clearfix">
                    <h1 class="heading-title pull-left">পরীক্ষার রুটিন</h1>
                    <div class="breadcrumbs pull-right">
                        <ul class="breadcrumbs-list">
                            <li class="breadcrumbs-label">আপনি এখানে আছেন : </li>
                            <li><a href="<?php echo base_url();?>">হোম</a><i class="fa fa-angle-right"></i></li>
                            <li class="current">পরীক্ষার রুটিন</li>
                        </ul>
                    </div><!--//breadcrumbs-->
                </header> 
          
			      	
		 <div class="page-content">
                    <div class="row page-row">
                           <form role="form" id="registerForm" method="POST" action="<?php echo base_url();?>welcome/show_exam_routine_download" >
                                            <div class="widget-content padding">
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-sm-4">
                                                            <label>পরীক্ষা</label>
                                                            <select class="form-control" name="term_id" id="exam_id" onchange="get_old_exam_routine(this.value);">
                                                                <option value="">----Select Exam----</option>
                                                                <?php
                                                                    foreach($term_list as $tl){ ?>
                                                                    <option value="<?php echo $tl['term_id'];?>"><?php echo $tl['term'];?></option>   
                                                                <?php    } ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                           <div id="show_exam_routine_table"> 
                                            
											<!-- exam routine will show here -->
                                            </div>
                                            <div style="margin:0px auto; width:30%;">
                 <button type="submit" class="btn btn-success" name="download" style="margin:25px auto;">Download Exam Routine</button>
                                             </div>
                                             </form>

                                          </div>
                                </div>
                            </div>
			</div>
             		<?php require 'application/views/welcome/includes/footer.php';?>
             		</div>
                           

                    

<script>
function get_old_exam_routine(term_id)
{//1
	
	$.ajax({//2 structure
		type: "POST",
		url: baseUrl + 'welcome/structure_exam_routine_by_term',
		data:
		{
			'exam_term_id':term_id,
		}, 
		success: function(html_data)
		{//3 structure
			if (html_data != '')
			{ // 4 structure
				$('#show_exam_routine_table').html(html_data).show(function(){
							$.ajax({//2
								type: "POST",
								url: baseUrl + 'welcome/get_id_per_exam_term',
								data:
								{
									'exam_term_id':term_id,
								}, 
								success: function(html_data)
								{//3
									if (html_data != '')
									{ //alert(html_data); 4
										var a=html_data.split('|');
										for (i=0;i<a.length;i++)
										{//5
											$.getJSON(//6
												baseUrl + 'welcome/get_old_exam_routine_by_term_show',
												{ 'id' : a[i] },
												function(jd) {//7
															$("th[class='class_id"+jd.column_no+"']").html(jd.class_name);
															$("th[class='exam_time"+jd.column_no+"']").html(jd.exam_time);
															$("td[class='date"+jd.row_no+"']").html(jd.exam_date);
															$("td[class='wkday"+jd.row_no+"']").html(jd.exam_day);
															$("tr[id='"+jd.row_no+"'] td[class='sub"+jd.column_no+"']").html(jd.subject_name);
																
														}////7
														
											);////6
										}////5
									}////4
								}////3
							});////2
				});
			}//// 4 structure
		}////3 structure
    });////2 structure								
}////1
</script>