<?php require 'application/views/welcome/includes/header.php';?>    

    <!-- ******CONTENT****** --> 
        <div class="content container" style="width:95%; margin:0px auto; background-color:#FFF; ">
            <div class="page-wrapper">
                <header class="page-heading clearfix">
                    <h1 class="heading-title pull-left">ক্লাস রুটিন</h1>
                    <div class="breadcrumbs pull-right">
                        <ul class="breadcrumbs-list">
                            <li class="breadcrumbs-label">আপনি এখানে আছেন : </li>
                            <li><a href="<?php echo base_url();?>">হোম</a><i class="fa fa-angle-right"></i></li>
                            <li class="current">ক্লাস রুটিন</li>
                        </ul>
                    </div><!--//breadcrumbs-->
                </header> 
                
                
 <div class="page-content">
                    <div class="row page-row">
                            
                                        <form role="form" id="registerForm" method="POST" action="<?php echo base_url();?>welcome/show_class_routine_download">
                                            <div class="widget-content padding">
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-sm-4">
                                                            <label>শ্রেণি </label>
                                       <select class="form-control" name="class_id" id="class_id" onchange="get_class_section_list(this.value);">
                                                                <option value="">----Select Class----</option>
                                                                <?php
                                                                    foreach($class_list as $cl){ ?>
                                                                    <option value="<?php echo $cl['class_id'];?>"><?php echo $cl['class_name'];?></option>   
                                                                <?php    } ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                                
                                                
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-sm-4">
                                                            <label> শাখা </label>
                                                            <select class="form-control" name="section_id" id="section_id" onchange="get_old_class_routine()">
                                                                <option value="">Select</option>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div id="">
                                           
											<table id="" class="table table-striped table-bordered" width="100%" cellspacing="0">
											<thead>
                                                <tr>
                                                    <th>Class Time</th>
                                                    <?php
                                                                    foreach($class_time as $ct){?>
                                                                    <th id="classDuration"><?php echo $ct['start_time'].'-'.$ct['close_time'];?></th>  
                                                                <?php }?>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <tr>
                                                    <td>Class Period</td>
                                                    <?php
                                                            foreach($class_time as $ct){ ?>
                                                            <td id='clperiod'><?php echo $ct['period'];?></td>  
                                                                <?php }?>
                                                </tr>
                                                
                                                    <?php
                                                            foreach($week as $wk){ ?>
                                                            <tr><td id='wkday'><?php echo $wk['day'];?></td>
                                                           
                                                            <?php for($i=0; $i<$count; $i++){ ?>
                                                            <td id="<?php echo $wk['day'];?>">
                     							<span class="form-control" style="border:none;" name="teachers_name" id="<?php echo 'tid'.$i;?>" >
                     											
                                                               <?php echo $tn['teacher_name'];?> </span>
                                                            <div id="subject_name">
                                                            <span class="form-control subject_name" style="border:none;" name="subject_name" id="<?php echo 'cid'.$i;?>">
                     											</span>
                                                              <!---Subject name will be display here--->
                                                            </div>
</td>  
                                                                <?php }?>
                                                            </tr>  
                                                                <?php }?>
                                               
                                            </tbody>
                                            </table>

                                            </div>
                                            <div style="margin:0px auto; width:30%;">
                                             <button type="submit" class="btn btn-success" name="download" style="margin:25px auto;">Download Class Routine</button>
                                             </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
			</div>
			<?php require 'application/views/welcome/includes/footer.php';?>
             		</div>

				
				

                    
<script type="text/javascript">
function get_class_section_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'welcome/section_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#section_id').html(html_data);
        }
    }
    });
	
}
</script>
<script>
function get_old_class_routine()
{
	$.ajax({
		type: "POST",
		url: baseUrl + 'welcome/get_id_per_class_section',
		data:
		{
			'class_id':$('#class_id').val(),
			'section_id':$('#section_id').val()
		}, 
		success: function(html_data)
		{
			if (html_data != '')
			{ 
				var a=html_data.split('|');
				for (i=0;i<a.length;i++)
				{
					$.getJSON(
						baseUrl + 'welcome/get_old_routine_by_section_class_show',
						{ 'id' : a[i] },
						function(jd) {
									$("td[id='"+jd.day+"'] span#tid"+jd.column_no).html(jd.teacher_name);
									$("td[id='"+jd.day+"'] span#cid"+jd.column_no).html(jd.subject_name);
									
								}
					);
				}
			}
    	}
    });
	
	var clPeriod=new Array();  
				 		var iclPeriod=0;
						$( "td#clperiod").each(function() {
								clPeriod[iclPeriod]=$(this).html();
								
								if($(this).html()=="tiffin")
								{//alert(iclPeriod);
								$('span#tid'+iclPeriod).html("<br/><span style=''>Break</span>");
								$('span#cid'+iclPeriod).html("");
								
								}
								iclPeriod++;
						});
										
}
</script>

    
