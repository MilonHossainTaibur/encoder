<?php require 'application/views/welcome/includes/header.php';?>    

    <!-- ******CONTENT****** --> 
        <div class="content container" style="width:95%; margin:0px auto; background-color:#FFF; ">
            <div class="page-wrapper">
                <header class="page-heading clearfix">
                    <h1 class="heading-title pull-left">ছবি গ্যালারি</h1>
                    <div class="col-md-2 col-sm-2 ">
                        <select class="form-control" placeholder="Catagory" data-placement="bottom" title="Catagory" name="catagory" 
                                             id="catagory_id" required onChange="check_photo_list(document.getElementById('catagory_id').selectedIndex)">
                            <option value='' SELECTED='selected'>Select a Catagory</option>
                            <?php
                            foreach($catagory_list as $r){ ?>
                            <option value='<?php echo $r['catagory_id'];?>'><?php echo $r['catagory_name']; ?></option>
                            <?php }
                            ?>
                        </select>
                    </div>
                    <div class="breadcrumbs pull-right">
                        <ul class="breadcrumbs-list">
                            <li class="breadcrumbs-label">আপনি এখানে আছেন : </li>
                            <li><a href="<?php echo base_url();?>">হোম </a><i class="fa fa-angle-right"></i></li>
                            <li class="current">ছবি গ্যালারি</li>
                        </ul>
                    </div><!--//breadcrumbs-->
                </header> 
                <div class="page-content" id='display'>
                    <div class="row page-row">
                        <?php
                            foreach($photo_gallery as $pg){ ?>
                            <a class="prettyphoto col-md-3 col-sm-3 col-xs-6" rel="prettyPhoto[gallery]" href="<?php echo base_url();?>template/upload/photo_gallery/<?php echo $pg['gallery_image_name'];?>"><img class="img-responsive img-thumbnail" src="<?php echo base_url();?>template/upload/photo_gallery/<?php echo $pg['gallery_image_name'];?>" alt="image note found" width="150" height="150" /></a>
                        <?php    }
                        ?>
                        
                    </div><!--//page-row-->
                </div><!--//page-content-->
            </div><!--//page-wrapper--> 
        </div><!--//content-->
    <?php require 'application/views/welcome/includes/footer.php';?></div><!--//wrapper-->

    
    
    
<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script>
<script type="text/javascript" src="<?php echo base_url();?>template/plugins/gmaps/gmaps.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>template/js/map.js"></script>
<script>
    function check_photo_list()
    {
        var catagory_id = $('#catagory_id').val();
		
       // document.write(department_id);
        if(catagory_id==0){
            alert("Select Catagory First");
        }
        
        $.ajax({ 
        url: baseUrl+'welcome/get_photo_list_by_catagory_id',
        data:
            {                  
                'catagory_id':catagory_id,
             
            }, 
            dataType: 'json',
            success: function(data)
            {
                result                = ''+data['result']+'';
                mainContent           = ''+data['mainContent']+'';
                if(result == 'success')
                {        
				$('#display').html(mainContent);  				
                }                
            }
        });
        return false; // keeps the page from not refreshing     
    }
</script> 