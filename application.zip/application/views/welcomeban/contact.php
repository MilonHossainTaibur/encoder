<?php require 'application/views/welcome/includes/header.php';?>    

    <!-- ******CONTENT****** --> 
         <div class="content container" style="width:95%; margin:0px auto; background-color:#FFF; ">
            <div class="page-wrapper">
                <header class="page-heading clearfix">
                    <h1 class="heading-title pull-left"> অভিভাবকের মতামত </h1>
                    <div class="breadcrumbs pull-right">
                        <ul class="breadcrumbs-list">
                            <li class="breadcrumbs-label">আপনি এখানে আছেন : </li>
                            <li><a href="<?php echo base_url();?>">হোম</a><i class="fa fa-angle-right"></i></li>
                            <li class="current"> অভিভাবকের মতামত </li>
                        </ul>
                    </div><!--//breadcrumbs-->
                </header>
                
                <div class="page-content">
                    <div class="row">
                        <article class="contact-form col-md-6 col-sm-6  page-row">                            
                            <h3 class="title"> সাথে থাকুন </h3>
                            
                            <form>
                                <div class="form-group name">
                                    <label for="name">নাম</label>
                                    <input id="name" type="text" class="form-control" placeholder="Enter your name">
                                </div><!--//form-group--> 
                                <div class="form-group email">
                                    <label for="email">ইমেল<span class="required">*</span></label>
                                    <input id="email" type="email" class="form-control" placeholder="Enter your email">
                                </div><!--//form-group-->
                                <div class="form-group phone">
                                    <label for="phone">ফোন </label>
                                    <input id="phone" type="tel" class="form-control" placeholder="Enter your contact number">
                                </div><!--//form-group-->
                                <div class="form-group message">
                                    <label for="message">বার্তা <span class="required">*</span></label>
                                    <textarea id="message" class="form-control" rows="6" placeholder="Enter your message here..."></textarea>
                                </div><!--//form-group-->
                                <button type="submit" class="btn btn-theme">বার্তা পাঠান</button>
                            </form>                  
                        </article><!--//contact-form-->
                        
                    </div><!--//page-row-->
                </div><!--//page-content-->
            </div><!--//page-wrapper--> 
        </div><!--//content-->
        <?php require 'application/views/welcome/includes/footer.php';?>    
    </div><!--//wrapper-->

    

    
<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script>
    <script type="text/javascript" src="<?php echo base_url();?>template/plugins/gmaps/gmaps.js"></script>            
    <script type="text/javascript" src="<?php echo base_url();?>template/js/map.js"></script>