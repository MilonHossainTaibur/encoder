<!--start section-->
<section class="nicdark_section">
	<div class="tp-banner-container">
		<div class="nicdark_slide1" >
			
			<ul>
				<?php
                        foreach($slide_image as $img){ ?>
                    
				<li data-transition="fade" data-slotamount="7" data-masterspeed="500" data-saveperformance="on"  data-title="<?= $img['slide_caption'];?>" style="margin-top:11% !important;">
					<img src="<?= base_url();?>template/images/slides/<?= $img['slide_image_name'];?>"  alt="" data-lazyload="<?= base_url();?>template/images/slides/<?= $img['slide_image_name'];?>" data-bgposition="center bottom" data-bgfit="cover" data-bgrepeat="no-repeat">
				</li>
				<?php    } ?>
			</ul>
			
		</div>
	</div>
</section>
<!--end section-->