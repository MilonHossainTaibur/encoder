<table id="datatables-2" class="table table-striped table-bordered">
    <thead>
    	<tr>
           <?php foreach($att_details[0] as $key=> $value): ?>
           		<td><?=  $key; ?></td>
           <?php endforeach; ?>
           	<td>Total</td>
           	<td>In Word</td>
           	<td>Office Assistant Signature</td>
           	<td>Headmaster Signature</td>
           	<td>Comment</td>
        </tr>
    </thead>
    <tbody>
        <?php foreach($att_details as $values): ?>
			<tr>
        	<?php $total=0; foreach($values as $key=> $value): if($key !='Date' && $key != 'class_name') $total+=$value; ?>
        		<td><?=  $value; ?></td>
    		<?php endforeach; ?>
    			<td><?=  $total; ?></td>
    			<td><?php $f = new NumberFormatter("en_IN", NumberFormatter::SPELLOUT);
						echo $f->format($total); ?></td>
				<td></td>
				<td></td>
				<td></td>
    		</tr>
    	<?php endforeach; ?>
    </tbody>
</table>
<script>
$("#datatables-2").DataTable({
        dom:'Bfrtip',
        buttons:[
            'excelHtml5',
            'pdfHtml5'
        ]});

</script>
