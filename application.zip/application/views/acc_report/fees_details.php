<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!--Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">			
            <div class="content">
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i> Fees Income Details </h1>
                </div>
            	<!-- Page Heading End-->
                <?php if($this->session->flashdata('message')):?>
					<?=$this->session->flashdata('message')?>
				<?php endif?>
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="widget" style="min-height:500px;">
                            <div class="widget-content padding">
                                <div class="row">
                                    <div class="col-sm-12 col-md-8 col-lg-8">
                                        <?php $months=array('01'=>'January','02'=>'February','03'=>'March','04'=>'April','05'=>'May','06'=>'June','07'=>'July','08'=>'August','09'=>'September','10'=>'October','11'=>'November','12'=>'December'); ?>
                                        <div class="form-group">
                                            <div class="row">
                                                <div class="col-xs-12 col-sm-6 col-md-4">
                                                    <label>Date <span style="color:red;">*</span></label>
                                                    <input type="text" id="input_date" class="form-control input_date">
                                                </div>
                                                <div class="col-xs-12 col-sm-6 col-md-4">
                                                    <label>Month <span style="color:red;">*</span></label>
                                                    <select class="selectpicker" id="month_id">
                                                        <option>Select Month</option>
                                                        <?php foreach($months as $key => $value){ ?>
                                                        <option value="<?= $key;?>"><?= $value;?></option>
                                                        <?php } ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <div class="row">
                                                <div class="col-sm-8">
                                                    <button type="button" class="btn btn-primary pull-right" onclick="teacher_att_report_json()">Show Report</button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div><hr/>
                            <div class="widget-content" id="display" style="overflow: auto;font-size: 12px;">
                                <!-- content will disply here -->
                            </div>   
                        </div>
                    </div>
                </div>
            </div>
        </div>
				
<?php include 'application/views/includes/footer.php';?>
<script>

window.onload = function () {
    // Initialize datepicker
    $('#input_date').datepicker({altFormat: "dd-mm-yyyy"});
    // Load Timepicker plugin
    //LoadTimePickerScript(DemoTimePicker);
    };
    
    
    // get the student monthly report
    function teacher_att_report_json()
    {
        var input_date = $('#input_date').val();
        var month_id = $('#month_id').val();
        var month_name = $( "#month_id option:selected" ).text();
            
        $.ajax({ 
        url: baseUrl+'acc_report/fees_details_json',
        data:
            {                  
                'update_at':input_date,
                'month_id':month_id,
                'month_name':month_name
            }, 
            dataType: 'json',
            success: function(data)
            {
                result                = ''+data['result']+'';
                mainContent           = ''+data['mainContent']+'';

                if(result == 'success')
                {            
                    $('#display').html(mainContent);     
                }                
            }
        });
        return false; // keeps the page from not refreshing     
    }
    
    //print all report
    function printPageArea(areaID){
        var printContent = document.getElementById(areaID);
        var WinPrint = window.open('', '', 'width=900,height=650');
        WinPrint.document.write('<link rel="stylesheet" type="text/css" href="<?= base_url();?>template/libs/bootstrap/css/bootstrap.min.css" media="print" />');
        WinPrint.document.write('<style type="text/css" media="print"> @page { font-size:12px; } table{font-size:12px;} table td{padding:3px;} .print_button{ display:none;} .header-div-box{display:inline-block;} .header-div-box.box-left{float:left; margin-bottom:10px;} .header-div-box.box-right{float:right;}</style>');
        WinPrint.document.write(printContent.innerHTML);
        WinPrint.document.close();
        WinPrint.focus();
        WinPrint.print();
        WinPrint.close();
    }
</script>