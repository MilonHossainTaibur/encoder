<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.3/toastr.min.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.1.3/toastr.css" />
</div>

<div class="content-page">
<!-- Start Content here -->
<div class="content">
<?php if($this->session->flashdata('message')):?>
<?=$this->session->flashdata('message')?>
<?php endif?>
<div class="page-heading">
   <h1><i class='fa fa-table'></i>  Freedom Fighter of this School</h1>
   <!-- Button trigger modal -->
   <button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal">
   <i class="fa fa-plus-square" aria-hidden="true"> Add New</i>
   </button>
   <hr>
</div>
<!--Modal-->
<div class="row">
   <div class="col-md-12">
      <div class="widget">
         <div class="widget-content">
            <div class="">
               <table id="datatables-1" class="table table-bordered table-striped" cellspacing="0" width="100%">
                  <thead>
                     <tr>
                        <th>Sl</th>
                        <th>Name</th>
                        <th>Designation</th>
                        
                        <th>Address</th>
                        <th>Photo</th>
                        <th>Sector No.</th>
                        <th>Mobile No.</th>
                        <th>Action</th>
                     </tr>
                  </thead>
                  <tbody>
                     <?php foreach($freedom_fighter_list as $fl){ ?>
                     <tr>
                        <td><?= $fl['order_by'];?></td>
                        <td><?= $fl['f_name'];?></td>
                        <td><?= $fl['f_des'];?></td>
                        <td><?= $fl['f_address'];?></td>
                        <td><img width="50px;" height="50px" class="img-circle center-block zoom-image" src="<?= base_url()?>upload/freedom_fighter/<?= $fl['f_photo'];?>" alt=""></td>
                         <td><?= $fl['f_sector'];?></td>
                        <td><?= $fl['f_phone'];?></td>
                        <td>
                           <a class="test" data-toggle="modal" data-target="#myModal"  href="javascript:void(0)" onClick="get_edit_data(<?= $fl['f_id'];?>)" title="Edit"><i class="fa fa-edit"></i></a> |
                           <a href="<?= base_url();?>web/freedom_fighter_delete/<?= $fl['f_id'];?>/<?= $fl['f_photo'];?>" title="Delete" onclick="return confirm('Are You Want to Delete it?' );"><i class="fa fa-remove"></i></a>                        </td>
                     </tr>
                     <?php 	} ?>
                  </tbody>
               </table>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog" role="document">
      <!--Content-->
      <div class="modal-content">
         <!--Header-->
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
            <h4 class="modal-title w-100" id="myModalLabel">Freedom Fighter</h4>
         </div>
         <!--Body-->
         <form  action="<?php echo base_url();?>web/freedom_fighter" role="form" method="post" enctype="multipart/form-data">
         <div class="modal-body">
               <div class="form-group">
                  <div class="row">
                     <div class="col-sm-6 col-md-6">
                        <label>Name</label>
                        <input type="text" name="f_name" id="f_name" class="form-control" required="required"/>
                        <input type="hidden" name="f_id" id="f_id" value="0" />
                        <input type="hidden" name="f_photo_old" id="f_photo_old" value="0" />
                     </div>
                     <div class="col-sm-6 col-md-6">
                        <label>Designation</label>
                        <input type="text" name="f_des" id="f_des" class="form-control" />
                     </div>
                     <div class="col-sm-6 col-md-6">
                        <label>Address</label>
                        <input type="text" name="f_address" id="f_address" class="form-control" />
                     </div>
                     <div class="col-sm-6 col-md-6">
                        <label>Mobile No.</label>
                        <input type="text" name="f_phone" id="f_phone" class="form-control"/>
                     </div>
                     <div class="col-sm-6 col-md-6">
                        <label>Sector</label>
                        <input type="text" name="f_sector" id="f_sector" class="form-control"  />
                     </div>
                     <div class="col-sm-6 col-md-6">
                        <label>Photo</label>
                        <input type="file" name="f_photo" id="f_photo">
                     </div>
                     <div class="col-sm-6 col-md-6">
                        <label>Order By</label>
                        <input type="text" name="order_by" id="order_by" class="form-control"ss>
                     </div>
                  </div><!--row-->
                  </div><!--form-group-->
               </div><!--modal body-->
        
         <!--Footer-->
         <div class="modal-footer">
         <button type="reset" class="btn btn-primary reset" id="reset">Clear</button>
         <button type="button" id="alert" class="btn btn-danger pull-left" data-dismiss="modal">Close</button>
         <input type="submit" name="submit" value="submit" class="btn btn-success" id="sub"   />
         <input type="submit" value="Update" class="btn btn-success" id="update">				
         </div>
         </form>
      </div>
      <!--/.Content-->
   </div>
</div>
<!-- /.Live preview-->
<!--modal end-->
<?php include 'application/views/includes/footer.php';?>
<script>
   function get_edit_data(f_id)
   {
      var freedomFighter_json=<?= json_encode($freedom_fighter_list); ?>;
      for(i=0; i <= freedomFighter_json.length; i++){
   	   	if(freedomFighter_json[i].f_id==f_id)
   	   	{
   	   		$('[name=f_id]').val(freedomFighter_json[i].f_id);
   	   		$('#f_name').val(freedomFighter_json[i].f_name);
   	   		$('#f_des').val(freedomFighter_json[i].f_des);
   	   		$('#f_address').val(freedomFighter_json[i].f_address);
   	   		$('#f_phone').val(freedomFighter_json[i].f_phone);
   	   		$('#f_sector').val(freedomFighter_json[i].f_sector);
   	   		$('#f_photo_old').val(freedomFighter_json[i].f_photo);
   	   		$('#order_by').val(freedomFighter_json[i].order_by);
   	   	}
      }
   }
</script>





