

<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
<div class="content-page">
<div class="content">
<div class="page-heading">
   <h1><i class="fa fa-desktop" aria-hidden="true"></i>
      Founder
   </h1>
   
   <hr>
   <!-- Button trigger modal -->
   <a type="button" class="btn btn-info" href="<?= base_url(); ?>web/founder_edit">
   <i class="fa fa-plus-square" aria-hidden="true"> Add</i>
   </a>
</div>
<?php if($this->session->flashdata('message')):?>
<?=$this->session->flashdata('message')?>
<?php endif?>
<div class="row">
   <div class="col-sm-12">
      <div class="widget" style="min-height:500px;">
         <div class="widget-content padding">
            <div class="row">
               <div class="col-md-12">
                  <div class="widget">
                  
                    
                     <div class="widget-content">
                        <table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
                           <thead>
                              <tr>
                                 <th>Founder Name</th>
                                 <th>Description</th>
                                 <th>Photo</th>
                                 <th>Action</th>
                              </tr>
                           </thead>
                           <tbody>
                              
                              <tr>
                                 <td><?= $founder[0]['name'];?></td>
                                 <td><?= $founder[0]['body'];?></td>
                                 <td><img class="img-fluid img-thumbnail msg-img img-responsive" width="100" height="auto" src="<?= base_url() ?>upload/founder/<?= $founder[0]['photo'];?>"></td>
                                 <td>
                                    <a class="btn btn-success btn-sm" href="<?= base_url();?>web/founder_edit/<?= $founder[0]['id'];?>" title="edit"><i class="fa fa-edit"></i></a>
                                 </td>
                              </tr>
                             
                           </tbody>
                        </table>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php include 'application/views/includes/footer.php';?>

