<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
	<div class="content-page">
		<div class="content">
			<div class="page-heading">
            	<h1><i class="fa fa-file-text-o"></i> Photo Catagory </h1>
			</div>
            <?php if($this->session->flashdata('message')):?>
				<?=$this->session->flashdata('message')?>
			<?php endif?>
			<div class="row">
                <div class="col-sm-12">
                    <div class="widget" style="min-height:500px;">
                        <div class="widget-content padding">
                            <div class="row">				
                                <div class="col-md-12">
                                    <div class="widget">
                                        <div class="widget-content padding"><a class="btn btn-info" href="javascript:void(0);" onclick="toggle_insertion_box(); return false;"><i class="fa fa-plus" aria-hidden="true"></i>
Add New Catagory</a>
                                            <div class="insertion_div">
											<hr/>
                                                 <form action="<?= base_url();?>web/catagory_save" method="POST" enctype="multipart/form-data" id="message-form">
													<div class="form-group">
														<div class="row">
														   <div class="col-sm-6 col-md-4">
																<label>Catagory</label>
																<input type="text" class="form-control" name="catagory_name" id="catagory_name" required />
																<input type="hidden" class="form-control" name="catagory_id" id="catagory_id" required />
															</div>
														</div>
													</div>
													<div class="form-group">
														<button type="submit" class="btn btn-primary">Save</button>
													</div>
												</form>
                                            </div>
                                        </div>

                                        <div class="widget-content">
                                            <table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
												<thead>
													<tr>
														<th>Catagory ID</th>
														<th>Catagory Name</th>
														<th>Action</th>
													</tr>
												</thead>
												<tbody>
													<?php foreach($catagory_list as $nl){ ?>
													<tr>
														<td><?= $nl['catagory_id'];?></td>
														<td><?= $nl['catagory_name'];?></td>
														<td>
														<a href="#" onclick="toggle_insertion_box(); edit_cat(<?= $nl['catagory_id'];?>);"><i class="fa fa-edit"></i></a> |
														<?=anchor ("web/catagory_delete/".$nl['catagory_id'],"<i class=\"fa fa-times\"></i>",array('onclick' => "return confirm('Do you want delete this record')"))?>
														
														</td>
													</tr>
													<?php }  ?>
												</tbody>
											</table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


<?php include 'application/views/includes/footer.php';?>

<script>
function edit_cat(id)
{
	var catagory=<?= json_encode($catagory_list); ?>;
	
	for(i=0; i < catagory.length; i++)
	{
		if(catagory[i].catagory_id==id)
		{
			$('#catagory_name').val(catagory[i].catagory_name);
			$('#catagory_id').val(catagory[i].catagory_id);
		}
	}
}

</script>   
