<?php
 $menusql = "SELECT distinct(exam_type) as `exam_type` FROM `tbl_mark_distribution` order by exam_type";
 $menuquery = mysql_query($menusql);
 while($menures= mysql_fetch_array($menuquery))
		{
			$menuresult[]=$menures;
		}
	
?>
<div class="left side-menu">
	<div class="sidebar-inner slimscrollleft">
		<div id="sidebar-menu">
			<ul>
				<li style="background-color:#5DAF8F;" class="web_db"><a href='<?php echo base_url();?>admin' target="_blank"><i class='fa-dedent'></i><span style="color:#000;">Dashboard</span></a>
					
				</li>
                
                <li style="background-color:#ABB7B7;"><a href='<?php echo base_url();?>welcome' target="_blank"><i class='icon-home-3'></i><span style="color:#000;">Visit Site</span> <span class="pull-right"></span></a>
					
				</li>
                
                 <li>
					<a href="<?php echo base_url();?>web/message" title="Principal Message">
						 <i class="fa fa-file-text-o"></i>
						 <span class="hidden-xs">Message</span>
					</a>
				</li>
                
               <li class='has_sub'><a href='javascript:void(0);'><i class="fa fa-bar-chart-o"></i><span>Notice & Form</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a> 
					
					<ul>
						<li><a href="<?php echo base_url();?>web/notice">New Notice</a></li>
						<li><a href="<?php echo base_url();?>web/notice_list">Notice List</a></li>	
						<li><a href="<?php echo base_url();?>web/form_add">New Form</a></li>
						<li><a href="<?php echo base_url();?>web/form_list">Form List</a></li>							
					</ul>
				</li>
                
                <li>
					<a href="<?php echo base_url();?>web/information_list" title="Slide">
						 <i class="fa fa-file-text-o"></i>
						 <span class="hidden-xs">Other Information </span>
					</a>
				</li>
                
                
                <li>
					<a href="<?php echo base_url();?>web/slide" title="Slide">
						 <i class="fa fa-picture-o"></i>
						 <span class="hidden-xs">Slide</span>
					</a>
				</li>
                
                <li>
					<a href="<?php echo base_url();?>web/about" title="About">
						 <i class="fa fa-file-text-o"></i>
						 <span class="hidden-xs">About</span>
					</a>
				</li>
                
               
                
                <li class='has_sub'><a href='javascript:void(0);'><i class="fa fa-picture-o"></i><span>Photos</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                    <ul>
                    	<li><a href="<?php echo base_url();?>web/picture_gallery">Photo Gallery</a></li>
                    	<li><a href="<?php echo base_url();?>web/catagory_list">Photo Catagory</a></li>
                    </ul>
				</li>	
                
               
                
				<li class='has_sub'><a href='javascript:void(0);'><i class='fa fa-user'></i><span>Teacher/Staff Management</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
					<ul>
						<li><a href="<?php echo base_url();?>admin/teacher_registration"><span>Teachers Registration</span></a></li>
						<li><a href="<?php echo base_url();?>admin/teacher_list"><span>Teacher List</span></a></li>
						<li><a href="<?php echo base_url();?>academic/class_teacher_assign"><span>Class Teacher Assign</span></a></li>
						<li><a href="<?php echo base_url();?>admin/teacher_salary_structure"><span>Teacher Salary Structure</span></a></li>
						<!--<li><a href="#"><span>Teachers Attendance</span></a></li>
						<li><a href="#"><span>Teachers Class Schedule</span></a></li>
						<li><a href="#"><span>Leave Application</span></a></li>-->
					</ul>
				</li> 
				<li class='has_sub'>
					<a href='javascript:void(0);'><i class='icon-users'></i><span>Student Management</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
					<ul>
						<li><a href="<?php echo base_url();?>admin/student_registration"><span>Student Registration</span></a></li>
						<li class='has_sub'><a href='javascript:void(0);'><span>Student List</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
							<ul>
								<li><a href="<?php echo base_url();?>admin/student_list"><span>All</span></a></li>
								<li><a href="<?php echo base_url();?>admin/class_wise_student_list"><span>Class Wise</span></a></li>
								<li><a href="<?php echo base_url();?>admin/section_wise_student_list"><span>Section Wise</span></a></li>
							</ul>
						</li>
						
						<li class='has_sub'>
							<a href='javascript:void(0);'><span>Student Subject Assign</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
							<ul>
								<li><a href="<?php echo base_url();?>admin/student_subject_assign"><span>Subject Assign</span></a></li>
								<li><a href="<?php echo base_url();?>admin/student_subject_view"><span>Subject View</span></a></li>
							</ul>
						</li>
						
						
						<!--<li class='has_sub'>
							<a href='javascript:void(0);'><span>Attendance Management</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
							<ul>
								<li><a href="#"><span>Attendance</span></a></li>
								<li><a href="#"><span>Report</span></a></li>
							</ul>
						</li>-->
					</ul>
				</li>
				
				
				
				<li class='has_sub'><a href='javascript:void(0);'><i class='fa fa-money'></i><span>Fees Management</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
					<ul>
						<li><a href="<?php echo base_url();?>fees/fees_cat"><span>Fees Category</span></a></li>
						<li><a href="<?php echo base_url();?>fees/class_wise_fees_management"><span>Fees Management</span></a></li>
						<li><a href="<?php echo base_url();?>fees/student_fees_generate"><span>Student Fees Generate</span></a></li>
						<li><a href="#"><span>Fees Collect</span></a></li>
						<li class='has_sub'>
							<a href='javascript:void(0);'><span>Reports</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
							<ul>
								<li><a href="#"><span>Paid Report</span></a></li>
								<li><a href="#"><span>Unpaid Report</span></a></li>
							</ul>
						</li>
					</ul>
				</li>
				
				<li class='has_sub'><a href='javascript:void(0);'><i class='fa fa-pencil-square-o'></i><span>Result Management</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
					<ul>
						<li class='has_sub'>
							<a href='javascript:void(0);'><span>Marks</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
							<ul>
                            <?php foreach($menuresult as $menuresults)
							{
								if($menuresults['exam_type']==1)
								{
								 ?>
									<li><a href="<?php echo base_url();?>school/set_ca_marks"><span>Set CA Marks</span></a></li>
						  <?php	 } 
								elseif($menuresults['exam_type']==2)
								{ ?>
									
									
						 <?php	 } 
								elseif($menuresults['exam_type']==3)
								{ ?>
									<li><a href="<?php echo base_url();?>school/set_hw_marks"><span>Set HW Marks</span></a></li>
						<?php	 } 
								elseif($menuresults['exam_type']==4)
								{ ?>
									<li><a href="<?php echo base_url();?>school/set_ct_marks"><span>Set CT Marks</span></a></li>
					   <?php	 } 
								elseif($menuresults['exam_type']==5)
								{ ?>
									<li><a href="<?php //echo base_url();?>school/set_project_marks"><span>Set Project Marks</span></a></li>
					   <?php	 } 
								elseif($menuresults['exam_type']==6)
								{ ?>
									<li><a href="<?php echo base_url();?>school/set_term_marks"><span>Set Term Marks</span></a></li>
					   <?php    }
				    		} ?>
								
							</ul>
						</li>
						<li class='has_sub'>
							<a href='javascript:void(0);'><span>Reports</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
							<ul>
								<li><a href="<?php echo base_url();?>academic/mark_sheet"><span>Marksheet</span></a></li>
								<li><a href="<?php echo base_url();?>academic/tabulation_sheet"><span>Tabulation Sheet</span></a></li>
                                <li><a href="<?php echo base_url();?>school/tabulation_sheet_subject_wise"><span>Tabulation Sheet Subject Wise</span></a></li>
								<li><a href="<?php echo base_url();?>academic/result_view"><span>Class Wise Result</span></a></li>
							</ul>
						</li>
					</ul>
				</li>
				
				
				
				
				<li class='has_sub'><a href='javascript:void(0);'><i class='fa fa-calculator'></i><span>Accounts Management</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
					<ul>
						
						<li class='has_sub'>
							<a href='javascript:void(0);'><span>Manage Master Head</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
							<ul>
								<li><a href="<?php echo base_url();?>accounts/master_head_create"><span>Master Head Create</span></a></li>
								<li><a href="<?php echo base_url();?>accounts/master_head_list"><span>Master Head List</span></a></li>
							</ul>
						</li>
						
						<li class='has_sub'>
							<a href='javascript:void(0);'><span>Manage Sub1 Head</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
							<ul>
								<li><a href="<?php echo base_url();?>accounts/sub1_head_create"><span>Sub1 Head Create</span></a></li>
								<li><a href="<?php echo base_url();?>accounts/sub1_head_list"><span>Sub1 Head List</span></a></li>
							</ul>
						</li>
						
						<li class='has_sub'>
							<a href='javascript:void(0);'><span>Manage Sub2 Head</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
							<ul>
								<li><a href="<?php echo base_url();?>accounts/sub2_head_create"><span>Sub2 Head Create</span></a></li>
								<li><a href="<?php echo base_url();?>accounts/sub2_head_list"><span>Sub2 Head List</span></a></li>
							</ul>
						</li>
						
						<li class='has_sub'>
							<a href='javascript:void(0);'><span>Manage Sub3 Head</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
							<ul>
								<li><a href="<?php echo base_url();?>accounts/sub3_head_create"><span>Sub3 Head Create</span></a></li>
								<li><a href="<?php echo base_url();?>accounts/sub3_head_list"><span>Sub3 Head List</span></a></li>
							</ul>
						</li>
						
						<li><a href="<?php echo base_url();?>accounts/navigation_head_view"><span>Navigation Head View</span></a></li>
						
						<li class='has_sub'>
							<a href='javascript:void(0);'><span>Debit Voucher</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
							<ul>
								<li><a href="<?php echo base_url();?>accounts/debit_voucher_entry"><span>Debit Voucher Entry</span></a></li>
								<li><a href="<?php echo base_url();?>accounts/debit_voucher_list"><span>Debit Voucher List</span></a></li>
							</ul>
						</li>
						
						<li class='has_sub'>
							<a href='javascript:void(0);'><span>Credit Voucher</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
							<ul>
								<li><a href="<?php echo base_url();?>accounts/credit_voucher_entry"><span>Credit Voucher Entry</span></a></li>
								<li><a href="<?php echo base_url();?>accounts/credit_voucher_list"><span>Credit Voucher List</span></a></li>
							</ul>
						</li>
						<!--
						<li><a href="<?php echo base_url();?>accounts/trial_balance"><span>Trial Balance</span></a></li>
						-->
					</ul>
				</li>
				
				
				
				<li class='has_sub'><a href='javascript:void(0);'><i class='fa fa-book'></i><span>Library Management</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
					<ul>
						<li><a href="<?php echo base_url();?>web/book_category_list"><span>Add Books Category</span></a></li>
						<li><a href="<?php echo base_url();?>web/book_list"><span>List of Books</span></a></li>
						<li><a href="#"><span>Issue Books</span></a></li>
						<li><a href="#"><span>Library Fines</span></a></li>
						<li><a href="#"><span>Movement Log</span></a></li>
						<li><a href="#"><span>Return Books</span></a></li>
						<li><a href="#"><span>Search Books</span></a></li>								
					</ul>
				</li>
				
				
				
				<li class='has_sub'><a href='javascript:void(0);'><i class='fa fa-taxi'></i><span>Transport</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
					<ul>
						<li><a href="#"><span>Add Vehicle</span></a></li>
						<li><a href="#"><span>Add Route</span></a></li>
						<li><a href="#"><span>Add Destination</span></a></li>
						<li><a href="#"><span>Add Driver</span></a></li>
						<li><a href="#"><span>Add Vehicle Timing</span></a></li>
						<li><a href="#"><span>Allocation</span></a></li>
						<li><a href="#"><span>Fees</span></a></li>
					</ul>
				</li>
				
				
				
				<li class='has_sub'><a href='javascript:void(0);'><i class='fa fa-table'></i><span>Hostel</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
					<ul>								
						<li><a href="#"><span>Add Hostel</span></a></li>
						<li><a href="#"><span>Add Floor</span></a></li>
						<li><a href="#"><span>Room List</span></a></li>
						<li><a href="#"><span>Registration</span></a></li>
						<li><a href="#"><span>Fees</span></a></li>
					</ul>
				</li>
				
				
				<li class='has_sub'><a href='javascript:void(0);'><i class='fa fa-envelope'></i><span>SMS Alert</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
					<ul>								
						<li><a href="<?php echo base_url();?>admin/student_sms_notice"><span>Notice to Students</span></a></li>
						<li><a href="<?php echo base_url();?>admin/attendance"><span>Digital Attendance </span></a></li>
						<li><a href="#"><span>Result SMS Alert</span></a></li>
					</ul>
				</li>
				
				
				
				
				
				<li class='has_sub'><a href='javascript:void(0);'><i class='fa fa-shopping-cart'></i><span>Inventory Management</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
					<ul>
						<li><a href="#"><span>Store Category</span></a></li>
						<li><a href="#"><span>Store Type</span></a></li>
						<li><a href="#"><span>Store</span></a></li>
						<li><a href="#"><span>Item Category</span></a></li>
						<li><a href="#"><span>Store Items</span></a></li>
						<li><a href="#"><span>Supplier Type</span></a></li>
						<li><a href="#"><span>Supplier</span></a></li>
						<li><a href="#"><span>Indents</span></a></li>
						<li><a href="#"><span>Purchase Order</span></a></li>
						<li><a href="#"><span>Billing</span></a></li>
						<li><a href="#"><span>GRN</span></a></li>
						
						<li class='has_sub'>
							<a href='javascript:void(0);'><span>Reports</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
							<ul>
								<li><a href="#"><span>Item Wise</span></a></li>
								<li><a href="#"><span>Day Wise</span></a></li>
								<li><a href="#"><span>Invoice Wise</span></a></li>
							</ul>
						</li>
					</ul>
				</li>
				
				
                <li class='has_sub'><a href='javascript:void(0);'><i class='fa fa-group'></i><span>Routines</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
					<ul>
						<li><a href="<?php echo base_url();?>academic/show_class_routine"><span>Show Class Routin</span></a></li>
						<li><a href="<?php echo base_url();?>academic/show_exam_routine"><span>Show Exam Routine </span></a></li>
					</ul>
				</li>
				
				
				<li class='has_sub'><a href='javascript:void(0);'><i class='fa fa-group'></i><span>User Management</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
					<ul>
						<li><a href="#"><span>Add User</span></a></li>
						<li><a href="#"><span>Set Privilege</span></a></li>
					</ul>
				</li>
				
				
				
				<li class='has_sub'><a href='javascript:void(0);'><i class='fa fa-wrench'></i><span>Settings</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
					<ul>
						<li class='has_sub'>
							<a href='javascript:void(0);'><span>General Settings</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
							<ul>
								<li><a href="<?php echo base_url();?>admin/institute_information"><span>Institute Information</span></a></li>
							</ul>
						</li>
						
						<li class='has_sub'>
							<a href='javascript:void(0);'><span>Class</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
							<ul>
								<li><a href="<?php echo base_url();?>admin/class_list"><span>Class Setup</span></a></li>
								<li><a href="<?php echo base_url();?>web/class_assign"><span>Class Assign</span></a></li>
                                <li><a href="<?php echo base_url();?>academic/set_class_timing"><span>Class Time</span></a></li>
                                <li><a href="<?php echo base_url();?>academic/class_routine"><span>Class Routine</span></a></li>
                                
								
							</ul>
						</li>						
						
						<li class='has_sub'>
							<a href='javascript:void(0);'><span>Section</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
							<ul>
								<li><a href="<?php echo base_url();?>admin/section_list"><span>Section Setup</span></a></li>
								<li><a href="<?php echo base_url();?>admin/section_assign"><span>Section Assign</span></a></li>
							</ul>
						</li>
                                                
                                                    <li><a href="<?php echo base_url();?>admin/session_list"><span>Session Setup</span></a></li>
								
						
						<li class='has_sub'>
							<a href='javascript:void(0);'><span>Shift</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
							<ul>
								<li><a href="<?php echo base_url();?>admin/shift_list"><span>Shift Setup</span></a></li>
								<li><a href="<?php echo base_url();?>admin/shift_assign"><span>Shift Assign</span></a></li>
							</ul>
						</li>
						
						<li class='has_sub'>
							<a href='javascript:void(0);'><span>Subject</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
							<ul>
								<li><a href="<?php echo base_url();?>admin/subject_list"><span>Subject Setup</span></a></li>
								<li><a href="<?php echo base_url();?>admin/subject_assign"><span>Subject Assign</span></a></li>
							</ul>
						</li>
						
						<li><a href="#"><span>Student's Category</span></a></li>
						
												<li class='has_sub'>
							<a href='javascript:void(0);'><span>Exam</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
							<ul>
                                <li class='has_sub'>
									<a href='javascript:void(0);'><span>Exam Setting</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
									<ul>
										<li><a href="<?php echo base_url();?>academic/gpa_system"><span>Set Grade Scale</span></a></li>
                                        <li><a href="<?php echo base_url();?>academic/mark_distribution_system"><span>Mark Distribution System</span></a></li>
                                        <li><a href="<?php echo base_url();?>academic/term_subject_list"><span>Term Subject Full Marks</span></a></li>
										<li><a href="<?php echo base_url();?>academic/subject_wise_total_marks_list"><span>Term Marks Distribution</span></a></li>
                                        <li><a href="<?php echo base_url();?>academic/set_exam_time"><span>Set Term Exam Time </span></a></li>
                                        <li><a href="<?php echo base_url();?>academic/exam_routine"><span>Set Term Exam Routine </span></a></li>
                                        <li><a href="<?php echo base_url();?>academic/set_admit_card_initial"><span> Admit Card </span></a></li>
									</ul>	
								</li>
								
								<li class='has_sub'>
									<a href='javascript:void(0);'><span>Set Exam</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
									<ul>
										 <?php foreach($menuresult as $menuresults)
							{
								//if($menuresults['exam_type']==4)
								//{
								 ?>
									<!--<li><a href="<?php// echo base_url();?>academic/ct_list"><span>CT List</span></a></li>-->
						  <?php	 //}
						  		if($menuresults['exam_type']==5)
								{
								 ?>
									<li><a href="<?php echo base_url();?>academic/assignment_list"><span>Assignment List</span></a></li>
						  <?php	 }
						   }?>	
                                        <li><a href="<?php echo base_url();?>academic/term_list"><span>Term List</span></a></li>
									</ul>	
								</li>
								<!--<li class='has_sub'>
									<a href='javascript:void(0);'><span>Subject Wise Total Marks</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
									<ul>
										<!--<li><a href="<?php //echo base_url();?>academic/create_hw"><span>Create</span></a></li>-->
										<!--<li><a href="<?php //echo base_url();?>academic/hw_list"><span>View</span></a></li>
                                        <li><a href="<?php //echo base_url();?>academic/subject_wise_total_marks_list"><span>View</span></a></li>
									</ul>	
								</li>
								<!--<li class='has_sub'>
									<a href='javascript:void(0);'><span>Set Project/Assignment</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
									<ul>
                                    <li><a href="<?php //echo base_url();?>academic/create_assignment"><span>Create</span></a></li>	
										
										<li><a href="<?php //echo base_url();?>academic/assignment_list"><span>View</span></a></li>
									</ul>	
								</li>
								<li class='has_sub'>
									<a href='javascript:void(0);'><span>Set Term</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
									<ul>
										
										<li><a href="<?php //echo base_url();?>academic/term_list"><span>View</span></a></li>
                                        
                                        
									</ul>	
								</li>
								<li><a href="#"><span>Set Grade Scale</span></a></li>
								<li><a href="#"><span>Total Marks (Percentage)</span></a></li>-->
							</ul>
						</li>
						
						
						<li class='has_sub'>
							<a href='javascript:void(0);'><span>Fees</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
							<ul>
								<li><a href="#"><span>Fees Category</span></a></li>
								<li><a href="#"><span>Fees Period</span></a></li>
							</ul>
						</li>
						
						<li class='has_sub'>
							<a href='javascript:void(0);'><span>Accounts</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
							<ul>
							
								<li><a href="<?php echo base_url();?>admin/chartof_accounts"><span>Create Chart of Accounts</span></a></li>
								
								<li><a href="#"><span>Create Ledger</span></a></li>
								<li><a href="#"><span>Create Category</span></a></li>
							</ul>
						</li>
						
						
						<li class='has_sub'>
							<a href='javascript:void(0);'><span>Holiday</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
							<ul>
								<li><a href="<?php echo base_url();?>admin/weekly_holiday"><span>Weekly Holiday</span></a></li>
								<li><a href="<?php echo base_url();?>admin/shift_assign"><span>General Holiday</span></a></li>
							</ul>
						</li>
						
						
						<li class='has_sub'>
							<a href='javascript:void(0);'><span>Timetable</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
							<ul>
								<li><a href="#"><span>Create Weekdays</span></a></li>
								<li><a href="#"><span>Work Allotment</span></a></li>
								<li><a href="#"><span>Edit Timetable</span></a></li>
								<li class='has_sub'>
									<a href='javascript:void(0);'><span>Teacher Timetable</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
									<ul>
										<li><a href="#"><span>Swap Timetable</span></a></li>
										<li><a href="#"><span>Swapped Timetable Report</span></a></li>
									</ul>
								</li>										
								<li><a href="#"><span>Set Class Timing</span></a></li>
								<li><a href="#"><span>Create Timetable</span></a></li>
								<li><a href="#"><span>View Timetable</span></a></li>
								<li><a href="#"><span>Institutional Timetable</span></a></li>
								<li><a href="#"><span>Class Allocation</span></a></li>
							</ul>
						</li>
						
						<li class='has_sub'>
							<a href='javascript:void(0);'><span>Teacher/Staff</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
							<ul>
								<li><a href="<?php echo base_url();?>admin/department_list"><span>Set Department</span></a></li>
								<li><a href="<?php echo base_url();?>admin/designation_list"><span>Set Designation</span></a></li>
							</ul>
						</li>
						
						<li class='has_sub'>
							<a href='javascript:void(0);'><span>Reports</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
							<ul>
								<li><a href="#"><span>Item Wise</span></a></li>
								<li><a href="#"><span>Day Wise</span></a></li>
								<li><a href="#"><span>Invoice Wise</span></a></li>
							</ul>
						</li>
						
						<li><a href="#"><span>Leave Management</span></a></li>
						<li><a href="#"><span>Event Management</span></a></li>								
						<li><a href="#"><span>Set Salary Details</span></a></li>
						<li><a href="#"><span>Set Working Days</span></a></li>
						<li class='has_sub'>
							<a href='javascript:void(0);'><span>Library</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
							<ul>
								<li><a href="#"><span>Add Category</span></a></li>
							</ul>
						</li>
						
						<li class='has_sub'>
							<a href='javascript:void(0);'><span>Daily Notification</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
							<ul>
								<li><a href="#"><span>Notification Add</span></a></li>
								<li><a href="#"><span>Notification List</span></a></li>
							</ul>
						</li>
					</ul>
				</li>
			</ul>
		 
			<div class="clearfix"></div>
		</div>
		<div class="clearfix"></div>
	<div class="clearfix"></div><br><br><br>
</div>