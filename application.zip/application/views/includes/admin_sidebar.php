<?php
$sql		= "SELECT distinct(exam_type) as `exam_type` FROM `tbl_mark_distribution` order by exam_type";
$query 		= $this->db->query($sql);
$menuresult	= $query->result_array();
?>
<div class="left side-menu">
        <div class="sidebar-inner slimscrollleft" style="background:#35363A;">
            <div id="sidebar-menu">
                <ul class="menu_active_class" style="display:none;">
                    <li class="web_db"><a href='<?= base_url();?>admin'><i class='fa fa-dashboard animated-hover fa-slow'></i><span>Dashboard</span></a>
                    </li>
                    <li><a href='http://thsict.edu.bd/' target="_blank"><i class='icon-home-3'></i><span>Visit Site</span> <span class="pull-right"></span></a>
                    </li>
                     <li class="notice">
                        <a href="<?= base_url();?>notice/notice_list" title="Message">
                            <i class="fa fa-bell"></i>
                            <span class="hidden-xs">Notice</span>
                        </a>
                    </li>
                    <li class='has_sub'><a class="<?php if($this->uri->uri_string()=='admin/admission_student_list' || $this->uri->uri_string()=='admin/admission_student_mark_entry' || $this->uri->uri_string()=='admin/admission_result_publish'){ echo 'active'; } ?>" href='javascript:void(0);'><i class="fa fa-align-justify" aria-hidden="true"></i>
						<span>Admission</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                        <ul>
                            <li><a class="<?php if($this->uri->uri_string()=='admin/admission_student_list'){ echo 'active'; } ?>" href="<?php echo base_url();?>admin/admission_student_list">Admission Student List</a></li>
                            <li><a class="<?php if($this->uri->uri_string()=='admin/admission_student_mark_entry'){ echo 'active'; } ?>" href="<?php echo base_url();?>admin/admission_student_mark_entry">Admission Student Mark Entry</a></li>
                            <li><a class="<?php if($this->uri->uri_string()=='admin/admission_result_publish'){ echo 'active'; } ?>" href="<?php echo base_url();?>admin/admission_result_publish">Publish Admission Result</a></li>
                            <!--li>
                                <a href="<?= base_url();?>web/donor" title="Donor">
                                    <span class="hidden-xs">Donor</span>
                                </a>
                            </li-->
                        </ul>
                    </li>
                    
                 <li class='has_sub'><a class="<?php if($this->uri->uri_string()=='web/message' || $this->uri->uri_string()=='web/founder' || $this->uri->uri_string()=='web/land_info' || $this->uri->uri_string()=='web/news' || $this->uri->uri_string()=='web/video_gallery' || $this->uri->uri_string()=='web/head_teacher_list'){ echo 'active'; } ?>" href='javascript:void(0);'><i class="fa fa-list"></i><span>Information</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                    <ul>
                    <li class="com">
                        <a  class="<?php if($this->uri->uri_string()=='web/video_gallery'){ echo 'active'; } ?>" href="<?= base_url();?>web/video_gallery" title="">
                            <i class="fa fa-video-camera" aria-hidden="true"></i>
                            <span class="hidden-xs">Video Gallery</span>
                        </a>
                    </li>
                    <li class="com">
                        <a  class="<?php if($this->uri->uri_string()=='web/news'){ echo 'active'; } ?>" href="<?= base_url();?>web/news" title="">
                            <i class="fa fa-calendar-o" aria-hidden="true"></i>
                            <span class="hidden-xs">News & Events</span>
                        </a>
                    </li>
                     <li class="message">
                        <a class="<?php if($this->uri->uri_string()=='web/message'){ echo 'active'; } ?>" href="<?= base_url();?>web/message" title="Message">
                            <i class="fa fa-file-text-o"></i>
                            <span class="hidden-xs">Message</span>
                        </a>
                    </li>
                    <li class="com">
                        <a class="<?php if($this->uri->uri_string()=='web/founder'){ echo 'active'; } ?>" href="<?= base_url();?>web/founder" title="">
                            <i class="fa fa-user" aria-hidden="true"></i>
                            <span class="hidden-xs">Founder</span>
                        </a>
                    </li>
                    <li class="com">
                        <a class="<?php if($this->uri->uri_string()=='web/head_teacher_list'){ echo 'active'; } ?>" href="<?= base_url();?>web/head_teacher_list" title="">
                            <i class="fa fa-user" aria-hidden="true"></i>
                            <span class="hidden-xs">Head Teacher List</span>
                        </a>
                    </li>
                    <li class="com">
                        <a  class="<?php if($this->uri->uri_string()=='web/land_info'){ echo 'active'; } ?>" href="<?= base_url();?>web/land_info" title="">
                            <i class="fa fa-desktop" aria-hidden="true"></i>
                            <span class="hidden-xs">Land Info</span>
                        </a>
                    </li>
                    <li class="com">
                        <a class="<?php if($this->uri->uri_string()=='web/other_assets'){ echo 'active'; } ?>" href="<?= base_url();?>web/other_assets" title="">
                            <i class="fa fa-desktop" aria-hidden="true"></i>
                            <span class="hidden-xs">Other Assets</span>
                        </a>
                    </li>
                   <li class="com">
                        <a class="<?php if($this->uri->uri_string()=='web/computer_lab'){ echo 'active'; } ?>" href="<?= base_url();?>web/computer_lab" title="">
                            <i class="fa fa-desktop" aria-hidden="true"></i>
                            <span class="hidden-xs">Computer Lab</span>
                        </a>
                    </li>
                    <li class="information_list">
                        <a class="<?php if($this->uri->uri_string()=='web/information_list'){ echo 'active'; } ?>" href="<?= base_url();?>web/information_list" title="Slide">
                            <i class="fa fa-file-text-o"></i>
                            <span class="hidden-xs">Other Information </span>
                        </a>
                    </li>
                    <li class="about">
                            <a class="<?php if($this->uri->uri_string()=='web/about'){ echo 'active'; } ?>" href="<?= base_url();?>web/about" title="About">
                                <i class="fa fa-file-text-o"></i>
                                <span class="hidden-xs">About</span>
                            </a>
                        </li>
                    </ul>
                    </li>
                   
                    <li class='has_sub'><a class="<?php if($this->uri->uri_string()=='web/managing_committee' || $this->uri->uri_string()=='web/donor'){ echo 'active'; } ?>" href='javascript:void(0);'><i class="fa fa-align-justify" aria-hidden="true"></i>
<span>Committee/Donor</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                        <ul>
                            <li><a class="<?php if($this->uri->uri_string()=='web/managing_committee'){ echo 'active'; } ?>" href="<?= base_url();?>web/managing_committee">Managing Committee</a></li>
                            <li>
                                <a class="<?php if($this->uri->uri_string()=='web/donor'){ echo 'active'; } ?>" href="<?= base_url();?>web/donor" title="Donor">
                                    <span class="hidden-xs">Donor</span>
                                </a>
                            </li>
                        </ul>
                    </li>
                   <li class='has_sub photos'><a class="<?php if($this->uri->uri_string()=='web/picture_gallery' || $this->uri->uri_string()=='web/catagory_list' || $this->uri->uri_string()=='web/slide'){ echo 'active'; } ?>" href='javascript:void(0);'><i class="fa fa-picture-o"></i><span>Gallery</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                        <ul>
                            <li><a class="<?php if($this->uri->uri_string()=='web/picture_gallery'){ echo 'active'; } ?>" href="<?= base_url();?>web/picture_gallery">Photo Gallery</a></li>
                            <li><a class="<?php if($this->uri->uri_string()=='web/catagory_list'){ echo 'active'; } ?>" href="<?= base_url();?>web/catagory_list">Photo Catagory</a></li>
                            <li class="slide">
                                <a class="<?php if($this->uri->uri_string()=='web/slide'){ echo 'active'; } ?>" href="<?= base_url();?>web/slide" title="Slide">
                                    
                                    <span class="hidden-xs">Slide</span>
                                </a>
                            </li>
<!--li>
                                <a href="<?= base_url();?>web/freedom_fighter" title="freedom_fighter">
                                    <span class="hidden-xs">Freedom Fighter</span>
                                </a>
                            </li-->

                        </ul>
                    </li>
                    <li class='has_sub teacher'><a href='javascript:void(0);'><i class='fa fa-user'></i><span>Teacher/Staff Management</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                        <ul>
                            <li class="tea_reg"><a class="<?php if($this->uri->uri_string()=='admin/teacher_registration'){ echo 'active'; } ?>" href="<?= base_url();?>admin/teacher_registration"><span>Teachers Registration</span></a></li>
                            <li class="tea_list"><a class="<?php if($this->uri->uri_string()=='admin/teacher_list'){ echo 'active'; } ?>" href="<?= base_url();?>admin/teacher_list"><span>Teacher List</span></a></li>
                            <li class="tea_asign"><a class="<?php if($this->uri->uri_string()=='academic/class_teacher_assign'){ echo 'active'; } ?>" href="<?= base_url();?>academic/class_teacher_assign"><span>Class Teacher Assign</span></a></li>
                            <li class='has_sub tea_salery'>
                                <a href='javascript:void(0);'><span>Teacher Salary</span> <span class="pull-right"><i class="fa fa-angle-down"></i> </span> </a>
                                <ul>
                                    <li><a class="<?php if($this->uri->uri_string()=='admin/salary_cat'){ echo 'active'; } ?>" href="<?= base_url();?>admin/salary_cat"><span>Teacher Salary Catagory</span></a></li>
                                    <li><a class="<?php if($this->uri->uri_string()=='admin/teacher_salary_structure'){ echo 'active'; } ?>" href="<?= base_url();?>admin/teacher_salary_structure"><span>Teacher Salary Structure</span></a></li>
                                </ul>
                            </li>
                            <!--<li><a href="#"><span>Teachers Class Schedule</span></a></li>
						<li><a href="#"><span>Leave Application</span></a></li>-->
                            <li class='has_sub atten'>
                                <a href='javascript:void(0);'><span>Attendance</span> <span class="pull-right"><i class="fa fa-angle-down"></i> </span> </a>
                                <ul>
                                    <li><a class="<?php if($this->uri->uri_string()=='attendance/teacher_attendance'){ echo 'active'; } ?>" href="<?= base_url();?>attendance/teacher_attendance"><span>Attendance</span></a></li>
                                    <li><a class="<?php if($this->uri->uri_string()=='attendance/teacher_attendance_report'){ echo 'active'; } ?>" href="<?= base_url();?>attendance/teacher_attendance_report"><span>Report</span></a></li>
                                </ul>
                            </li>
                        </ul>

                    </li>
                    <li class='has_sub stu_man'>
                        <a href='javascript:void(0);'><i class='icon-users'></i><span>Student Management</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                        <ul>
                            <li class='stu_reg'><a class="<?php if($this->uri->uri_string()=='admin/student_registration'){ echo 'active'; } ?>" href="<?= base_url();?>admin/student_registration"><span>Student Registration</span></a></li>
                            <li class='stu_list'><a class="<?php if($this->uri->uri_string()=='admin/student_list'){ echo 'active'; } ?>" href="<?= base_url();?>admin/student_list"><span>Student List</span></a></li>
                            <li><a class="<?php if($this->uri->uri_string()=='student_promote'){ echo 'active'; } ?>" href="<?php echo base_url();?>student_promote"><span>Student Promoted</span></a></li>
                            <li><a class="<?php if($this->uri->uri_string()=='student_final_promote'){ echo 'active'; } ?>" href="<?php echo base_url();?>student_final_promote"><span>Student Final Promote</span></a></li>
                            <li><a class="<?php if($this->uri->uri_string()=='student_roll_assign'){ echo 'active'; } ?>" href="<?php echo base_url();?>student_roll_assign"><span>Student Roll Assign</span></a></li>
                            <li><a class="<?php if($this->uri->uri_string()=='student_change_section'){ echo 'active'; } ?>" href="<?php echo base_url();?>student_change_section"><span>Student Change Section</span></a></li>
                            <li><a class="<?php if($this->uri->uri_string()=='student_change_group_final'){ echo 'active'; } ?>" href="<?php echo base_url();?>student_change_group_final"><span>Student Change Group</span></a></li>
                             <li class='stu_arc'><a class="<?php if($this->uri->uri_string()=='archive/student_archive'){ echo 'active'; } ?>" href="<?= base_url();?>archive/student_archive"><span>Student Archive</span></a></li>

                            <li class='has_sub stu_assign'>
                                <a href='javascript:void(0);'><span>Student Subject Assign</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                                <ul>
                                    <li><a class="<?php if($this->uri->uri_string()=='admin/student_subject_assign'){ echo 'active'; } ?>" href="<?= base_url();?>admin/student_subject_assign"><span>Subject Assign</span></a></li>
                                    <li><a class="<?php if($this->uri->uri_string()=='admin/student_subject_view'){ echo 'active'; } ?>" href="<?= base_url();?>admin/student_subject_view"><span>Subject View</span></a></li>
                                </ul>
                            </li>
                            <li class='has_sub att'>
                                <a href='javascript:void(0);'><span>Attendance</span> <span class="pull-right"><i class="fa fa-angle-down"></i> </span> </a>
                                <ul>
                                    <li><a class="<?php if($this->uri->uri_string()=='attendance/student_attendance'){ echo 'active'; } ?>" href="<?= base_url();?>attendance/student_attendance"><span>Attendance</span></a></li>
                                    <li><a class="<?php if($this->uri->uri_string()=='attendance/student_attendance_report'){ echo 'active'; } ?>" href="<?= base_url();?>attendance/student_attendance_report"><span>Report</span></a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>

                    <li class='has_sub fee_man'><a href='javascript:void(0);'><i class='fa fa-money'></i><span>Fees Management</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                        <ul>
                            <li class='fee_gen_edit'><a href="<?= base_url();?>fees/student_fees_generate_edit"><span>Fees Generate (editable)</span></a></li>
                            <li class='fee_gen'><a href="<?= base_url();?>fees/student_fees_generate"><span>Fees Generate</span></a></li>
                            <li class='fee_coll_edit'><a href="<?= base_url();?>fees/fees_collect_edit"><span>Fees Collect (editable)</span></a></li>
                            <li class='fee_coll'><a href="<?= base_url();?>fees/fees_collect"><span>Fees Collect</span></a></li>
                            <li class='stu_wise_fee_edit'><a href="<?= base_url();?>fees/student_wise_fees_edit"><span>Student Wise Fees (editable)</span></a></li>
                            <li class='stu_wise_fee'><a href="<?= base_url();?>fees/student_wise_fees"><span>Student Wise Fees</span></a></li>
                            <li class='has_sub fees_rep'>
                                <a href='javascript:void(0);'><span>Reports</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                                <ul>
                                    <li><a href="<?= base_url();?>fees/paid_report"><span>Paid Report</span></a></li>
                                    <li><a href="<?= base_url();?>fees/unpaid_report"><span>Unpaid Report</span></a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>

                    <li class='has_sub res_man'><a href='javascript:void(0);'><i class='fa fa-pencil-square-o'></i><span>Result Management</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                        <ul>
                            <li class='has_sub marks'>
                                <a href='javascript:void(0);'><span>Marks</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                                <ul>

                                <!--li><a href="<?= base_url();?>exam/set_term_marks"><span>Set Term Marks</span></a></li-->
                                    <?php foreach($menuresult as $menuresults)
							{
								if($menuresults['exam_type']==1)
								{
								 ?>
                                        <li><a class="<?php if($this->uri->uri_string()=='exam/set_ca_marks'){ echo 'active'; } ?>" href="<?= base_url();?>exam/set_ca_marks"><span>Set CA Marks</span></a></li>
                                        <?php	 }
								elseif($menuresults['exam_type']==2)
								{ ?>
                                            <li><a class="<?php if($this->uri->uri_string()=='exam/set_cw_marks'){ echo 'active'; } ?>" href="<?= base_url();?>exam/set_cw_marks"><span>Set CW Marks</span></a></li>
                                            <?php	 }
								elseif($menuresults['exam_type']==3)
								{ ?>
                                                <li><a class="<?php if($this->uri->uri_string()=='exam/set_hw_marks'){ echo 'active'; } ?>" href="<?= base_url();?>exam/set_hw_marks"><span>Set HW Marks</span></a></li>
                                                <?php	 }
								elseif($menuresults['exam_type']==4)
								{ ?>
                                                    <li><a class="<?php if($this->uri->uri_string()=='exam/set_ct_marks'){ echo 'active'; } ?>" href="<?= base_url();?>exam/set_ct_marks"><span>Set CT Marks</span></a></li>
                                                    <?php	 }
								elseif($menuresults['exam_type']==5)
								{ ?>
                                                        <li><a class="<?php if($this->uri->uri_string()=='exam/set_project_marks'){ echo 'active'; } ?>" href="<?= base_url();?>exam/set_project_marks"><span>Set Project Marks</span></a></li>
                                                        <?php	 }
								elseif($menuresults['exam_type']==6)
								{ ?>
                                                            <li><a class="<?php if($this->uri->uri_string()=='exam/set_term_marks'){ echo 'active'; } ?>" href="<?= base_url();?>exam/set_term_marks"><span>Set Term Marks</span></a></li>
                                                            <?php    }
				    		} ?>

                                </ul>
                            </li>


                            <!--// Ssc, Jsc, Psc Result Sheet Start //-->

                             <li class='has_sub res_report'>
                                <a href='javascript:void(0);'><span>Result Sheet (SSC, JSC)</span><span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                                <ul>
                                <!--li><a href="<?= base_url();?>result/ssc_result"><span>SSC Result</span></a></li>
                    <li><a href="<?= base_url();?>result/psc_result"><span>PSC Result</span></a></li-->
                                    <li><a class="<?php if($this->uri->uri_string()=='result/mark_entry'){ echo 'active'; } ?>" href="<?= base_url();?>result/mark_entry"><span>Mark Entry</span></a></li>
                                    <li><a class="<?php if($this->uri->uri_string()=='result/mark_entry_report'){ echo 'active'; } ?>" href="<?php echo base_url();?>result/mark_entry_report"><span>Report</span></a></li>
                                
                                </ul>
                            </li>
                            
                          <!--// Ssc, Jsc, Psc Result Sheet End //-->



                            <li class='has_sub res_report'>
                                <a href='javascript:void(0);'><span>Reports</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                                <ul>
                                <!--li><a href="<?= base_url();?>result/ssc_result"><span>SSC Result</span></a></li>
					<li><a href="<?= base_url();?>result/psc_result"><span>PSC Result</span></a></li-->
                                    <li><a class="<?php if($this->uri->uri_string()=='result/mark_sheet'){ echo 'active'; } ?>" href="<?= base_url();?>result/mark_sheet"><span>Marksheet</span></a></li>
                                    <li><a class="<?php if($this->uri->uri_string()=='result/tabulation_sheet'){ echo 'active'; } ?>" href="<?php echo base_url();?>result/tabulation_sheet"><span>Tabulation Sheet</span></a></li>
                                    <li><a class="<?php if($this->uri->uri_string()=='terms_tabulation'){ echo 'active'; } ?>" href="<?php echo base_url();?>terms_tabulation"><span>Result Sheet</span></a></li>
                                    <li><a class="<?php if($this->uri->uri_string()=='terms_tabulation_all'){ echo 'active'; } ?>" href="<?php echo base_url();?>terms_tabulation_all"><span>Result Sheet (All Student)</span></a></li>
                                    <li><a class="<?php if($this->uri->uri_string()=='result/bill_sheet_term'){ echo 'active'; } ?>" href="<?php echo base_url();?>result/bill_sheet_term"><span>Bill Sheet</span></a></li>
                                    <li><a class="<?php if($this->uri->uri_string()=='result/tabulation_sheet_subject_wise'){ echo 'active'; } ?>" href="<?= base_url();?>result/tabulation_sheet_subject_wise"><span>Tabulation Sheet Subject Wise</span></a></li>
                                     <li><a class="<?php if($this->uri->uri_string()=='result/result_publish'){ echo 'active'; } ?>" href="<?= base_url();?>result/result_publish"><span>Publish Result</span></a></li>
                                </ul>
                            </li>
                            <li class="stu_entro"><a href="<?= base_url();?>result/student_enrollment"><span>Student Enrolment</span></a></li>
                        </ul>
                    </li>

                    <li class='has_sub ac_man'><a href='javascript:void(0);'><i class='fa fa-calculator'></i><span>Accounts Management</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                        <ul>
                            <li class='has_sub nav_head_view'>
                                <a href='javascript:void(0);'><span>Manage Master Head</span> <span class="pull-right"><i class="fa fa-angle-down"> </i></span></a>
                                <ul>
                                    <li><a href="<?= base_url();?>accounts/master_head_create"><span>Master Head Create</span></a></li>
                                    <li><a href="<?= base_url();?>accounts/master_head_list"><span>Master Head List</span></a></li>
                                </ul>
                            </li>

                            <li class='has_sub nav_head_view'>
                                <a href='javascript:void(0);'><span>Manage Sub1 Head</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                                <ul>
                                    <li><a href="<?= base_url();?>accounts/sub1_head_create"><span>Sub1 Head Create</span></a></li>
                                    <li><a href="<?= base_url();?>accounts/sub1_head_list"><span>Sub1 Head List</span></a></li>
                                </ul>
                            </li>

                            <li class='has_sub nav_head_view'>
                                <a href='javascript:void(0);'><span>Manage Sub2 Head</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                                <ul>
                                    <li><a href="<?= base_url();?>accounts/sub2_head_create"><span>Sub2 Head Create</span></a></li>
                                    <li><a href="<?= base_url();?>accounts/sub2_head_list"><span>Sub2 Head List</span></a></li>
                                </ul>
                            </li>

                            <li class='has_sub nav_head_view'>
                                <a href='javascript:void(0);'><span>Manage Sub3 Head</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                                <ul>
                                    <li><a href="<?= base_url();?>accounts/sub3_head_create"><span>Sub3 Head Create</span></a></li>
                                    <li><a href="<?= base_url();?>accounts/sub3_head_list"><span>Sub3 Head List</span></a></li>
                                </ul>
                            </li>

                            <li class="nav_head_view"><a href="<?= base_url();?>accounts/navigation_head_view"><span>Navigation Head View</span></a></li>

                            <li class='has_sub debit_vou'>
                                <a href='javascript:void(0);'><span>Debit Voucher</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                                <ul>
                                    <li><a href="<?= base_url();?>accounts/debit_voucher_entry"><span>Debit Voucher Entry</span></a></li>
                                    <li><a href="<?= base_url();?>accounts/debit_voucher_list"><span>Debit Voucher List</span></a></li>
                                </ul>
                            </li>

                            <li class='has_sub credit_vou'>
                                <a href='javascript:void(0);'><span>Credit Voucher</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                                <ul>
                                    <li><a href="<?= base_url();?>accounts/credit_voucher_entry"><span>Credit Voucher Entry</span></a></li>
                                    <li><a href="<?= base_url();?>accounts/credit_voucher_list"><span>Credit Voucher List</span></a></li>
                                </ul>
                            </li>
                            <li class='has_sub nav_head_view'>
                                <a href='javascript:void(0);'><span>Reports</span> <span class="pull-right"><i class="fa fa-angle-down"> </i></span></a>
                                <ul>
                                    <li><a href="<?= base_url();?>accounts/trial_balance"><span>Trial Balance</span></a></li>
                                </ul>
                            </li>
                            <!--
						<li><a href="<?= base_url();?>accounts/trial_balance"><span>Trial Balance</span></a></li>
						-->
                        </ul>
                    </li>

                    <li class='has_sub library'><a href='javascript:void(0);'><i class='fa fa-book'></i><span>Library Management</span> <span class="pull-right"> <i class="fa fa-angle-down"></i></span></a>
                        <ul>
                            <li class="add_book"><a href="<?= base_url();?>library/book_category_list"><span>Add Books Category</span></a></li>
                            <li class="book_list"><a href="<?= base_url();?>library/book_list"><span>List of Books</span></a></li>
                             <li class="book_issue"><a href="<?= base_url();?>library/book_issue"><span>Issue Books</span></a></li>
                            <li class="lib_fin"><a href="#"><span>Library Fines</span></a></li>
                            <li class="mov_log"><a href="#"><span>Movement Log</span></a></li>
                            <li class="re_book"><a href="#"><span>Return Books</span></a></li>
                        </ul>
                    </li>

                    <!--
				<li class='has_sub'><a href='javascript:void(0);'><i class='fa fa-taxi'></i><span>Transport</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
					<ul>
						<li><a href="#"><span>Add Vehicle</span></a></li>
						<li><a href="#"><span>Add Route</span></a></li>
						<li><a href="#"><span>Add Destination</span></a></li>
						<li><a href="#"><span>Add Driver</span></a></li>
						<li><a href="#"><span>Add Vehicle Timing</span></a></li>
						<li><a href="#"><span>Allocation</span></a></li>
						<li><a href="#"><span>Fees</span></a></li>
					</ul>
				</li>

				<li class='has_sub'><a href='javascript:void(0);'><i class='fa fa-table'></i><span>Hostel</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
					<ul>
						<li><a href="#"><span>Add Hostel</span></a></li>
						<li><a href="#"><span>Add Floor</span></a></li>
						<li><a href="#"><span>Room List</span></a></li>
						<li><a href="#"><span>Registration</span></a></li>
						<li><a href="#"><span>Fees</span></a></li>
					</ul>
				</li>-->

				<li class='has_sub sms'><a href='javascript:void(0);'><i class='fa fa-envelope'></i><span>SMS Alert</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
					<ul>
						<li><a class="<?php if($this->uri->uri_string()=='sms_notice/student_sms'){ echo 'active'; } ?>" href="<?= base_url();?>sms_notice/student_sms"><span>Notice to Students</span></a></li>
						<li><a class="<?php if($this->uri->uri_string()=='sms_notice/teacher_sms'){ echo 'active'; } ?>" href="<?= base_url();?>sms_notice/teacher_sms"><span>Notice to Teacher</span></a></li>
						<li><a class="<?php if($this->uri->uri_string()=='sms_notice/managing_committee_sms'){ echo 'active'; } ?>" href="<?= base_url();?>sms_notice/managing_committee_sms"><span>Notice to Managing Committee</span></a></li>
						<li><a class="<?php if($this->uri->uri_string()=='sms_notice/donor_sms'){ echo 'active'; } ?>" href="<?= base_url();?>sms_notice/donor_sms"><span>Notice to Donor</span></a></li>
					</ul>
				</li>
                    <!--
				<li class='has_sub'><a href='javascript:void(0);'><i class='fa fa-shopping-cart'></i><span>Inventory Management</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
					<ul>
						<li><a href="#"><span>Store Category</span></a></li>
						<li><a href="#"><span>Store Type</span></a></li>
						<li><a href="#"><span>Store</span></a></li>
						<li><a href="#"><span>Item Category</span></a></li>
						<li><a href="#"><span>Store Items</span></a></li>
						<li><a href="#"><span>Supplier Type</span></a></li>
						<li><a href="#"><span>Supplier</span></a></li>
						<li><a href="#"><span>Indents</span></a></li>
						<li><a href="#"><span>Purchase Order</span></a></li>
						<li><a href="#"><span>Billing</span></a></li>
						<li><a href="#"><span>GRN</span></a></li>

						<li class='has_sub'>
							<a href='javascript:void(0);'><span>Reports</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
							<ul>
								<li><a href="#"><span>Item Wise</span></a></li>
								<li><a href="#"><span>Day Wise</span></a></li>
								<li><a href="#"><span>Invoice Wise</span></a></li>
							</ul>
						</li>
					</ul>
				</li>-->

                    <li class='has_sub routin'><a href='javascript:void(0);'><i class='fa fa-list'></i><span>Routines</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                        <ul>
                            <li><a class="<?php if($this->uri->uri_string()=='academic/show_class_routine'){ echo 'active'; } ?>" href="<?= base_url();?>academic/show_class_routine"><span>Show Class Routin</span></a></li>
                            <li><a class="<?php if($this->uri->uri_string()=='academic/show_class_routine_by_teacher'){ echo 'active'; } ?>" href="<?= base_url();?>academic/show_class_routine_by_teacher"><span>Show Class Routin by Teacher</span></a></li>
                            <li><a class="<?php if($this->uri->uri_string()=='academic/examroutine'){ echo 'active'; } ?>" href="<?= base_url();?>academic/examroutine"><span>Show Exam Routine </span></a></li>
                        </ul>
                    </li>

                    <li class='has_sub auth'><a href='javascript:void(0);'><i class='fa fa-group'></i><span>User Management</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                        <ul>
                            <!--<li><a href="#"><span>Add User</span></a></li>-->
                            <li><a class="<?php if($this->uri->uri_string()=='auth/user_panel'){ echo 'active'; } ?>" href="<?= base_url() ?>auth/user_panel"><span>Set Privilege</span></a></li>
                        </ul>
                    </li>

                    <li class='has_sub sett'><a href='javascript:void(0);'><i class='fa fa-wrench'></i><span>Settings</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                        <ul>
                            <li class='has_sub gen_sett'>
                                <a href='javascript:void(0);'><span>General Settings</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                                <ul>
                                    <li><a class="<?php if($this->uri->uri_string()=='admin/institute_information'){ echo 'active'; } ?>" href="<?= base_url();?>admin/institute_information"><span>Institute Information</span></a></li>
                                </ul>
                            </li>

                            <li class='has_sub class'>
                                <a href='javascript:void(0);'><span>Class</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                                <ul>
                                    <li><a class="<?php if($this->uri->uri_string()=='admin/class_list'){ echo 'active'; } ?>" href="<?= base_url();?>admin/class_list"><span>Class Setup</span></a></li>
                                    <li><a class="<?php if($this->uri->uri_string()=='academic/set_class_timing'){ echo 'active'; } ?>" href="<?= base_url();?>academic/set_class_timing"><span>Class Time</span></a></li>
                                    <li><a class="<?php if($this->uri->uri_string()=='academic/class_routine'){ echo 'active'; } ?>" href="<?= base_url();?>academic/class_routine"><span>Class Routine</span></a></li>
                                </ul>
                            </li>

                            <li class='has_sub sec'>
                                <a href='javascript:void(0);'><span>Section</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                                <ul>
                                    <li><a class="<?php if($this->uri->uri_string()=='admin/section_list'){ echo 'active'; } ?>" href="<?= base_url();?>admin/section_list"><span>Section Setup</span></a></li>
                                    <li><a class="<?php if($this->uri->uri_string()=='admin/section_assign'){ echo 'active'; } ?>" href="<?= base_url();?>admin/section_assign"><span>Section Assign</span></a></li>
                                </ul>
                            </li>
                            <li class='has_sub group'>
                                <a href='javascript:void(0);'><span>Group</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                                <ul>
                                    <li><a class="<?php if($this->uri->uri_string()=='academic/group_list'){ echo 'active'; } ?>" href="<?= base_url();?>academic/group_list"><span>Group Setup</span></a></li>
                                    <li><a class="<?php if($this->uri->uri_string()=='academic/group_assign'){ echo 'active'; } ?>" href="<?= base_url();?>academic/group_assign"><span>Group Assign</span></a></li>

                                </ul>
                            </li>
                            <li class="sess_set"><a class="<?php if($this->uri->uri_string()=='admin/session_list'){ echo 'active'; } ?>" href="<?= base_url();?>admin/session_list"><span>Session Setup</span></a></li>

                            <li class="shift_set"><a class="<?php if($this->uri->uri_string()=='admin/shift_list'){ echo 'active'; } ?>" href="<?= base_url();?>admin/shift_list"><span>Shift Setup</span></a></li>

                            <li class='has_sub subject'>
                                <a href='javascript:void(0);'><span>Subject</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                                <ul>
                                    <li><a class="<?php if($this->uri->uri_string()=='admin/subject_list'){ echo 'active'; } ?>" href="<?= base_url();?>admin/subject_list"><span>Subject Setup</span></a></li>
                                    <li><a class="<?php if($this->uri->uri_string()=='admin/subject_assign'){ echo 'active'; } ?>" href="<?= base_url();?>admin/subject_assign"><span>Subject Assign</span></a></li>
                                </ul>
                            </li>

                            <li class='has_sub exam'>
                                <a href='javascript:void(0);'><span>Exam</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                                <ul>
                                    <li class='has_sub exam_stt'>
                                        <a href='javascript:void(0);'><span>Exam Setting</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                                        <ul>
                                            <li><a class="<?php if($this->uri->uri_string()=='exam/gpa_system'){ echo 'active'; } ?>" href="<?= base_url();?>exam/gpa_system"><span>Set Grade Scale</span></a></li>
                                            <li><a class="<?php if($this->uri->uri_string()=='exam/mark_distribution_system'){ echo 'active'; } ?>" href="<?= base_url();?>exam/mark_distribution_system"><span>Mark Distribution System</span></a></li>
                                            <!--<li><a href="<?//php echo base_url();?>academic/term_subject_list"><span>Term Subject Full Marks</span></a></li>-->
                                            <li><a class="<?php if($this->uri->uri_string()=='exam/subject_wise_total_marks_list'){ echo 'active'; } ?>" href="<?= base_url();?>exam/subject_wise_total_marks_list"><span>Term Marks Distribution</span></a></li>
                                            <li><a class="<?php if($this->uri->uri_string()=='exam/set_exam_time'){ echo 'active'; } ?>" href="<?= base_url();?>exam/set_exam_time"><span>Set Term Exam Time </span></a></li>
                                            <li><a class="<?php if($this->uri->uri_string()=='exam/exam_routine'){ echo 'active'; } ?>" href="<?= base_url();?>exam/exam_routine"><span>Set Term Exam Routine </span></a></li>
                                            <li><a class="<?php if($this->uri->uri_string()=='exam/admit_card_initial'){ echo 'active'; } ?>" href="<?= base_url();?>exam/admit_card_initial"><span> Admit Card </span></a></li>
                                        </ul>
                                    </li>
                                    <li class="ad_card"><a href="<?= base_url();?>exam/admit_card_initial"><span> Admit Card </span></a></li>
                                    <li class='has_sub exam_set'>
                                        <a href='javascript:void(0);'><span>Set Exam</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                                        <ul>
                                            <?php foreach($menuresult as $menuresults)
							{
								//if($menuresults['exam_type']==4)
								//{
								 ?>
                                                <!--<li><a href="<?php// echo base_url();?>academic/ct_list"><span>CT List</span></a></li>-->
                                                <?php	 //}
						  		if($menuresults['exam_type']==5)
								{
								 ?>
                                                    <li><a href="<?= base_url();?>exam/assignment_list"><span>Assignment List</span></a></li>
                                                    <?php	 }
						   }?>
                                                        <li><a class="<?php if($this->uri->uri_string()=='exam/term_list'){ echo 'active'; } ?>" href="<?= base_url();?>exam/term_list"><span>Term List</span></a></li>
                                        </ul>
                                    </li>
                                    <!--<li class='has_sub'>
									<a href='javascript:void(0);'><span>Subject Wise Total Marks</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
									<ul>
										<!--<li><a href="<?php //echo base_url();?>academic/create_hw"><span>Create</span></a></li>-->
                                    <!--<li><a href="<?php //echo base_url();?>academic/hw_list"><span>View</span></a></li>
                                        <li><a href="<?php //echo base_url();?>academic/subject_wise_total_marks_list"><span>View</span></a></li>
									</ul>
								</li>
								<!--<li class='has_sub'>
									<a href='javascript:void(0);'><span>Set Project/Assignment</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
									<ul>
                                    <li><a href="<?php //echo base_url();?>academic/create_assignment"><span>Create</span></a></li>

										<li><a href="<?php //echo base_url();?>academic/assignment_list"><span>View</span></a></li>
									</ul>
								</li>
								<li class='has_sub'>
									<a href='javascript:void(0);'><span>Set Term</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
									<ul>

										<li><a href="<?php //echo base_url();?>academic/term_list"><span>View</span></a></li>

									</ul>
								</li>
								<li><a href="#"><span>Set Grade Scale</span></a></li>
								<li><a href="#"><span>Total Marks (Percentage)</span></a></li>-->
                                </ul>
                            </li>

                            <li class='has_sub fees'>
                                <a href='javascript:void(0);'><span>Fees</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                                <ul>
                                    <li><a class="<?php if($this->uri->uri_string()=='fees/fees_cat'){ echo 'active'; } ?>" href="<?= base_url();?>fees/fees_cat"><span>Fees Category</span></a></li>
                                    <li><a class="<?php if($this->uri->uri_string()=='fees/fees_type'){ echo 'active'; } ?>" href="<?= base_url();?>fees/fees_type"><span>Fees Type</span></a></li>
                                    <li><a class="<?php if($this->uri->uri_string()=='fees/class_wise_fees_management'){ echo 'active'; } ?>" href="<?= base_url();?>fees/class_wise_fees_management"><span>Fees Management</span></a></li>
                                </ul>
                            </li>

                            <!--<li class='has_sub holi'>
							<a href='javascript:void(0);'><span>Holiday</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
							<ul>
								<li><a href="<?= base_url();?>admin/weekly_holiday"><span>Weekly Holiday</span></a></li>
								<li><a href="<?= base_url();?>admin/shift_assign"><span>General Holiday</span></a></li>
							</ul>
						</li>-->
                            <li class="aca_cal"><a class="<?php if($this->uri->uri_string()=='academic/academic_calendar'){ echo 'active'; } ?>" href="<?= base_url();?>academic/academic_calendar"><span>Academic calendar</span></a></li>

                            <li class='has_sub tea_staff'>
                                <a href='javascript:void(0);'><span>Teacher/Staff</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                                <ul>
                                    <li><a class="<?php if($this->uri->uri_string()=='admin/department_list'){ echo 'active'; } ?>" href="<?= base_url();?>admin/department_list"><span>Set Department</span></a></li>
                                    <li><a class="<?php if($this->uri->uri_string()=='admin/designation_list'){ echo 'active'; } ?>" href="<?= base_url();?>admin/designation_list"><span>Set Designation</span></a></li>
                                </ul>
                            </li>

                            <li class='has_sub'>
                                <a href='javascript:void(0);'><span>Reports</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                                <ul>
                                    <li><a class="<?php if($this->uri->uri_string()=='acc_report/fees_details'){ echo 'active'; } ?>" href="<?= base_url();?>acc_report/fees_details"><span>Fees Details Report</span></a></li>
                                    <li><a class="<?php if($this->uri->uri_string()=='accounts/income_report'){ echo 'active'; } ?>" href="<?= base_url();?>accounts/income_report"><span>Income Report</span></a></li>
                                    <li><a class="<?php if($this->uri->uri_string()=='accounts/income_report'){ echo 'active'; } ?>" href="<?= base_url();?>accounts/income_report"><span>Expense Report</span></a></li>
                                </ul>
                            </li>
                        </ul>
                    </li>
                </ul>

                <div class="clearfix"></div>
            </div>
            <div class="clearfix"></div>
            <div class="clearfix"></div>
            <br>
            <br>
            <br>
        </div>