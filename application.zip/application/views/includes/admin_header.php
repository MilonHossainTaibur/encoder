<!DOCTYPE html>
<html>
<head>
        <meta charset="UTF-8">
        <title>WCL IMS</title>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />
        <meta name="apple-mobile-web-app-capable" content="yes" />
        <meta name="description" content="">
        <meta name="keywords" content="online school management, school management, educational institute management, institute management, college management, student management, teacher management, result management">
        <meta name="author" content="Huban Creative">

        <?php include 'application/views/includes/includes.php';?>
        <style>
        .zoom-image{
    -webkit-transition: all .3s ease; /* Safari and Chrome */
  	-moz-transition: all .3s ease; /* Firefox */
  	-o-transition: all .3s ease; /* IE 9 */
  	-ms-transition: all .3s ease; /* Opera */
  	transition: all .3s ease;
}
.zoom-image:hover{
 -webkit-backface-visibility: hidden;
    backface-visibility: hidden;
    -webkit-transform:translateZ(0) scale(2.20); /* Safari and Chrome */
    -moz-transform:scale(2.20); /* Firefox */
    -ms-transform:scale(2.20); /* IE 9 */
    -o-transform:translatZ(0) scale(2.20); /* Opera */
    transform:translatZ(0) scale(2.20);
}
        
        </style>
    </head>
    <body class="fixed-left">
       
	<div id="wrapper">
		<?php
    $sql = "SELECT * FROM tbl_school_information where school_id=1 LIMIT 1";
    $query = $this->db->query($sql);
    $sc_info = $query->row_array();
?>
<!-- Top Bar Start -->
<div class="topbar">
    <div class="topbar-left">
        <div class="logo">
            <h1 style="color:#FFF;"><?= $sc_info['school_title'];?></h1>
        </div>
        <button class="button-menu-mobile open-left">
        <i class="fa fa-bars"></i>
        </button>
    </div>
    <!-- Button mobile view to collapse sidebar menu -->
    <div class="navbar navbar-default" role="navigation">
        <div class="container">
            <div class="navbar-collapse2">               
                <ul class="nav navbar-nav navbar-right top-navbar">
                    <li class="dropdown topbar-profile">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"><span class="rounded-image topbar-profile-image"><img src="<?= base_url();?>template/images/users/user-35.jpg"></span><strong> <?= $_SESSION['user_name'] ?></strong><i class="fa fa-caret-down"></i></a> 
                        <ul class="dropdown-menu">                            
                            <li><a href="#">Change Password</a></li>
                            <li><a href="<?= base_url();?>login/logout"><i class="icon-logout-1"></i> Logout</a></li>
                        </ul>
                    </li>
                   
                </ul>
            </div>
            <!--/.nav-collapse -->
        </div>
    </div>
</div>