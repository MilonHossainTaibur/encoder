<?php

if(!defined('BASEPATH'))
    exit('No direct script access allowed');

class Exam_model extends CI_Model
{
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
	
	/****************** markes distribution system *******************/
	function mark_distribution_list($school_id)
	{
		$sql="SELECT
			tbl_mark_distribution.class_id,
			tbl_mark_distribution.group_id,
			tbl_mark_distribution.subject_id,
			tbl_class.class_name as `class_name`,
			tbl_group.group_name as `group_name`,
			tbl_subject.subject_name as `subject_name`,
			GROUP_CONCAT(if(`tbl_mark_distribution`.`exam_short_name`='CA',`tbl_mark_distribution`.`term_mark_per`,'') ) as ca,
			GROUP_CONCAT(if(`tbl_mark_distribution`.`exam_short_name`='CW',`tbl_mark_distribution`.`term_mark_per`,'') ) as cw,
			GROUP_CONCAT(if(`tbl_mark_distribution`.`exam_short_name`='HW',`tbl_mark_distribution`.`term_mark_per`,'') ) as hw,
			GROUP_CONCAT(if(`tbl_mark_distribution`.`exam_short_name`='CT',`tbl_mark_distribution`.`term_mark_per`,'') ) as ct,
			GROUP_CONCAT(if(`tbl_mark_distribution`.`exam_short_name`='AS/PJ',`tbl_mark_distribution`.`term_mark_per`,'') ) as aspj,
			GROUP_CONCAT(if(`tbl_mark_distribution`.`exam_short_name`='TE',`tbl_mark_distribution`.`term_mark_per`,'') ) as te
			FROM `tbl_mark_distribution`
			inner join tbl_class on tbl_mark_distribution.class_id=tbl_class.class_id
			inner join tbl_group on tbl_mark_distribution.group_id=tbl_group.group_id 
			inner join tbl_subject on tbl_mark_distribution.subject_id=tbl_subject.subject_id 
			where tbl_mark_distribution.school_id=$school_id GROUP BY tbl_mark_distribution.class_id,tbl_mark_distribution.group_id,tbl_mark_distribution.subject_id order by tbl_mark_distribution.class_id, tbl_mark_distribution.exam_type";
		$query = $this->db->query($sql);
      $row= $query->result_array();
	  return $row;
	}
	
	function get_marks_list_by_class_group($school_id,$class_id,$group_id)
    {           
        $sql = "SELECT GROUP_CONCAT(distinct(subject_id)) as sub FROM `tbl_mark_distribution` WHERE school_id=$school_id and class_id=$class_id and group_id=$group_id GROUP BY class_id limit 1";
        $query = $this->db->query($sql);
         $row= $query->row_array();
        return $row;
    }
	/****************** / markes distribution system *******************/
	
	
	/****************** set markes *******************/
	
	// student list for class attdence 
	public function get_class_wise_student_list_exam_ca($school_id,$class_id,$section_id,$group_id,$session_id,$shift_id,$term_id,$exam_year,$subject_id)
    {           
        $sql = "SELECT tbl_student.student_id, tbl_student.student_name, 
				GROUP_CONCAT(if(tbl_ca_marks.student_id= tbl_student.student_id && tbl_ca_marks.term_id=$term_id && tbl_ca_marks.exam_year='$exam_year' && tbl_ca_marks.subject_id=$subject_id,tbl_ca_marks.obtained_marks,'')) as obtained_marks,
				GROUP_CONCAT(if(tbl_ca_marks.student_id= tbl_student.student_id && tbl_ca_marks.term_id=$term_id && tbl_ca_marks.exam_year='$exam_year' && tbl_ca_marks.subject_id=$subject_id,tbl_ca_marks.ca_marks_id,'0')) as ca_marks_id FROM tbl_student
				inner join tbl_student_class on tbl_student.student_id = tbl_student_class.student_id
				left join tbl_ca_marks on tbl_student.student_id=tbl_ca_marks.student_id
				inner join tbl_class on tbl_student_class.class_id = tbl_class.class_id 
				inner join tbl_section on tbl_student_class.section_id = tbl_section.section_id 
				inner join tbl_shift on tbl_student_class.shift_id = tbl_shift.shift_id 
				inner join tbl_group on tbl_student_class.group_id = tbl_group.group_id 
				where tbl_student.school_id = $school_id 
				and tbl_student_class.class_id = $class_id
				and tbl_student_class.section_id = $section_id
				and tbl_student_class.group_id = $group_id
				and tbl_student_class.session_id = $session_id
				and tbl_student_class.shift_id = $shift_id
				GROUP BY tbl_student.student_id
				order by tbl_student_class.student_id asc";
				//return($sql);
				
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
	// student list for class work 
	public function get_class_wise_student_list_exam_cw($school_id,$class_id,$section_id,$group_id,$session_id,$shift_id,$term_id,$exam_year,$subject_id)
    {           
        $sql = "SELECT tbl_student.student_id, tbl_student.student_name, 
				GROUP_CONCAT(if(tbl_cw_marks.student_id= tbl_student.student_id && tbl_cw_marks.term_id=$term_id && tbl_cw_marks.exam_year='$exam_year' && tbl_cw_marks.subject_id=$subject_id,tbl_cw_marks.obtained_marks,'')) as obtained_marks,
				GROUP_CONCAT(if(tbl_cw_marks.student_id= tbl_student.student_id && tbl_cw_marks.term_id=$term_id && tbl_cw_marks.exam_year='$exam_year' && tbl_cw_marks.subject_id=$subject_id,tbl_cw_marks.cw_marks_id,'0')) as cw_marks_id FROM tbl_student
				inner join tbl_student_class on tbl_student.student_id = tbl_student_class.student_id
				left join tbl_cw_marks on tbl_student.student_id=tbl_cw_marks.student_id
				inner join tbl_class on tbl_student_class.class_id = tbl_class.class_id 
				inner join tbl_section on tbl_student_class.section_id = tbl_section.section_id 
				inner join tbl_shift on tbl_student_class.shift_id = tbl_shift.shift_id 
				inner join tbl_group on tbl_student_class.group_id = tbl_group.group_id 
				where tbl_student.school_id = $school_id 
				and tbl_student_class.class_id = $class_id
				and tbl_student_class.section_id = $section_id
				and tbl_student_class.group_id = $group_id
				and tbl_student_class.session_id = $session_id
				and tbl_student_class.shift_id = $shift_id
				GROUP BY tbl_student.student_id
				order by tbl_student_class.student_id asc";
				//return($sql);
				
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
	// student list for Home work 
	public function get_class_wise_student_list_exam_hw($school_id,$class_id,$section_id,$group_id,$session_id,$shift_id,$term_id,$exam_year,$subject_id)
    {           
        $sql = "SELECT tbl_student.student_id, tbl_student.student_name, 
				GROUP_CONCAT(if(tbl_hw_marks.student_id= tbl_student.student_id && tbl_hw_marks.term_id=$term_id && tbl_hw_marks.exam_year='$exam_year' && tbl_hw_marks.subject_id=$subject_id,tbl_hw_marks.obtained_marks,'')) as obtained_marks,
				GROUP_CONCAT(if(tbl_hw_marks.student_id= tbl_student.student_id && tbl_hw_marks.term_id=$term_id && tbl_hw_marks.exam_year='$exam_year' && tbl_hw_marks.subject_id=$subject_id,tbl_hw_marks.hw_marks_id,'0')) as hw_marks_id FROM tbl_student
				inner join tbl_student_class on tbl_student.student_id = tbl_student_class.student_id
				left join tbl_hw_marks on tbl_student.student_id=tbl_hw_marks.student_id
				inner join tbl_class on tbl_student_class.class_id = tbl_class.class_id 
				inner join tbl_section on tbl_student_class.section_id = tbl_section.section_id 
				inner join tbl_shift on tbl_student_class.shift_id = tbl_shift.shift_id 
				inner join tbl_group on tbl_student_class.group_id = tbl_group.group_id 
				where tbl_student.school_id = $school_id 
				and tbl_student_class.class_id = $class_id
				and tbl_student_class.section_id = $section_id
				and tbl_student_class.group_id = $group_id
				and tbl_student_class.session_id = $session_id
				and tbl_student_class.shift_id = $shift_id
				GROUP BY tbl_student.student_id
				order by tbl_student_class.student_id asc";
				//return($sql);
				
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
	// student list for Class Test
	public function get_class_wise_student_list_exam_ct($school_id,$class_id,$section_id,$group_id,$session_id,$shift_id,$term_id,$exam_year,$subject_id)
    {           
        $sql = "SELECT tbl_student.student_id, tbl_student.student_name, 
				GROUP_CONCAT(if(tbl_ct_marks.student_id= tbl_student.student_id && tbl_ct_marks.term_id=$term_id && tbl_ct_marks.exam_year='$exam_year' && tbl_ct_marks.subject_id=$subject_id,tbl_ct_marks.obtained_marks,'')) as obtained_marks,
				GROUP_CONCAT(if(tbl_ct_marks.student_id= tbl_student.student_id && tbl_ct_marks.term_id=$term_id && tbl_ct_marks.exam_year='$exam_year' && tbl_ct_marks.subject_id=$subject_id,tbl_ct_marks.ct_marks_id,'0')) as ct_marks_id FROM tbl_student
				inner join tbl_student_class on tbl_student.student_id = tbl_student_class.student_id
				left join tbl_ct_marks on tbl_student.student_id=tbl_ct_marks.student_id
				inner join tbl_class on tbl_student_class.class_id = tbl_class.class_id 
				inner join tbl_section on tbl_student_class.section_id = tbl_section.section_id 
				inner join tbl_shift on tbl_student_class.shift_id = tbl_shift.shift_id 
				inner join tbl_group on tbl_student_class.group_id = tbl_group.group_id 
				where tbl_student.school_id = $school_id 
				and tbl_student_class.class_id = $class_id
				and tbl_student_class.section_id = $section_id
				and tbl_student_class.group_id = $group_id
				and tbl_student_class.session_id = $session_id
				and tbl_student_class.shift_id = $shift_id
				GROUP BY tbl_student.student_id
				order by tbl_student_class.student_id asc";
				//return($sql);
				
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
	// assignment list
	function get_assignment_list($school_id){

       $sql = "SELECT * FROM `tbl_assignment` as A INNER JOIN tbl_class ON A.class_id = tbl_class.class_id INNER JOIN tbl_group ON tbl_group.group_id = A.group_id INNER JOIN tbl_section ON A.section_id= tbl_section.section_id INNER JOIN tbl_subject ON tbl_subject.subject_id = A.sub_id INNER JOIN tbl_term ON tbl_term.term_id = A.term_id WHERE A.school_id = $school_id ORDER BY A.id ASC";
	  $query = $this->db->query($sql);
        $row= $query->result_array();
		return $row;
    }
	
	// student list for Class Test
	public function get_class_wise_student_list_exam_pa($school_id,$class_id,$section_id,$group_id,$session_id,$shift_id,$term_id,$exam_year,$subject_id,$pa_id)
    {           
        $sql = "SELECT tbl_student.student_id, tbl_student.student_name, 
				GROUP_CONCAT(if(tbl_assignment_marks.student_id= tbl_student.student_id && tbl_assignment_marks.pa_id=$pa_id && tbl_assignment_marks.term_id=$term_id && tbl_assignment_marks.exam_year='$exam_year' && tbl_assignment_marks.subject_id=$subject_id,tbl_assignment_marks.obtained_marks,'')) as obtained_marks,
				GROUP_CONCAT(if(tbl_assignment_marks.student_id= tbl_student.student_id && tbl_assignment_marks.pa_id=$pa_id && tbl_assignment_marks.term_id=$term_id && tbl_assignment_marks.exam_year='$exam_year' && tbl_assignment_marks.subject_id=$subject_id,tbl_assignment_marks.pa_marks_id,'0')) as pa_marks_id FROM tbl_student
				inner join tbl_student_class on tbl_student.student_id = tbl_student_class.student_id
				left join tbl_assignment_marks on tbl_student.student_id=tbl_assignment_marks.student_id
				inner join tbl_class on tbl_student_class.class_id = tbl_class.class_id 
				inner join tbl_section on tbl_student_class.section_id = tbl_section.section_id 
				inner join tbl_shift on tbl_student_class.shift_id = tbl_shift.shift_id 
				inner join tbl_group on tbl_student_class.group_id = tbl_group.group_id 
				where tbl_student.school_id = $school_id 
				and tbl_student_class.class_id = $class_id
				and tbl_student_class.section_id = $section_id
				and tbl_student_class.group_id = $group_id
				and tbl_student_class.session_id = $session_id
				and tbl_student_class.shift_id = $shift_id
				GROUP BY tbl_student.student_id
				order by tbl_student_class.student_id asc";
				//return($sql);
				
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	//student list for term marks
	public function get_class_wise_student_list_exam_term($school_id, $class_id,$section_id,$group_id,$shift_id,$session_id,$term_id,$subject_id,$exam_year,$sub_con,$sub_code)
	{
		$where='';
		if($sub_con=='religion'){
			$where='and tbl_student.religion = "'.$sub_code.'"';
		}
		elseif($sub_con=='option_sub'){
			$where='and tbl_student_subject.subject_id="'.$subject_id.'" ';
		}
		$sql="SELECT tbl_student.student_id,tbl_student_class.roll_no,tbl_student.student_name,
				GROUP_CONCAT(DISTINCT if(tbl_term_marks.subject_id=$subject_id && tbl_term_marks.term_id=$term_id && tbl_term_marks.school_id=$school_id && tbl_term_marks.class_id=$class_id && tbl_term_marks.exam_year='$exam_year' && tbl_term_marks.session_id=$session_id,tbl_term_marks.subjective_marks,'')) as subjective_marks,
				GROUP_CONCAT(DISTINCT if(tbl_term_marks.subject_id=$subject_id && tbl_term_marks.term_id=$term_id && tbl_term_marks.school_id=$school_id && tbl_term_marks.class_id=$class_id && tbl_term_marks.exam_year='$exam_year' && tbl_term_marks.session_id=$session_id,tbl_term_marks.objective_marks,'')) as objective_marks,
				GROUP_CONCAT(DISTINCT if(tbl_term_marks.subject_id=$subject_id && tbl_term_marks.term_id=$term_id && tbl_term_marks.school_id=$school_id && tbl_term_marks.class_id=$class_id && tbl_term_marks.exam_year='$exam_year' && tbl_term_marks.session_id=$session_id,tbl_term_marks.practical_marks,'')) as practical_marks,
				GROUP_CONCAT(DISTINCT if(tbl_term_marks.subject_id=$subject_id && tbl_term_marks.term_id=$term_id && tbl_term_marks.school_id=$school_id && tbl_term_marks.class_id=$class_id && tbl_term_marks.exam_year='$exam_year' && tbl_term_marks.session_id=$session_id,tbl_term_marks.term_marks_id,'')) as term_marks_id
				FROM tbl_student 
				inner join tbl_student_class on tbl_student.student_id = tbl_student_class.student_id
                left join tbl_term_marks on tbl_student.student_id=tbl_term_marks.student_id
                left join tbl_student_subject on tbl_student.student_id=tbl_student_subject.student_id 
				where tbl_student.school_id = $school_id
				$where
				and tbl_student_class.class_id = $class_id
				and tbl_student_class.section_id = $section_id
				and tbl_student_class.group_id = $group_id
				and tbl_student_class.shift_id = $shift_id
				and tbl_student_class.session_id = $session_id
				group by tbl_student.student_id
				order by tbl_student_class.roll_no asc";

		$query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
	}
	
	public function get_class_wise_student_list_exam_term_group_student($school_id,$class_id,$group_id,$session_id,$subject_id)
	{
		$sql="SELECT distinct(student_id) FROM tbl_student_subject
			where tbl_student_subject.school_id = $school_id
			and tbl_student_subject.class_id = $class_id
			and tbl_student_subject.group_id = $group_id
			and tbl_student_subject.subject_id= $subject_id
			and tbl_student_subject.session_id = $session_id";
		
		$query = $this->db->query($sql);
        	$row= $query->result_array();
        	return $row;
	}
	
	function subject_wise_total_marks_class_wise($school_id,$sub_id,$class_id)
	{
		$sql = "SELECT A.subjective_marks,A.objective_marks,A.practical_marks,B.marks_type,B.subject_name FROM `tbl_subject_wise_total_marks` as A 
				left join tbl_subject as B on A.subject_id=B.subject_id
				WHERE A.school_id = '$school_id' and A.subject_id= '$sub_id' and A.class_id= '$class_id' limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
	}
	
	/****************** / set markes *******************/
	
	/****************** subject wise marks *******************/
	function get_subject_marks_list_by_class_group($school_id,$class_id,$group_id,$term_id)
    {           
        $sql = "SELECT GROUP_CONCAT(subject_id) as sub FROM `tbl_subject_wise_total_marks` WHERE school_id=$school_id and class_id=$class_id and group_id=$group_id and term_id=$term_id GROUP BY class_id limit 1";
        $query = $this->db->query($sql);
         $row= $query->row_array();
        return $row;
    }
	
	function get_sub_list_by_id_mark_dist($class_id, $school_id,$group_id,$sub)
    {  
        $sql = "SELECT * FROM `tbl_class_subject` as cs INNER JOIN `tbl_subject` as s ON cs.subject_id = s.subject_id WHERE cs.school_id=$school_id AND cs.class_id=$class_id AND cs.group_id=$group_id and cs.subject_id NOT IN ($sub) order by s.subject_id";
        $query = $this->db->query($sql);
        $res = $query->result_array();
        return $res;        
    }
	
	function subject_wise_total_marks_by_id($school_id,$subject_marks_id)
    {           
		$sql = "SELECT A.* ,B.subject_name,B.marks_type,B.subject_code  FROM `tbl_subject_wise_total_marks`as A
				left join tbl_subject as B on B.subject_id=A.subject_id
 				WHERE A.school_id = $school_id and A.subject_marks_id= $subject_marks_id limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
	
	function subject_wise_total_marks($school_id)
    {           
		$sql = "SELECT * FROM `tbl_subject_wise_total_marks` as A INNER JOIN tbl_class ON A.class_id = tbl_class.class_id INNER JOIN tbl_subject ON tbl_subject.subject_id = A.subject_id inner join tbl_group as g on A.group_id=g.group_id inner join tbl_term as t on A.term_id=t.term_id WHERE A.school_id = $school_id ORDER BY A.subject_marks_id ASC";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	/****************** / subject wise marks *******************/
	
	/****************** admit card *******************/
	function get_class_wise_student_list_admit($school_id, $class_id,$section_id,$group_id, $session_id, $exam_date)
    {           
       $sql = "SELECT tbl_student.student_id,tbl_student.student_name,tbl_students_fees.status FROM tbl_student 
				inner join tbl_student_class on tbl_student.student_id = tbl_student_class.student_id
                left join tbl_students_fees on tbl_student.student_id = tbl_students_fees.student_id
				where tbl_student.school_id = $school_id
				and tbl_student_class.class_id = $class_id
				and tbl_student_class.section_id = $section_id
				and tbl_student_class.group_id = $group_id
				and tbl_student_class.session_id = $session_id
                and tbl_students_fees.fees_date = '$exam_date'
                GROUP BY tbl_students_fees.student_id
				order by tbl_student.student_id asc";
       
		$query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
	function class_wise_student_list_for_admit($school_id, $class_id,$session_id,$section_id,$group_id)
    {            
       $sql = "SELECT tbl_student.student_id,tbl_student.student_name, tbl_student.student_image, tbl_student_class.roll_no FROM tbl_student 
				left join tbl_student_class on tbl_student.student_id = tbl_student_class.student_id
				where tbl_student.school_id = $school_id
				and tbl_student_class.class_id = $class_id
				and tbl_student_class.group_id = $group_id
				and tbl_student_class.section_id = $section_id
				and tbl_student_class.session_id = $session_id
				order by tbl_student_class.roll_no asc";
       
		$query = $this->db->query($sql);
        $row= $query->result_array();
       // print($row);
        return $row;
	}
	
	function get_class_wise_student_list_admit_print($school_id, $class_id,$session_id,$section_id,$group_id, $student_id)
    {           
        $sql = "SELECT tbl_student.student_name,tbl_student.father_name,tbl_student.mother_name,tbl_student.student_id, tbl_student.student_image, tbl_group.group_name, tbl_class.class_name, tbl_section.section_name,tbl_student_class.roll_no FROM tbl_student
				inner join tbl_student_class on tbl_student.student_id = tbl_student_class.student_id
				inner join tbl_class on tbl_student_class.class_id = tbl_class.class_id
				inner join tbl_section on tbl_student_class.section_id = tbl_section.section_id
				inner join tbl_group on tbl_student_class.group_id = tbl_group.group_id
				where tbl_student.school_id = $school_id 
				and tbl_student_class.class_id = $class_id
				and tbl_student_class.session_id = $session_id 
				and tbl_student_class.section_id = $section_id
				and tbl_student_class.group_id = $group_id
				and tbl_student_class.student_id IN $student_id
				order by tbl_student.student_id asc";
			
        $query = $this->db->query($sql);
        $row= $query->result_array();
                return $row;
    }

	function get_class_wise_exam_routine($school_id, $class_id,$section_id, $group_id, $term_id, $session_id)
    {
        $sql = "SELECT er.*, s.subject_name, et.exam_time as examtime,er.exam_time as e_time, er.exam_subject_id as subject_id
                FROM tbl_exam_routine er
                LEFT JOIN tbl_subject s on er.exam_subject_id = s.subject_id
                LEFT JOIN tbl_exam_time et on er.exam_time = et.id
                WHERE er.class_id = $class_id and er.section_id=$section_id and er.group_id=$group_id  and er.exam_term_id = $term_id and er.session_id = $session_id
				and exam_subject_id not in('6','7','8')
                ORDER BY er.exam_date asc ";

        $query  = $this->db->query($sql);
        $row    = $query->result_array();
        //print_r($row);
        return $row;
    }
	/****************** / admit card *******************/
}