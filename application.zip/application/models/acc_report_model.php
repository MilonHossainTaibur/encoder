<?php 
	if(!defined('BASEPATH'))
    exit('No direct script access allowed');

class Acc_report_model extends CI_Model
{
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }

    
    function get_fees_details($school_id,$month,$update_at)
    {
    	if($month)
    		$where="where `tm`.update_at LIKE '$month%'";
    	else
    		$where="where `tm`.update_at='$update_at' ";

        $sql = "SELECT * FROM tbl_fees_category WHERE school_id = $school_id ORDER BY fees_cat_id ASC";
        $query = $this->db->query($sql);
        $rows= $query->result_array();
        $partical_col='';
        foreach($rows as $row):
        	$partical_col.="sum(case when s.fees_particulars = '".$row['fees_particulars']."' then tm.amount end) `".$row['fees_particulars']."`,";
        endforeach;
        $partical_cols=rtrim($partical_col, ",");
        $sql2 = "select tm.update_at as Date,
  					tc.class_name,
					  $partical_cols
					FROM tbl_students_fees tm
					INNER JOIN tbl_class tc
					  ON tm.class_id = tc.class_id
					INNER JOIN tbl_fees_category s
					  on tm.fees_cat_id = s.fees_cat_id
					  $where
					group by tm.update_at, tc.class_name";
		$query2 = $this->db->query($sql2);
        $row2= $query2->result_array();
		return $row2;
    }
    
    
	
}
?>