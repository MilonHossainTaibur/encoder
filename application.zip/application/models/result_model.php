<?php

if(!defined('BASEPATH')) exit('No direct script access allowed');

class Result_model extends CI_Model
{
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }

    //Ssc, Jsc, Psc Result Sheet start//


    function get_mark_entry_json($school_id,$class_id,$group_id,$session_id){

		        $sql = "select ca.*, c.*, d.*, e.group_name, f.session_name from tbl_student_class as ca left join tbl_student as c on c.student_id=ca.student_id left join tbl_class as d on d.class_id=ca.class_id left join tbl_group as e on e.group_id=ca.group_id left join tbl_session as f on f.session_id=ca.session_id where ca.school_id = '$school_id'and ca.class_id = '$class_id' and ca.group_id = '$group_id' and ca.session_id = '$session_id'";
		        $query  = $this->db->query($sql);
		        $row    = $query->result_array();
		        return $row;

    }





    function get_mark_entry_report_json($class_id,$group_id,$session_id){

        $sql = "select ca.*, SUM(CASE WHEN gender = 'Male' and registration = '1' THEN 1 ELSE 0 END) as registration_Male_count,
                 SUM(CASE WHEN gender = 'Female' and registration = '1' THEN 1 ELSE 0 END) as registration_Female_count,
                 SUM(CASE WHEN gender = 'Male' and participate = '1' THEN 1 ELSE 0 END) as participate_Male_count,
                 SUM(CASE WHEN gender = 'Female' and participate = '1' THEN 1 ELSE 0 END) as participate_Female_count,
                 SUM(CASE WHEN gender = 'Male' THEN 1 ELSE 0 END) as Total_Male_count,
                 SUM(CASE WHEN gender = 'Female' THEN 1 ELSE 0 END) as Total_Female_count,
                 SUM(CASE WHEN gender = 'Male' and gpa = '5' THEN 1 ELSE 0 END) as gpa_five_male,
                 SUM(CASE WHEN gender = 'Male' and gpa between '4' and '4.99' THEN 1 ELSE 0 END) as gpa_four_male,
                 SUM(CASE WHEN gender = 'Male' and gpa between '3' and '3.99' THEN 1 ELSE 0 END) as gpa_three_male,
                 SUM(CASE WHEN gender = 'Male' and gpa between '2' and '2.99' THEN 1 ELSE 0 END) as gpa_two_male,
                 SUM(CASE WHEN gender = 'Male' and gpa = '1' THEN 1 ELSE 0 END) as gpa_one_male,
                 SUM(CASE WHEN gender = 'Male' and gpa = '0' THEN 1 ELSE 0 END) as gpa_ziro_male,
                 SUM(CASE WHEN gender = 'Female' and gpa = '5' THEN 1 ELSE 0 END) as gpa_five_female,
                 SUM(CASE WHEN gender = 'Female' and gpa between '4' and '4.99' THEN 1 ELSE 0 END) as gpa_four_female,
                 SUM(CASE WHEN gender = 'Female' and gpa between '3' and '3.99' THEN 1 ELSE 0 END) as gpa_three_female,
                 SUM(CASE WHEN gender = 'Female' and gpa between '2' and '2.99' THEN 1 ELSE 0 END) as gpa_two_female,
                 SUM(CASE WHEN gender = 'Female' and gpa = '1' THEN 1 ELSE 0 END) as gpa_one_female,
                 SUM(CASE WHEN gender = 'Female' and gpa = '0' THEN 1 ELSE 0 END) as gpa_ziro_female, c.class_name as classname, d.session_name as sessionname, e.group_name as groupname from tbl_jsc_ssc_result as ca left join tbl_class as c on c.class_id=ca.class_id left join tbl_session as d on d.session_id=ca.session_id left join tbl_group as e on e.group_id=ca.group_id where 
                  ca.class_id = '$class_id' 
                  and ca.group_id = '$group_id' 
                  and ca.session_id = '$session_id'";

        $query  = $this->db->query($sql);
        $row    = $query->result_array();
        return $row;

    }
	//Ssc, Jsc, Psc Result Sheet end//
	
	/* function use for tabulation sheet */
	function tab_mark_distribution_list_result($school_id,$class_id,$group_id,$term_id)
	{
		$sql="SELECT (select GROUP_CONCAT(tbl_mark_distribution.exam_type,'~',tbl_mark_distribution.exam_short_name,':',tbl_mark_distribution.term_mark_per) from tbl_mark_distribution WHERE tbl_mark_distribution.subject_id=tbl_class_subject.subject_id and tbl_mark_distribution.class_id=tbl_class_subject.class_id and tbl_mark_distribution.group_id=tbl_class_subject.group_id group by tbl_mark_distribution.subject_id) as mark_dist, `tbl_subject_wise_total_marks`.`subjective_marks`, `tbl_subject_wise_total_marks`.`objective_marks`, `tbl_subject_wise_total_marks`.`practical_marks`, `tbl_subject_wise_total_marks`.`pass_marks`,`tbl_subject`.`subject_id`,`tbl_subject`.`subject_name`,`tbl_subject`.`subject_code`,`tbl_subject`.`marks_type` FROM `tbl_mark_distribution`
join `tbl_subject` on `tbl_mark_distribution`.`subject_id`=`tbl_subject`.`subject_id`
INNER join tbl_class_subject on tbl_subject.subject_id=tbl_class_subject.subject_id
join `tbl_subject_wise_total_marks` on `tbl_mark_distribution`.`subject_id`=`tbl_subject_wise_total_marks`.`subject_id` AND `tbl_mark_distribution`.`class_id`=`tbl_subject_wise_total_marks`.`class_id` AND
`tbl_class_subject`.`group_id`=`tbl_subject_wise_total_marks`.`group_id`
			where tbl_mark_distribution.school_id=$school_id
			and tbl_class_subject.class_id=$class_id
			and tbl_class_subject.group_id=$group_id
			and tbl_subject_wise_total_marks.term_id=$term_id
			group by `tbl_mark_distribution`.`subject_id`
			order by tbl_subject.is_optional asc, tbl_subject.subject_code asc
			";
		$query = $this->db->query($sql);
      	$row= $query->result_array();
	  	return $row;
	}
	function get_student_list_tabu($school_id,$session_id,$class_id,$shift_id,$section_id,$group_id,$exam_year,$term_id)
	{
		$sql = "SELECT tbl_tabulation_marks.*,tbl_subject.marks_type,
				tbl_subject.subject_name,tbl_subject.subject_code,
				tbl_student.student_name,tbl_student_class.roll_no FROM `tbl_tabulation_marks`
			join tbl_subject on tbl_tabulation_marks.subject_id=tbl_subject.subject_id 
			join tbl_student on tbl_tabulation_marks.student_id=tbl_student.student_id
			join tbl_student_class on tbl_tabulation_marks.student_id=tbl_student_class.student_id
			where tbl_tabulation_marks.school_id=$school_id
			and tbl_tabulation_marks.class_id=$class_id
			and tbl_student_class.session_id=$session_id
			and tbl_student_class.shift_id=$shift_id
			and tbl_student_class.section_id=$section_id
			and tbl_student_class.group_id=$group_id
			and tbl_tabulation_marks.exam_year='$exam_year'
			and tbl_tabulation_marks.term_id=$term_id
			order by tbl_student_class.roll_no,tbl_subject.subject_code";
			
        $query = $this->db->query($sql);
      	$row= $query->result_array();
	  	return $row;
	}	
	
	function get_student_list_tabu_group($school_id,$session_id,$class_id,$shift_id,$section_id,$group_id,$exam_year,$term_id)
	{
		if($section_id){$where_and = "and tbl_student_class.section_id=$section_id";}else{$where_and = "";}
		$sql = "SELECT tbl_tabulation_marks.*,tbl_subject.marks_type,
				tbl_subject.subject_name,tbl_subject.subject_code,
				tbl_student.student_name,tbl_student.father_name,tbl_student.mother_name,tbl_student_class.roll_no,tbl_section.section_name FROM `tbl_tabulation_marks`
			join tbl_subject on tbl_tabulation_marks.subject_id=tbl_subject.subject_id 
			join tbl_student on tbl_tabulation_marks.student_id=tbl_student.student_id
			join tbl_student_class on tbl_tabulation_marks.student_id=tbl_student_class.student_id
			join tbl_section on tbl_tabulation_marks.section_id=tbl_section.section_id
			where tbl_tabulation_marks.school_id=$school_id
			and tbl_tabulation_marks.class_id=$class_id
			and tbl_student_class.session_id=$session_id
			and tbl_student_class.shift_id=$shift_id
			$where_and
			and tbl_student_class.group_id=$group_id
			and tbl_tabulation_marks.exam_year='$exam_year'
			and tbl_tabulation_marks.term_id in $term_id
			group by tbl_tabulation_marks.student_id
			order by tbl_student_class.roll_no";

        $query = $this->db->query($sql);
      	$row= $query->result_array();
	  	return $row;
	}

	function get_student_lists($school_id,$session_id,$class_id,$shift_id,$section_id,$group_id,$exam_year,$term_id)
	{
		if($section_id){$where_and = "and tbl_student_class.section_id=$section_id";}else{$where_and = "";}
		if($group_id){$where_and_group = "and tbl_student_class.group_id=$group_id";}else{$where_and_group = "";}
		$sql = "SELECT tbl_tabulation_marks.student_id, tbl_tabulation_marks.school_id, tbl_tabulation_marks.class_id, tbl_tabulation_marks.term_id FROM `tbl_tabulation_marks`
			join tbl_subject on tbl_tabulation_marks.subject_id=tbl_subject.subject_id
			join tbl_student on tbl_tabulation_marks.student_id=tbl_student.student_id
			join tbl_student_class on tbl_tabulation_marks.student_id=tbl_student_class.student_id
			join tbl_section on tbl_tabulation_marks.section_id=tbl_section.section_id
			where tbl_tabulation_marks.school_id=$school_id
			and tbl_tabulation_marks.class_id=$class_id
			and tbl_student_class.session_id=$session_id
			and tbl_student_class.shift_id=$shift_id
			$where_and
			$where_and_group
			and tbl_tabulation_marks.exam_year='$exam_year'
			and tbl_tabulation_marks.term_id=$term_id
			group by tbl_tabulation_marks.student_id
			order by tbl_student_class.roll_no";

		$query = $this->db->query($sql);
		$row= $query->result_array();
		return $row;
	}
	/* /function use for tabulation sheet */
	/* function use for subject wise tabulation sheet */
	function check_final_submit($school_id,$subject_id,$class_id,$group_id,$term_id,$exam_year,$section_id,$shift_id)
	{
		$sql = "SELECT *
			FROM `tbl_tabulation_marks`
			where tbl_tabulation_marks.school_id=$school_id
			and tbl_tabulation_marks.subject_id=$subject_id
			and tbl_tabulation_marks.class_id=$class_id
			and tbl_tabulation_marks.group_id=$group_id
			and tbl_tabulation_marks.term_id=$term_id
			and tbl_tabulation_marks.exam_year=$exam_year
			and tbl_tabulation_marks.section_id=$section_id
			and tbl_tabulation_marks.shift_id=$shift_id";
		$query 	= $this->db->query($sql);
      	$row	= $query->row_array();
	  	return $row;
	}
	
	function mark_distribution_list_result($school_id,$subject_id,$class_id,$group_id,$term_id)
	{
		$sql = "SELECT GROUP_CONCAT(`tbl_mark_distribution`.`exam_short_name`,':', `tbl_mark_distribution`.`term_mark_per`) as mark_dist,
			`tbl_subject_wise_total_marks`.`subjective_marks`, `tbl_subject_wise_total_marks`.`objective_marks`, `tbl_subject_wise_total_marks`.`practical_marks`, `tbl_subject_wise_total_marks`.`pass_marks`
			FROM `tbl_mark_distribution`
			join `tbl_subject_wise_total_marks` on `tbl_mark_distribution`.`subject_id`=`tbl_subject_wise_total_marks`.`subject_id` 
				AND `tbl_mark_distribution`.`class_id`=`tbl_subject_wise_total_marks`.`class_id` 
				AND `tbl_mark_distribution`.`group_id`=`tbl_subject_wise_total_marks`.`group_id`
			where tbl_mark_distribution.school_id=$school_id
			and tbl_mark_distribution.subject_id=$subject_id
			and tbl_mark_distribution.class_id=$class_id
			and tbl_mark_distribution.group_id=$group_id
			and tbl_subject_wise_total_marks.term_id=$term_id
			group by `tbl_mark_distribution`.`subject_id`";
		$query 	= $this->db->query($sql);
      	$row	= $query->row_array();
	  	return $row;
	}
	/* function use for subject wise tabulation sheet */
	function get_student_list_sub_tabu($school_id,$session_id,$class_id,$shift_id,$section_id,$group_id,$subject_id,$exam_year,$term_id)
	{
		$sql="SELECT `tbl_student`.`student_name`, `tbl_student_class`.`student_id`, `tbl_student_class`.`roll_no`, `tbl_ca_marks`.`obtained_marks` as `CA`, `tbl_cw_marks`.`obtained_marks` as `CW`, 
			`tbl_hw_marks`.`obtained_marks` as `HW`, `tbl_ct_marks`.`obtained_marks` as `CT`, `tbl_assignment_marks`.`obtained_marks` as `AS/PJ`, `tbl_term_marks`.`subjective_marks` as `sub`,
			`tbl_term_marks`.`objective_marks` as `obj`, `tbl_term_marks`.`practical_marks` as `prac` from `tbl_student_class`
			
			LEFT JOIN `tbl_student` on `tbl_student_class`.`school_id`=`tbl_student`.`school_id` AND `tbl_student_class`.`student_id`=`tbl_student`.`student_id` 

			LEFT JOIN `tbl_term_marks` on `tbl_student_class`.`school_id`=`tbl_term_marks`.`school_id` AND `tbl_student_class`.`class_id`=`tbl_term_marks`.`class_id` AND `tbl_student_class`.`session_id`=`tbl_term_marks`.`session_id` AND `tbl_student_class`.`student_id`=`tbl_term_marks`.`student_id` 
			
			LEFT JOIN `tbl_ca_marks` on `tbl_term_marks`.`school_id`=`tbl_ca_marks`.`school_id` AND `tbl_term_marks`.`class_id`=`tbl_ca_marks`.`class_id` AND `tbl_term_marks`.`session_id`=`tbl_ca_marks`.`session_id` AND `tbl_term_marks`.`student_id`=`tbl_ca_marks`.`student_id` AND `tbl_term_marks`.`subject_id`=`tbl_ca_marks`.`subject_id` 
			
			LEFT JOIN `tbl_cw_marks` on `tbl_term_marks`.`school_id`=`tbl_cw_marks`.`school_id` AND `tbl_term_marks`.`class_id`=`tbl_cw_marks`.`class_id` AND `tbl_term_marks`.`session_id`=`tbl_cw_marks`.`session_id` AND `tbl_term_marks`.`student_id`=`tbl_cw_marks`.`student_id` AND `tbl_term_marks`.`subject_id`=`tbl_cw_marks`.`subject_id` 
			
			LEFT JOIN `tbl_hw_marks` on `tbl_term_marks`.`school_id`=`tbl_hw_marks`.`school_id` AND `tbl_term_marks`.`class_id`=`tbl_hw_marks`.`class_id` AND `tbl_term_marks`.`session_id`=`tbl_hw_marks`.`session_id` AND `tbl_term_marks`.`student_id`=`tbl_hw_marks`.`student_id` AND `tbl_term_marks`.`subject_id`=`tbl_hw_marks`.`subject_id` 
			
			LEFT JOIN `tbl_ct_marks` on `tbl_term_marks`.`school_id`=`tbl_ct_marks`.`school_id` AND `tbl_term_marks`.`class_id`=`tbl_ct_marks`.`class_id` AND `tbl_term_marks`.`session_id`=`tbl_ct_marks`.`session_id` AND `tbl_term_marks`.`student_id`=`tbl_ct_marks`.`student_id`  AND `tbl_term_marks`.`subject_id`=`tbl_ct_marks`.`subject_id` 
			
			LEFT JOIN `tbl_assignment_marks` on `tbl_term_marks`.`school_id`=`tbl_assignment_marks`.`school_id` AND `tbl_term_marks`.`student_id`=`tbl_assignment_marks`.`student_id` AND `tbl_term_marks`.`class_id`=`tbl_assignment_marks`.`class_id` AND `tbl_term_marks`.`session_id`=`tbl_assignment_marks`.`session_id` AND `tbl_term_marks`.`student_id`=`tbl_assignment_marks`.`student_id` AND `tbl_term_marks`.`subject_id`=`tbl_assignment_marks`.`subject_id` 

			where `tbl_student_class`.`school_id`=$school_id
			AND `tbl_student_class`.`session_id`=$session_id
			AND `tbl_student_class`.`class_id`=$class_id
			AND `tbl_student_class`.`shift_id`=$shift_id
			AND `tbl_student_class`.`section_id`=$section_id
			AND `tbl_student_class`.`group_id`=$group_id
			
			AND `tbl_term_marks`.`subject_id`=$subject_id
			AND `tbl_term_marks`.`exam_year`='$exam_year'
			AND `tbl_term_marks`.`term_id`=$term_id
			order by `tbl_student_class`.`roll_no`";
		$query = $this->db->query($sql);
      	$row= $query->result_array();
	  	return $row;
	}
	/* function use for mark sheet */
	
	function selece_student_marksheet($data)
    {
        $this->db->select('`tbl_student`.student_name,`tbl_student_class`.student_id');
		$this->db->from('tbl_student_class');
		$this->db->join('tbl_student', 'tbl_student_class.student_id = tbl_student.student_id');
		$this->db->where($data);
        $query = $this->db->get();
        $result = $query->result_array();
        return $result;
    }

	function select_student_roll($school_id,$class_id,$shift_id,$section_id,$group_id,$exam_year)
	{
        $sql = "SELECT `tbl_student`.student_name,`tbl_student`.student_image,`tbl_student_class`.* FROM tbl_student_class
				inner join tbl_student on tbl_student_class.student_id = tbl_student.student_id
				where `tbl_student_class`.`school_id`=$school_id
                AND `tbl_student_class`.`session_id`=$exam_year
                AND `tbl_student_class`.`class_id`=$class_id
                AND `tbl_student_class`.`shift_id`=$shift_id
                AND `tbl_student_class`.`group_id`=$group_id
                AND `tbl_student_class`.`section_id`=$section_id
                order by `tbl_student_class`.`roll_no`";
        $query = $this->db->query($sql);
        return $query->result();
	}

    function mark_sheet_student_info($school_id,$session_id,$student_id,$class_id)
    {           
        $sql = "SELECT tbl_student.student_name, tbl_student.student_id, tbl_group.group_name, tbl_class.class_name, tbl_section.section_name, tbl_student_class.roll_no, tbl_shift.shift_name FROM tbl_student
				inner join tbl_student_class on tbl_student.student_id = tbl_student_class.student_id
				inner join tbl_class on tbl_student_class.class_id = tbl_class.class_id
				inner join tbl_section on tbl_student_class.section_id = tbl_section.section_id
				inner join tbl_group on tbl_student_class.group_id = tbl_group.group_id
				inner join tbl_shift on tbl_student_class.shift_id = tbl_shift.shift_id
				where tbl_student.school_id = $school_id
				and tbl_student_class.session_id = $session_id
				and tbl_student_class.class_id = $class_id
				and tbl_student_class.student_id = $student_id";
        $query = $this->db->query($sql);
        return $query->row_array();
    }
	function mark_sheet_student_info_with_optional($school_id,$session_id,$student_id,$class_id)
    {
        $sql = "SELECT tbl_student_subject.subject_id, tbl_student.student_name, tbl_student.student_id, tbl_group.group_name, tbl_class.class_name, tbl_section.section_name, tbl_student_class.roll_no, tbl_shift.shift_name FROM tbl_student
				inner join tbl_student_class on tbl_student.student_id = tbl_student_class.student_id
				inner join tbl_class on tbl_student_class.class_id = tbl_class.class_id
				inner join tbl_section on tbl_student_class.section_id = tbl_section.section_id
				inner join tbl_group on tbl_student_class.group_id = tbl_group.group_id
				inner join tbl_shift on tbl_student_class.shift_id = tbl_shift.shift_id
                left join tbl_student_subject on tbl_student_class.student_id=tbl_student_subject.student_id
				where tbl_student.school_id = $school_id
				and tbl_student_class.session_id = $session_id
				and tbl_student_class.class_id = $class_id
				and tbl_student_class.student_id = $student_id
				/*and tbl_student_subject.optional_id=1*/";
        $query = $this->db->query($sql);
        return $query->row_array();
        //return $sql;
    }
	/* for student att count SELECT sum(if(status=1,1,0)) as present,sum(if(status=0,1,0)) as absent FROM `tbl_student_attendance` where student_id=1000001 */
	function get_max_subject_number($school_id,$class_id,$term_id,$session)
    {           
        $sql = "SELECT subject_id, max(sub_total) as max_mark FROM `tbl_tabulation_marks` where school_id=$school_id and class_id=$class_id and exam_year='$session' and term_id=$term_id group by class_id , exam_year, term_id, subject_id";
        $query = $this->db->query($sql);
      	$row= $query->result_array();
	  	return $row;
    }
	function get_student_rank($school_id,$class_id,$section_id,$shift_id,$term_id,$session)
    {
        if($section_id){$where_and = "and tbl_student_class.section_id=$section_id";}else{$where_and = "";}
        $sql = "SELECT tbl_student_class.roll_no,tbl_tabulation_marks.student_id, sum(tbl_tabulation_marks.sub_total) as rank FROM `tbl_tabulation_marks`
				join tbl_student_class on tbl_tabulation_marks.student_id=tbl_student_class.student_id
				where tbl_student_class.school_id=$school_id
				and tbl_tabulation_marks.class_id=$class_id
				$where_and
				and tbl_tabulation_marks.shift_id=$shift_id
				and tbl_tabulation_marks.exam_year='$session'
				and tbl_tabulation_marks.term_id=$term_id
				GROUP by tbl_tabulation_marks.student_id ORDER BY rank DESC,tbl_student_class.roll_no ASC";
        $query = $this->db->query($sql);
      	$row= $query->result_array();
	  	return $row;
    }
    function get_student_marksheet_info($school_id,$class_id,$student_id,$term_id,$session)
    {           
        $sql = "SELECT tbl_tabulation_marks.*,tbl_subject.subject_name,tbl_subject.subject_code 
		FROM `tbl_tabulation_marks` 
		join tbl_subject on tbl_tabulation_marks.subject_id=tbl_subject.subject_id
		where tbl_tabulation_marks.school_id=$school_id 
		and tbl_tabulation_marks.class_id=$class_id 
		and tbl_tabulation_marks.exam_year='$session' 
		and tbl_tabulation_marks.term_id=$term_id 
		and tbl_tabulation_marks.student_id=$student_id 
		order by tbl_subject.is_optional asc, tbl_subject.subject_code asc";
        $query 	= $this->db->query($sql);
      	$row	= $query->result_array();
	  	return $row;
    }
	/****** result publish ****/
	function get_class_section_list($school_id)
    {           
        $this->db->select('tcs.class_id,tcs.section_id,tc.class_name,ts.section_name');
		$this->db->from('`tbl_class_section` as tcs');
		$this->db->join('tbl_class as tc', 'tcs.class_id=tc.class_id');
		$this->db->join('tbl_section as ts', 'tcs.section_id=ts.section_id');
		$this->db->where('tcs.school_id',$school_id);
		$this->db->order_by('tcs.class_id','ASC');
		$this->db->order_by('tcs.section_id','ASC');
        $query = $this->db->get();
        $result = $query->result_array();
        return $result;   
    }

	function get_class_section_Pub_list($c_data)
	{
		$this->db->select('class_id,section_id,status');
        $this->db->where($c_data);
		//$this->db->order_by($order_field, $order_condition);
        $query = $this->db->get('tbl_result_publish');
		if($query->num_rows() > 0)
			{
				foreach($query->result() as $row)
				{
					$data[$row->class_id.$row->section_id] = $row;
				}
				return $data;
			}
			else
			{
				return 0;
			}
    }
	/***** result publish ******/
	
	function get_bn_en_total($school_id,$student_id,$term_id,$exam_year,$subjectsin)
    {           
        $sql = "SELECT sum(f_mark) as full_mark, sum(sub_total) as total FROM `tbl_tabulation_marks` where school_id= $school_id and student_id=$student_id and term_id=$term_id and exam_year=$exam_year and subject_id in ('$subjectsin')";
        $query = $this->db->query($sql);
      	$row= $query->result_array();
	  	return $row;
    }
	
	function get_student_optional_subject_id($school_id,$class_id,$student_id)
    {           
        $sql = "SELECT subject_id FROM `tbl_student_subject`where school_id=$school_id and class_id=$class_id and student_id=$student_id and optional_id=1";
        $query = $this->db->query($sql);
      	$row= $query->result_array();
	  	return $row[0];
    }
	
	function get_student_rank_by_gpa($school_id,$class_id,$section_id,$shift_id,$term_id,$session)
    {
        if($section_id){$where_and = "and tbl_student_class.section_id=$section_id";}else{$where_and = "";}
        $sql = "SELECT tbl_student_class.roll_no, tbl_tabulation_marks.student_id, IFNULL(sum(case when tbl_tabulation_marks.gpa=0 then 0 END),1) as score, sum(case when tbl_tabulation_marks.gpa=0 then tbl_tabulation_marks.gpa else tbl_tabulation_marks.gpa END) AS score2, tbl_bn.*, tbl_en.*
		FROM `tbl_tabulation_marks`
		join tbl_student_class on tbl_tabulation_marks.student_id=tbl_student_class.student_id
		join (SELECT student_id, (case when sum(sub)>45 then 1 else 0 END) as bn_sub_pass_flag, (case when sum(obj)>19 then 1 else 0 END) as bn_obj_pass_flag FROM `tbl_tabulation_marks` where subject_id in (1,2) group by student_id) as tbl_bn on tbl_tabulation_marks.student_id=tbl_bn.student_id
		join (SELECT student_id, (case when sum(sub)>65 then 1 else 0 END) as en_sub_pass_flag FROM `tbl_tabulation_marks` where subject_id in (3,4) group by student_id) as tbl_en on tbl_tabulation_marks.student_id=tbl_en.student_id
		where tbl_tabulation_marks.class_id= $class_id 
		and tbl_tabulation_marks.term_id=$term_id 
		$where_and
		group by tbl_tabulation_marks.student_id 
		ORDER BY score DESC, bn_sub_pass_flag DESC, bn_obj_pass_flag DESC, en_sub_pass_flag DESC, score2 desc, roll_no ASC ";
        $query = $this->db->query($sql);
      	$row= $query->result_array();
	  	return $row;
    }

	function get_student_promote_class($school_id,$session_id,$class_id,$group_id)
	{
		//if($section_id){$where_and = "and tbl_student_class.section_id=$section_id";}else{$where_and = "";}
		$sql = "SELECT s.student_id, s.student_name, spc.shift_id, spc.group_id
		FROM `tbl_student` as s
		join `tbl_student_promote_class` as spc on s.student_id = spc.student_id
		WHERE spc.promote_class_id = $class_id
		AND spc.group_id = $group_id
		AND spc.session_id = $session_id
		ORDER BY spc.student_promote_class_id ASC ";
		$query = $this->db->query($sql);
		$row= $query->result_array();
		return $row;
	}
}