<?php

if(!defined('BASEPATH')) exit('No direct script access allowed');

class Admission_result_model extends CI_Model
{
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
	
	function get_admission_result($school_id)
    {           
        $this->db->select('tma.*');
		$this->db->from('`tbl_mock_admission` as tma');
		//$this->db->where('tcs.school_id',$school_id);
		$this->db->order_by('tma.get_mark','DESC');
		$this->db->order_by('tma.exam_roll','ASC');
        $query 	= $this->db->get();
        $result = $query->result_array();
        return $result;   
    }
	
	function get_admission_list($school_id)
    {           
        $this->db->select('tma.*');
		$this->db->from('`tbl_mock_admission` as tma');
		$this->db->order_by('tma.exam_roll ','ASC');
		$this->db->order_by('tma.admission_id','ASC');
        $query 	= $this->db->get();
        $result = $query->result_array();
        return $result;   
    }
}