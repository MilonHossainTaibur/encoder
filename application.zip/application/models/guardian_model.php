<?php

if(!defined('BASEPATH'))
    exit('No direct script access allowed');

class Guardian_model extends CI_Model
{
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
	
	function class_info($c_data)
    {           
        $this->db->select('tsc.class_id ,tsc.section_id , tc.class_name, tc.class_short_form');
		$this->db->from('tbl_student_class as tsc');
		$this->db->join('tbl_class as tc', 'tsc.class_id = tc.class_id');
		$this->db->where($c_data); 
		
        $query = $this->db->get();
        $result = $query->row_array();
        return $result;  
    }
}