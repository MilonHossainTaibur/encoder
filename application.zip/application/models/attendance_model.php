<?php 
	if(!defined('BASEPATH'))
    exit('No direct script access allowed');

class Attendance_model extends CI_Model
{
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    
	function get_class_list($school_id)
    {           
        $sql = "SELECT * FROM tbl_class where school_id = $school_id order by class_short_form asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
	function get_class_wise_student_list($data, $order_field, $order_type)
    {           
       /*$sql = "SELECT tbl_student.student_id,tbl_student.student_name,tbl_student_class.roll_no FROM tbl_student 
				inner join tbl_student_class on tbl_student.student_id = tbl_student_class.student_id
				where tbl_student.school_id = $school_id 
				and tbl_student_class.class_id = $class_id
				and tbl_student_class.section_id = $section_id 
				and tbl_student_class.session_id = $session_id 
				order by tbl_student_class.roll_no asc";*/
       
		$this->db->select('tbl_student.student_id,tbl_student.student_name,tbl_student.mobile_contact,tbl_student_class.roll_no');
		$this->db->from('tbl_student_class');
		$this->db->join('tbl_student', 'tbl_student_class.student_id = tbl_student.student_id');
		$this->db->where($data);
		$this->db->order_by($order_field,$order_type);
        $query = $this->db->get();
        $result = $query->result_array();
        return $result;  
    }
	
	function get_class_wise_att_student_list($school_id, $class_id, $section_id, $session_id,$shift_id)
    {           
       $sql = "SELECT tbl_student.student_id,tbl_student.student_name,tbl_student.mobile_contact,tbl_student_class.roll_no,tbl_student_attendance.status,tbl_student_attendance.sms_status,tbl_student_attendance.att_id FROM tbl_student 
				inner join tbl_student_class on tbl_student.student_id = tbl_student_class.student_id
				inner join tbl_student_attendance on tbl_student_class.student_id = tbl_student_attendance.student_id and tbl_student_class.session_id = tbl_student_attendance.session_id 
				where tbl_student.school_id = $school_id 
				and tbl_student_class.class_id = $class_id
				and tbl_student_class.session_id = $session_id
				and tbl_student_class.section_id = $section_id 
				and tbl_student_class.shift_id = $shift_id
				and tbl_student_attendance.att_date LIKE '".date('Y-m-d')."%'
				order by tbl_student_class.roll_no asc";
       
		$query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    function teacher_list($condition_id,$condition_id_value,$fields)
	{
		$this->db->select($fields);
		$this->db->from('tbl_teacher_registration');
		$this->db->join('tbl_designation', 'tbl_teacher_registration.designation_id = tbl_designation.designation_id');
		$this->db->where($condition_id, $condition_id_value);
        $query = $this->db->get();
        $result = $query->result_array();
        return $result; 
    
	}
	function get_class_wise_att_teacher_list($school_id)
    {           
       $sql = "SELECT tbl_teacher_registration.teacher_id,tbl_designation.designation_name,tbl_teacher_registration.teacher_name,tbl_teacher_attendance.status,tbl_teacher_attendance.absent_reason,tbl_teacher_attendance.att_id FROM tbl_teacher_registration 
				inner join tbl_teacher_attendance on tbl_teacher_registration.teacher_id = tbl_teacher_attendance.teacher_id
				left join tbl_designation on tbl_teacher_registration.designation_id = tbl_designation.designation_id
				where tbl_teacher_registration.school_id = $school_id 
				and tbl_teacher_attendance.att_date LIKE '".date('Y-m-d')."%'
				order by tbl_teacher_registration.teacher_id asc";
       
		$query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	/* report section */
	
	/* student attendance report */
    function get_class_wise_att_count_daily($school_id, $att_date)
    {           
        $sql = "SELECT `tbl_class`.`class_name`, `tbl_student_attendance`.`class_id`,`tbl_section`.`section_name`,
		SUM(if(`tbl_student_attendance`.`status` = 1, 1, 0)) AS present,
		SUM(if(`tbl_student_attendance`.`status` = 0, 1, 0)) AS absent FROM `tbl_student_attendance`
		join `tbl_class` on `tbl_class`.`class_id`=`tbl_student_attendance`.`class_id`
		join `tbl_section` on `tbl_section`.`section_id`=`tbl_student_attendance`.`section_id`
		where `tbl_student_attendance`.`school_id` = $school_id 
		and `tbl_student_attendance`.att_date LIKE '$att_date%'
		group by `tbl_student_attendance`.`class_id`,`tbl_student_attendance`.`section_id`";
				
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
	function get_class_wise_att_count_monthly($school_id,$class_id,$att_month)
    {           
        $sql = "SELECT `tbl_student`.`student_name`, `tbl_student_attendance`.`student_id`,
				SUM(if(`tbl_student_attendance`.`status` = 1, 1, 0)) AS present,
				SUM(if(`tbl_student_attendance`.`status` = 0, 1, 0)) AS absent FROM `tbl_student_attendance`
				join `tbl_student` on `tbl_student`.`student_id`=`tbl_student_attendance`.`student_id` 
				where `tbl_student_attendance`.`school_id` = $school_id
				and `tbl_student_attendance`.`class_id`=$class_id
				and `tbl_student_attendance`.att_date LIKE '$att_month%'
				group by `tbl_student_attendance`.`student_id` ORDER BY `tbl_student_attendance`.`student_id` ASC";
        
		$query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	function get_student_wise_att_count_monthly($school_id,$class_id,$att_month,$student_id)
	{
		 $sql = "SELECT `tbl_student_attendance`.`att_date`, `tbl_student_attendance`.`status`
				FROM `tbl_student_attendance` 
				where `tbl_student_attendance`.`school_id`=$school_id
				and `tbl_student_attendance`.`class_id`=$class_id
				and `tbl_student_attendance`.att_date LIKE '$att_month%'
				and `tbl_student_attendance`.`student_id`=$student_id
				ORDER BY `tbl_student_attendance`.`att_date` ASC";
		$query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
	}

	function get_monthwise_report_for_student($student_id)
	{
		$sql = "SELECT YEAR(att_date) AS Y, DATE_FORMAT(`att_date`,'%m') AS M, SUM(IF(status = '1',1,0)) AS present, SUM(IF(status = '0',1,0)) AS absent FROM tbl_student_attendance WHERE student_id = '$student_id' GROUP by Y,M";
		$query = $this->db->query($sql);
		$row = $query->result_array();
		return $row;
	}

	function get_monthly_att_details($year, $month, $student_id)
	{
		$sql = "SELECT att_date,status FROM `tbl_student_attendance` WHERE att_date LIKE '$year-$month%' AND student_id = '$student_id'";
		$query = $this->db->query($sql);
		$row = $query->result_array();
		return $row;

	}

	/* student report end */
	
	/* teacher report start */

	function get_teacher_day_att($school_id, $att_date)
    {           
        $sql = "SELECT `tbl_teacher_attendance`.`teacher_id`,`tbl_teacher_attendance`.`status`, `tbl_teacher_attendance`.`absent_reason`
				FROM `tbl_teacher_attendance`
				where `tbl_teacher_attendance`.`school_id` = $school_id 
				and `tbl_teacher_attendance`.att_date LIKE '$att_date%'
				order by `tbl_teacher_attendance`.`teacher_id`";
				
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
	function get_teacher_month_att($school_id,$att_month)
    {           
        $sql = "SELECT `tbl_teacher_attendance`.`teacher_id`,
				SUM(if(`tbl_teacher_attendance`.`status` = 1, 1, 0)) AS present,
				SUM(if(`tbl_teacher_attendance`.`status` = 0, 1, 0)) AS absent FROM `tbl_teacher_attendance`
				where `tbl_teacher_attendance`.`school_id` = $school_id
				and `tbl_teacher_attendance`.att_date LIKE '$att_month%'
				group by `tbl_teacher_attendance`.`teacher_id` ORDER BY `tbl_teacher_attendance`.`teacher_id` ASC";
        
		$query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
	function get_teacher_wise_att($school_id,$teacher_id,$att_month)
	{
		 $sql = "SELECT `tbl_teacher_attendance`.`att_date`, `tbl_teacher_attendance`.`status`, `tbl_teacher_attendance`.`absent_reason`
				FROM `tbl_teacher_attendance` 
				where `tbl_teacher_attendance`.`school_id`=$school_id
				and `tbl_teacher_attendance`.att_date LIKE '$att_month%'
				and `tbl_teacher_attendance`.`teacher_id`=$teacher_id
				ORDER BY `tbl_teacher_attendance`.`att_date` ASC";
		$query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
	}
}
?>