<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
/*
| -------------------------------------------------------------------------
| URI ROUTING
| -------------------------------------------------------------------------
| This file lets you re-map URI requests to specific controller functions.
|
| Typically there is a one-to-one relationship between a URL string
| and its corresponding controller class/method. The segments in a
| URL normally follow this pattern:
|
|	example.com/class/method/id/
|
| In some instances, however, you may want to remap this relationship
| so that a different class/function is called than the one
| corresponding to the URL.
|
| Please see the user guide for complete details:
|
|	http://codeigniter.com/user_guide/general/routing.html
|
| -------------------------------------------------------------------------
| RESERVED ROUTES
| -------------------------------------------------------------------------
|
| There area two reserved routes:
|
|	$route['default_controller'] = 'welcome';
|
| This route indicates which controller class should be loaded if the
| URI contains no data. In the above example, the "welcome" class
| would be loaded.
|
|	$route['404_override'] = 'errors/page_missing';
|
| This route will tell the Router what URI segments to use if those provided
| in the URL cannot be matched to a valid route.
|
*/

$route['default_controller'] = "home";
$route['get_userr_list'] = "welcome/get_userr_list";
$route['404_override'] = '';

/*
$default_controller = "welcome";
$controller_exceptions = array('admin','forums');
$route['default_controller'] = $default_controller;
$route["^((?!\b".implode('\b|\b', $controller_exceptions)."\b).*)$"] = $default_controller.'/$1';
$route['404_override'] = '';
*/
$route['add_employee_opt']      = "admin1/add_employee_opt";
$route['a_logout']              = "login/logout";
$route['about_college']         = "welcome/about_college";
$route['principal_message']     = "welcome/principal_message";
$route['department']            = "welcome/department";
$route['class_routine']         = "welcome/class_routine";
$route['class_routine_view']    = "welcome/class_routine_view";
$route['central_routine']       = "welcome/central_routine";
$route['exam_routine']          = "welcome/exam_routine";
$route['exam_routine_view']     = "welcome/exam_routine_view";
$route['student_details']       = "welcome/student_details";
$route['teacher']               = "welcome/teacher";
$route['general_notice']        = "welcome/general_notice";
$route['admission_notice']      = "welcome/admission_notice";
$route['single_notice']         = "welcome/single_notice";
$route['photo_gallery']         = "welcome/photo_gallery";
$route['contact']               = "welcome/contact";
$route['student']               = "welcome/student";
$route['result']                = "welcome/result";
$route['individual_result']     = "welcome/individual_result";
$route['important_information'] = "welcome/important_information";
$route['rules_regulations']     = "welcome/rules_regulations";
$route['steps']                 = "welcome/steps";
$route['facilities']            = "welcome/facilities";
$route['terms_tabulation_all']  = "result/tabulation_sheet_term_all";
$route['terms_tabulation']      = "result/tabulation_sheet_term";
$route['student_promote']       = "result/student_yearly_promote";
$route['student_final_promote'] = "result/student_yearly_final_promote";
$route['student_roll_assign']   = "result/student_roll_assign";
$route['student_change_section']= "result/student_change_section";
$route['student_change_group_final'] = "result/student_change_group_final";
$route['mock_admission']        = "exam/mock_admission";
$route['news_update']        = "web/news_update";

/* End of file routes.php */
/* Location: ./application/config/routes.php */
?>