(function($) {
    "use strict";
    jQuery(document).ready(function($) {

        // Declare Carousel jquery object
        var owl = $('.home-slider');
        // Carousel initialization
        owl.owlCarousel({
            items: 1,
            loop: true,
            dots: false,
            nav: true,
            autoHeight: true,
            lazyLoad: true,
            touchDrag: true,
            mouseDrag: true,
            animateIn: 'fadeIn',
            animateOut: 'fadeOut',
            autoplay: true,
            autoplayTimeout: 4000,
            navText: ["<i class='fa fa-angle-left'></i>",
                "<i class='fa fa-angle-right'></i>"
            ],
        });
        // add animate.css class(es) to the elements to be animated
        function animationSet(uniElement, aniInOut) {
            // Store all animationend event name in a string.
            // cf animate.css documentation
            var animationEnd = 'animationend';
            uniElement.each(function() {
                var $element = $(this);
                var $animationType = 'animated ' + $element.data('animation-' + aniInOut);
                $element.addClass($animationType).one(animationEnd, function() {
                    // remove animate.css Class at the end of the animations
                    $element.removeClass($animationType);
                });
            });
        }
        // Fired before current slide change
        owl.on('change.owl.carousel', function(event) {
            var $currentItem = $('.owl-item', owl).eq(event.item.index);
            var $elemsToanim = $currentItem.find("[data-animation-out]");
            animationSet($elemsToanim, 'out');
        });
        // Fired after current slide has been changed
        owl.on('changed.owl.carousel', function(event) {
            var $currentItem = $('.owl-item', owl).eq(event.item.index);
            var $elemsToanim = $currentItem.find("[data-animation-in]");
            animationSet($elemsToanim, 'in');
        })
        //Student Testimonial Slider //   
        $(".testimonial-slider").owlCarousel({
            margin: 10,
            loop: true,
            nav: true,
            dots: true,
            autoplay: false,
            autoplayTimeout: 1000,
            autoplayHoverPause: true,
            autoplaySpeed: 1500,
            animateIn: 'fadeIn',
            animateOut: 'fadeOut',
            navText: ["<i class='fa fa-angle-left'></i>",
                "<i class='fa fa-angle-right'></i>"
            ],
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 2
                },
                1000: {
                    items: 2
                }
            }

        });
        //Partner Slider
        $(".school-gallery").owlCarousel({
            margin: 10,
            loop: true,
            autoplay: true,
            autoplayTimeout: 1000,
            autoplayHoverPause: true,
            autoplaySpeed: 1500,
            navText: ["<i class='fa fa-angle-left'></i>",
                "<i class='fa fa-angle-right'></i>"
            ],
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 3
                },
                1000: {
                    items: 4
                }
            }

        });

        //NEWS SLIDER     
        $(".news-slider").owlCarousel({
            loop: true,
            margin: 10,
            autoplay: false,
            autoplayTimeout: 4000,
            responsive: {
                0: {
                    items: 1
                },
                600: {
                    items: 2
                },
                1000: {
                    items: 3
                }
            }

        });




        $('.collapse').on('shown.bs.collapse', function() {
            $(this).parent().find(".fa-plus").removeClass("fa-plus").addClass("fa-minus");
        }).on('hidden.bs.collapse', function() {
            $(this).parent().find(".fa-minus").removeClass("fa-minus").addClass("fa-plus");
        });

        //for internet explorer When Owl carousel Not Working
        var owl = $("#owl-wrap").data('owlCarousel');

        if ($('html').hasClass('no-backgroundsize')) {
            $(window).load(function() {
                window.setTimeout(function() {
                    owl.reinit();
                }, 250);
            });
        }




        /*
         **********************************************************
         * OPAQUE NAVBAR SCRIPT
         **********************************************************
         */

        // Toggle tranparent navbar when the user scrolls the page

        $(window).scroll(function() {
            if ($(this).scrollTop() > 50) /*height in pixels when the navbar becomes non opaque*/ {
                $('.uni-nav').addClass('navbar-bg');
            } else {
                $('.uni-nav').removeClass('navbar-bg');
            }
            /**Back to top***/
            //Check to see if the window is top if not then display button
            if ($(this).scrollTop() > 100) {
                $('.back-top').fadeIn();
            } else {
                $('.back-top').fadeOut();
            }
        });





        /**Mobile menu**/
        $('#mobile-menu').slicknav({
            'label': 'Educate',
            // The duration of the sliding animation.
            'duration': 500,
            // Easing used for open animations.
            'easingOpen': 'swing',
            // Easing used for close animations.
            'easingClose': 'swing',
            // open / close symbols
            'closedSymbol': '<i class="fa fa-plus" aria-hidden="true"></i>',
            'openedSymbol': '<i class="fa fa-minus" aria-hidden="true"></i>',
            // Element, jQuery object, or jQuery selector string to prepend the mobile menu to.
            'prependTo': 'body',
            // Element, jQuery object, or jQuery selector string to append the mobile menu to.
            'appendTo': '.menu-pos',

            // Element type for parent menu items.
            //'parentTag': 'a', 
            // Close menu when a link is clicked.
            //'closeOnClick': true,
            // Allow clickable links as parent elements.
            //'allowParentLinks': true,

            // If false, parent links will be separated from the sub-menu toggle.
            //'nestedParentLinks': true,

            // Show children of parent links by default.
            //'showChildren': false,

            // Remove IDs from all menu elements.
           // 'removeIds': true,

            // Remove classes from all menu elements.
            'removeClasses': true,

            // Remove styles from all menu elements.
            //'removeStyles': true,

            // Add branding to menu bar.
            //'brand': '<div class=""><a href="index.html"></div>',
            //'animations': 'jquery',

        });
    })

}(jQuery));